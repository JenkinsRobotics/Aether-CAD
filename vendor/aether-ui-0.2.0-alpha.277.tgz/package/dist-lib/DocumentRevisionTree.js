import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useMemo } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { historyBranchKey } from "./DocumentServices.js";
import { documentHistoryGraph } from "./document-history-graph.js";
import { visibleParents } from "./document-history-view.js";
import "./DocumentRevisionTree.css";
const commands = [
  { id: "save", label: "Save", icon: "save" },
  { id: "version", label: "Create version", icon: "tag" },
  { id: "branch", label: "Branch", icon: "branch-from" },
  { id: "restore", label: "Take over", icon: "restore" },
  { id: "release", label: "Release", icon: "tag" }
];
function DocumentRevisionTree({ history, branch, selection, drafts = {}, onBranchChange, onSelect, actions, busy = false }) {
  const graph = useMemo(() => documentHistoryGraph(history), [history]);
  const rows = useMemo(() => {
    const versions = new Set(history.versions.map((version) => version.revision));
    return [
      ...graph.filter((row) => row.kind !== "workspace" && !(row.kind === "start" && versions.has(row.revision))).reverse(),
      ...history.branches.flatMap((item) => graph.filter((row) => row.id === `workspace:${historyBranchKey(item)}`))
    ];
  }, [graph, history]);
  const lanes = [.../* @__PURE__ */ new Set([...history.branches.map(historyBranchKey), ...rows.map((row) => row.branchID ?? row.branch)])];
  const gutter = Math.max(100, lanes.length * 30 + 34), height = rows.length * 40 + 40;
  const x = (row) => 22 + lanes.indexOf(row.branchID ?? row.branch) * 30;
  const y = (index) => 20 + index * 40;
  const current = drafts[branch];
  return /* @__PURE__ */ jsxs("div", { className: "aui-revision-tree", "aria-label": "Revision tree", "aria-busy": busy, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-revision-tree-heading", children: [
      /* @__PURE__ */ jsx("div", { className: "aui-revision-tree-branches", role: "group", "aria-label": "Branches", children: history.branches.map((item) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-pressed": branch === historyBranchKey(item), disabled: busy, onClick: () => onBranchChange(historyBranchKey(item)), children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "branch", width: 13, height: 13 }),
        item.name
      ] }, historyBranchKey(item))) }),
      /* @__PURE__ */ jsxs("div", { className: "aui-revision-tree-draft", children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "pencil", width: 13, height: 13 }),
        /* @__PURE__ */ jsx("span", { children: "Draft" }),
        /* @__PURE__ */ jsxs("span", { className: "aui-revision-tree-muted", children: [
          current?.dirty ? "unsaved changes" : current?.changed ? "changed" : current ? "up to date" : "",
          current?.sinceVersion && /* @__PURE__ */ jsxs(Fragment, { children: [
            " since ",
            /* @__PURE__ */ jsx("code", { children: current.sinceVersion })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-revision-tree-actions", role: "group", "aria-label": "Revision actions", children: commands.map((command) => {
      const action = actions?.[command.id];
      return /* @__PURE__ */ jsxs(Button, { className: `aui-revision-tree-action aui-revision-tree-action--${command.id}`, primary: command.id === "version", disabled: busy || history.writable === false || !action || action.disabled, title: action?.reason, onClick: action?.onInvoke, children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: command.icon, width: 14, height: 14 }),
        command.label
      ] }, command.id);
    }) }),
    rows.length ? /* @__PURE__ */ jsx("div", { className: "aui-revision-tree-scroll", children: /* @__PURE__ */ jsxs("div", { className: "aui-revision-tree-graph", style: { "--revision-gutter": `${gutter}px`, minWidth: gutter + 310, height }, children: [
      /* @__PURE__ */ jsxs("svg", { className: "aui-revision-tree-lines", width: gutter, height, "aria-hidden": "true", children: [
        rows.flatMap((row, index) => visibleParents(row, graph, rows, true).map((id) => {
          const parentIndex = rows.findIndex((item) => item.id === id), parent = rows[parentIndex];
          if (!parent) return null;
          const middle = (y(index) + y(parentIndex)) / 2;
          return /* @__PURE__ */ jsx("path", { "data-from": row.id, "data-to": id, className: row.primaryParents.includes(id) ? "" : "is-merge", d: `M ${x(parent)} ${y(parentIndex)} C ${x(parent)} ${middle}, ${x(row)} ${middle}, ${x(row)} ${y(index)}` }, `${row.id}:${id}`);
        })),
        rows.map((row, index) => /* @__PURE__ */ jsxs("g", { className: row.kind === "workspace" && (row.branchID ?? row.branch) === branch ? "is-current" : "", children: [
          row.kind === "workspace" && /* @__PURE__ */ jsx("path", { className: "aui-revision-tree-continuation", d: `M ${x(row)} ${y(index)} V ${height}` }),
          /* @__PURE__ */ jsx("circle", { cx: x(row), cy: y(index), r: 6 }),
          row.kind !== "workspace" && /* @__PURE__ */ jsx("circle", { className: "aui-revision-tree-dot", cx: x(row), cy: y(index), r: 3 })
        ] }, row.id))
      ] }),
      /* @__PURE__ */ jsx("div", { role: "group", "aria-label": "History milestones", children: rows.map((row) => {
        const key = row.branchID ?? row.branch, draft = drafts[key];
        const here = row.kind === "workspace" && key === branch;
        return /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-revision-tree-row", "aria-pressed": selection === row.id, onClick: () => onSelect(row), children: [
          /* @__PURE__ */ jsx("code", { className: row.kind === "workspace" ? "is-branch" : "", children: row.name }),
          /* @__PURE__ */ jsx("span", { className: row.kind === "workspace" ? "aui-revision-tree-muted" : "aui-revision-tree-message", children: row.kind === "workspace" ? `draft \xB7 ${draft?.dirty ? "unsaved changes" : draft?.changed ? "changed" : draft ? "as its version" : "saved snapshot"}` : row.message || (row.kind === "start" ? "Document created" : "Version") }),
          row.status && row.status !== "version" && /* @__PURE__ */ jsx("span", { className: "aui-revision-tree-state", children: row.status }),
          here && /* @__PURE__ */ jsx("span", { className: "aui-revision-tree-here", children: "you are here" })
        ] }, row.id);
      }) })
    ] }) }) : /* @__PURE__ */ jsx("p", { className: "aui-revision-tree-muted", children: "No revision history yet." })
  ] });
}
export {
  DocumentRevisionTree
};
