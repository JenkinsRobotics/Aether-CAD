import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
function AdvisorWelcome({ hasContext = false }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-advisor-welcome", children: [
    /* @__PURE__ */ jsx("p", { children: "Ask questions and plan your next step in Aether." }),
    /* @__PURE__ */ jsx("strong", { children: "Working with" }),
    /* @__PURE__ */ jsxs("ul", { children: [
      hasContext && /* @__PURE__ */ jsxs("li", { children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "document" }),
        /* @__PURE__ */ jsx("span", { children: "Shared workspace context" })
      ] }),
      /* @__PURE__ */ jsxs("li", { children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "comment" }),
        /* @__PURE__ */ jsx("span", { children: "Your conversation" })
      ] }),
      /* @__PURE__ */ jsxs("li", { children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "advisor" }),
        /* @__PURE__ */ jsx("span", { children: "An AI provider, when connected" })
      ] })
    ] })
  ] });
}
function advisorQuestions(app) {
  switch (app) {
    case "cad":
      return ["How should I plan this part?", "Explain features and bodies.", "Help me review this design before creating a version."];
    case "map":
      return ["Help me plan a projection for this scene.", "How should I organize my surfaces?", "Help me write a creative brief for this projection."];
    case "animation":
      return ["Help me plan this character\u2019s motion.", "Explain joints and movement limits.", "What should I review before previewing an animation?"];
    case "sketch":
      return ["Help me plan this drawing.", "How should I organize my sketch?", "Help me review this drawing before creating a version."];
    default:
      return ["What can you help me with?", "Help me plan my next step.", "What should I review before sharing my work?"];
  }
}
export {
  AdvisorWelcome,
  advisorQuestions
};
