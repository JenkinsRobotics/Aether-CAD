import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ApplicationContextMenu } from "./ApplicationContextMenu.js";
import { useEffect, useRef, useState } from "react";
import { AppWordmark } from "./AppWordmark.js";
import { AppMark } from "./AppMark.js";
import { appWordmarkData } from "@aether/assets/branding/wordmarks/data";
import { AppIcon } from "./AppIcon.js";
import { AppLauncher } from "./AppLauncher.js";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
import { storedAppearance, setAetherAppearance } from "./StudioChrome.js";
import { SettingsWindow } from "./SettingsWindow.js";
import "./ApplicationChrome.css";
function ApplicationIdentity({ id, name, homeUrl = `/${id}/`, onHome, apps, launcher = true, showName = true, identityStyle = "wordmark" }) {
  const wordmark = identityStyle === "wordmark" && Object.hasOwn(appWordmarkData.apps, id);
  return /* @__PURE__ */ jsxs("div", { className: `aui-application-identity${wordmark ? " aui-application-identity--wordmark" : ""}`, children: [
    launcher && /* @__PURE__ */ jsx(AppLauncher, { apps: apps ?? [], currentID: id }),
    /* @__PURE__ */ jsx("a", { href: homeUrl, onClick: onHome, "aria-label": `${name} home`, title: `${name} home`, children: wordmark ? showName ? /* @__PURE__ */ jsx(AppWordmark, { app: id, size: 36, decorative: true }) : /* @__PURE__ */ jsx(AppMark, { app: id, size: 36 }) : /* @__PURE__ */ jsx(AppIcon, { app: id, size: 36 }) }),
    showName && !wordmark && /* @__PURE__ */ jsx("strong", { children: name })
  ] });
}
function ApplicationSettings({ name, appID, onSettings, enabled = true }) {
  const [open, setOpen] = useState(false);
  const handler = useRef(onSettings);
  handler.current = onSettings;
  useEffect(() => {
    if (!enabled) return;
    const show = (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      if (handler.current) handler.current();
      else setOpen(true);
    };
    document.addEventListener("aether-open-settings", show, true);
    return () => document.removeEventListener("aether-open-settings", show, true);
  }, [enabled]);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(ApplicationContextMenu, { name, enabled }),
    /* @__PURE__ */ jsx(
      SettingsWindow,
      {
        open,
        title: `${name} settings`,
        headerAppID: appID,
        sections: [],
        activePaneID: "",
        onSelectPane: () => void 0,
        onClose: () => setOpen(false),
        children: null
      }
    )
  ] });
}
function ApplicationAccountControls() {
  const [mode, setMode] = useState(storedAppearance);
  useEffect(() => {
    const sync = () => setMode(storedAppearance());
    document.addEventListener("aether-appearance", sync);
    window.addEventListener("storage", sync);
    return () => {
      document.removeEventListener("aether-appearance", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);
  return /* @__PURE__ */ jsxs("div", { className: "aui-application-account", children: [
    /* @__PURE__ */ jsx(MenuButton, { label: "Settings", className: "aui-icon-button", placement: "bottom-end", items: [
      { id: "settings", label: "Settings", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }) },
      ...["system", "light", "dark"].map((value, index) => ({ id: value, label: value === "system" ? "Follow system theme" : value === "light" ? "Light" : "Dark", kind: "radio", checked: mode === value, separatorBefore: index === 0, heading: index === 0 ? "Color mode" : void 0 }))
    ], onSelect: (id) => {
      if (id === "settings") document.dispatchEvent(new CustomEvent("aether-open-settings", { cancelable: true }));
      else setAetherAppearance(id);
    }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }) }),
    /* @__PURE__ */ jsx("div", { "data-aether-account": "" })
  ] });
}
export {
  ApplicationAccountControls,
  ApplicationIdentity,
  ApplicationSettings
};
