/** Suite-wide chrome controls, automatically included by every SettingsWindow. */
export declare function SharedChromeSettings(): import("react").JSX.Element;
