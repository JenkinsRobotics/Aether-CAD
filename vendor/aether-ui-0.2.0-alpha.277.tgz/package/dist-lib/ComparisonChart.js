import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { ChartLegend } from "./ChartLegend.js";
import "./ComparisonChart.css";
const amount = (value) => Number.isFinite(value) ? Math.max(0, value) : 0;
const compact = (value) => value >= 1e3 ? `${+(value / 1e3).toFixed(1)}k` : String(Math.round(value));
function ComparisonChart({ label, data, series, kind = "line", selectedID, onSelect, formatValue = compact }) {
  const [hidden, setHidden] = useState([]), [hovered, setHovered] = useState(null);
  const visible = series.filter((item) => !hidden.includes(item.id));
  if (!data.length || !series.length) return /* @__PURE__ */ jsx("p", { className: "aui-dashboard-empty", children: "No chart data." });
  const peak = Math.max(1, ...data.flatMap((point) => visible.map((item) => amount(point.values[item.id]))));
  const step = 10 ** Math.floor(Math.log10(peak / 4));
  const maximum = Math.ceil(peak / (step * 2)) * step * 2;
  const x = (index) => kind === "bar" ? 40 + (index + 0.5) * 544 / data.length : 40 + index * 544 / Math.max(1, data.length - 1);
  const y = (value) => 148 - amount(value) / maximum * 124;
  const active = data.findIndex((point) => point.id === (hovered ?? selectedID));
  const uniqueLabels = data.flatMap((point, index) => index === 0 || point.label !== data[index - 1].label ? [index] : []);
  const labelIndices = new Set(uniqueLabels.filter((_, index) => index % Math.max(1, Math.ceil(uniqueLabels.length / 11)) === 0));
  const activePoint = data[active];
  const inspect = (id) => {
    setHovered(id);
    onSelect?.(id);
  };
  return /* @__PURE__ */ jsxs("div", { className: "aui-comparison-chart", children: [
    /* @__PURE__ */ jsx(ChartLegend, { series, hidden, onToggle: (id) => setHidden((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]), label: `${label} series` }),
    !visible.length ? /* @__PURE__ */ jsx("p", { className: "aui-dashboard-empty", children: "Select a series to display." }) : /* @__PURE__ */ jsxs("svg", { viewBox: "0 0 600 178", role: "group", "aria-label": label, children: [
      [0, 1, 2, 3, 4].map((tick) => /* @__PURE__ */ jsxs("g", { className: "aui-comparison-axis", children: [
        /* @__PURE__ */ jsx("line", { x1: "38", x2: "586", y1: 148 - tick * 31, y2: 148 - tick * 31 }),
        /* @__PURE__ */ jsx("text", { x: "28", y: 151 - tick * 31, textAnchor: "end", children: formatValue(maximum * tick / 4) })
      ] }, tick)),
      visible.map((item, seriesIndex) => kind === "line" ? /* @__PURE__ */ jsx("polyline", { points: data.map((point, i) => `${x(i)},${y(point.values[item.id])}`).join(" "), fill: "none", stroke: item.color, strokeWidth: "2" }, item.id) : /* @__PURE__ */ jsx("g", { fill: item.color, children: data.map((point, i) => {
        const width = Math.min(5, 544 / data.length / (visible.length + 2));
        return /* @__PURE__ */ jsx("rect", { x: x(i) + (seriesIndex - (visible.length - 1) / 2) * (width + 3) - width / 2, y: y(point.values[item.id]), width, height: 148 - y(point.values[item.id]), rx: "1" }, point.id);
      }) }, item.id)),
      data.map((point, i) => /* @__PURE__ */ jsxs("g", { children: [
        labelIndices.has(i) && /* @__PURE__ */ jsx("text", { className: "aui-comparison-label", x: x(i), y: "170", textAnchor: "middle", children: point.label }),
        /* @__PURE__ */ jsx(
          "rect",
          {
            className: "aui-comparison-hit",
            x: Math.max(32, x(i) - 272 / data.length),
            y: "20",
            width: 544 / data.length,
            height: "130",
            role: "button",
            tabIndex: 0,
            "aria-label": `${point.label}: ${visible.map((item) => `${item.label} ${formatValue(amount(point.values[item.id]))}`).join(", ")}`,
            "aria-pressed": point.id === selectedID,
            onMouseEnter: () => setHovered(point.id),
            onMouseLeave: () => setHovered(null),
            onFocus: () => setHovered(point.id),
            onBlur: () => setHovered(null),
            onClick: () => inspect(point.id),
            onKeyDown: (event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                inspect(point.id);
              }
            }
          }
        )
      ] }, point.id)),
      activePoint && /* @__PURE__ */ jsxs("g", { className: "aui-comparison-inspection", "aria-hidden": "true", children: [
        /* @__PURE__ */ jsx("line", { x1: x(active), x2: x(active), y1: "24", y2: "148" }),
        /* @__PURE__ */ jsxs("g", { transform: `translate(${Math.min(398, Math.max(40, x(active) - 80))},2)`, children: [
          /* @__PURE__ */ jsx("rect", { width: "186", height: "18", rx: "4" }),
          /* @__PURE__ */ jsx("text", { x: "8", y: "12", children: visible.map((item) => `${item.label}: ${formatValue(amount(activePoint.values[item.id]))}`).join(" \xB7 ") })
        ] })
      ] })
    ] })
  ] });
}
export {
  ComparisonChart
};
