import { jsx, jsxs } from "react/jsx-runtime";
import "./CoordinateFields.css";
function CoordinateFields({ label, fields }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-coordinate-fields", role: "group", "aria-label": label, children: [
    /* @__PURE__ */ jsx("span", { className: "aui-coordinate-fields-label", children: label }),
    /* @__PURE__ */ jsx("div", { className: "aui-coordinate-fields-axes", children: fields.map((field) => /* @__PURE__ */ jsxs("label", { children: [
      /* @__PURE__ */ jsx("span", { children: field.axis }),
      field.control
    ] }, field.axis)) })
  ] });
}
function createCoordinateFields(label, fields) {
  const row = document.createElement("div"), caption = document.createElement("span"), axes = document.createElement("div");
  row.className = "aui-coordinate-fields";
  row.setAttribute("role", "group");
  row.setAttribute("aria-label", label);
  caption.className = "aui-coordinate-fields-label";
  caption.textContent = label;
  axes.className = "aui-coordinate-fields-axes";
  for (const { axis, control } of fields) {
    const field = document.createElement("label"), name = document.createElement("span");
    name.textContent = axis;
    if (!control.hasAttribute("aria-label")) control.setAttribute("aria-label", `${label} ${axis}`);
    field.append(name, control);
    axes.append(field);
  }
  row.append(caption, axes);
  return row;
}
export {
  CoordinateFields,
  createCoordinateFields
};
