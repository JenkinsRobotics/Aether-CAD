import { jsx, jsxs } from "react/jsx-runtime";
import "./ModelStudioComposition.css";
import { useEffect, useRef, useState } from "react";
function ModelPositionReadout({ position, unit = "cm" }) {
  const slot = useRef(null), content = useRef(null);
  const [fits, setFits] = useState(false);
  useEffect(() => {
    const available = slot.current, readout = content.current;
    if (!available || !readout || typeof ResizeObserver === "undefined") return;
    const measure = () => setFits(available.clientWidth > 0 && readout.scrollWidth <= available.clientWidth);
    const observer = new ResizeObserver(measure);
    observer.observe(available);
    observer.observe(readout);
    measure();
    return () => observer.disconnect();
  }, []);
  return /* @__PURE__ */ jsx("div", { className: "ps-position-slot", ref: slot, children: /* @__PURE__ */ jsxs("div", { className: "ps-selection-readout", ref: content, role: "group", "aria-label": "Selected part position", style: { visibility: fits ? "visible" : "hidden" }, children: [
    position.map((value, axis) => /* @__PURE__ */ jsxs("span", { children: [
      ["X", "Y", "Z"][axis],
      " ",
      /* @__PURE__ */ jsx("b", { children: value })
    ] }, axis)),
    /* @__PURE__ */ jsx("small", { children: unit })
  ] }) });
}
export {
  ModelPositionReadout
};
