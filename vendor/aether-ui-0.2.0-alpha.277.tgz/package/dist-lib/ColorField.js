import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
const validHex = (value) => /^#[0-9a-f]{6}$/i.test(value);
function ColorField({ value, defaultValue = "#2b9cf3", onChange, ariaLabel, disabled = false, invalidMessage = "Enter a six-digit hex color.", className }) {
  const initial = validHex(value ?? defaultValue) ? (value ?? defaultValue).toLowerCase() : "#2b9cf3";
  const [internal, setInternal] = useState(initial);
  const current = value ?? internal;
  const [draft, setDraft] = useState(current);
  const [invalid, setInvalid] = useState(false);
  useEffect(() => {
    setDraft(current);
    setInvalid(false);
  }, [current]);
  const commit = () => {
    if (!validHex(draft)) {
      setInvalid(true);
      return;
    }
    const next = draft.toLowerCase();
    setInvalid(false);
    setDraft(next);
    if (value === void 0) setInternal(next);
    onChange?.(next);
  };
  const choose = (next) => {
    setDraft(next);
    setInvalid(false);
    if (value === void 0) setInternal(next);
    onChange?.(next);
  };
  const key = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      commit();
    }
    if (event.key === "Escape") {
      event.preventDefault();
      setDraft(current);
      setInvalid(false);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: ["aui-color-field", className].filter(Boolean).join(" "), children: [
    /* @__PURE__ */ jsx("input", { className: "aui-color-field-picker", type: "color", "aria-label": `${ariaLabel} picker`, value: validHex(current) ? current : initial, disabled, onChange: (event) => choose(event.target.value) }),
    /* @__PURE__ */ jsx("input", { className: "aui-color-field-text", "aria-label": ariaLabel, value: draft, disabled, "aria-invalid": invalid || void 0, onChange: (event) => setDraft(event.target.value), onBlur: commit, onKeyDown: key }),
    invalid ? /* @__PURE__ */ jsx("span", { className: "aui-field-error", role: "alert", children: invalidMessage }) : null
  ] });
}
export {
  ColorField
};
