import { useLayoutEffect, useRef, useState } from "react";
import "./WorkspaceShellMotion.css";
import { useWorkspaceSpacing } from "./WorkspaceSpacing.js";
const WORKSPACE_PANEL_DURATION_MS = 240;
function useClosingPanels(state, enabled, preset, sides) {
  const previous = useRef(state);
  const previousPreset = useRef(preset);
  const [closing, setClosing] = useState({});
  const replaced = (id) => sides.find((side) => side.includes(id))?.some((peer) => peer !== id && state[peer] && state[peer].placement !== "hidden" && (!previous.current[peer] || previous.current[peer].placement === "hidden"));
  useLayoutEffect(() => {
    const reduced = typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches;
    const next = {};
    if (enabled && !reduced && previousPreset.current === preset) {
      for (const [id, entry] of Object.entries({ ...closing, ...previous.current })) {
        if (entry.placement !== "hidden" && (!state[id] || state[id].placement === "hidden") && !replaced(id)) next[id] = entry;
      }
    }
    previous.current = state;
    previousPreset.current = preset;
    setClosing(next);
    if (!Object.keys(next).length) return;
    const timer = setTimeout(() => setClosing({}), WORKSPACE_PANEL_DURATION_MS);
    return () => clearTimeout(timer);
  }, [state, enabled, preset]);
  const retained = { ...closing };
  if (enabled && previousPreset.current === preset && !(typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches)) {
    for (const [id, entry] of Object.entries(previous.current)) {
      if (entry.placement !== "hidden" && (!state[id] || state[id].placement === "hidden") && !replaced(id)) retained[id] = entry;
    }
  }
  return enabled ? retained : {};
}
function useWorkspaceInsets(areaRef, enabled, preset, revision) {
  const { margin, clearance } = useWorkspaceSpacing();
  const [insets, setInsets] = useState({ top: margin, left: margin, right: margin, bottom: margin });
  useLayoutEffect(() => {
    const area = areaRef.current;
    if (!area || !enabled) return;
    const ownedChrome = (selector) => Array.from(area.querySelectorAll(selector)).filter((node) => node.closest(".aui-shell-area") === area);
    const measure = () => {
      const box = area.querySelector(":scope > .aui-shell-main")?.getBoundingClientRect() ?? area.getBoundingClientRect();
      const next = { top: margin, left: margin, right: margin, bottom: margin };
      if (preset !== "docked") {
        const toolbar = ownedChrome(".aui-shell-fltoolbar")[0];
        if (toolbar) next.top = Math.max(margin, toolbar.getBoundingClientRect().bottom - box.top + clearance);
      }
      for (const side of ["left", "right"]) {
        const nodes = ownedChrome(`.aui-shell-fledge--${side}, .aui-shell[data-design="studio"] .aui-shell-fledge--${side} .aui-tabbed-sidebar-content, .aui-float-panel[data-shell-side="${side}"]`);
        for (const node of nodes) {
          const bounds = node.getBoundingClientRect();
          if (!bounds.width || !bounds.height) continue;
          next[side] = Math.max(next[side], side === "left" ? bounds.right - box.left + clearance : box.right - bounds.left + clearance);
        }
      }
      setInsets((old) => Object.keys(next).every((key) => old[key] === next[key]) ? old : next);
    };
    measure();
    const observer = typeof ResizeObserver !== "undefined" ? new ResizeObserver(measure) : null;
    observer?.observe(area);
    ownedChrome(".aui-shell-fltoolbar, .aui-shell-fledge, .aui-float-panel").forEach((node) => observer?.observe(node));
    area.addEventListener("animationend", measure);
    area.addEventListener("transitionend", measure);
    return () => {
      observer?.disconnect();
      area.removeEventListener("animationend", measure);
      area.removeEventListener("transitionend", measure);
    };
  }, [enabled, preset, margin, clearance, ...revision]);
  return Object.fromEntries(Object.entries(insets).map(([key, value]) => [`--aui-workspace-inset-${key}`, `${Math.max(0, value)}px`]));
}
export {
  WORKSPACE_PANEL_DURATION_MS,
  useClosingPanels,
  useWorkspaceInsets
};
