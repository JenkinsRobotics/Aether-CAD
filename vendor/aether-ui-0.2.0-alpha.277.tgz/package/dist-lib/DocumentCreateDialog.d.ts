import { type DocumentConnection } from "./DocumentServices.js";
/** One creation dialog, whether invoked from history or the command rail. */
export declare function DocumentCreateDialog({ connection, onClose, mode, sourceRevision, sourceName }: {
    connection?: DocumentConnection;
    onClose: () => void;
    mode?: "version" | "branch";
    sourceRevision?: number;
    sourceName?: string;
}): import("react").ReactPortal;
