import { type FlowDocument, type FlowSelection } from "./flow-diagram-model.js";
export interface FlowEditOptions {
    mergeKey?: string;
}
export type FlowDocumentChange = (next: FlowDocument, options?: FlowEditOptions) => void;
export declare function FlowDiagramInspector({ value, selection, onChange, onSelect, onDelete, onNotice }: {
    value: FlowDocument;
    selection: FlowSelection | null;
    onChange: FlowDocumentChange;
    onSelect: (selection: FlowSelection | null) => void;
    onDelete: () => void;
    onNotice: (message: string) => void;
}): import("react").JSX.Element;
