import type { CommandPaletteCommand } from "./CommandPalette.js";
export declare function normalize(value: string): string;
export declare function fuzzyScore(command: CommandPaletteCommand, query: string): number | null;
