import type { ReactNode } from "react";
import "./LinkCard.css";
/**
 * A card that opens something: icon, title, description and an action line
 * (Jonathan, 2026-10-13 — the concept-app card, made the standard). Used for
 * app showcases, demo directories and any "go to" tile. A link when given
 * `href`, otherwise a button.
 */
export declare function LinkCard({ icon, title, description, action, href, external, onSelect, className }: {
    icon?: ReactNode;
    title: string;
    description?: ReactNode;
    /** The call to action, e.g. "Open demo in new tab". */
    action?: string;
    href?: string;
    /** Opens in a new tab and marks the action with ↗. */
    external?: boolean;
    onSelect?: () => void;
    className?: string;
}): import("react").JSX.Element;
/** Responsive grid for LinkCards. */
export declare function LinkCardGrid({ children, ariaLabel }: {
    children: ReactNode;
    ariaLabel?: string;
}): import("react").JSX.Element;
