import { jsx, jsxs } from "react/jsx-runtime";
import { useRef } from "react";
import { AetherIcon } from "./AetherIcon.js";
const TICK_STEPS = [0.1, 0.25, 0.5, 1, 2, 5, 10, 30, 60];
function tickStep(durationS) {
  const target = durationS / 8;
  return TICK_STEPS.find((step) => step >= target) ?? 60;
}
function timecode(timeS, framesPerSecond) {
  const clamped = Math.max(timeS, 0);
  const minutes = Math.floor(clamped / 60);
  const seconds = Math.floor(clamped % 60);
  const frames = Math.floor((clamped - Math.floor(clamped)) * framesPerSecond + 1e-6);
  return [minutes, seconds, frames].map((value) => value.toString().padStart(2, "0")).join(":");
}
function TransportGlyph({ kind }) {
  if (kind === "play") return /* @__PURE__ */ jsx(AetherIcon, { name: "play" });
  if (kind === "stop") return /* @__PURE__ */ jsx("span", { className: "aui-timeline-stop-glyph" });
  if (kind === "pause") return /* @__PURE__ */ jsxs("span", { className: "aui-timeline-pause-glyph", children: [
    /* @__PURE__ */ jsx("i", {}),
    /* @__PURE__ */ jsx("i", {})
  ] });
  const previous = kind.startsWith("previous");
  const doubled = kind.endsWith("key");
  return /* @__PURE__ */ jsxs("span", { className: `aui-timeline-chevron-glyph${previous ? " aui-timeline-chevron-glyph--previous" : ""}`, children: [
    /* @__PURE__ */ jsx(AetherIcon, { name: "chevron" }),
    doubled ? /* @__PURE__ */ jsx(AetherIcon, { name: "chevron" }) : null
  ] });
}
function trackIcon(track) {
  if (track.kind === "audio") return /* @__PURE__ */ jsx(AetherIcon, { name: "animate" });
  if (track.kind === "event") return /* @__PURE__ */ jsx(AetherIcon, { name: "hardware" });
  return /* @__PURE__ */ jsx(AetherIcon, { name: "revolute" });
}
function graphPoints(track, duration, trackIndex) {
  if (track.keyframes.length === 0) return "";
  const values = track.keyframes.map((keyframe, index) => keyframe.value ?? Math.sin(index + trackIndex) * 0.7);
  const minimum = Math.min(...values, -1);
  const maximum = Math.max(...values, 1);
  const range = Math.max(maximum - minimum, 1e-6);
  return track.keyframes.map((keyframe, index) => {
    const x = keyframe.timeS / duration * 100;
    const y = 12 + (1 - (values[index] - minimum) / range) * 76;
    return `${x},${y}`;
  }).join(" ");
}
function Timeline(props) {
  const { tracks, durationS, timeS, onSeek } = props;
  const lanesRef = useRef(null);
  const scrubbing = useRef(false);
  if (tracks.length === 0) {
    return /* @__PURE__ */ jsx("div", { className: "aui-timeline", children: /* @__PURE__ */ jsx("div", { className: "aui-timeline-empty", children: props.emptyState ?? "no tracks" }) });
  }
  const duration = Math.max(durationS, 1e-6);
  const toPercent = (time) => `${time / duration * 100}%`;
  const seekFromEvent = (event) => {
    const lanes = lanesRef.current;
    if (!lanes) return;
    const rect = lanes.getBoundingClientRect();
    if (rect.width <= 0) return;
    const fraction = (event.clientX - rect.left) / rect.width;
    onSeek(Math.min(Math.max(fraction, 0), 1) * duration);
  };
  const onPointerDown = (event) => {
    scrubbing.current = true;
    event.currentTarget.setPointerCapture?.(event.pointerId);
    seekFromEvent(event);
  };
  const onPointerMove = (event) => {
    if (scrubbing.current) seekFromEvent(event);
  };
  const onPointerUp = () => {
    scrubbing.current = false;
  };
  const step = tickStep(duration);
  const ticks = [];
  for (let time = 0; time <= duration + 1e-9; time += step) ticks.push(time);
  if (props.variant === "editor") {
    const framesPerSecond = props.framesPerSecond ?? 30;
    const mode = props.mode ?? "dope-sheet";
    return /* @__PURE__ */ jsxs("div", { className: "aui-timeline aui-timeline--editor", "data-mode": mode, children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-timeline-editor-transport", children: [
        /* @__PURE__ */ jsxs("div", { className: "aui-timeline-editor-buttons", children: [
          /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Previous keyframe", disabled: !props.onSeekAdjacentKeyframe, onClick: () => props.onSeekAdjacentKeyframe?.(-1), children: /* @__PURE__ */ jsx(TransportGlyph, { kind: "previous-key" }) }),
          /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Previous frame", disabled: !props.onStepFrame, onClick: () => props.onStepFrame?.(-1), children: /* @__PURE__ */ jsx(TransportGlyph, { kind: "previous-frame" }) }),
          /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Stop", disabled: !props.onStop, onClick: props.onStop, children: /* @__PURE__ */ jsx(TransportGlyph, { kind: "stop" }) }),
          /* @__PURE__ */ jsx("button", { type: "button", "aria-label": props.playing ? "Pause" : "Play", disabled: !props.onTogglePlay, onClick: props.onTogglePlay, children: /* @__PURE__ */ jsx(TransportGlyph, { kind: props.playing ? "pause" : "play" }) }),
          /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Next frame", disabled: !props.onStepFrame, onClick: () => props.onStepFrame?.(1), children: /* @__PURE__ */ jsx(TransportGlyph, { kind: "next-frame" }) }),
          /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Next keyframe", disabled: !props.onSeekAdjacentKeyframe, onClick: () => props.onSeekAdjacentKeyframe?.(1), children: /* @__PURE__ */ jsx(TransportGlyph, { kind: "next-key" }) }),
          /* @__PURE__ */ jsx("span", { className: "aui-timeline-editor-divider" }),
          /* @__PURE__ */ jsx("button", { type: "button", className: props.looping ? "aui-timeline-loop--active" : void 0, "aria-label": "Loop preview", "aria-pressed": props.looping, disabled: !props.onToggleLoop, onClick: props.onToggleLoop, children: /* @__PURE__ */ jsx(AetherIcon, { name: "redo" }) }),
          /* @__PURE__ */ jsx("strong", { children: props.clipName ?? "Animation" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-timeline-editor-status", children: [
          /* @__PURE__ */ jsxs("label", { children: [
            /* @__PURE__ */ jsx("span", { className: "aui-visually-hidden", children: "Frame rate" }),
            /* @__PURE__ */ jsx("select", { "aria-label": "Frame rate", value: framesPerSecond, disabled: !props.onFramesPerSecondChange, onChange: (event) => props.onFramesPerSecondChange?.(Number(event.target.value)), children: [24, 25, 30, 60].map((value) => /* @__PURE__ */ jsxs("option", { value, children: [
              value,
              " fps"
            ] }, value)) })
          ] }),
          /* @__PURE__ */ jsxs("output", { "aria-label": "Timeline position", children: [
            timecode(timeS, framesPerSecond),
            " ",
            /* @__PURE__ */ jsxs("span", { children: [
              "/ ",
              timecode(duration, framesPerSecond)
            ] })
          ] }),
          /* @__PURE__ */ jsxs("span", { className: "aui-timeline-output-state", children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "hardware" }),
            props.outputStatus ?? "OUTPUT OFFLINE"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-timeline-editor-body", children: [
        /* @__PURE__ */ jsxs("div", { className: "aui-timeline-editor-side", children: [
          /* @__PURE__ */ jsxs("div", { className: "aui-timeline-editor-side-heading", children: [
            /* @__PURE__ */ jsx("strong", { children: mode === "curves" ? "VISIBLE CURVES" : "TRACKS" }),
            /* @__PURE__ */ jsxs("span", { children: [
              tracks.filter((track) => track.kind !== "audio" && track.kind !== "event").length,
              " motion"
            ] })
          ] }),
          tracks.map((track) => /* @__PURE__ */ jsxs("div", { className: "aui-timeline-editor-track-label", style: { "--aui-timeline-track-color": track.color }, children: [
            /* @__PURE__ */ jsx("span", { className: "aui-timeline-editor-track-icon", children: trackIcon(track) }),
            /* @__PURE__ */ jsxs("span", { children: [
              /* @__PURE__ */ jsx("strong", { children: track.label }),
              /* @__PURE__ */ jsx("small", { children: track.detail ?? (track.kind === "motion" ? "rad" : "") })
            ] })
          ] }, track.id))
        ] }),
        /* @__PURE__ */ jsxs(
          "div",
          {
            className: "aui-timeline-lanes aui-timeline-editor-lanes",
            ref: lanesRef,
            onPointerDown,
            onPointerMove,
            onPointerUp,
            children: [
              /* @__PURE__ */ jsx("div", { className: "aui-timeline-ruler", children: ticks.map((tick) => /* @__PURE__ */ jsx("span", { className: "aui-timeline-tick", style: { left: toPercent(tick) }, children: step >= 1 ? `${tick.toFixed(0)}s` : tick.toFixed(2) }, tick.toFixed(3))) }),
              /* @__PURE__ */ jsxs("div", { className: "aui-timeline-play-range", children: [
                /* @__PURE__ */ jsx("span", {}),
                /* @__PURE__ */ jsx("span", {})
              ] }),
              mode === "dope-sheet" ? tracks.map((track) => /* @__PURE__ */ jsxs("div", { className: "aui-timeline-row aui-timeline-editor-row", style: { "--aui-timeline-track-color": track.color }, children: [
                track.keyframes.length === 0 ? /* @__PURE__ */ jsx("span", { className: "aui-timeline-empty-lane", children: track.kind === "audio" ? "Import audio to display a waveform" : "No authored events" }) : null,
                track.keyframes.map((keyframe, index) => {
                  const isSelected = props.selected?.trackID === track.id && props.selected.index === index;
                  return /* @__PURE__ */ jsx(
                    "span",
                    {
                      role: "button",
                      "aria-label": `${track.label} keyframe at ${keyframe.timeS.toFixed(2)}s`,
                      className: isSelected ? "aui-timeline-key aui-timeline-key--selected" : "aui-timeline-key",
                      style: { left: toPercent(keyframe.timeS) },
                      onPointerDown: (event) => {
                        event.stopPropagation();
                        props.onSelectKeyframe?.(track.id, index);
                      }
                    },
                    index
                  );
                })
              ] }, track.id)) : /* @__PURE__ */ jsx("svg", { className: "aui-timeline-graph", viewBox: "0 0 100 100", preserveAspectRatio: "none", "aria-label": "Animation curves", children: tracks.filter((track) => track.keyframes.length > 0).map((track, index) => /* @__PURE__ */ jsx("polyline", { points: graphPoints(track, duration, index), style: { "--aui-timeline-track-color": track.color } }, track.id)) }),
              /* @__PURE__ */ jsx("div", { className: "aui-timeline-playhead", style: { left: toPercent(timeS) } })
            ]
          }
        )
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "aui-timeline", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-timeline-side", children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-timeline-transport", children: [
        props.onTogglePlay ? /* @__PURE__ */ jsx("button", { type: "button", className: "aui-icon-button", "aria-label": props.playing ? "Pause" : "Play", onClick: props.onTogglePlay, children: props.playing ? /* @__PURE__ */ jsx(TransportGlyph, { kind: "pause" }) : /* @__PURE__ */ jsx(AetherIcon, { name: "play" }) }) : null,
        /* @__PURE__ */ jsxs("span", { className: "aui-timeline-clock", children: [
          timeS.toFixed(2),
          "s"
        ] })
      ] }),
      tracks.map((track) => /* @__PURE__ */ jsx("div", { className: "aui-timeline-label", title: track.label, children: track.label }, track.id))
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-timeline-lanes", ref: lanesRef, onPointerDown, onPointerMove, onPointerUp, children: [
      /* @__PURE__ */ jsx("div", { className: "aui-timeline-ruler", children: ticks.map((tick) => /* @__PURE__ */ jsx("span", { className: "aui-timeline-tick", style: { left: toPercent(tick) }, children: step >= 1 ? tick.toFixed(0) : tick.toFixed(2) }, tick.toFixed(3))) }),
      tracks.map((track) => /* @__PURE__ */ jsx("div", { className: "aui-timeline-row", children: track.keyframes.map((keyframe, index) => {
        const isSelected = props.selected?.trackID === track.id && props.selected.index === index;
        return /* @__PURE__ */ jsx(
          "span",
          {
            role: "button",
            "aria-label": `${track.label} keyframe at ${keyframe.timeS.toFixed(2)}s`,
            className: isSelected ? "aui-timeline-key aui-timeline-key--selected" : "aui-timeline-key",
            style: { left: toPercent(keyframe.timeS) },
            onPointerDown: (event) => {
              event.stopPropagation();
              props.onSelectKeyframe?.(track.id, index);
            }
          },
          index
        );
      }) }, track.id)),
      /* @__PURE__ */ jsx("div", { className: "aui-timeline-playhead", style: { left: toPercent(timeS) } })
    ] })
  ] });
}
export {
  Timeline
};
