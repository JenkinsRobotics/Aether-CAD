import { jsx } from "react/jsx-runtime";
import { useState } from "react";
import "./WorkflowElements.css";
function Avatar({ name, src, size = "standard" }) {
  const [failedSource, setFailedSource] = useState();
  return /* @__PURE__ */ jsx("span", { className: "aui-avatar", "data-size": size, role: "img", "aria-label": name, children: src && src !== failedSource ? /* @__PURE__ */ jsx("img", { src, alt: "", onError: () => setFailedSource(src) }) : name.trim().split(/\s+/).slice(0, 2).map((word) => word[0]).join("").toUpperCase() || "?" });
}
export {
  Avatar
};
