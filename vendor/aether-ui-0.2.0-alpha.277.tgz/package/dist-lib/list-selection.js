function selectListItems(ids, selected, anchor, target, range, additive) {
  const start = anchor === null ? -1 : ids.indexOf(anchor), end = ids.indexOf(target);
  if (range && start >= 0 && end >= 0) {
    return /* @__PURE__ */ new Set([...additive ? selected : [], ...ids.slice(Math.min(start, end), Math.max(start, end) + 1)]);
  }
  if (additive) {
    const next = new Set(selected);
    if (next.has(target)) next.delete(target);
    else next.add(target);
    return next;
  }
  return /* @__PURE__ */ new Set([target]);
}
export {
  selectListItems
};
