import { type MouseEvent, type ReactNode } from "react";
import { type AetherIconName } from "./AetherIcon.js";
import { type AppWordmarkName } from "./AppWordmark.js";
import { type LaunchableApp } from "./AppLauncher.js";
import "./ApplicationSidebar.css";
export interface SidebarItem {
    id: string;
    label: string;
    /** A shared glyph name, or a custom tile (e.g. a workspace initial). */
    icon: AetherIconName | ReactNode;
    /** Count or short status shown at the row's end; hidden in the rail. */
    badge?: number | string;
    current?: boolean;
    disabled?: boolean;
    href?: string;
    onSelect?: () => void;
    onContextMenu?: (event: MouseEvent<HTMLElement>) => void;
}
export interface SidebarSection {
    id: string;
    /** Group title; the collapsed rail replaces captions with dividers. */
    title?: string;
    items: readonly SidebarItem[];
}
export declare function SidebarRow({ item }: {
    item: SidebarItem;
}): import("react").JSX.Element;
/** Sections of navigation rows. Rendered by ApplicationSidebar; exported for app-owned layouts. */
export declare function SidebarNavigation({ sections, ariaLabel, captions, collapsible, storageKeyPrefix }: {
    sections: readonly SidebarSection[];
    ariaLabel: string;
    captions?: boolean;
    collapsible?: boolean;
    storageKeyPrefix?: string;
}): import("react").JSX.Element;
/**
 * The standard Aether sidebar. Products provide sections and commands; the host
 * owns identity (the account mount in the footer). Collapses to an icon rail.
 */
export declare function ApplicationSidebar({ id, name, app, icon, homeUrl, brand, action, sections, settings, apps, currentApp, children, footerTools, footer, className, userLabel, toggleInContent, selection, defaultCollapsed, variant }: {
    /** Captioned is the reference standard: compact collapsible sections and brand-to-rail toggle. Studio retains its larger workspace treatment. */
    variant?: "standard" | "captioned" | "studio";
    /** "solid": accent-filled current row; "tint": a soft accent wash with accent text. */
    selection?: "solid" | "tint";
    defaultCollapsed?: boolean;
    /** Stable storage key; independent of the currently selected workspace. */
    id: string;
    toggleInContent?: boolean;
    userLabel?: ReactNode;
    name: string;
    /** Registered app identity. Canonical Aether names are also recognized automatically. */
    app?: AppWordmarkName;
    /** Fallback artwork for custom applications. Registered apps use wordmark/A artwork. */
    icon?: ReactNode;
    /** Brand home link for standard navigation; captioned navigation uses its brand to collapse. */
    homeUrl?: string;
    /** false when a page header already shows the product identity. */
    brand?: boolean;
    /** Primary command above the navigation, e.g. "Create or upload". */
    action?: ReactNode;
    sections?: readonly SidebarSection[];
    /** Adds the pinned Settings row; without `onSelect` it opens the app's shared settings window. */
    settings?: Partial<SidebarItem> | true;
    /** Adds the suite app launcher below Settings. */
    apps?: readonly LaunchableApp[];
    /** The app this sidebar belongs to, marked current in the launcher. */
    currentApp?: string;
    children?: ReactNode;
    footerTools?: ReactNode;
    /** Optional app document/status footer; omitting this retains tools, settings and account. */
    footer?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
export declare function SidebarGroup({ title, children, storageKey, caption }: {
    title: string;
    children: ReactNode;
    storageKey?: string;
    caption?: boolean;
}): import("react").JSX.Element;
export declare function WorkspaceIcon({ name }: {
    name: string;
}): import("react").JSX.Element;
