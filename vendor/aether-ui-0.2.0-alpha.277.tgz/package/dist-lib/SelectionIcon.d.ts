/** Selection artwork composes the shared pointer with a region outline. */
export declare function SelectionIcon({ mode }: {
    mode?: "window" | "crossing" | "directional";
}): import("react").JSX.Element;
