import { jsx, jsxs } from "react/jsx-runtime";
import { useContext, useMemo, useState } from "react";
import { CollectionView, CollectionActions, CollectionHost } from "./CollectionView.js";
import { treePanelContextItems } from "./tree-panel-context.js";
import { CollectionFilter } from "./CollectionFilter.js";
import { Menu } from "./Menu.js";
import { AetherIcon } from "./AetherIcon.js";
import { Tree } from "./Tree.js";
import "./TreePanel.css";
function TreeToolbar({ label, controls }) {
  return /* @__PURE__ */ jsx(CollectionActions, { label, controls });
}
const ROW_MENU = "aui:row-menu";
function stateRows(nodes, hasMenu) {
  return nodes.map((node) => ({
    ...node,
    // State controls and the shared row menu are the only row buttons.
    actions: [
      ...node.actions?.filter((action) => action.pinned || action.state) ?? [],
      ...node.variant !== "divider" && hasMenu(node.id) ? [{ id: ROW_MENU, label: `Options for ${node.label}`, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) }] : []
    ],
    children: node.children && stateRows(node.children, hasMenu)
  }));
}
function TreePanel({
  id,
  controls = [],
  controlsLabel = "Tree controls",
  menuItems,
  onCommand,
  filterResultCount,
  menuLabel = "Item options",
  secondary,
  className,
  nodes,
  onContextMenu,
  onSelect,
  selectedIDs,
  title,
  headerActions,
  headerControls,
  showFilter = true,
  showFooter = true,
  actionPlacement,
  filterOptions,
  onCategoryChange,
  onFilterChange,
  filterInputRef,
  filterInputID,
  filterLabel,
  filter,
  backgroundItems = [],
  onBackgroundCommand,
  ...tree
}) {
  const [query, setQuery] = useState(""), [category, setCategory] = useState("all");
  const effectiveQuery = onFilterChange ? filter ?? "" : query;
  const [menu, setMenu] = useState(null);
  const host = useContext(CollectionHost);
  const itemsFor = (id2) => {
    if (menuItems) return menuItems(id2);
    const find = (rows) => {
      for (const row of rows) {
        if (row.id === id2) return row;
        const child = row.children && find(row.children);
        if (child) return child;
      }
    };
    return [
      ...find(nodes)?.actions?.map((action) => ({ id: action.id, label: action.label, icon: action.icon })) ?? [],
      ...controls.filter((control) => control.scope === "row" || control.shortcut).map((control) => ({ ...control, id: `control:${control.id}`, disabled: control.disabled || !selectedIDs.has(id2) }))
    ];
  };
  const presentation = useMemo(() => stateRows(filterTreeCategory(nodes, category), (id2) => itemsFor(id2).length > 0), [nodes, category, menuItems, controls, selectedIDs]);
  const runRow = (id2, command) => {
    if (!menuItems && command.startsWith("control:")) {
      controls.find((control) => control.id === command.slice(8) && !control.disabled)?.onClick();
    } else (onCommand ?? tree.onAction)?.(id2, command);
  };
  const expanded = category === "all" ? tree.expandedIDs : new Set(allBranchIDs(presentation));
  const branches = allBranchIDs(presentation);
  const panelControls = [...headerControls ?? [], ...controls, ...host.controls ?? []].filter((control) => control.scope !== "row" && !control.shortcut);
  const background = treePanelContextItems(panelControls, {
    extra: backgroundItems,
    filterOptions,
    category,
    query: effectiveQuery,
    expand: Boolean(category === "all" && tree.expandedIDs && tree.onToggle && branches.some((id2) => !expanded?.has(id2))),
    collapse: Boolean(category === "all" && tree.expandedIDs && tree.onToggle && branches.some((id2) => expanded?.has(id2)))
  });
  const runBackground = (id2) => {
    if (id2.startsWith("control:")) panelControls.find((control) => control.id === id2.slice(8) && !control.disabled)?.onClick();
    else if (id2.startsWith("filter:")) {
      const value = id2.slice(7);
      setCategory(value);
      onCategoryChange?.(value);
    } else if (id2 === "tree:clear-filter") (onFilterChange ?? setQuery)("");
    else if (id2 === "tree:expand" || id2 === "tree:collapse") {
      branches.filter((branch) => Boolean(expanded?.has(branch)) === (id2 === "tree:collapse")).forEach((branch) => tree.onToggle?.(branch, id2 === "tree:expand"));
    } else onBackgroundCommand?.(id2);
  };
  return /* @__PURE__ */ jsxs(
    CollectionView,
    {
      id,
      title: title ?? tree.ariaLabel,
      headerActions,
      controls,
      primaryControls: headerControls,
      controlsLabel,
      className: ["aui-tree-panel", className].filter(Boolean).join(" "),
      menuItems: background,
      onCommand: runBackground,
      showFooter,
      actionPlacement,
      onContextMenu: (event) => {
        if (event.target.closest('input, textarea, [contenteditable], [role="menu"], [role="treeitem"]')) return;
        event.preventDefault();
        event.stopPropagation();
        if (background.length) setMenu({ id: null, x: event.clientX, y: event.clientY });
      },
      filter: showFilter && /* @__PURE__ */ jsx(
        CollectionFilter,
        {
          query: effectiveQuery,
          onQueryChange: onFilterChange ?? setQuery,
          options: filterOptions,
          resultCount: filterResultCount,
          value: category,
          onChange: (value) => {
            setCategory(value);
            onCategoryChange?.(value);
          },
          ariaLabel: filterLabel ?? `Search ${tree.ariaLabel ?? "Items"}`,
          inputRef: filterInputRef,
          inputID: filterInputID
        }
      ),
      onKeyDown: (event) => {
        if (event.defaultPrevented) return;
        if (!(event.target instanceof HTMLElement) || !event.target.matches('[role="treeitem"][aria-selected="true"]')) return;
        const key = event.key === "Backspace" ? "Delete" : event.key;
        if (event.metaKey || event.ctrlKey || event.altKey || !["Delete", "F2"].includes(key)) return;
        const id2 = event.target.dataset.treeId;
        const item = id2 && itemsFor(id2).find((entry) => entry.shortcut === key && !entry.disabled);
        if (item && id2) {
          event.preventDefault();
          event.stopPropagation();
          runRow(id2, item.id);
        } else if (!menuItems) {
          const control = controls.find((entry) => entry.shortcut === key && !entry.disabled);
          if (control) {
            event.preventDefault();
            event.stopPropagation();
            control.onClick();
          }
        }
      },
      children: [
        /* @__PURE__ */ jsx("div", { className: "aui-tree-panel-content", children: /* @__PURE__ */ jsx(
          Tree,
          {
            ...tree,
            rootInset: tree.rootInset ?? 7,
            rowHeight: tree.rowHeight ?? 24,
            expandedIDs: expanded,
            filter: effectiveQuery || filter,
            nodes: presentation,
            selectedIDs,
            onSelect,
            onAction: (id2, action, anchor) => {
              if (action !== ROW_MENU) {
                tree.onAction?.(id2, action);
                return;
              }
              if (!selectedIDs.has(id2)) onSelect([id2], "single");
              const box = anchor?.getBoundingClientRect();
              if (box && itemsFor(id2).length) setMenu({ id: id2, x: box.left, y: box.bottom });
            },
            onContextMenu: (id2, x, y) => {
              if (!selectedIDs.has(id2)) onSelect([id2], "single");
              if (itemsFor(id2).length) setMenu({ id: id2, x, y });
              onContextMenu?.(id2, x, y);
            }
          }
        ) }),
        secondary && /* @__PURE__ */ jsx("div", { className: "aui-tree-panel-secondary", children: secondary }),
        menu && /* @__PURE__ */ jsx(
          Menu,
          {
            className: "aui-collection-popup",
            open: true,
            anchor: { x: menu.x, y: menu.y },
            ariaLabel: menu.id === null ? `${title ?? tree.ariaLabel ?? "Tree"} actions` : menuLabel,
            items: menu.id === null ? background : itemsFor(menu.id),
            onClose: () => setMenu(null),
            onSelect: (id2) => {
              if (menu.id === null) runBackground(id2);
              else runRow(menu.id, id2);
              setMenu(null);
            }
          }
        )
      ]
    }
  );
}
function allBranchIDs(nodes) {
  return nodes.flatMap((n) => n.children?.length ? [n.id, ...allBranchIDs(n.children)] : []);
}
function filterTreeCategory(nodes, category) {
  if (category === "all") return [...nodes];
  return nodes.flatMap((node) => {
    const children = node.children && filterTreeCategory(node.children, category);
    return node.category === category || children?.length ? [{ ...node, children }] : [];
  });
}
export {
  TreePanel,
  TreeToolbar,
  filterTreeCategory
};
