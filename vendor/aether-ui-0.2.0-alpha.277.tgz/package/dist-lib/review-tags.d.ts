/** One normalization for tags typed in the composer or task editor. */
export declare function parseReviewTags(text: string): string[];
