import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import "./ConceptWidgets.css";
function ImportWorkflow({ title, detail, destination, files, step = 2, stepCount = 3, options = [], onBack, onImport }) {
  return /* @__PURE__ */ jsxs("section", { className: "aui-import-workflow", "aria-label": title, children: [
    /* @__PURE__ */ jsx("div", { className: "aui-import-workflow__steps", children: Array.from({ length: stepCount }, (_, index) => /* @__PURE__ */ jsx("span", { "data-complete": index < step }, index)) }),
    /* @__PURE__ */ jsxs("header", { className: "aui-import-workflow__header", children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "import" }),
      /* @__PURE__ */ jsx("strong", { children: title }),
      /* @__PURE__ */ jsx("span", { children: detail })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-import-workflow__destination", children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("span", { children: "DESTINATION" }),
        /* @__PURE__ */ jsx("strong", { children: destination })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { children: files.map((file) => /* @__PURE__ */ jsxs("div", { className: "aui-import-workflow__file", children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "file-character" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: file.name }),
        /* @__PURE__ */ jsx("span", { children: file.detail })
      ] })
    ] }, file.id)) }),
    /* @__PURE__ */ jsx("div", { className: "aui-import-workflow__options", children: options.map((option, index) => /* @__PURE__ */ jsxs("label", { children: [
      /* @__PURE__ */ jsx("input", { type: "checkbox", defaultChecked: index === 0 }),
      option
    ] }, option)) }),
    /* @__PURE__ */ jsxs("div", { className: "aui-import-workflow__actions", children: [
      /* @__PURE__ */ jsx(Button, { onClick: onBack, children: "Back" }),
      /* @__PURE__ */ jsxs(Button, { primary: true, onClick: onImport, children: [
        "Add ",
        files.length,
        " file",
        files.length === 1 ? "" : "s"
      ] })
    ] })
  ] });
}
export {
  ImportWorkflow
};
