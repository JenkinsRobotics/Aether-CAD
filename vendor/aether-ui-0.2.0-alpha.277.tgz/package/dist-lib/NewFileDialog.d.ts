export declare function NewFileDialog({ title, directory, onCreate, onClose }: {
    title: string;
    directory: string;
    onCreate: (name: string) => Promise<void>;
    onClose: () => void;
}): import("react").JSX.Element;
