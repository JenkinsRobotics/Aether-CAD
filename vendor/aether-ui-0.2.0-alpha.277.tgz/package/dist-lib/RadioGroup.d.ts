import type { ReactNode } from "react";
export interface RadioGroupOption {
    id: string;
    label: ReactNode;
    description?: ReactNode;
    disabled?: boolean;
}
export interface RadioGroupProps {
    options: readonly RadioGroupOption[];
    value?: string;
    defaultValue?: string;
    onChange?: (id: string) => void;
    label: ReactNode;
    name?: string;
    orientation?: "horizontal" | "vertical";
    disabled?: boolean;
    error?: ReactNode;
    className?: string;
}
export declare function RadioGroup({ options, value, defaultValue, onChange, label, name, orientation, disabled, error, className }: RadioGroupProps): import("react").JSX.Element;
