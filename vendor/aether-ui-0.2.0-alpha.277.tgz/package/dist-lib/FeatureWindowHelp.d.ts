/** On-demand instructions beside the editor, with no change to its layout. */
export declare function createFeatureWindowHelp(title: string, trigger: HTMLButtonElement, onDismiss: () => void): {
    add(contentNode: HTMLElement | string): void;
    show(): void;
    hide: () => void;
    dispose: () => void;
};
