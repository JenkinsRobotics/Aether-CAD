import "./ModelStudioComposition.css";
/** Optional scene readout: never takes space away from the modeling tools. */
export declare function ModelPositionReadout({ position, unit }: {
    position: readonly number[];
    unit?: string;
}): import("react").JSX.Element;
