import { jsx, jsxs } from "react/jsx-runtime";
import { CollapsibleSidebar, SidebarLabel, SidebarToggle } from "./CollapsibleSidebar.js";
import { SidebarRow } from "./ApplicationSidebar.js";
import "./DashboardNavigation.css";
function DashboardNavigation({ id, brand, mark, items, activeID, onNavigate, secondary, footer }) {
  return /* @__PURE__ */ jsxs(CollapsibleSidebar, { id, ariaLabel: `${brand} navigation`, className: "aui-dashboard-navigation aui-application-sidebar aui-application-sidebar--tint", defaultCollapsed: true, toggle: "custom", footer, children: [
    /* @__PURE__ */ jsxs(SidebarToggle, { className: "aui-dashboard-navigation__brand", children: [
      mark,
      /* @__PURE__ */ jsx(SidebarLabel, { children: brand })
    ] }),
    /* @__PURE__ */ jsx("nav", { "aria-label": brand, children: items.map((item) => /* @__PURE__ */ jsx(SidebarRow, { item: { ...item, current: activeID === item.id, onSelect: () => onNavigate(item.id) } }, item.id)) }),
    secondary && /* @__PURE__ */ jsx("div", { className: "aui-dashboard-navigation__secondary", children: secondary })
  ] });
}
export {
  DashboardNavigation
};
