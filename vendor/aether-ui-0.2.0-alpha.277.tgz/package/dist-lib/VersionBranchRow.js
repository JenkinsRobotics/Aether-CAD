import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
function VersionBranchRow({ entry, active, icon, label, onSelect, menu }) {
  const [failedImage, setFailedImage] = useState(null);
  return /* @__PURE__ */ jsxs("div", { className: "aui-vc-entry-head aui-vc-branch-head", children: [
    /* @__PURE__ */ jsxs(
      "button",
      {
        type: "button",
        className: "aui-vc-select",
        "aria-label": `Select ${entry.name}`,
        "aria-pressed": active,
        "aria-expanded": active,
        onClick: onSelect,
        children: [
          /* @__PURE__ */ jsx("span", { className: "aui-vc-snapshot", children: entry.snapshot && failedImage !== entry.snapshot ? /* @__PURE__ */ jsx("img", { src: entry.snapshot, alt: `Snapshot of ${entry.name}`, onError: () => setFailedImage(entry.snapshot) }) : entry.preview ?? /* @__PURE__ */ jsxs("span", { className: "aui-vc-no-snapshot", "aria-label": "No saved snapshot", children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: icon }),
            /* @__PURE__ */ jsx("small", { children: "No snapshot" })
          ] }) }),
          /* @__PURE__ */ jsxs("span", { className: "aui-vc-branch-copy", children: [
            /* @__PURE__ */ jsxs("span", { className: "aui-vc-branch-title", title: entry.name, children: [
              entry.versionLabel && /* @__PURE__ */ jsx("small", { children: entry.versionLabel }),
              /* @__PURE__ */ jsx("strong", { children: entry.name })
            ] }),
            /* @__PURE__ */ jsx("time", { dateTime: new Date(entry.saved * 1e3).toISOString(), title: `${entry.author} \xB7 ${new Date(entry.saved * 1e3).toLocaleString()}`, children: new Date(entry.saved * 1e3).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) }),
            active ? /* @__PURE__ */ jsx("span", { className: "aui-vc-branch-summary", children: entry.description }) : /* @__PURE__ */ jsxs("span", { className: "aui-vc-branch-meta", children: [
              /* @__PURE__ */ jsxs("span", { title: entry.branch, children: [
                /* @__PURE__ */ jsx("i", {}),
                entry.branch
              ] }),
              /* @__PURE__ */ jsx("span", { className: "aui-vc-badge", children: entry.current ? "Current" : label })
            ] })
          ] })
        ]
      }
    ),
    menu
  ] });
}
export {
  VersionBranchRow
};
