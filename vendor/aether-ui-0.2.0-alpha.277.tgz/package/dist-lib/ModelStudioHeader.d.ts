import type { ReactNode } from "react";
import type { ApplicationIdentityProps } from "./ApplicationChrome.js";
import { type CommandPaletteCommand } from "./CommandPalette.js";
import "./ModelStudioHeader.css";
import "./ModelStudioComposition.css";
export type ModelStudioApp = "cad" | "sketch" | "map" | "io";
/** The approved transparent header, connected to the local study's existing commands. */
export declare function ModelStudioHeader({ app, title, homeUrl, onHome, name, workspaceName, commands, onAction, utilities }: {
    app?: ModelStudioApp;
    /** Product name used by search and help, e.g. "Sketch Studio". */
    title?: string;
    name: string;
    workspaceName: string;
    commands: readonly CommandPaletteCommand[];
    onAction: (id: string) => void;
    /** Right-side account/theme/apps controls; the owning app supplies real ones. */
    utilities?: ReactNode;
} & Pick<ApplicationIdentityProps, "homeUrl" | "onHome">): import("react").JSX.Element;
