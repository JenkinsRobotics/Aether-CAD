import { jsx, jsxs } from "react/jsx-runtime";
import { Tooltip } from "./Tooltip.js";
function ToolHelp({ label, help, disabledReason, children }) {
  if (!help) return children;
  return /* @__PURE__ */ jsx(Tooltip, { placement: "right-start", delayMilliseconds: 650, disabledReason, content: /* @__PURE__ */ jsxs("span", { className: "aui-tool-help", children: [
    /* @__PURE__ */ jsx("strong", { children: label }),
    /* @__PURE__ */ jsx("span", { children: help.summary }),
    /* @__PURE__ */ jsx("ol", { children: help.steps.map((step) => /* @__PURE__ */ jsx("li", { children: step }, step)) }),
    help.illustration
  ] }), children });
}
export {
  ToolHelp
};
