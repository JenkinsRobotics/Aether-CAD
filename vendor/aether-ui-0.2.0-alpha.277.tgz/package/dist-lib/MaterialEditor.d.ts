import "./ConceptWidgets.css";
export interface MaterialChannel {
    id: string;
    label: string;
    value: number;
}
export interface MaterialEditorProps {
    name: string;
    color: string;
    type: string;
    channels: readonly MaterialChannel[];
    onNameChange?: (name: string) => void;
    onColorChange?: (color: string) => void;
    onChannelChange?: (id: string, value: number) => void;
    onAssign?: () => void;
}
export declare function MaterialEditor({ name, color, type, channels, onNameChange, onColorChange, onChannelChange, onAssign }: MaterialEditorProps): import("react").JSX.Element;
