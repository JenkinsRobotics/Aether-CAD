import type { MenuItem } from './Menu.js';
interface ReviewFilterGroup {
    id: string;
    label: string;
    value: string;
    defaultValue: string;
    options: readonly {
        value: string;
        label: string;
    }[];
    onChange: (value: string) => void;
}
/** One fixed-height search row; the standard popup owns every secondary filter. */
export declare function ReviewFilterBar({ subject, query, onQueryChange, groups, actions, onAction, onReset }: {
    subject: 'comments' | 'tasks';
    query: string;
    onQueryChange: (value: string) => void;
    groups: readonly ReviewFilterGroup[];
    actions?: readonly MenuItem[];
    onAction?: (id: string) => void;
    onReset: () => void;
}): import("react").JSX.Element;
export {};
