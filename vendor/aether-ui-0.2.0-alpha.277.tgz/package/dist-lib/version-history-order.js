function orderVersionHistory(entries, oldest = false) {
  const byID = new Map(entries.map((entry) => [entry.id, entry]));
  const children = new Map(entries.map((entry) => [entry.id, 0]));
  for (const entry of entries) for (const parent of new Set(entry.parents)) {
    if (byID.has(parent)) children.set(parent, children.get(parent) + 1);
  }
  const pending = entries.filter((entry) => children.get(entry.id) === 0);
  const result = [];
  while (pending.length) {
    pending.sort((a, b) => b.saved - a.saved || a.id.localeCompare(b.id));
    const entry = pending.shift();
    result.push(entry);
    for (const id of new Set(entry.parents)) {
      if (!byID.has(id)) continue;
      children.set(id, children.get(id) - 1);
      if (children.get(id) === 0) pending.push(byID.get(id));
    }
  }
  const included = new Set(result.map((entry) => entry.id));
  result.push(...entries.filter((entry) => !included.has(entry.id)));
  return oldest ? result.reverse() : result;
}
export {
  orderVersionHistory
};
