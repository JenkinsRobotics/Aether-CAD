import { type ReactNode } from "react";
import { type AetherIconName } from "./AetherIcon.js";
import "./ConceptWidgets.css";
export interface SpecimenDefinition {
    id: string;
    title: string;
    detail: string;
    icon: AetherIconName;
    idealSize?: string;
    previewHeight?: number;
    designSize?: readonly [number, number];
    content: ReactNode;
}
export interface SpecimenSectionDefinition {
    id: string;
    title: string;
    detail: string;
    specimens: readonly SpecimenDefinition[];
    minimumWidth?: number;
    maximumWidth?: number;
}
export interface SpecimenBoardProps {
    title: string;
    detail: string;
    icon?: AetherIconName;
    eyebrow?: string;
    stats?: readonly string[];
    status?: string;
    sections: readonly SpecimenSectionDefinition[];
}
export declare function SpecimenBoard({ title, detail, icon, eyebrow, stats, status, sections }: SpecimenBoardProps): import("react").JSX.Element;
