import type { ReactNode } from "react";
import { type ApplicationIdentityProps } from "./ApplicationChrome.js";
export interface DocumentBarProps {
    /** Standard app identity, launcher, settings and account chrome. Omit in embedded demos. */
    application?: ApplicationIdentityProps & {
        onSettings?: () => void;
        onShare?: () => void;
    };
    /** Direct layout/docking and window controls, immediately before Settings. */
    viewControls?: ReactNode;
    /** App-supplied account presentation; omitted uses the Studio host account mount. */
    account?: ReactNode;
    /** Used until the user saves header icon preferences for this app. */
    defaultHeaderPins?: readonly string[];
    /** Compact utilities place Settings before the pinned icons, matching reading/tab order. */
    compactControls?: boolean;
    /** Left cluster: home button, project name, save state, commands. */
    leading?: ReactNode;
    /** Centered on the window (usually workspace <Tabs>). */
    center?: ReactNode;
    /** Right cluster: engine status, layout preset button, window menus. */
    trailing?: ReactNode;
    className?: string;
    /** Transparent lets the parent workspace show through without a frame or blur. */
    variant?: "standard" | "transparent";
    /** Disable for embedded component previews. */
    windowChrome?: boolean;
}
/** The shared top app-window row (Swift `StudioDocumentBar`): leading and
 *  trailing clusters with the center slot truly window-centered. */
export declare function DocumentBar({ leading, center, trailing, className, variant, windowChrome, application, viewControls, account, defaultHeaderPins, compactControls }: DocumentBarProps): import("react").JSX.Element;
