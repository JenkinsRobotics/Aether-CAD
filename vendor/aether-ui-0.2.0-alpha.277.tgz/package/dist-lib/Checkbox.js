import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef } from "react";
function Checkbox({
  label,
  description,
  indeterminate = false,
  className,
  ...inputProps
}) {
  const inputRef = useRef(null);
  useEffect(() => {
    if (inputRef.current) inputRef.current.indeterminate = indeterminate;
  }, [indeterminate]);
  const classes = ["aui-checkbox"];
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs("label", { className: classes.join(" "), children: [
    /* @__PURE__ */ jsx(
      "input",
      {
        ...inputProps,
        ref: inputRef,
        type: "checkbox",
        "aria-checked": indeterminate ? "mixed" : inputProps.checked
      }
    ),
    /* @__PURE__ */ jsx("span", { className: "aui-checkbox-mark", "aria-hidden": true, children: indeterminate ? "\u2212" : "\u2713" }),
    /* @__PURE__ */ jsxs("span", { className: "aui-checkbox-copy", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-checkbox-label", children: label }),
      description ? /* @__PURE__ */ jsx("span", { className: "aui-checkbox-description", children: description }) : null
    ] })
  ] });
}
export {
  Checkbox
};
