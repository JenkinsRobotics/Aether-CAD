import "./StylePropertiesPanel.css";
/** Presentation values in CSS pixels, degrees and percent. The owning app
 * translates them to its document model; the inspector never owns geometry. */
export interface StylePropertiesValue {
    width: number;
    height: number;
    rotation: number;
    opacity: number;
    corners: [number, number, number, number];
    fill: {
        enabled: boolean;
        color: string;
        opacity: number;
    };
    border: {
        enabled: boolean;
        color: string;
        width: number;
        style: "solid" | "dashed" | "dotted";
    };
    shadow: {
        enabled: boolean;
        color: string;
        opacity: number;
        x: number;
        y: number;
        blur: number;
        spread: number;
    };
}
export interface StylePropertiesPanelProps {
    value: StylePropertiesValue;
    onChange: (value: StylePropertiesValue) => void;
    selectionLabel?: string;
    onReset?: () => void;
    className?: string;
}
export declare function StylePropertiesPanel({ value: v, onChange, selectionLabel, onReset, className }: StylePropertiesPanelProps): import("react").JSX.Element;
