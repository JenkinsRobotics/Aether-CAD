import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { Menu } from "./Menu.js";
import { assignTabFolder, documentTabMenu } from "./DocumentTabTray.js";
function useDocumentBrowserContext(props, options) {
  const { folders = [], onFoldersChange, onAdd, onManage, onOrganize } = props;
  const { itemsFor, choose } = documentTabMenu(props);
  const [context, setContext] = useState(null);
  const [editing, setEditing] = useState(null);
  const tabItems = (id) => [
    ...itemsFor(id),
    ...onFoldersChange ? [{ id: "browser:move", label: "Move to folder", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "collection-folder" }), separatorBefore: true, children: [{ id: "", name: options.rootLabel }, ...folders].map((folder) => ({
      id: `browser:move:${folder.id}`,
      label: folder.name,
      kind: "radio",
      checked: (folders.find((f) => f.tabs.includes(id))?.id ?? "") === folder.id
    })) }] : []
  ];
  const creationItems = [
    ...props.creation?.items ?? [{ id: "browser:create", label: "New design\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }],
    ...onFoldersChange ? [{ id: "browser:new-folder", label: "New folder\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder-add" }) }] : [],
    ...onManage ? [{ id: "browser:manage", label: "Manage and import files\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "import" }) }] : []
  ];
  const actionItems = [
    ...creationItems,
    ...onOrganize ? [{ id: "browser:organize", label: "Organize folders\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "collection-folder" }) }] : []
  ];
  const backgroundItems = [
    ...actionItems,
    { id: "browser:list", label: "List view", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "items" }), kind: "radio", checked: options.view === "list", separatorBefore: true },
    { id: "browser:gallery", label: "Gallery view", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "layout" }), kind: "radio", checked: options.view === "gallery" },
    ...options.folderID ? [{ id: "browser:root", label: `Back to ${options.rootLabel}`, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "home" }), separatorBefore: true }] : []
  ];
  const select = (target2, action) => {
    setContext(null);
    if (target2.kind === "tab" && action.startsWith("browser:move:")) onFoldersChange?.(assignTabFolder(folders, target2.id, action.slice("browser:move:".length)));
    else if (target2.kind === "tab") choose(target2.id, action);
    else if (props.creation?.items.some((item) => item.id === action)) props.creation.onSelect(action);
    else if (action === "browser:create") onAdd();
    else if (action === "browser:new-folder") setEditing({ name: "" });
    else if (action === "browser:manage") onManage?.();
    else if (action === "browser:organize") onOrganize?.();
    else if (action === "browser:list" || action === "browser:gallery") options.setView(action === "browser:list" ? "list" : "gallery");
    else if (action === "browser:root") options.setFolder(null);
    else if (target2.kind === "folder") {
      const folder = folders.find((f) => f.id === target2.id);
      if (!folder) return;
      if (action === "browser:open-folder") options.setFolder(folder.id);
      else if (action === "browser:rename-folder") setEditing({ id: folder.id, name: folder.name });
      else if (action === "browser:ungroup") onFoldersChange?.(folders.filter((f) => f.id !== folder.id));
    }
  };
  const target = context?.target;
  const folderItems = [
    { id: "browser:open-folder", label: "Open folder", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "file-folder" }) },
    ...onFoldersChange ? [{ id: "browser:rename-folder", label: "Rename folder\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "notes" }), shortcut: "F2" }, { id: "browser:ungroup", label: "Ungroup folder", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "delete" }), shortcut: "Delete" }] : []
  ];
  const contextItems = target?.kind === "tab" ? tabItems(target.id) : target?.kind === "folder" ? folderItems : backgroundItems;
  const saveFolder = () => {
    if (!editing?.name.trim() || !onFoldersChange) return;
    const name = editing.name.trim();
    onFoldersChange(editing.id ? folders.map((f) => f.id === editing.id ? { ...f, name } : f) : [...folders, { id: crypto.randomUUID(), name, tabs: [], collapsed: false }]);
    setEditing(null);
  };
  return {
    creationItems,
    actionItems,
    selectBackground: (action) => select({ kind: "background" }, action),
    shortcut: (target2, key) => {
      const command = (target2.kind === "tab" ? tabItems(target2.id) : target2.kind === "folder" ? folderItems : []).find((item) => !item.disabled && item.shortcut === (key === "Backspace" ? "Delete" : key));
      if (!command || !["F2", "Delete", "Backspace"].includes(key)) return false;
      select(target2, command.id);
      return true;
    },
    folderItems,
    selectFolder: (id, action) => select({ kind: "folder", id }, action),
    tabItems,
    selectTab: (id, action) => select({ kind: "tab", id }, action),
    open: (event, target2) => {
      if (event.target.closest('input, textarea, [contenteditable], [role="menu"]')) return;
      event.preventDefault();
      event.stopPropagation();
      setContext({ target: target2, x: event.clientX, y: event.clientY });
    },
    overlays: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(
        Menu,
        {
          className: "aui-collection-popup",
          open: Boolean(context),
          anchor: context,
          ariaLabel: target?.kind === "tab" ? "Document actions" : target?.kind === "folder" ? "Folder actions" : "Files actions",
          items: contextItems,
          onClose: () => setContext(null),
          onSelect: (action) => {
            if (target) select(target, action);
          }
        }
      ),
      /* @__PURE__ */ jsx(
        Dialog,
        {
          open: Boolean(editing),
          title: editing?.id ? "Rename folder" : "New folder",
          onClose: () => setEditing(null),
          actions: /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(Button, { onClick: () => setEditing(null), children: "Cancel" }),
            /* @__PURE__ */ jsx(Button, { primary: true, disabled: !editing?.name.trim(), onClick: saveFolder, children: editing?.id ? "Rename" : "Create folder" })
          ] }),
          children: /* @__PURE__ */ jsx("form", { onSubmit: (event) => {
            event.preventDefault();
            saveFolder();
          }, children: /* @__PURE__ */ jsxs("label", { children: [
            "Folder name",
            /* @__PURE__ */ jsx("input", { autoFocus: true, "aria-label": "Folder name", maxLength: 80, value: editing?.name ?? "", onChange: (event) => setEditing((current) => current && { ...current, name: event.target.value }) })
          ] }) })
        }
      )
    ] })
  };
}
export {
  useDocumentBrowserContext
};
