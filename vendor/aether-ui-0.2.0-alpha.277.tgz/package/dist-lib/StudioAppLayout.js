import { jsx, jsxs } from "react/jsx-runtime";
import { useRef } from "react";
import { PanelResizeHandle } from "./PanelResizeHandle.js";
import "./StudioAppLayout.css";
const STUDIO_APP_LAYOUT_METRICS = {
  headerHeight: 56,
  inset: 20,
  auxWidth: 360,
  sideWidth: 216,
  sideMinWidth: 180,
  sideMaxWidth: 480,
  centerToolbarMaxWidth: 620
};
function StudioAppLayout({
  header,
  aux,
  auxOpen = true,
  auxLabel = "Aux sidebar",
  left,
  right,
  children,
  centerLabel,
  centerTop,
  centerBottom,
  leftTools,
  rightTools,
  footer,
  overlays,
  leftWidth,
  onLeftWidthChange,
  leftResizeLabel = "Resize left sidebar",
  mobilePanel = null,
  className,
  style,
  rootRef,
  data
}) {
  const m = STUDIO_APP_LAYOUT_METRICS;
  const vars = { ...leftWidth ? { "--aui-studio-left-width": `${leftWidth}px` } : {}, ...style };
  const leftCard = useRef(null);
  return /* @__PURE__ */ jsxs("div", { ref: rootRef, className: ["aui-studio-app", className].filter(Boolean).join(" "), "data-header": !!header, style: vars, ...data, children: [
    header && /* @__PURE__ */ jsx("div", { className: "aui-studio-app-header", "data-app-region": "header", children: header }),
    aux !== void 0 && /* @__PURE__ */ jsx("aside", { className: "aui-studio-app-aux", "data-app-region": "aux", "aria-label": auxLabel, hidden: !auxOpen, children: aux }),
    /* @__PURE__ */ jsxs("div", { className: "aui-studio-app-workspace", children: [
      /* @__PURE__ */ jsxs("main", { className: "aui-studio-app-center", "data-app-region": "center", "aria-label": centerLabel, "data-mobile-panel": mobilePanel ?? "none", children: [
        children,
        left && /* @__PURE__ */ jsxs("div", { className: "aui-studio-app-left", "data-app-region": "left", ref: leftCard, children: [
          left,
          onLeftWidthChange && /* @__PURE__ */ jsx(
            PanelResizeHandle,
            {
              edge: "right",
              label: leftResizeLabel,
              value: () => leftCard.current?.getBoundingClientRect().width ?? m.sideWidth,
              min: m.sideMinWidth,
              max: m.sideMaxWidth,
              onChange: onLeftWidthChange,
              onReset: () => onLeftWidthChange(void 0)
            }
          )
        ] }),
        centerTop && /* @__PURE__ */ jsx("div", { className: "aui-studio-app-center-top", "data-app-region": "center-top", children: centerTop }),
        right && /* @__PURE__ */ jsx("div", { className: "aui-studio-app-right", "data-app-region": "right", children: right }),
        leftTools && /* @__PURE__ */ jsx("div", { className: "aui-studio-app-left-tools", "data-app-region": "left-tools", children: leftTools }),
        rightTools && /* @__PURE__ */ jsx("div", { className: "aui-studio-app-right-tools", "data-app-region": "right-tools", children: rightTools }),
        centerBottom && /* @__PURE__ */ jsx("div", { className: "aui-studio-app-center-bottom", "data-app-region": "center-bottom", children: centerBottom }),
        overlays
      ] }),
      footer && /* @__PURE__ */ jsx("div", { className: "aui-studio-app-footer", "data-app-region": "footer", children: footer })
    ] })
  ] });
}
export {
  STUDIO_APP_LAYOUT_METRICS,
  StudioAppLayout
};
