import { type MenuItem } from "./Menu.js";
import { type LayoutPreset } from "./WorkspaceShell.js";
import { type AetherThemeManifest } from "./themes.js";
export type { AetherThemeManifest } from "./themes.js";
/** Native studio-mode button: colored per preset, primary click cycles,
 * right-click or ArrowDown opens the Studio modes menu with reset. */
export declare function StudioModeButton({ preset, onChange, extraItems, onExtraSelect }: {
    preset: LayoutPreset;
    onChange: (preset: LayoutPreset) => void;
    extraItems?: readonly MenuItem[];
    onExtraSelect?: (id: string) => void;
}): import("react").JSX.Element;
/** Native workspace windows/tabs menu. Browser-managed entries stay listed
 * but disabled, exactly as named in the native app. */
export declare function WorkspaceWindowMenu(): import("react").JSX.Element;
export type AppearanceMode = "system" | "light" | "dark";
export declare function storedAppearance(): AppearanceMode;
/** Hot-installs a theme at runtime (VS Code-style): resolves the manifest
 * against the pack, synthesizes the scoped CSS and injects it, replacing any
 * prior install of the same id. Pair with setAetherTheme(manifest.id) to
 * activate immediately. dev/build-theme-css.mjs emits identical selectors. */
export declare function installAetherTheme(manifest: AetherThemeManifest): void;
/** Installed-theme selection: themes generate side-by-side scoped classes;
 * this applies the persisted choice. The default theme is the bare :root. */
export declare function setAetherTheme(themeID: string): void;
export declare function activeAetherTheme(): string;
/** The viewport theme: the stage's own look (background, grid, part and sketch
 * colours), chosen independently of the interface theme. `null` means the
 * interface theme's own viewport look. */
export declare function setAetherViewportTheme(viewportID: string | null): void;
export declare function activeAetherViewportTheme(): string | null;
/** Sets and persists the appearance mode app-wide, as the toggle's click does. */
export declare function setAetherAppearance(mode: AppearanceMode): void;
/** Adopt the approved design once; later explicit user choices remain editable. */
export declare function useStudioDesignDefaults(): void;
/** A concept app that presents in its own theme: the classes ride on <html>
 * (so portalled menus share them) for the component's lifetime, and the
 * person's persisted theme and appearance come back on unmount. */
export declare function useScopedAetherTheme(themeID: string | null, appearance?: "light" | "dark"): void;
/** Native appearance toggle: cycles System → Light → Dark and applies
 * app-wide immediately; the choice persists per device. */
export declare function AppearanceToggle(): import("react").JSX.Element;
