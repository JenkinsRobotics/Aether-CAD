import "./WorkflowWidgets.css";
export interface BatchActionReviewProps {
    title: string;
    description: string;
    totalLabel: string;
    fields: readonly {
        label: string;
        value: string;
    }[];
    onRun: () => void;
    onCancel?: () => void;
    busy?: boolean;
}
export declare function BatchActionReview({ title, description, totalLabel, fields, onRun, onCancel, busy }: BatchActionReviewProps): import("react").JSX.Element;
