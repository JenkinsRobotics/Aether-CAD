import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Inspector, InspectorSection, InspectorActions } from "./Inspector.js";
import { FieldRow } from "./FieldRow.js";
import { TextField } from "./TextField.js";
import { Checkbox } from "./Checkbox.js";
import { NumberField } from "./NumberField.js";
import { SelectField } from "./SelectField.js";
import { Button } from "./Button.js";
import "./ConceptInspectors.css";
function ConfigurationInspector({ kinds, value, initialValue, connectors = [], offsetUnit, rotationUnit, onChange, onApply, onCancel, title = "Configuration" }) {
  const [local, setLocal] = useState(initialValue ?? { name: "Configuration", kind: kinds[0]?.id ?? "", offset: true, limits: true, simulation: false, x: 0, y: 0, z: 0, angle: 0, min: -70, max: 70 });
  const [applied, setApplied] = useState(false);
  const [checkpoint, setCheckpoint] = useState(value ?? local);
  const current = value ?? local;
  const kind = kinds.find((entry) => entry.id === current.kind) ?? kinds[0];
  const update = (patch) => {
    const next = { ...current, ...patch };
    setLocal(next);
    setApplied(false);
    onChange?.(next);
  };
  return /* @__PURE__ */ jsx(Inspector, { children: /* @__PURE__ */ jsx("section", { "aria-label": title, children: /* @__PURE__ */ jsxs(InspectorSection, { title, children: [
    /* @__PURE__ */ jsxs(InspectorActions, { label: "Configuration actions", children: [
      /* @__PURE__ */ jsx(Button, { "aria-label": "Accept configuration", onClick: () => {
        setApplied(true);
        setCheckpoint(current);
        onApply?.(current);
      }, children: "\u2713" }),
      /* @__PURE__ */ jsx(Button, { "aria-label": "Cancel configuration", onClick: () => {
        setLocal(checkpoint);
        onChange?.(checkpoint);
        onCancel?.();
        setApplied(false);
      }, children: "\xD7" })
    ] }),
    /* @__PURE__ */ jsx(FieldRow, { label: "Name", children: /* @__PURE__ */ jsx(TextField, { "aria-label": "Name", value: current.name, onChange: (e) => update({ name: e.target.value }) }) }),
    /* @__PURE__ */ jsx(FieldRow, { label: "Type", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Type", value: current.kind, onChange: (e) => update({ kind: e.target.value }), options: kinds.map((entry) => ({ value: entry.id, label: entry.label })) }) }),
    connectors.length ? /* @__PURE__ */ jsx(FieldRow, { label: "Connectors", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Connectors", value: current.connector ?? connectors[0]?.value, options: connectors, onChange: (event) => update({ connector: event.target.value }) }) }) : null,
    /* @__PURE__ */ jsx("small", { children: kind?.detail }),
    /* @__PURE__ */ jsx(Checkbox, { label: "Offset", checked: current.offset, disabled: !kind?.offset, onChange: (e) => update({ offset: e.target.checked }) }),
    current.offset && kind?.offset ? /* @__PURE__ */ jsxs(Fragment, { children: [
      ["x", "y", "z"].map((axis) => /* @__PURE__ */ jsx(FieldRow, { label: axis.toUpperCase(), children: /* @__PURE__ */ jsx(NumberField, { "aria-label": `Offset ${axis.toUpperCase()}`, value: current[axis], unit: offsetUnit, onValueChange: (n) => update({ [axis]: n ?? 0 }) }) }, axis)),
      kind.rotation ? /* @__PURE__ */ jsx(FieldRow, { label: "Rotation", children: /* @__PURE__ */ jsx(NumberField, { "aria-label": "Offset rotation", value: current.angle, unit: rotationUnit, onValueChange: (n) => update({ angle: n ?? 0 }) }) }) : null
    ] }) : null,
    /* @__PURE__ */ jsx(Checkbox, { label: "Limits", checked: current.limits, disabled: !kind?.limits, onChange: (e) => update({ limits: e.target.checked }) }),
    current.limits && kind?.limits ? /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx(FieldRow, { label: "Minimum", children: /* @__PURE__ */ jsx(NumberField, { "aria-label": "Minimum", value: current.min, unit: kind.rotation ? rotationUnit : offsetUnit, onValueChange: (n) => update({ min: n ?? 0 }) }) }),
      /* @__PURE__ */ jsx(FieldRow, { label: "Maximum", children: /* @__PURE__ */ jsx(NumberField, { "aria-label": "Maximum", value: current.max, unit: kind.rotation ? rotationUnit : offsetUnit, onValueChange: (n) => update({ max: n ?? 0 }) }) })
    ] }) : null,
    /* @__PURE__ */ jsx(Checkbox, { label: "Simulation connection", checked: current.simulation, onChange: (e) => update({ simulation: e.target.checked }) }),
    /* @__PURE__ */ jsx("output", { "aria-live": "polite", children: applied ? "Configuration applied" : "Editing configuration" })
  ] }) }) });
}
export {
  ConfigurationInspector
};
