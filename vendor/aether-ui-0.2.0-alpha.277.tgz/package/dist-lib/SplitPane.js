import { jsx, jsxs } from "react/jsx-runtime";
import { useRef, useState } from "react";
function SplitPane({
  primary,
  secondary,
  orientation = "horizontal",
  primarySize,
  defaultPrimarySize = 280,
  minPrimarySize = 120,
  maxPrimarySize = 720,
  collapsed,
  defaultCollapsed = false,
  collapseSide = "secondary",
  onResize,
  onCollapsedChange,
  separatorLabel = "Resize panels",
  className,
  style
}) {
  const [internalSize, setInternalSize] = useState(defaultPrimarySize);
  const [internalCollapsed, setInternalCollapsed] = useState(defaultCollapsed);
  const containerRef = useRef(null);
  const size = primarySize ?? internalSize;
  const isCollapsed = collapsed ?? internalCollapsed;
  const clamp = (value) => {
    const room = containerRef.current?.getBoundingClientRect().width ?? 0;
    const cap = room > 0 ? Math.min(maxPrimarySize, Math.max(minPrimarySize, room - minPrimarySize)) : maxPrimarySize;
    return Math.min(cap, Math.max(minPrimarySize, value));
  };
  const resize = (value) => {
    const next = clamp(value);
    if (primarySize === void 0) setInternalSize(next);
    onResize?.(next);
  };
  const setCollapsed = (value) => {
    if (collapsed === void 0) setInternalCollapsed(value);
    onCollapsedChange?.(value);
  };
  const beginResize = (event) => {
    event.preventDefault();
    const startCoordinate = orientation === "horizontal" ? event.clientX : event.clientY;
    const startSize = size;
    const move = (moveEvent) => {
      const coordinate = orientation === "horizontal" ? moveEvent.clientX : moveEvent.clientY;
      resize(startSize + coordinate - startCoordinate);
    };
    const finish = () => {
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerup", finish);
    };
    document.addEventListener("pointermove", move);
    document.addEventListener("pointerup", finish);
  };
  const onSeparatorKey = (event) => {
    const decrement = orientation === "horizontal" ? "ArrowLeft" : "ArrowUp";
    const increment = orientation === "horizontal" ? "ArrowRight" : "ArrowDown";
    const step = event.shiftKey ? 50 : 10;
    if (event.key === decrement) resize(size - step);
    else if (event.key === increment) resize(size + step);
    else if (event.key === "Home") setCollapsed(true);
    else if (event.key === "End") {
      setCollapsed(false);
      resize(maxPrimarySize);
    } else if (event.key === "Enter") setCollapsed(!isCollapsed);
    else return;
    event.preventDefault();
  };
  const primaryCollapsed = isCollapsed && collapseSide === "primary";
  const secondaryCollapsed = isCollapsed && collapseSide === "secondary";
  const bar = "var(--aui-splitpane-separator, 5px)";
  const tracks = primaryCollapsed ? `0px ${bar} minmax(0, 1fr)` : secondaryCollapsed ? `minmax(0, 1fr) ${bar} 0px` : `${size}px ${bar} minmax(0, 1fr)`;
  const paneStyle = orientation === "horizontal" ? { gridTemplateColumns: tracks } : { gridTemplateRows: tracks };
  return /* @__PURE__ */ jsxs(
    "div",
    {
      ref: containerRef,
      className: ["aui-split-pane", `aui-split-pane--${orientation}`, className].filter(Boolean).join(" "),
      style: { ...style, ...paneStyle },
      children: [
        /* @__PURE__ */ jsx("div", { className: "aui-split-pane-primary", hidden: primaryCollapsed, children: primary }),
        /* @__PURE__ */ jsx(
          "div",
          {
            className: "aui-split-pane-separator",
            role: "separator",
            "aria-label": separatorLabel,
            "aria-orientation": orientation === "horizontal" ? "vertical" : "horizontal",
            "aria-valuemin": minPrimarySize,
            "aria-valuemax": maxPrimarySize,
            "aria-valuenow": size,
            tabIndex: 0,
            onPointerDown: beginResize,
            onDoubleClick: () => setCollapsed(!isCollapsed),
            onKeyDown: onSeparatorKey
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "aui-split-pane-secondary", hidden: secondaryCollapsed, children: secondary }),
        secondaryCollapsed ? /* @__PURE__ */ jsx("button", { className: "aui-split-pane-restore", type: "button", onClick: () => setCollapsed(false), children: "Restore panel" }) : null
      ]
    }
  );
}
export {
  SplitPane
};
