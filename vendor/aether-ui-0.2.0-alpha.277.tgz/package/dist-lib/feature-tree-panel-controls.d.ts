import type { TreeControl } from './TreePanel.js';
import { type FeatureTreeCommand, type FeatureTreeItem, type FeatureTreeRequest } from './feature-tree.js';
/** Collection operations use the same capability checks and dispatch as row operations. */
export declare function featureTreePanelControls(items: readonly FeatureTreeItem[], available: readonly FeatureTreeCommand[], can: (request: FeatureTreeRequest) => boolean, dispatch: (request: FeatureTreeRequest) => void, historyLength?: number): TreeControl[];
