import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
function SelectionIcon({ mode = "window" }) {
  return /* @__PURE__ */ jsxs("span", { className: `aui-selection-icon aui-selection-icon--${mode}`, "aria-hidden": "true", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-selection-icon-region" }),
    /* @__PURE__ */ jsx(AetherIcon, { name: "node-select" })
  ] });
}
export {
  SelectionIcon
};
