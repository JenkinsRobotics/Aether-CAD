import { jsx } from "react/jsx-runtime";
function Button({ primary, active, appearance = "standard", className, ...rest }) {
  const classes = ["aui-button"];
  if (primary) classes.push("aui-button--primary");
  if (active) classes.push("aui-button--active");
  if (appearance !== "standard") classes.push(`aui-button--${appearance}`);
  if (className) classes.push(className);
  return /* @__PURE__ */ jsx("button", { type: "button", className: classes.join(" "), ...rest });
}
export {
  Button
};
