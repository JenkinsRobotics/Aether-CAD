import { jsx } from "react/jsx-runtime";
import { appIconSources as sources } from "@aether/assets/branding/apps/sources";
function AppIcon({ app = "studio", size = 32, alt = "", style, ...props }) {
  return /* @__PURE__ */ jsx("img", { src: sources[app] ?? sources.studio, alt, width: size, height: size, style: { objectFit: "contain", borderRadius: "22%", flexShrink: 0, ...style }, ...props });
}
export {
  AppIcon
};
