/** Renderer-independent artwork recipes, usable without mounting a widget. */
export { modelStudioEnvironment, modelStudioSurfaces } from "@aether/assets/themes/rendering/model-studio";
/** Default framing in the reference's meter/Y-up presentation coordinates. */
export declare const modelStudioCamera: {
    readonly target: readonly [0, 1.85, 0];
    readonly views: {
        readonly perspective: readonly [5, 3.5, 7.7];
        readonly front: readonly [0, 2, 9];
        readonly right: readonly [9, 2, 0];
        readonly top: readonly [0.01, 11, 0.01];
    };
};
