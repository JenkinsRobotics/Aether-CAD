function parseCSSColor(value) {
  const text = value.trim();
  if (!text) return null;
  const hex = /^#([0-9a-f]{3,8})$/i.exec(text);
  if (hex) {
    const digits = hex[1];
    const expand = (part) => parseInt(part.length === 1 ? part + part : part, 16);
    if (digits.length === 3 || digits.length === 4) {
      return { r: expand(digits[0]), g: expand(digits[1]), b: expand(digits[2]), a: digits.length === 4 ? expand(digits[3]) / 255 : 1 };
    }
    if (digits.length === 6 || digits.length === 8) {
      return {
        r: parseInt(digits.slice(0, 2), 16),
        g: parseInt(digits.slice(2, 4), 16),
        b: parseInt(digits.slice(4, 6), 16),
        a: digits.length === 8 ? parseInt(digits.slice(6, 8), 16) / 255 : 1
      };
    }
    return null;
  }
  const rgb = /^rgba?\(([^)]+)\)$/i.exec(text);
  if (!rgb) return null;
  const parts = rgb[1].split(/[\s,/]+/).filter(Boolean).map(Number);
  if (parts.length < 3 || parts.slice(0, 3).some((n) => !Number.isFinite(n))) return null;
  const alpha = parts.length > 3 && Number.isFinite(parts[3]) ? parts[3] : 1;
  return { r: parts[0], g: parts[1], b: parts[2], a: alpha };
}
const TOKENS = [
  ["backgroundTop", "viewport-bg-top"],
  ["backgroundBottom", "viewport-bg-bottom"],
  ["grid", "viewport-grid"],
  ["gridAxis", "viewport-grid-axis"],
  ["part", "viewport-part"],
  ["partShade", "viewport-part-shade"],
  ["partEdge", "viewport-part-edge"],
  ["cavity", "viewport-cavity"],
  ["sketch", "viewport-sketch"],
  ["sketchConstrained", "viewport-sketch-constrained"],
  ["construction", "viewport-construction"],
  ["selection", "viewport-selection"],
  ["hover", "viewport-hover"]
];
const toColor = (rgba) => ({ hex: Math.round(rgba.r) << 16 | Math.round(rgba.g) << 8 | Math.round(rgba.b), alpha: rgba.a });
function viewportPalette(tokens) {
  const palette = {};
  for (const [key, token] of TOKENS) {
    const parsed = parseCSSColor(tokens[token] ?? "");
    if (parsed) palette[key] = toColor(parsed);
  }
  const top = parseCSSColor(tokens["viewport-bg-top"] ?? "");
  const bottom = parseCSSColor(tokens["viewport-bg-bottom"] ?? "");
  if (top && bottom) palette.background = toColor({ r: (top.r + bottom.r) / 2, g: (top.g + bottom.g) / 2, b: (top.b + bottom.b) / 2, a: 1 });
  else if (top) palette.background = toColor(top);
  return palette;
}
function readViewportPalette(element) {
  if (typeof document === "undefined" || typeof getComputedStyle !== "function") return {};
  const style = getComputedStyle(element ?? document.documentElement);
  const tokens = {};
  for (const [, token] of TOKENS) tokens[token] = style.getPropertyValue(`--aether-${token}`);
  return viewportPalette(tokens);
}
export {
  parseCSSColor,
  readViewportPalette,
  viewportPalette
};
