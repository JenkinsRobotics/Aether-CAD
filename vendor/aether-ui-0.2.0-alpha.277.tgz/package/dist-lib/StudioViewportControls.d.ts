import type { ReactNode } from "react";
import "./StudioViewportControls.css";
/** Camera above environment, with room for each control's expanded surface. */
export declare function StudioViewportControls({ children, className }: {
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
