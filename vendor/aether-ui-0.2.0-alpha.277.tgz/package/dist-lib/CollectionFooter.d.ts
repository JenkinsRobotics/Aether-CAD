import type { ReactNode } from 'react';
import { type MenuItem } from './Menu.js';
/** The same panel commands as empty-space right-click, pinned below its scroll area. */
export declare function CollectionFooter({ label, items, onCommand, children }: {
    label: string;
    items: readonly MenuItem[];
    onCommand: (id: string) => void;
    children?: ReactNode;
}): import("react").JSX.Element | null;
