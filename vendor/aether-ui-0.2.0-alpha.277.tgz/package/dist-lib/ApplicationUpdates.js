import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import "./ApplicationUpdates.css";
function ApplicationUpdates({ name, description, artwork, updates = [] }) {
  const id = useId(), track = useRef(null);
  useEffect(() => {
    const list = track.current;
    if (!list) return;
    const onWheel = (event) => {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.deltaX !== 0 || !event.deltaY) return;
      const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? list.clientWidth : 1;
      const next = Math.max(0, Math.min(list.scrollWidth - list.clientWidth, list.scrollLeft + event.deltaY * unit));
      if (next === list.scrollLeft) return;
      event.preventDefault();
      list.scrollLeft = next;
    };
    list.addEventListener("wheel", onWheel, { passive: false });
    return () => list.removeEventListener("wheel", onWheel);
  }, []);
  const scroll = (direction) => track.current?.scrollBy({ left: 352 * direction, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  return /* @__PURE__ */ jsxs("section", { className: "aui-app-updates", "aria-labelledby": id, children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { id, children: "What\u2019s new" }),
        /* @__PURE__ */ jsxs("p", { children: [
          "The latest in ",
          name,
          ", and what\u2019s coming next."
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-app-updates-nav", children: [
        /* @__PURE__ */ jsx(IconButton, { label: "Scroll updates left", onClick: () => scroll(-1), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-left" }) }),
        /* @__PURE__ */ jsx(IconButton, { label: "Scroll updates right", onClick: () => scroll(1), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right" }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("ul", { ref: track, tabIndex: 0, "aria-label": `${name} updates; scroll for more`, children: [
      /* @__PURE__ */ jsxs("li", { className: "aui-app-update aui-app-update-welcome", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("small", { children: "Welcome" }),
          /* @__PURE__ */ jsx("h3", { children: name }),
          /* @__PURE__ */ jsx("p", { children: description })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "aui-app-update-art", "aria-hidden": "true", children: artwork })
      ] }),
      updates.map((item) => /* @__PURE__ */ jsxs("li", { className: "aui-app-update", style: { "--update-color": item.color ?? "#b8cce9" }, children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("small", { children: item.status === "Planned" ? "Coming soon" : item.status }),
          /* @__PURE__ */ jsx("h3", { children: item.title }),
          /* @__PURE__ */ jsx("p", { children: item.description })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "aui-app-update-art", "aria-hidden": "true", children: item.artwork })
      ] }, item.id))
    ] })
  ] });
}
export {
  ApplicationUpdates
};
