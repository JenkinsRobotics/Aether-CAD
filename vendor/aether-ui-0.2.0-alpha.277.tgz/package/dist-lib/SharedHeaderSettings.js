import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Checkbox } from "./Checkbox.js";
import { IconButton } from "./IconButton.js";
import { SelectField } from "./SelectField.js";
import { SettingsCard, SettingsRow } from "./SettingsWindow.js";
import { setHeaderPins, useAvailableHeaderControls, useHeaderPins } from "./header-controls.js";
function HeaderPins({ config }) {
  const pins = useHeaderPins(config.appID, config.defaults);
  const selected = pins.flatMap((id) => config.controls.find((item) => item.id === id) ?? []);
  const controls = [...selected, ...config.controls.filter((item) => !pins.includes(item.id))];
  const move = (id, step) => {
    const target = selected[selected.findIndex((item) => item.id === id) + step];
    if (!target) return;
    const next = [...pins], from = next.indexOf(id), to = next.indexOf(target.id);
    [next[from], next[to]] = [next[to], next[from]];
    setHeaderPins(config.appID, next);
  };
  return /* @__PURE__ */ jsx(SettingsCard, { title: "Pinned header icons", caption: `Choose the icons in ${config.name}'s header. Changes are saved on this device. Settings and your account remain available.`, children: controls.map((item) => {
    const checked = pins.includes(item.id), index = selected.findIndex((value) => value.id === item.id);
    return /* @__PURE__ */ jsxs(SettingsRow, { label: item.label, icon: /* @__PURE__ */ jsx(AetherIcon, { name: item.icon }), children: [
      /* @__PURE__ */ jsx(Checkbox, { label: "", "aria-label": `Show ${item.label} in header`, checked, onChange: () => setHeaderPins(config.appID, checked ? pins.filter((id) => id !== item.id) : [...pins, item.id]) }),
      /* @__PURE__ */ jsx(IconButton, { size: "small", style: { visibility: checked ? void 0 : "hidden" }, "aria-hidden": !checked, label: `Move ${item.label} earlier`, disabled: !checked || index === 0, onClick: () => move(item.id, -1), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-up" }) }),
      /* @__PURE__ */ jsx(IconButton, { size: "small", style: { visibility: checked ? void 0 : "hidden" }, "aria-hidden": !checked, label: `Move ${item.label} later`, disabled: !checked || index === selected.length - 1, onClick: () => move(item.id, 1), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" }) })
    ] }, item.id);
  }) });
}
function SharedHeaderSettings({ appID }) {
  const headers = useAvailableHeaderControls();
  const [selected, setSelected] = useState("");
  const config = headers.find((header) => header.appID === (appID ?? selected)) ?? (!appID ? headers[0] : void 0);
  if (!config) return /* @__PURE__ */ jsx(SettingsCard, { title: "Header", children: /* @__PURE__ */ jsx("p", { children: "Open an application header to choose its pinned icons." }) });
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    !appID && headers.length > 1 && /* @__PURE__ */ jsx(SettingsCard, { children: /* @__PURE__ */ jsx(SettingsRow, { label: "Application", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Header application", value: config.appID, options: headers.map((header) => ({ value: header.appID, label: header.name })), onChange: (event) => setSelected(event.target.value) }) }) }),
    /* @__PURE__ */ jsx(HeaderPins, { config }, config.appID)
  ] });
}
export {
  SharedHeaderSettings
};
