/** Native-text preservation and explicitly scoped work-area commands.
 * Empty chrome never invents a generic application menu. */
export declare function ApplicationContextMenu({ name, enabled }: {
    name: string;
    enabled?: boolean;
}): import("react").JSX.Element;
