import { jsx } from "react/jsx-runtime";
import packagedAssets0 from "@aether/assets/catalogs/fbb09378fa973b";
import { freecadIconCatalog } from "@aether/assets/icon-packs/freecad-graphite/catalog";
import { freecadToolIconMap } from "@aether/assets/icon-packs/freecad-graphite/tool-map";
import "./FreeCADIcon.css";
const files = packagedAssets0;
function FreeCADIcon({ name, palette = "auto", size = 32, label, className = "", style }) {
  const iconId = name in freecadToolIconMap ? freecadToolIconMap[name] : name;
  const palettes = palette === "auto" ? ["dark", "light"] : [palette];
  return /* @__PURE__ */ jsx(
    "span",
    {
      className: `aui-freecad-icon ${className}`,
      "data-palette": palette,
      role: label ? "img" : void 0,
      "aria-label": label,
      "aria-hidden": label ? void 0 : true,
      style: { width: size, height: size, ...style },
      children: palettes.map((mode) => /* @__PURE__ */ jsx(
        "img",
        {
          className: `aui-freecad-icon-${mode}`,
          alt: "",
          draggable: false,
          loading: "lazy",
          width: size,
          height: size,
          src: files[`../../assets/icon-packs/freecad-graphite/${mode}/${iconId}.svg`]
        },
        mode
      ))
    }
  );
}
export {
  FreeCADIcon,
  freecadIconCatalog,
  freecadToolIconMap
};
