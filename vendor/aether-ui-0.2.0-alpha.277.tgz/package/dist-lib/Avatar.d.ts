import "./WorkflowElements.css";
export interface AvatarProps {
    name: string;
    src?: string;
    size?: "small" | "standard";
}
/** Initials are always available if no portrait is supplied or it fails to load. */
export declare function Avatar({ name, src, size }: AvatarProps): import("react").JSX.Element;
