import { jsx } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { flattenFeatureItems } from "./feature-tree.js";
function featureTreePanelControls(items, available, can, dispatch, historyLength) {
  const rows = flattenFeatureItems(items);
  const controls = [];
  if (available.includes("visibility")) {
    for (const visible of [true, false]) {
      const ids = rows.filter((row) => Boolean(row.hidden) === visible).map((row) => row.id);
      const request = { command: "visibility", ids, value: visible };
      controls.push({
        id: visible ? "show-all" : "hide-all",
        label: visible ? "Show all" : "Hide all",
        icon: /* @__PURE__ */ jsx(AetherIcon, { name: visible ? "visible" : "hidden" }),
        disabled: !ids.length || !can(request),
        onClick: () => dispatch(request)
      });
    }
  }
  if (historyLength !== void 0 && available.includes("rollback")) {
    const request = { command: "rollback", ids: [], index: historyLength };
    controls.push({
      id: "rollback-end",
      label: "Roll to end",
      icon: /* @__PURE__ */ jsx(AetherIcon, { name: "history" }),
      disabled: !can(request),
      onClick: () => dispatch(request)
    });
  }
  return controls;
}
export {
  featureTreePanelControls
};
