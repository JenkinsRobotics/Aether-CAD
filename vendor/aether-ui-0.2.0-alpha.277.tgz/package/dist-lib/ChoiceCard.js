import { jsx, jsxs } from "react/jsx-runtime";
import "./WorkflowElements.css";
function ChoiceCard({ name, value, label, description, detail, checked, onChange, disabled, children }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-choice-card", "data-selected": checked, "data-disabled": disabled || void 0, children: [
    /* @__PURE__ */ jsxs("label", { children: [
      /* @__PURE__ */ jsx("input", { type: "radio", name, value, checked, disabled, onChange: () => onChange(value) }),
      /* @__PURE__ */ jsxs("span", { children: [
        /* @__PURE__ */ jsx("strong", { children: label }),
        description && /* @__PURE__ */ jsx("small", { children: description })
      ] }),
      detail && /* @__PURE__ */ jsx("span", { className: "aui-choice-card-detail", children: detail })
    ] }),
    checked && children && /* @__PURE__ */ jsx("div", { className: "aui-choice-card-content", children })
  ] });
}
export {
  ChoiceCard
};
