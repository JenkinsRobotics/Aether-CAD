import { jsx, jsxs } from "react/jsx-runtime";
import { useId, useState } from "react";
import "./DashboardCharts.css";
const number = (n) => n.toLocaleString();
const short = (n) => n >= 1e3 ? `${(n / 1e3).toFixed(1)}k` : String(n);
function curve(points) {
  return points.map(([x, y], i) => {
    if (!i) return `M${x},${y}`;
    const p0 = points[Math.max(0, i - 2)], p1 = points[i - 1], p3 = points[Math.min(points.length - 1, i + 1)];
    const clamp = (v) => Math.max(Math.min(p1[1], y), Math.min(Math.max(p1[1], y), v));
    return `C${p1[0] + (x - p0[0]) / 6},${clamp(p1[1] + (y - p0[1]) / 6)} ${x - (p3[0] - p1[0]) / 6},${clamp(y - (p3[1] - p1[1]) / 6)} ${x},${y}`;
  }).join(" ");
}
function DashboardLineChart({ label, data, formatValue = number, selectedID, onSelect, maximum, axisFormat = short }) {
  const gradient = useId().replace(/:/g, "");
  const [hovered, setHovered] = useState(null);
  if (!data.length) return /* @__PURE__ */ jsx("div", { className: "aui-dashboard-empty", children: "No chart data." });
  const max = Math.max(1, maximum ?? Math.max(...data.map((p) => p.value)) * 1.15);
  const points = data.map((p, i) => [52 + i / Math.max(1, data.length - 1) * 308, 268 - Math.max(0, p.value) / max * 250]);
  const active = Math.max(0, data.findIndex((p) => p.id === (hovered ?? selectedID)));
  const [x, y] = points[active], tooltipX = Math.min(250, Math.max(56, x + 16)), tooltipY = Math.min(205, Math.max(10, y - 10));
  const path = curve(points);
  return /* @__PURE__ */ jsxs("svg", { className: "aui-dashboard-line-chart", viewBox: "0 0 380 310", role: "group", "aria-label": label, children: [
    /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsxs("linearGradient", { id: gradient, x1: "0", y1: "0", x2: "0", y2: "1", children: [
      /* @__PURE__ */ jsx("stop", { offset: "0%", stopColor: "currentColor", stopOpacity: ".17" }),
      /* @__PURE__ */ jsx("stop", { offset: "100%", stopColor: "currentColor", stopOpacity: "0" })
    ] }) }),
    [0, 1, 2, 3, 4].map((i) => /* @__PURE__ */ jsx("text", { className: "aui-dashboard-chart__axis", x: "2", y: 273 - i * 62.5, children: axisFormat(max * i / 4) }, i)),
    /* @__PURE__ */ jsx("path", { className: "aui-dashboard-chart__axis-line", d: "M50,18 V277 H364" }),
    /* @__PURE__ */ jsx("path", { d: `${path} L360,268 L52,268 Z`, fill: `url(#${gradient})` }),
    /* @__PURE__ */ jsx("path", { d: path, fill: "none", stroke: "currentColor", strokeWidth: "3" }),
    /* @__PURE__ */ jsx("line", { x1: x, x2: x, y1: "18", y2: "276", stroke: "currentColor", strokeOpacity: ".3", strokeDasharray: "3 4" }),
    data.map((point, i) => /* @__PURE__ */ jsxs("g", { children: [
      (i % 2 === 0 || data.length < 7) && /* @__PURE__ */ jsx("text", { className: "aui-dashboard-chart__axis", x: points[i][0], y: "304", textAnchor: "middle", children: point.label }),
      /* @__PURE__ */ jsx(
        "circle",
        {
          className: "aui-dashboard-chart__point",
          cx: points[i][0],
          cy: points[i][1],
          r: i === active ? 8 : 12,
          "data-active": i === active,
          tabIndex: 0,
          role: "button",
          "aria-label": `${point.label}: ${formatValue(point.value)}`,
          "aria-pressed": selectedID === point.id,
          onMouseEnter: () => setHovered(point.id),
          onMouseLeave: () => setHovered(null),
          onFocus: () => setHovered(point.id),
          onBlur: () => setHovered(null),
          onClick: () => onSelect?.(point.id),
          onKeyDown: (e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onSelect?.(point.id);
            }
          }
        }
      )
    ] }, point.id)),
    /* @__PURE__ */ jsxs("g", { className: "aui-dashboard-chart__tooltip", transform: `translate(${tooltipX} ${tooltipY})`, "aria-hidden": "true", children: [
      /* @__PURE__ */ jsx("rect", { width: "104", height: "65", rx: "10" }),
      /* @__PURE__ */ jsx("text", { x: "12", y: "24", children: data[active].label }),
      /* @__PURE__ */ jsx("text", { className: "aui-dashboard-chart__value", x: "12", y: "49", children: formatValue(data[active].value) })
    ] })
  ] });
}
function DashboardBarChart({ label, data, formatValue = number, selectedID, onSelect, axisFormat = short }) {
  const peak = Math.max(1, ...data.map((point) => point.value));
  const step = 10 ** Math.floor(Math.log10(peak / 4));
  const maximum = Math.ceil(peak / (step * 4)) * step * 4;
  return /* @__PURE__ */ jsxs("div", { className: "aui-dashboard-bar-chart", role: "group", "aria-label": label, children: [
    /* @__PURE__ */ jsx("div", { className: "aui-dashboard-bar-chart__axis", "aria-hidden": true, children: [1, 0.75, 0.5, 0.25, 0].map((n) => /* @__PURE__ */ jsx("span", { children: axisFormat(maximum * n) }, n)) }),
    /* @__PURE__ */ jsx("div", { className: "aui-dashboard-bar-chart__bars", children: data.map((point) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-label": `${point.label}: ${formatValue(point.value)}`, "aria-pressed": selectedID === point.id, onClick: () => onSelect?.(point.id), children: [
      /* @__PURE__ */ jsx("span", { className: "aui-dashboard-bar-chart__column", style: { height: `${Math.max(2, point.value / maximum * 100)}%` }, children: /* @__PURE__ */ jsx("span", { children: formatValue(point.value) }) }),
      /* @__PURE__ */ jsx("span", { className: "aui-dashboard-bar-chart__label", children: point.label })
    ] }, point.id)) })
  ] });
}
export {
  DashboardBarChart,
  DashboardLineChart
};
