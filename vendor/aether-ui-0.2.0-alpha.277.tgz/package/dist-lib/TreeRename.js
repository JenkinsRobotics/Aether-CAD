import { jsx } from "react/jsx-runtime";
import { useLayoutEffect, useRef, useState } from "react";
function TreeRename({ label, onCommit, onCancel }) {
  const [draft, setDraft] = useState(label);
  const input = useRef(null);
  const finished = useRef(false);
  useLayoutEffect(() => {
    input.current?.focus();
    input.current?.select();
  }, []);
  const finish = (cancel = false) => {
    if (finished.current) return;
    finished.current = true;
    const value = draft.trim();
    if (cancel || !value) onCancel();
    else onCommit(value);
  };
  return /* @__PURE__ */ jsx(
    "input",
    {
      ref: input,
      className: "aui-tree-rename",
      "aria-label": `Rename ${label}`,
      value: draft,
      onChange: (event) => setDraft(event.target.value),
      onClick: (event) => event.stopPropagation(),
      onBlur: () => finish(),
      onKeyDown: (event) => {
        event.stopPropagation();
        if (event.key === "Enter" || event.key === "Escape") {
          event.preventDefault();
          finish(event.key === "Escape");
        }
      }
    }
  );
}
export {
  TreeRename
};
