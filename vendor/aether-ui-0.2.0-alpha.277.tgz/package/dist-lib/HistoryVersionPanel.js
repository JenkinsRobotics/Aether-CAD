import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { HistoryPanel } from "./HistoryPanel.js";
import { PanelNotifications } from "./PanelNotifications.js";
import { SegmentedControl } from "./SegmentedControl.js";
import { SidePanelHeader } from "./SidePanelHeader.js";
import "./HistoryPanel.css";
function HistoryVersionPanel({ history, versions, initialTab = "history", storageKey }) {
  const [tab, setTab] = useState(() => {
    try {
      const saved = storageKey && sessionStorage.getItem(storageKey);
      if (saved === "history" || saved === "versions") return saved;
    } catch {
    }
    return initialTab;
  });
  const select = (value) => {
    const next = value === "versions" ? "versions" : "history";
    setTab(next);
    try {
      if (storageKey) sessionStorage.setItem(storageKey, next);
    } catch {
    }
  };
  return /* @__PURE__ */ jsx(PanelNotifications, { children: /* @__PURE__ */ jsxs("section", { className: "aui-history-versions", "aria-label": "History and version control", children: [
    /* @__PURE__ */ jsx(SidePanelHeader, { title: "History & versions", icon: "history" }),
    /* @__PURE__ */ jsx(SegmentedControl, { variant: "panel", ariaLabel: "History tabs", value: tab, onChange: select, options: [
      { id: "history", label: "History", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "history" }) },
      { id: "versions", label: "Version control", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "version-control" }) }
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-history-versions-page", hidden: tab !== "history", children: history ?? /* @__PURE__ */ jsx(HistoryPanel, { embedded: true, entries: [], emptyMessage: "This editor has no editing history to display yet." }) }),
    /* @__PURE__ */ jsx("div", { className: "aui-history-versions-page", hidden: tab !== "versions", children: versions })
  ] }) });
}
export {
  HistoryVersionPanel
};
