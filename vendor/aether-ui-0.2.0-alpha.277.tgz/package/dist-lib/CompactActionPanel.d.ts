import "./ConceptInspectors.css";
export interface CompactActionPanelProps {
    primaryLabel?: string;
    primaryShortcut?: string;
    settingsShortcut?: string;
    initialTheme?: "light" | "dark";
    onPrimary?: () => void;
    onSettings?: () => void;
}
/** Independent theme preview, matching the native compact command specimen. */
export declare function CompactActionPanel({ primaryLabel, primaryShortcut, settingsShortcut, initialTheme, onPrimary, onSettings }: CompactActionPanelProps): import("react").JSX.Element;
