import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { IconButton } from "./IconButton.js";
import "./DocumentNotesView.css";
function DocumentNotesView(props) {
  const editButton = useRef(null);
  const wasEditing = useRef(false);
  useEffect(() => {
    if (wasEditing.current && !props.editing) editButton.current?.focus();
    wasEditing.current = props.editing;
  }, [props.editing]);
  return /* @__PURE__ */ jsxs("section", { className: "aui-document-notes", "aria-label": "Document notes", children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-document-notes-header", children: [
      /* @__PURE__ */ jsx("h3", { children: "Document notes" }),
      /* @__PURE__ */ jsx(IconButton, { label: "Refresh document notes", disabled: props.busy, onClick: props.onRefresh, children: /* @__PURE__ */ jsx(AetherIcon, { name: "refresh" }) }),
      /* @__PURE__ */ jsx("span", { ref: (node) => {
        editButton.current = node?.querySelector("button") ?? null;
      }, children: /* @__PURE__ */ jsx(
        IconButton,
        {
          label: "Edit document notes",
          "aria-pressed": props.editing,
          disabled: !props.loaded || !props.canEdit || props.busy || props.editing,
          onClick: props.onEdit,
          children: /* @__PURE__ */ jsx(AetherIcon, { name: "pencil" })
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-document-notes-body", children: [
      props.error && /* @__PURE__ */ jsx("p", { role: "alert", children: props.error }),
      props.conflict,
      !props.loaded && !props.editing ? /* @__PURE__ */ jsx("p", { role: "status", children: "Loading document notes\u2026" }) : props.editing ? /* @__PURE__ */ jsxs("form", { onSubmit: (event) => {
        event.preventDefault();
        props.onSave();
      }, children: [
        /* @__PURE__ */ jsx(
          "textarea",
          {
            autoFocus: true,
            "aria-label": "Document notes text",
            value: props.text,
            onChange: (event) => props.onChange(event.target.value),
            maxLength: 5e4,
            rows: 12,
            disabled: props.busy,
            onKeyDown: (event) => {
              if (event.key === "Escape" && !props.busy) {
                event.preventDefault();
                event.stopPropagation();
                props.onCancel();
              }
            }
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "aui-document-notes-actions", children: [
          /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", disabled: props.busy || props.conflicted || !props.canEdit, children: "Save notes" }),
          /* @__PURE__ */ jsx(Button, { disabled: props.busy, onClick: props.onCancel, children: "Cancel" })
        ] })
      ] }) : /* @__PURE__ */ jsx("p", { className: "aui-document-notes-text", "data-empty": !props.savedText || void 0, children: props.savedText || "No document notes yet." })
    ] })
  ] });
}
export {
  DocumentNotesView
};
