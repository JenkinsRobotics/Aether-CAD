import type { DocumentConnection } from "./DocumentServices.js";
import "./StudioReview.css";
/** One approved review surface; both controllers stay mounted to retain drafts. */
export declare function DocumentReviewPanel({ connection, initialTab }: {
    connection: DocumentConnection;
    initialTab?: 'comments' | 'tasks';
}): import("react").JSX.Element;
