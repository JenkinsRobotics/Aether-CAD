import { jsx } from "react/jsx-runtime";
import { useLayoutEffect, useRef } from "react";
import { updateApplicationStatusBar } from "./application-status.js";
import "./ApplicationStatusBar.css";
function ApplicationStatusBar(props) {
  const ref = useRef(null);
  useLayoutEffect(() => {
    if (ref.current) updateApplicationStatusBar(ref.current, props);
  }, [props.appName, props.companyName, props.connection, props.connectionLabel, props.message]);
  return /* @__PURE__ */ jsx("footer", { ref });
}
export {
  ApplicationStatusBar
};
