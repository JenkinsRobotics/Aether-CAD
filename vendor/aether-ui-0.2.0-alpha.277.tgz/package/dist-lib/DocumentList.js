import { jsx, jsxs } from "react/jsx-runtime";
import { useRef } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { ListBoxRows } from "./ListBox.js";
import { SearchField } from "./SearchField.js";
import "./DocumentList.css";
function filterDocumentListItems(items, query) {
  const terms = query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  return items.filter((item) => {
    const text = [item.name, item.reference, item.version, item.revision, item.status?.label].filter(Boolean).join(" ").toLocaleLowerCase();
    return terms.every((term) => text.includes(term));
  });
}
function DocumentList({ items, selectedIDs, onSelect, onOpen, onContextMenu, query, onQueryChange, ariaLabel = "Documents", selectionMode = "multiple", height = 590, loading, error, toolbar }) {
  const search = useRef(null), root = useRef(null);
  const visible = filterDocumentListItems(items, query);
  const hiddenSelection = selectedIDs.size - visible.filter((item) => selectedIDs.has(item.id)).length;
  return /* @__PURE__ */ jsxs("div", { className: "aui-document-list", ref: root, onKeyDown: (event) => {
    const editable = event.target.closest('input, textarea, select, [contenteditable="true"]');
    if (event.key === "/" && !editable && !event.metaKey && !event.ctrlKey && !event.altKey) {
      event.preventDefault();
      search.current?.focus();
    }
    if (event.key === "ArrowDown" && event.target === search.current) {
      event.preventDefault();
      root.current?.querySelector('[role="option"][tabindex="0"]')?.focus();
    }
  }, children: [
    toolbar && /* @__PURE__ */ jsx("div", { className: "aui-document-list-toolbar", children: toolbar }),
    /* @__PURE__ */ jsxs("div", { className: "aui-document-list-search", children: [
      /* @__PURE__ */ jsx(SearchField, { value: query, onQueryChange, inputRef: search, ariaLabel: `Search ${ariaLabel.toLowerCase()}`, placeholder: "Search documents" }),
      !query && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-document-list-shortcut", "aria-label": "Focus document search", title: "Search \xB7 / while the list is focused", onClick: () => search.current?.focus(), children: /* @__PURE__ */ jsx("kbd", { children: "/" }) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-document-list-scroll", style: { maxHeight: height }, children: /* @__PURE__ */ jsx(
      ListBoxRows,
      {
        items: visible.map((item) => ({
          id: item.id,
          label: item.name,
          description: item.reference,
          disabled: item.disabled,
          icon: item.thumbnail ?? /* @__PURE__ */ jsx(AetherIcon, { name: "document", width: 24, height: 24 }),
          accessory: /* @__PURE__ */ jsxs("span", { className: "aui-document-list-metadata", children: [
            item.version && /* @__PURE__ */ jsx("span", { className: "aui-document-list-version", "aria-label": `Version ${item.version}`, title: `Version ${item.version}`, children: item.version }),
            item.revision && /* @__PURE__ */ jsx("span", { className: "aui-document-list-revision", "data-outline": item.revisionStyle === "outline" || void 0, "aria-label": `Revision ${item.revision}`, title: `Revision ${item.revision}`, children: item.revision }),
            item.status && /* @__PURE__ */ jsxs("span", { className: "aui-document-list-status", "data-kind": item.status.kind, title: `${item.status.kind === "branch" ? "Branch" : "Status"}: ${item.status.label}`, children: [
              item.status.kind === "branch" && /* @__PURE__ */ jsx("span", { className: "aui-document-list-branch-dot", "aria-hidden": true }),
              item.status.label
            ] })
          ] })
        })),
        selectedIDs,
        onSelect,
        onActivate: onOpen,
        onContextMenu,
        selectionMode,
        ariaLabel,
        rowHeight: 58,
        height,
        loading,
        error,
        emptyState: query ? "No matching documents." : "No documents yet."
      }
    ) }),
    /* @__PURE__ */ jsxs("div", { className: "aui-document-list-footer", role: "status", children: [
      loading ? "Loading documents\u2026" : error ? "Documents unavailable" : `${visible.length} of ${items.length} documents`,
      !loading && !error && selectedIDs.size > 0 && /* @__PURE__ */ jsxs("span", { children: [
        selectedIDs.size,
        " selected",
        hiddenSelection > 0 && ` \xB7 ${hiddenSelection} hidden`,
        " ",
        /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Clear document selection", onClick: () => onSelect([], "single"), children: "Clear" })
      ] })
    ] })
  ] });
}
export {
  DocumentList,
  filterDocumentListItems
};
