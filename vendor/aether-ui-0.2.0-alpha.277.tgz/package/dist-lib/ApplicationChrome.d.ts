import { type MouseEvent } from "react";
import { type LaunchableApp } from "./AppLauncher.js";
import "./ApplicationChrome.css";
export interface ApplicationIdentityProps {
    id: string;
    name: string;
    homeUrl?: string;
    onHome?: (event: MouseEvent<HTMLAnchorElement>) => void;
    apps?: readonly LaunchableApp[];
    /** false when the app launcher is placed elsewhere (editor headers put it on the right). */
    launcher?: boolean;
    /** false shows the icon alone (home button), e.g. in an editor whose tabs carry the names. */
    showName?: boolean;
    /** Defaults to the approved wordmark; icon is retained for custom/legacy integrations. */
    identityStyle?: "icon" | "wordmark";
}
/** Host catalog is presentation data; the server decides which apps are visible. */
export declare function ApplicationIdentity({ id, name, homeUrl, onHome, apps, launcher, showName, identityStyle }: ApplicationIdentityProps): import("react").JSX.Element;
/** Own the host gear's Settings command while this application header is mounted.
 * Capture prevents retained editor listeners opening a second settings window. */
export declare function ApplicationSettings({ name, appID, onSettings, enabled }: {
    name: string;
    appID?: string;
    onSettings?: () => void;
    enabled?: boolean;
}): import("react").JSX.Element;
/** One settings gear followed by the host identity, also usable without a host. */
export declare function ApplicationAccountControls(): import("react").JSX.Element;
