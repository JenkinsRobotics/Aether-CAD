import { jsx, jsxs } from "react/jsx-runtime";
import { Button } from "./Button.js";
import "./ConceptWidgets.css";
function MaterialEditor({ name, color, type, channels, onNameChange, onColorChange, onChannelChange, onAssign }) {
  return /* @__PURE__ */ jsxs("section", { className: "aui-material-editor", "aria-label": "Material editor", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-material-editor__preview", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-material-editor__sphere", style: { "--material-color": color } }),
      /* @__PURE__ */ jsxs("div", { className: "aui-material-editor__identity", children: [
        /* @__PURE__ */ jsx("input", { "aria-label": "Material name", value: name, onChange: (event) => onNameChange?.(event.target.value) }),
        /* @__PURE__ */ jsx("select", { "aria-label": "Material type", defaultValue: type, children: /* @__PURE__ */ jsx("option", { children: type }) }),
        /* @__PURE__ */ jsxs("label", { className: "aui-material-editor__color", children: [
          /* @__PURE__ */ jsx("input", { "aria-label": "Material color", type: "color", value: color, onChange: (event) => onColorChange?.(event.target.value) }),
          color.toUpperCase()
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { children: channels.map((channel) => /* @__PURE__ */ jsxs("label", { className: "aui-material-editor__channel", children: [
      /* @__PURE__ */ jsx("span", { children: channel.label }),
      /* @__PURE__ */ jsx("input", { "aria-label": channel.label, type: "range", min: "0", max: "1", step: "0.01", value: channel.value, onChange: (event) => onChannelChange?.(channel.id, Number(event.target.value)) }),
      /* @__PURE__ */ jsx("output", { children: channel.value.toFixed(2) })
    ] }, channel.id)) }),
    /* @__PURE__ */ jsxs("div", { className: "aui-material-editor__actions", children: [
      /* @__PURE__ */ jsx(Button, { children: "Node Editor" }),
      /* @__PURE__ */ jsx(Button, { primary: true, onClick: onAssign, children: "Assign" })
    ] })
  ] });
}
export {
  MaterialEditor
};
