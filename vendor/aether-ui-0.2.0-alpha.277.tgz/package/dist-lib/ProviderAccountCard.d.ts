import type { ReactNode } from 'react';
import './ProviderAccountCard.css';
/** Personal provider presentation. Hosts own authentication, storage and actions. */
export interface ProviderAccountCardProps {
    name: string;
    publisher: string;
    icon: ReactNode;
    status: string;
    enabled?: boolean;
    capabilities?: ReactNode;
    account?: {
        connected: boolean;
        label?: string;
    };
    actions: ReactNode;
    children?: ReactNode;
    footer?: ReactNode;
}
export declare function ProviderAccountCard({ name, publisher, icon, status, enabled, capabilities, account, actions, children, footer }: ProviderAccountCardProps): import("react").JSX.Element;
