import { type TimelineTrack } from "./Timeline.js";
import "./ConceptInspectors.css";
export interface SequenceEditorProps {
    initialTracks: readonly TimelineTrack[];
    durationS?: number;
    initialMode?: "dope-sheet" | "curves" | "waypoints";
}
/** Local authoring specimen. Products supply evaluated motion to their renderer. */
export declare function SequenceEditor({ initialTracks, durationS, initialMode }: SequenceEditorProps): import("react").JSX.Element;
