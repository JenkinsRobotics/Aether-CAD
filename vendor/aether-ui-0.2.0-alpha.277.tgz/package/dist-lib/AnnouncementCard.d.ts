import { type AetherIconName } from "./AetherIcon.js";
import "./ConceptWidgets.css";
export interface AnnouncementItem {
    id: string;
    title: string;
    detail: string;
    icon?: AetherIconName;
    selected?: boolean;
}
export interface AnnouncementCardProps {
    badge?: string;
    title: string;
    detail: string;
    items?: readonly AnnouncementItem[];
    onDismiss?: () => void;
}
export declare function AnnouncementCard({ badge, title, detail, items, onDismiss }: AnnouncementCardProps): import("react").JSX.Element;
