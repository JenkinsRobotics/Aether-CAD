import { historyBranchKey, historyReferenceKey } from "./DocumentServices.js";
function milestoneChanges(row, history) {
  if (row.kind === "start") return [];
  const byID = new Map(history.revisions.map((save) => [save.revision, save]));
  const boundary = new Set(history.versions.filter((v) => row.kind === "workspace" || v.revision !== row.revision).map((v) => v.revision));
  const result = [], seen = /* @__PURE__ */ new Set();
  let id = row.revision;
  while (id != null && !seen.has(id)) {
    seen.add(id);
    if (boundary.has(id)) break;
    const save = byID.get(id);
    if (!save || save.parent_revision == null) break;
    result.push(save);
    id = save.parent_revision;
  }
  return result;
}
function visibleHistory(rows, history, branch, filter, automatic, query) {
  const allowed = new Set(filter === "workspaces" ? history.branches.map(historyBranchKey) : [branch]);
  if (filter === "parents") {
    const byID = new Map(history.revisions.map((save) => [save.revision, save]));
    let id = history.branches.find((b) => historyBranchKey(b) === branch)?.head_revision;
    const seen = /* @__PURE__ */ new Set();
    while (id != null && !seen.has(id)) {
      seen.add(id);
      const save = byID.get(id);
      if (!save) break;
      allowed.add(historyReferenceKey(save));
      id = save.parent_revision;
    }
  }
  const needle = query.trim().toLowerCase();
  return rows.filter((row) => (automatic || row.origin !== "automatic") && (needle || filter === "all" || row.kind === "start" || allowed.has(row.branchID ?? row.branch)) && (!needle || [row.name, row.author, row.message, ...milestoneChanges(row, history).map((s) => `${s.event} ${s.note} ${s.author}`)].join(" ").toLowerCase().includes(needle)));
}
function visibleParents(row, all, shown, merges) {
  const byID = new Map(all.map((item) => [item.id, item]));
  const visible = new Set(shown.map((item) => item.id));
  const found = /* @__PURE__ */ new Set(), seen = /* @__PURE__ */ new Set(), queue = [...merges ? row.parents : row.primaryParents];
  while (queue.length) {
    const id = queue.pop();
    if (seen.has(id)) continue;
    seen.add(id);
    const parent = byID.get(id);
    if (!parent) continue;
    if (visible.has(id)) found.add(id);
    else queue.push(...merges ? parent.parents : parent.primaryParents);
  }
  return [...found];
}
export {
  milestoneChanges,
  visibleHistory,
  visibleParents
};
