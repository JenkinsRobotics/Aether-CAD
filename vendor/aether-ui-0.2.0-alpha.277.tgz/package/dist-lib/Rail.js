import { jsx } from "react/jsx-runtime";
function Rail({ children, className, ...props }) {
  return /* @__PURE__ */ jsx("div", { ...props, className: ["aui-rail", className].filter(Boolean).join(" "), children });
}
function RailButton({ label, active, className, children, ...props }) {
  const classes = ["aui-rail-button"];
  if (active) classes.push("aui-rail-button--active");
  if (className) classes.push(className);
  return /* @__PURE__ */ jsx(
    "button",
    {
      ...props,
      type: "button",
      className: classes.join(" "),
      title: label,
      "aria-label": label,
      "aria-pressed": active ?? false,
      children
    }
  );
}
export {
  Rail,
  RailButton
};
