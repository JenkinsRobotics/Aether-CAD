import { jsx, jsxs } from "react/jsx-runtime";
import { DashboardCard } from "./DashboardCards.js";
import { SegmentedControl } from "./SegmentedControl.js";
import { SelectField } from "./SelectField.js";
import { Button } from "./Button.js";
import "./WorkflowWidgets.css";
function FieldMappingForm({ mode, onModeChange, fileName, itemCount, onUpdateFile, fields, columns, value, onChange, onContinue }) {
  const valid = fields.every((field) => !field.required || columns.includes(value[field.id]));
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title: "Map fields", className: "aui-workflow", children: /* @__PURE__ */ jsxs("div", { className: "aui-workflow-stack", children: [
    /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Import mode", value: mode, onChange: onModeChange, options: [{ id: "individual", label: "Individual" }, { id: "list", label: "Lead list" }] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-workflow-file", children: [
      /* @__PURE__ */ jsxs("span", { children: [
        /* @__PURE__ */ jsx("strong", { children: fileName }),
        /* @__PURE__ */ jsx("small", { children: itemCount })
      ] }),
      /* @__PURE__ */ jsx(Button, { onClick: onUpdateFile, children: "Update" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-workflow-map", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-workflow-hint", children: "Property" }),
      /* @__PURE__ */ jsx("span", { className: "aui-workflow-hint", children: "Column in your file" }),
      fields.map((field) => /* @__PURE__ */ jsxs("label", { className: "aui-workflow-map-row", children: [
        /* @__PURE__ */ jsxs("span", { children: [
          field.label,
          field.required ? " *" : ""
        ] }),
        /* @__PURE__ */ jsx(SelectField, { "aria-label": `Map ${field.label}`, value: value[field.id] ?? "", onChange: (e) => onChange({ ...value, [field.id]: e.target.value }), options: [{ value: "", label: "Select column" }, ...columns.map((column) => ({ value: column, label: column }))] })
      ] }, field.id))
    ] }),
    /* @__PURE__ */ jsx(Button, { primary: true, disabled: !valid, onClick: onContinue, children: "Continue" })
  ] }) });
}
export {
  FieldMappingForm
};
