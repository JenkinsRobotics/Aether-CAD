import type { InputHTMLAttributes } from "react";
export interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
    /** Marks the value invalid (error border + aria-invalid). */
    invalid?: boolean;
    /** Unit suffix rendered inside the field (e.g. "mm", "deg", "s"). */
    unit?: string;
}
/** Single-line inset text input, optionally with a unit suffix. */
export declare function TextField({ invalid, unit, className, style, ...rest }: TextFieldProps): import("react").JSX.Element;
