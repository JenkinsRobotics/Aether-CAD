import { type ReactNode } from "react";
import { type DocumentBarProps } from "./DocumentBar.js";
import "./StudioAppFrame.css";
export interface StudioDocumentBarProps extends DocumentBarProps {
    documentName?: string;
    /** Real branch/version and connection state supplied by the owning product. */
    documentState?: ReactNode;
    onSearch?: () => void;
    /** In-place search supplied by the app, using the shared CommandSearch. */
    search?: ReactNode;
    /** The document's own menu, shown left of its name as Onshape does (Jonathan, 2026-11-01). */
    documentMenu?: ReactNode;
}
/** Transparent document identity on the left; configurable utilities/account on the right. */
export declare function StudioDocumentBar({ documentName, documentState, documentMenu, onSearch, search, leading, trailing, className, ...props }: StudioDocumentBarProps): import("react").JSX.Element;
