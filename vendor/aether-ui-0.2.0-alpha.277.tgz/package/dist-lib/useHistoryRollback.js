import { jsx } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
function useHistoryRollback({ index, ids, disabled, onChange }) {
  const listRef = useRef(null);
  const markerRef = useRef(null);
  const drag = useRef(null);
  const [preview, setPreview] = useState(null);
  const cutoff = Math.max(0, Math.min(ids.length, index));
  const position = preview ?? cutoff;
  const cancel = () => {
    drag.current = null;
    setPreview(null);
  };
  const commit = (next) => {
    if (!disabled && next !== cutoff) onChange?.(next);
  };
  const indexAt = (y) => {
    const rows = listRef.current?.querySelectorAll("[data-history-rollback-index]") ?? [];
    for (const row of rows) {
      const rect = row.getBoundingClientRect();
      if (y < rect.top + rect.height / 2) return Number(row.dataset.historyRollbackIndex);
    }
    return ids.length;
  };
  const update = (y) => {
    if (!drag.current) return;
    drag.current.y = y;
    drag.current.index = indexAt(y);
    setPreview(drag.current.index);
  };
  const finish = (event) => {
    if (!drag.current || event.pointerId !== drag.current.pointer) return;
    const next = indexAt(event.clientY);
    cancel();
    commit(next);
    markerRef.current?.focus({ preventScroll: true });
  };
  const order = JSON.stringify(ids);
  useEffect(cancel, [order, cutoff, disabled]);
  useEffect(() => {
    if (preview === null) return;
    let frame = 0;
    const tick = () => {
      const list = listRef.current, active = drag.current;
      if (!list || !active) return;
      const rect = list.getBoundingClientRect();
      const distance = active.y < rect.top + 24 ? active.y - rect.top - 24 : active.y > rect.bottom - 24 ? active.y - rect.bottom + 24 : 0;
      if (distance) {
        const before = list.scrollTop;
        list.scrollTop += Math.max(-12, Math.min(12, distance / 3));
        if (list.scrollTop !== before) update(active.y);
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    const escape = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        cancel();
      }
    };
    window.addEventListener("blur", cancel);
    document.addEventListener("keydown", escape, true);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("blur", cancel);
      document.removeEventListener("keydown", escape, true);
    };
  }, [preview !== null]);
  const marker = /* @__PURE__ */ jsx("div", { role: "listitem", className: "aui-history-rollback-slot", children: /* @__PURE__ */ jsx(
    "button",
    {
      ref: markerRef,
      type: "button",
      role: "slider",
      "aria-label": "History rollback",
      "aria-orientation": "vertical",
      "aria-valuemin": 0,
      "aria-valuemax": ids.length,
      "aria-valuenow": position,
      "aria-valuetext": `${position} of ${ids.length} steps applied`,
      disabled,
      title: "Roll history \u2014 drag or use Up/Down, Home/End",
      className: "aui-history-rollback",
      onPointerDown: (event) => {
        if (disabled || event.button !== 0 || !listRef.current) return;
        event.preventDefault();
        event.stopPropagation();
        event.currentTarget.focus();
        listRef.current.setPointerCapture(event.pointerId);
        drag.current = { pointer: event.pointerId, y: event.clientY, index: cutoff };
        setPreview(cutoff);
      },
      onKeyDown: (event) => {
        const next = event.key === "ArrowUp" ? cutoff - 1 : event.key === "ArrowDown" ? cutoff + 1 : event.key === "Home" ? 0 : event.key === "End" ? ids.length : null;
        if (next !== null) {
          event.preventDefault();
          event.stopPropagation();
          if (!drag.current) commit(Math.max(0, Math.min(ids.length, next)));
        }
      }
    }
  ) }, "history-rollback");
  return { marker, position, listProps: {
    ref: listRef,
    onPointerMove: (event) => {
      if (event.pointerId === drag.current?.pointer) update(event.clientY);
    },
    onPointerUp: finish,
    onPointerCancel: cancel,
    onLostPointerCapture: cancel
  } };
}
export {
  useHistoryRollback
};
