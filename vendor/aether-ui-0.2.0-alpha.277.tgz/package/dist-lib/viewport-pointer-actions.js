function bindViewportPointerActions(canvas, actions) {
  let gesture = null;
  const cancel = () => {
    gesture = null;
  };
  const down = (event) => {
    if (gesture) {
      cancel();
      return;
    }
    gesture = {
      id: event.pointerId,
      button: event.button,
      x: event.clientX,
      y: event.clientY,
      moved: false,
      context: event.button === 2 || event.button === 0 && event.ctrlKey
    };
  };
  const move = (event) => {
    if (gesture?.id === event.pointerId && Math.hypot(event.clientX - gesture.x, event.clientY - gesture.y) > 4) gesture.moved = true;
  };
  const up = (event) => {
    if (!gesture || gesture.id !== event.pointerId) return;
    move(event);
    const finished = gesture;
    cancel();
    if (finished.moved || event.button !== finished.button) return;
    const rect = canvas.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) return;
    if (finished.context) actions.menu(event.clientX, event.clientY);
    else if (finished.button === 0) actions.pick(event);
  };
  const context = (event) => {
    event.preventDefault();
  };
  const key = (event) => {
    if (event.key !== "ContextMenu" && !(event.key === "F10" && event.shiftKey)) return;
    event.preventDefault();
    cancel();
    const rect = canvas.getBoundingClientRect();
    actions.menu(rect.left + rect.width / 2, rect.top + rect.height / 2);
  };
  canvas.addEventListener("pointerdown", down);
  canvas.addEventListener("contextmenu", context);
  canvas.addEventListener("keydown", key);
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", cancel);
  window.addEventListener("blur", cancel);
  return () => {
    cancel();
    canvas.removeEventListener("pointerdown", down);
    canvas.removeEventListener("contextmenu", context);
    canvas.removeEventListener("keydown", key);
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", cancel);
    window.removeEventListener("blur", cancel);
  };
}
export {
  bindViewportPointerActions
};
