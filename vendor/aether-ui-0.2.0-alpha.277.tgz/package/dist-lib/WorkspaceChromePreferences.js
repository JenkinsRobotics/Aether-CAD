import { useMemo, useSyncExternalStore } from "react";
const CHROME_PREFERENCES_KEY = "aether.workspace-chrome.v1";
const EVENT = "aether-workspace-chrome";
const options = {
  sidebarOpening: ["app", "inside", "outside"],
  sidebarAttachment: ["auto", "attached", "detached"],
  sidebarDesign: ["app", "rail", "tabs-top", "tabs-bottom"],
  tabSize: ["auto", "compact", "touch"],
  tabLabels: ["icons", "labels"],
  toolbarDensity: ["app", "compact", "standard", "expanded"],
  ribbonAppearance: ["app", "glass", "panel"],
  workspaceSelector: ["app", "column", "strip"],
  toolPopup: ["app", "list", "grid"],
  panelMotion: ["auto", "none"]
};
const DEFAULT_WORKSPACE_CHROME = Object.freeze({
  sidebarOpening: "app",
  sidebarAttachment: "attached",
  sidebarDesign: "app",
  tabSize: "auto",
  tabLabels: "icons",
  toolbarDensity: "app",
  ribbonAppearance: "app",
  workspaceSelector: "app",
  toolPopup: "app",
  panelMotion: "auto"
});
function readWorkspaceChrome(raw) {
  let value = {};
  try {
    const parsed = JSON.parse(raw ?? "{}");
    if (parsed && typeof parsed === "object") value = parsed;
  } catch {
  }
  if (value.sidebarAttachment === "auto") value.sidebarAttachment = "attached";
  return Object.fromEntries(Object.entries(options).map(([key, values]) => [
    key,
    values.includes(value[key]) ? value[key] : DEFAULT_WORKSPACE_CHROME[key]
  ]));
}
let volatileSnapshot = null;
function snapshot() {
  try {
    return localStorage.getItem(CHROME_PREFERENCES_KEY);
  } catch {
    return volatileSnapshot;
  }
}
function subscribe(listener) {
  window.addEventListener(EVENT, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(EVENT, listener);
    window.removeEventListener("storage", listener);
  };
}
function setWorkspaceChrome(patch) {
  const next = readWorkspaceChrome(JSON.stringify({ ...readWorkspaceChrome(snapshot()), ...patch }));
  volatileSnapshot = JSON.stringify(next);
  try {
    localStorage.setItem(CHROME_PREFERENCES_KEY, volatileSnapshot);
  } catch {
  }
  window.dispatchEvent(new Event(EVENT));
}
function useWorkspaceChrome() {
  const raw = useSyncExternalStore(subscribe, snapshot, () => null);
  return useMemo(() => readWorkspaceChrome(raw), [raw]);
}
function resolveSidebarAttachment(choice) {
  return choice === "detached" ? "detached" : "attached";
}
export {
  CHROME_PREFERENCES_KEY,
  DEFAULT_WORKSPACE_CHROME,
  readWorkspaceChrome,
  resolveSidebarAttachment,
  setWorkspaceChrome,
  useWorkspaceChrome
};
