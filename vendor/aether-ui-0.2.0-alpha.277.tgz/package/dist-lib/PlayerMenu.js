import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import "./PlayerMenu.css";
function PlayerMenu({ appName = "Aether", name, link, linked, detail, show, progress, tiles, columns = 4, onAction, info, infoTitle = "Info", keys = "Arrows choose \xB7 Enter selects \xB7 Esc closes the menu", popup, onPopupClose, contained = false }) {
  const grid = useRef(null), dialog = useRef(null);
  const [asking, setAsking] = useState(null);
  const shown = popup ?? asking;
  useEffect(() => {
    if (!shown) grid.current?.querySelector("button")?.focus();
  }, [shown]);
  useEffect(() => {
    if (shown) dialog.current?.querySelector("[data-default]")?.focus();
  }, [shown]);
  const close = () => {
    setAsking(null);
    onPopupClose?.();
  };
  const press = (tile) => {
    if (tile.id === "info") setAsking({ kind: "info", title: infoTitle, lines: info });
    else if (tile.confirm) setAsking({ kind: "warn", title: tile.confirm.title, detail: tile.confirm.detail, onYes: () => {
      setAsking(null);
      onAction(tile.id);
    } });
    else onAction(tile.id);
  };
  const move = (event) => {
    const step = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -columns, ArrowDown: columns }[event.key];
    if (step === void 0) return;
    event.preventDefault();
    if (shown) {
      const choices = [...dialog.current.querySelectorAll("button")];
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") choices[(choices.indexOf(document.activeElement) + 1) % choices.length]?.focus();
      return;
    }
    const buttons = [...grid.current.querySelectorAll("button")], at = buttons.indexOf(document.activeElement);
    buttons[Math.min(buttons.length - 1, Math.max(0, at < 0 ? 0 : at + step))]?.focus();
  };
  const menu = /* @__PURE__ */ jsxs("div", { className: contained ? "aui-player-menu is-contained" : "aui-player-menu", role: "dialog", "aria-label": `${name} menu`, onKeyDown: move, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-player-menu-top", children: [
      /* @__PURE__ */ jsx("strong", { className: "aui-player-menu-brand", children: appName }),
      /* @__PURE__ */ jsx("span", { className: "aui-player-menu-name", children: name }),
      /* @__PURE__ */ jsxs("span", { className: linked ? "aui-player-menu-link is-ok" : "aui-player-menu-link", children: [
        linked ? "\u25CF" : "\u25CB",
        " ",
        link
      ] }),
      detail && /* @__PURE__ */ jsx("span", { className: "aui-player-menu-detail", children: detail })
    ] }),
    progress && /* @__PURE__ */ jsxs("section", { className: "aui-player-menu-progress", "aria-label": progress.title, children: [
      /* @__PURE__ */ jsx("strong", { children: progress.title }),
      /* @__PURE__ */ jsx("div", { className: "aui-player-menu-bar", role: "progressbar", "aria-valuenow": progress.percent ?? 0, "aria-valuemin": 0, "aria-valuemax": 100, children: /* @__PURE__ */ jsx("div", { style: { width: `${progress.percent ?? 25}%` } }) }),
      /* @__PURE__ */ jsx("span", { children: progress.detail })
    ] }),
    show && /* @__PURE__ */ jsx("p", { className: "aui-player-menu-show", children: show }),
    /* @__PURE__ */ jsx("div", { ref: grid, className: "aui-player-menu-tiles", style: { gridTemplateColumns: `repeat(${columns}, 1fr)` }, children: tiles.map((tile) => /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => press(tile), children: [
      /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: tile.icon }),
      tile.label
    ] }, tile.id)) }),
    /* @__PURE__ */ jsx("p", { className: "aui-player-menu-keys", children: keys }),
    shown && /* @__PURE__ */ jsx("div", { className: "aui-player-menu-scrim", children: /* @__PURE__ */ jsxs("div", { ref: dialog, className: `aui-player-menu-card is-${shown.kind}`, role: "alertdialog", "aria-label": shown.title, children: [
      /* @__PURE__ */ jsx("span", { className: "aui-player-menu-icon", "aria-hidden": "true", children: { info: "i", ok: "\u2713", bad: "\u2715", warn: "!" }[shown.kind] }),
      /* @__PURE__ */ jsx("strong", { children: shown.title }),
      shown.detail && /* @__PURE__ */ jsx("p", { children: shown.detail }),
      shown.lines?.map((line) => /* @__PURE__ */ jsx("p", { className: "aui-player-menu-line", children: line }, line)),
      /* @__PURE__ */ jsxs("div", { className: "aui-player-menu-choices", children: [
        shown.onYes && /* @__PURE__ */ jsx("button", { type: "button", className: "is-yes", onClick: shown.onYes, children: "Yes" }),
        /* @__PURE__ */ jsx("button", { type: "button", "data-default": true, className: shown.onYes ? "is-no" : "", onClick: close, children: shown.onYes ? "No" : "OK" })
      ] })
    ] }) })
  ] });
  return contained ? /* @__PURE__ */ jsx("div", { className: "aui-player-menu-frame", children: menu }) : menu;
}
export {
  PlayerMenu
};
