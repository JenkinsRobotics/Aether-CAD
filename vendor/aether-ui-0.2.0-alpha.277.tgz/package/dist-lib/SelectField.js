import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
function SelectField({
  options,
  placeholder,
  invalid,
  icon,
  className,
  ...selectProps
}) {
  const classes = ["aui-select-field"];
  if (invalid) classes.push("aui-select-field--invalid");
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs("span", { className: "aui-select-field-wrap", "data-icon": icon ? "" : void 0, children: [
    icon ? /* @__PURE__ */ jsx("span", { className: "aui-select-field-icon", "aria-hidden": "true", children: icon }) : null,
    /* @__PURE__ */ jsxs(
      "select",
      {
        ...selectProps,
        className: classes.join(" "),
        "aria-invalid": invalid || void 0,
        children: [
          placeholder ? /* @__PURE__ */ jsx("option", { value: "", children: placeholder }) : null,
          options.map((option) => /* @__PURE__ */ jsx("option", { value: option.value, disabled: option.disabled, children: option.label }, option.value))
        ]
      }
    ),
    /* @__PURE__ */ jsx("span", { className: "aui-select-field-arrow", "aria-hidden": true, children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" }) })
  ] });
}
export {
  SelectField
};
