import "./WorkflowWidgets.css";
export interface AccountProfileValue {
    name: string;
    company: string;
}
export interface AccountProfileProps {
    value: AccountProfileValue;
    email: string;
    onChange: (value: AccountProfileValue) => void;
    onAction: (action: "api-key" | "email" | "password" | "delete") => void;
    onSave: () => void;
    onCancel: () => void;
}
export declare function AccountProfile({ value, email, onChange, onAction, onSave, onCancel }: AccountProfileProps): import("react").JSX.Element;
