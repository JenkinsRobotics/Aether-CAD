import type { CSSProperties } from "react";
import { type DocumentBarProps } from "./DocumentBar.js";
import { type WorkspaceShellProps } from "./WorkspaceShell.js";
import { type WorkspaceRibbonProps } from "./WorkspaceRibbon.js";
import "./RibbonWorkspaceShell.css";
export interface RibbonWorkspaceShellProps extends Omit<WorkspaceShellProps, "toolbar" | "style"> {
    /** Document identity and account/chrome slots. Workspace switching lives in the ribbon. */
    documentBar: Omit<DocumentBarProps, "center">;
    ribbon: WorkspaceRibbonProps;
    className?: string;
    /** Give the shell a bounded height, or place it in a parent with a definite height. */
    style?: CSSProperties;
}
/** Document header and tabbed ribbon layout. Uses the same retained viewport,
 * rails, dockable panels, bottom panel, and status bar as WorkspaceShell. */
export declare function RibbonWorkspaceShell({ documentBar, ribbon, className, style, preservePanelContent, ...workspace }: RibbonWorkspaceShellProps): import("react").JSX.Element;
