import "./WorkflowWidgets.css";
export interface TextVariantsProps {
    tone: string;
    onToneChange: (value: string) => void;
    length: number;
    onLengthChange: (value: number) => void;
    variants: readonly {
        id: string;
        text: string;
    }[];
    selected: string;
    onSelect: (id: string) => void;
    onMore: () => void;
}
export declare function TextVariants({ tone, onToneChange, length, onLengthChange, variants, selected, onSelect, onMore }: TextVariantsProps): import("react").JSX.Element;
