import { jsx, jsxs } from "react/jsx-runtime";
import { useId } from "react";
import "./ApplicationSplash.css";
const phaseLabels = { pending: "Waiting", running: "Loading", done: "Ready", failed: "Unavailable" };
function ApplicationSplash({ appName, tagline, version, artworkUrl, headline, detail, progress, state = "loading", stages = [], footnote, actions }) {
  const id = useId();
  const fraction = typeof progress === "number" && Number.isFinite(progress) ? Math.min(1, Math.max(0, progress)) : void 0;
  return /* @__PURE__ */ jsxs("section", { className: "aui-application-splash", "data-state": state, "aria-labelledby": id, "aria-busy": state === "loading", children: [
    /* @__PURE__ */ jsx("div", { className: "aui-splash-art", "aria-hidden": "true", children: artworkUrl && /* @__PURE__ */ jsx("img", { src: artworkUrl, alt: "" }) }),
    /* @__PURE__ */ jsxs("div", { className: "aui-splash-brand", children: [
      /* @__PURE__ */ jsx("span", { children: "Aether" }),
      version && /* @__PURE__ */ jsx("span", { children: version })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-splash-panel", children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-splash-copy", children: [
        tagline && /* @__PURE__ */ jsx("p", { className: "aui-splash-tagline", children: tagline }),
        /* @__PURE__ */ jsx("h1", { id, children: appName }),
        /* @__PURE__ */ jsxs("div", { className: "aui-splash-status", role: state === "error" ? "alert" : "status", "aria-live": state === "error" ? "assertive" : "polite", "aria-atomic": "true", children: [
          /* @__PURE__ */ jsx("h2", { children: headline }),
          detail && /* @__PURE__ */ jsx("p", { children: detail })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-splash-progress-row", children: [
          /* @__PURE__ */ jsx("progress", { "aria-label": `${appName} startup progress`, max: 1, value: fraction }),
          /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: fraction === void 0 ? "" : `${Math.round(fraction * 100)}%` })
        ] }),
        footnote && /* @__PURE__ */ jsx("p", { className: "aui-splash-footnote", children: footnote }),
        actions && /* @__PURE__ */ jsx("div", { className: "aui-splash-actions", children: actions })
      ] }),
      stages.length > 0 && /* @__PURE__ */ jsx("ol", { className: "aui-splash-stages", "aria-label": "Startup stages", children: stages.map((stage) => /* @__PURE__ */ jsxs("li", { "data-phase": stage.phase, children: [
        /* @__PURE__ */ jsx("span", { className: "aui-splash-dot", "aria-hidden": "true" }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "aui-splash-stage-title", children: [
            /* @__PURE__ */ jsx("strong", { children: stage.title }),
            /* @__PURE__ */ jsx("span", { children: phaseLabels[stage.phase] })
          ] }),
          stage.detail && /* @__PURE__ */ jsx("p", { children: stage.detail })
        ] })
      ] }, stage.id)) })
    ] })
  ] });
}
export {
  ApplicationSplash
};
