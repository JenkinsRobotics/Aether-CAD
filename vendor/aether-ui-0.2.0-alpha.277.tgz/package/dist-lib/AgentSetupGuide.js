import { jsx, jsxs } from "react/jsx-runtime";
import { SelectField } from "./SelectField.js";
import "./AgentSetupGuide.css";
function AgentSetupGuide({ clients, client, onClientChange, description, steps }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-agent-setup", children: [
    /* @__PURE__ */ jsxs("label", { className: "aui-agent-setup__client", children: [
      "Your agent",
      /* @__PURE__ */ jsx(SelectField, { "aria-label": "Your agent", value: client, options: clients, onChange: (event) => onClientChange(event.target.value) })
    ] }),
    description && /* @__PURE__ */ jsx("div", { className: "aui-agent-setup__description", children: description }),
    /* @__PURE__ */ jsx("ol", { className: "aui-agent-setup__steps", children: steps.map((step, index) => /* @__PURE__ */ jsxs("li", { children: [
      /* @__PURE__ */ jsx("span", { className: "aui-agent-setup__number", "aria-hidden": "true", children: index + 1 }),
      /* @__PURE__ */ jsxs("section", { "aria-label": step.title, children: [
        /* @__PURE__ */ jsx("h3", { children: step.title }),
        step.content
      ] })
    ] }, step.id)) })
  ] });
}
export {
  AgentSetupGuide
};
