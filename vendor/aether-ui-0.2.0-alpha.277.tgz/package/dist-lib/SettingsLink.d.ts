import type { ButtonHTMLAttributes } from "react";
import "./WorkflowElements.css";
export interface SettingsLinkProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    label: string;
    description?: string;
    destructive?: boolean;
}
export declare function SettingsLink({ label, description, destructive, className, ...props }: SettingsLinkProps): import("react").JSX.Element;
