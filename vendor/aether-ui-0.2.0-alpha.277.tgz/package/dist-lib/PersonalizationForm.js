import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { DashboardCard } from "./DashboardCards.js";
import { SegmentedControl } from "./SegmentedControl.js";
import { TextField } from "./TextField.js";
import { FileField } from "./FileField.js";
import { Button } from "./Button.js";
import "./WorkflowWidgets.css";
function PersonalizationForm({ onImport }) {
  const [kind, setKind] = useState("website"), [url, setURL] = useState(""), [files, setFiles] = useState([]), [notes, setNotes] = useState("");
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title: "Personalize", className: "aui-workflow", children: /* @__PURE__ */ jsxs("form", { className: "aui-workflow-stack", onSubmit: (e) => {
    e.preventDefault();
    onImport({ kind, url, files, notes });
  }, children: [
    /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Source type", value: kind, onChange: setKind, options: [{ id: "website", label: "Website" }, { id: "document", label: "Document" }, { id: "manual", label: "Manual" }] }),
    kind === "website" ? /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Company URL",
      /* @__PURE__ */ jsx(TextField, { type: "url", required: true, value: url, onChange: (e) => setURL(e.target.value), placeholder: "https://company.com" })
    ] }) : kind === "document" ? /* @__PURE__ */ jsx(FileField, { label: "Company document", files, onFilesChange: setFiles, accept: ".pdf,.txt,.docx" }) : /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Company information",
      /* @__PURE__ */ jsx("textarea", { required: true, value: notes, onChange: (e) => setNotes(e.target.value), placeholder: "Describe your audience and value proposition" })
    ] }),
    /* @__PURE__ */ jsx("p", { className: "aui-workflow-hint", children: "Add your audience and value proposition from a source, or enter them manually." }),
    /* @__PURE__ */ jsx(Button, { type: "submit", disabled: kind === "document" && !files.length, children: "Import source" })
  ] }) });
}
export {
  PersonalizationForm
};
