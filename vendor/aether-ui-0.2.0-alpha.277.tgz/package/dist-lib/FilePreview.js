import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import "./FilePreview.css";
function previewKind(name) {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  if (["png", "jpg", "jpeg", "gif", "webp", "avif", "bmp", "svg", "ico"].includes(ext)) return "image";
  if (ext === "pdf") return "pdf";
  if (["mp4", "webm", "ogv", "mov"].includes(ext)) return "video";
  if (["mp3", "wav", "ogg", "m4a", "flac"].includes(ext)) return "audio";
  if (["txt", "md", "json", "csv", "log", "yml", "yaml", "xml", "svg"].includes(ext)) return "text";
  return "none";
}
function canPreview(name) {
  return previewKind(name) !== "none";
}
function FilePreview({ name, url, detail, onClose, onOpen, onDownload, onPrevious, onNext }) {
  const kind = previewKind(name);
  const [text, setText] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    if (kind !== "text") {
      setText(null);
      return;
    }
    let live = true;
    setText(null);
    setError("");
    fetch(url).then((response) => response.ok ? response.text() : Promise.reject(new Error("The file could not be read."))).then((body) => {
      if (live) setText(body.slice(0, 2e5));
    }).catch((e) => {
      if (live) setError(e.message);
    });
    return () => {
      live = false;
    };
  }, [url, kind]);
  useEffect(() => {
    const onKey = (event) => {
      if (event.key === "Escape") onClose();
      else if (event.key === "ArrowLeft" && onPrevious) onPrevious();
      else if (event.key === "ArrowRight" && onNext) onNext();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose, onPrevious, onNext]);
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: "aui-file-preview-scrim",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": `Preview of ${name}`,
      onClick: (event) => {
        if (event.target === event.currentTarget) onClose();
      },
      children: /* @__PURE__ */ jsxs("div", { className: "aui-file-preview", children: [
        /* @__PURE__ */ jsxs("header", { children: [
          /* @__PURE__ */ jsxs("span", { className: "aui-file-preview-name", children: [
            /* @__PURE__ */ jsx("strong", { title: name, children: name }),
            detail ? /* @__PURE__ */ jsx("small", { children: detail }) : null
          ] }),
          onOpen ? /* @__PURE__ */ jsx("button", { type: "button", className: "aui-file-preview-open", onClick: onOpen, children: "Open" }) : null,
          onDownload ? /* @__PURE__ */ jsx(IconButton, { label: "Download", onClick: onDownload, children: /* @__PURE__ */ jsx(AetherIcon, { name: "export" }) }) : null,
          /* @__PURE__ */ jsx(IconButton, { label: "Close preview", onClick: onClose, children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-file-preview-stage", "data-kind": kind, children: [
          onPrevious ? /* @__PURE__ */ jsx(IconButton, { label: "Previous file", className: "aui-file-preview-step", onClick: onPrevious, children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-left" }) }) : null,
          kind === "image" ? /* @__PURE__ */ jsx("img", { src: url, alt: name }) : null,
          kind === "pdf" ? /* @__PURE__ */ jsx("iframe", { src: url, title: `Preview of ${name}` }) : null,
          kind === "video" ? /* @__PURE__ */ jsx("video", { src: url, controls: true, preload: "metadata" }) : null,
          kind === "audio" ? /* @__PURE__ */ jsx("audio", { src: url, controls: true, preload: "metadata" }) : null,
          kind === "text" ? error ? /* @__PURE__ */ jsx("p", { className: "aui-file-preview-none", children: error }) : text === null ? /* @__PURE__ */ jsx("p", { className: "aui-file-preview-none", children: "Loading\u2026" }) : /* @__PURE__ */ jsx("pre", { children: text }) : null,
          kind === "none" ? /* @__PURE__ */ jsxs("p", { className: "aui-file-preview-none", children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "document-text", "aria-hidden": "true" }),
            "No preview for this kind of file. Download it, or open it in its app."
          ] }) : null,
          onNext ? /* @__PURE__ */ jsx(IconButton, { label: "Next file", className: "aui-file-preview-step", onClick: onNext, children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right" }) }) : null
        ] })
      ] })
    }
  );
}
export {
  FilePreview,
  canPreview,
  previewKind
};
