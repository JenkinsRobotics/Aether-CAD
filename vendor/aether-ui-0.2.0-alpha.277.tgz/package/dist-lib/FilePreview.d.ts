import "./FilePreview.css";
/**
 * Preview for a stored file, the way a drive shows you what something is
 * before you commit to opening it (Jonathan, 2026-10-04).
 *
 * The browser already renders images, PDFs, video and audio; this hands each
 * one to the element that knows how, and says plainly when it cannot. The
 * alternative — a thumbnail service — is a lot of machinery for a preview the
 * browser gives away, and it would need a second code path for every format.
 *
 * Presentation only: it is given a URL and a name, so Drive, the app libraries
 * and anything else with a content endpoint can use the same component.
 */
export type PreviewKind = "image" | "pdf" | "video" | "audio" | "text" | "none";
/** What the browser can show, decided by extension. */
export declare function previewKind(name: string): PreviewKind;
export declare function canPreview(name: string): boolean;
export interface FilePreviewProps {
    name: string;
    /** Where the bytes are. The component never builds this itself. */
    url: string;
    /** Shown under the name — size, owner, modified date, whatever fits. */
    detail?: string;
    onClose: () => void;
    /** Offered beside Close when the file can be opened in its editor. */
    onOpen?: () => void;
    onDownload?: () => void;
    /** Step through a selection without closing. */
    onPrevious?: () => void;
    onNext?: () => void;
}
export declare function FilePreview({ name, url, detail, onClose, onOpen, onDownload, onPrevious, onNext }: FilePreviewProps): import("react").JSX.Element;
