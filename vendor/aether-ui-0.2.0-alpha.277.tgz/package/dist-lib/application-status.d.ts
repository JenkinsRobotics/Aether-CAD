/** Presentation only. The application/session adapter supplies confirmed state. */
export type ApplicationConnection = "connecting" | "connected" | "offline" | "local";
export interface ApplicationStatusProps {
    appName: string;
    companyName?: string;
    connection: ApplicationConnection;
    connectionLabel?: string;
    message?: string;
}
/** The single DOM renderer shared by React and the pre-React hosted bootstrap. */
export declare function updateApplicationStatusBar(row: HTMLElement, props: ApplicationStatusProps): void;
export declare function createApplicationStatusBar(props: ApplicationStatusProps, owner?: Document): HTMLElement;
