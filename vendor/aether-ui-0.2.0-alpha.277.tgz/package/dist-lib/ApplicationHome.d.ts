import type { ReactNode } from "react";
import type { LaunchableApp } from "./AppLauncher.js";
import "./ApplicationHome.css";
/** Shared product-library frame. Products own navigation, storage and actions. */
export declare function ApplicationHomeFrame({ children, className, layout, design }: {
    children: ReactNode;
    className?: string;
    /** "sidebar": the ApplicationSidebar runs full height and owns identity and account. */
    layout?: "header" | "sidebar";
    design?: "standard" | "studio";
}): import("react").JSX.Element;
/** The same library header for hosted libraries and local-first applications. */
export declare function ApplicationHomeHeader({ app, name, apps, search, className, identity, onSettings, design }: {
    app: string;
    name: string;
    apps: readonly LaunchableApp[];
    search?: ReactNode;
    className?: string;
    /** false when an ApplicationSidebar shows the product, account and app launcher: keeps search only. */
    identity?: boolean;
    design?: "standard" | "studio";
    onSettings?: () => void;
}): import("react").JSX.Element;
