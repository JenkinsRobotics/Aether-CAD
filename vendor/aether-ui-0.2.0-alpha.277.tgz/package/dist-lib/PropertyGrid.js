import { jsx, jsxs } from "react/jsx-runtime";
import { useMemo, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Inspector } from "./Inspector.js";
import { FieldRow } from "./FieldRow.js";
function PropertyGrid({
  sections,
  ariaLabel,
  filter,
  modifiedOnly = false,
  collapsedIDs,
  defaultCollapsedIDs,
  onToggleSection,
  emptyState,
  className
}) {
  const [internalCollapsed, setInternalCollapsed] = useState(
    () => new Set(defaultCollapsedIDs ?? [])
  );
  const query = (filter ?? "").trim().toLocaleLowerCase();
  const visible = useMemo(
    () => sections.map((section) => ({
      ...section,
      properties: section.properties.filter((property) => {
        if (modifiedOnly && !property.modified) return false;
        if (!query) return true;
        return `${section.label} ${property.label}`.toLocaleLowerCase().includes(query);
      })
    })).filter((section) => section.properties.length > 0),
    [modifiedOnly, query, sections]
  );
  const toggle = (id) => {
    const collapsed = collapsedIDs ? collapsedIDs.has(id) : internalCollapsed.has(id);
    onToggleSection?.(id, collapsed);
    if (!collapsedIDs) {
      setInternalCollapsed((current) => {
        const next = new Set(current);
        if (collapsed) next.delete(id);
        else next.add(id);
        return next;
      });
    }
  };
  return /* @__PURE__ */ jsx(Inspector, { children: /* @__PURE__ */ jsx(
    "div",
    {
      className: ["aui-property-grid", className].filter(Boolean).join(" "),
      role: "region",
      "aria-label": ariaLabel,
      children: visible.length === 0 ? /* @__PURE__ */ jsx("div", { className: "aui-property-grid-empty", children: emptyState ?? "No properties" }) : visible.map((section) => {
        const collapsed = collapsedIDs ? collapsedIDs.has(section.id) : internalCollapsed.has(section.id);
        return /* @__PURE__ */ jsxs("section", { className: "aui-property-section", children: [
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              className: "aui-property-section-heading",
              "aria-expanded": !collapsed,
              onClick: () => toggle(section.id),
              children: [
                /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: /* @__PURE__ */ jsx(AetherIcon, { name: collapsed ? "chevron-right" : "chevron-down" }) }),
                /* @__PURE__ */ jsx("strong", { children: section.label }),
                section.badge ? /* @__PURE__ */ jsx("small", { children: section.badge }) : null
              ]
            }
          ),
          !collapsed ? /* @__PURE__ */ jsx("div", { className: "aui-property-section-body", children: section.properties.map((property) => /* @__PURE__ */ jsx(
            "div",
            {
              className: `aui-property-item${property.readOnly ? " aui-property-item--readonly" : ""}`,
              children: /* @__PURE__ */ jsx(
                FieldRow,
                {
                  label: property.label,
                  help: property.help,
                  error: property.error,
                  modified: property.modified,
                  onReset: property.readOnly ? void 0 : property.onReset,
                  children: /* @__PURE__ */ jsxs("div", { className: "aui-property-editor", "aria-readonly": property.readOnly || void 0, children: [
                    property.editor,
                    property.mixed ? /* @__PURE__ */ jsx("span", { className: "aui-property-mixed", children: "Mixed" }) : null
                  ] })
                }
              )
            },
            property.id
          )) }) : null
        ] }, section.id);
      })
    }
  ) });
}
export {
  PropertyGrid
};
