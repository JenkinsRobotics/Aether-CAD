import type { ReactNode } from "react";
export type PanelPlacement = "docked" | "floating" | "hidden";
export interface PanelPlacementMenuProps {
    label: string;
    placement: PanelPlacement;
    onChange: (placement: PanelPlacement) => void;
    className?: string;
    children?: ReactNode;
}
/** Product-free panel placement control. Applications own persistence and
 * decide what each stable panel ID means. */
export declare function PanelPlacementMenu({ label, placement, onChange, className, children, }: PanelPlacementMenuProps): import("react").JSX.Element;
