import { type ReactNode } from 'react';
import { type MenuItem } from './Menu.js';
import './CollectionView.css';
export interface CollectionControl {
    id: string;
    label: string;
    icon: ReactNode;
    disabled?: boolean;
    separatorBefore?: boolean;
    scope?: 'row' | 'panel';
    shortcut?: 'Delete' | 'F2';
    onClick: () => void;
}
/** Docking remains owned by WorkspaceShell; its commands join the collection menu. */
export declare const CollectionHost: import("react").Context<{
    title?: string;
    controls?: readonly CollectionControl[];
}>;
/** Collection headers expose creation only; all commands remain in context menus. */
export declare function CollectionActions({ controls, primaryControls, label, items, onCommand }: {
    controls?: readonly CollectionControl[];
    primaryControls?: readonly CollectionControl[];
    label?: string;
    items?: readonly MenuItem[];
    onCommand?: (id: string) => void;
}): import("react").JSX.Element | null;
export declare function CollectionView({ title, headerActions, filter, children, footer, controls, primaryControls, controlsLabel, menuItems, onCommand, showFooter, actionPlacement, className, id, onKeyDown, onContextMenu }: {
    title?: string;
    headerActions?: ReactNode;
    filter?: ReactNode;
    children: ReactNode;
    footer?: ReactNode;
    controls?: readonly CollectionControl[];
    primaryControls?: readonly CollectionControl[];
    controlsLabel?: string;
    menuItems?: readonly MenuItem[];
    onCommand?: (id: string) => void;
    showFooter?: boolean;
    /** Compact authoring trees keep creation and options beside the title, without a footer row. */
    actionPlacement?: 'header' | 'footer';
    className?: string;
    id?: string;
    onKeyDown?: React.KeyboardEventHandler<HTMLDivElement>;
    onContextMenu?: React.MouseEventHandler<HTMLDivElement>;
}): import("react").JSX.Element;
