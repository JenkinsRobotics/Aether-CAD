import type { ReactNode } from "react";
import "./WorkflowElements.css";
export interface ChoiceCardProps {
    name: string;
    value: string;
    label: string;
    description?: string;
    detail?: ReactNode;
    checked: boolean;
    onChange: (value: string) => void;
    disabled?: boolean;
    children?: ReactNode;
}
/** Native radio semantics; interactive selected content stays outside its label. */
export declare function ChoiceCard({ name, value, label, description, detail, checked, onChange, disabled, children }: ChoiceCardProps): import("react").JSX.Element;
