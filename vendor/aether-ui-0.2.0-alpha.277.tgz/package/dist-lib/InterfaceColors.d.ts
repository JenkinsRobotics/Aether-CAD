/** Browser-local interface overrides. Separate light/dark palettes preserve readability. */
export declare const interfaceColorFields: readonly [readonly ["bg-app", "Page background"], readonly ["bg-shell", "Workspace background"], readonly ["bg-panel", "Panels and cards"], readonly ["bg-bar", "Toolbars and sidebar"], readonly ["bg-inset", "Input backgrounds"], readonly ["border", "Borders"], readonly ["accent", "Accent"], readonly ["text", "Text"], readonly ["text-dim", "Secondary text"]];
export type InterfaceColorToken = typeof interfaceColorFields[number][0];
export type InterfaceColors = Partial<Record<InterfaceColorToken, string>>;
export type ColorMode = "light" | "dark";
export declare const INTERFACE_COLORS_KEY = "aether-interface-colors-v1";
export declare function validateInterfaceColors(input: unknown): InterfaceColors;
export declare function readInterfaceColors(mode: ColorMode): InterfaceColors;
export declare function resolvedInterfaceMode(): ColorMode;
export declare function applyInterfaceColors(): void;
export declare function setInterfaceColors(mode: ColorMode, colors: InterfaceColors): void;
export declare const neutralInterfaceColors: Record<ColorMode, InterfaceColors>;
