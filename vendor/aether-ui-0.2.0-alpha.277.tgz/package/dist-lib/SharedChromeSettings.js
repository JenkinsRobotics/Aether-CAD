import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { SettingsCard, SettingsRow } from "./SettingsWindow.js";
import { SelectField } from "./SelectField.js";
import { Button } from "./Button.js";
import { SharedWorkspaceSettings } from "./SharedWorkspaceSettings.js";
import { DEFAULT_WORKSPACE_CHROME, setWorkspaceChrome, useWorkspaceChrome } from "./WorkspaceChromePreferences.js";
function SharedChromeSettings() {
  const prefs = useWorkspaceChrome();
  const field = (key, label, choices) => /* @__PURE__ */ jsx(
    SelectField,
    {
      "aria-label": label,
      value: prefs[key],
      options: choices.map(([value, text]) => ({ value, label: text })),
      onChange: (event) => setWorkspaceChrome({ [key]: event.target.value })
    }
  );
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(SettingsCard, { title: "Sidebar tabs", caption: "Shared across Aether apps in this browser. App default preserves each app\u2019s existing layout choice.", children: [
      /* @__PURE__ */ jsx(SettingsRow, { label: "Tab placement", children: field("sidebarDesign", "Sidebar tab placement", [["app", "App default"], ["rail", "Side rail"], ["tabs-top", "Top tabs"], ["tabs-bottom", "Bottom tabs"]]) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Opening direction", caption: "Inside places the tabs at the outer edge. Outside places the editor between the tabs and that edge. Both collapse to the selected workspace edge.", children: field("sidebarOpening", "Sidebar opening direction", [["app", "App default"], ["inside", "Inside \xB7 toward workspace"], ["outside", "Outside \xB7 toward window edge"]]) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Container", caption: "Combined is the standard at every window size: one continuous background and border around icons and content. Detached is an optional secondary design.", children: field("sidebarAttachment", "Sidebar container", [["attached", "Combined card \xB7 default"], ["detached", "Detached tray \xB7 secondary"]]) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Tab size", caption: "Automatic uses 36 px cells with 20 px icons. Compact uses 30 px cells with 18 px icons; Touch uses 44 px cells with 26 px icons. Attached and detached trays always match.", children: field("tabSize", "Sidebar tab size", [["auto", "Automatic"], ["compact", "Compact"], ["touch", "Touch"]]) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Tab labels", children: field("tabLabels", "Sidebar tab labels", [["icons", "Icons only"], ["labels", "Icons and labels"]]) })
    ] }),
    /* @__PURE__ */ jsxs(SettingsCard, { title: "Toolbars", caption: "Density applies to both shared toolbar families. Ribbon appearance and workspace selector apply to WorkspaceRibbon; popup layout applies to the ToolSidebar family.", children: [
      /* @__PURE__ */ jsx(SettingsRow, { label: "Density", caption: "Compact opens groups from icons. Standard and Expanded expose the grouped tools; Expanded also exposes the workspace in ToolSidebar.", children: field("toolbarDensity", "Toolbar density", [["app", "App default"], ["compact", "Compact"], ["standard", "Standard"], ["expanded", "Expanded"]]) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Ribbon appearance", children: field("ribbonAppearance", "Ribbon appearance", [["app", "App default"], ["glass", "Glass"], ["panel", "Panel"]]) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Workspace selector", children: field("workspaceSelector", "Workspace selector", [["app", "App default"], ["column", "Leading column"], ["strip", "Tab strip"]]) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Tool group popup", children: field("toolPopup", "Tool group popup", [["app", "App default"], ["list", "List"], ["grid", "Grid"]]) })
    ] }),
    /* @__PURE__ */ jsxs(SettingsCard, { title: "Panel behavior", caption: "Standard sidebars open one panel per side. Click the active tab again to collapse it. Docked panels reserve workspace space; Floating panels overlay it. Change docking mode in the app\u2019s layout controls.", children: [
      /* @__PURE__ */ jsx(SettingsRow, { label: "Opening and closing", caption: "Automatic follows the system\u2019s reduced-motion preference.", children: field("panelMotion", "Panel animation", [["auto", "Animate \xB7 respect reduced motion"], ["none", "No animation"]]) }),
      /* @__PURE__ */ jsx(Button, { onClick: () => setWorkspaceChrome(DEFAULT_WORKSPACE_CHROME), children: "Restore toolbar and sidebar defaults" })
    ] }),
    /* @__PURE__ */ jsx(SharedWorkspaceSettings, {})
  ] });
}
export {
  SharedChromeSettings
};
