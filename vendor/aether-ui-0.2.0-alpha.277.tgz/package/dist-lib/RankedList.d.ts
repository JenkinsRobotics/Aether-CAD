import type { ReactNode } from "react";
import "./RankedList.css";
export interface RankedListItem {
    id: string;
    label: string;
    value: string;
    icon?: ReactNode;
}
/** Dense ranked metrics. Selection reports the item ID, never navigates implicitly. */
export declare function RankedList({ label, items, onSelect, selectedID }: {
    label: string;
    items: readonly RankedListItem[];
    onSelect?: (id: string) => void;
    selectedID?: string;
}): import("react").JSX.Element;
