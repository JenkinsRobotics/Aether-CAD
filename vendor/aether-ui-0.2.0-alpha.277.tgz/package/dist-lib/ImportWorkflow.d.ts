import "./ConceptWidgets.css";
export interface ImportFileItem {
    id: string;
    name: string;
    detail: string;
}
export interface ImportWorkflowProps {
    title: string;
    detail: string;
    destination: string;
    files: readonly ImportFileItem[];
    step?: number;
    stepCount?: number;
    options?: readonly string[];
    onBack?: () => void;
    onImport?: () => void;
}
export declare function ImportWorkflow({ title, detail, destination, files, step, stepCount, options, onBack, onImport }: ImportWorkflowProps): import("react").JSX.Element;
