import { type ReactNode, type RefObject } from 'react';
import { type MenuItem } from './Menu.js';
import './CollectionView.css';
export interface CollectionFilterOption {
    id: string;
    label: string;
    icon?: ReactNode;
}
export interface CollectionFilterProps {
    query: string;
    onQueryChange: (query: string) => void;
    options?: readonly CollectionFilterOption[];
    value?: string;
    onChange?: (id: string) => void;
    ariaLabel: string;
    inputRef?: RefObject<HTMLInputElement | null>;
    inputID?: string;
    /** Rows the filter is showing; omitted means no count is announced. */
    resultCount?: number;
    placeholder?: string;
    /** Grouped filters share the same single-line search control as tree filters. */
    menu?: {
        label: string;
        items: readonly MenuItem[];
        onSelect: (id: string) => void;
        active?: boolean;
        summary?: string;
    };
}
export declare function CollectionFilter({ query, onQueryChange, options, value, onChange, ariaLabel, inputRef, inputID, resultCount, placeholder, menu }: CollectionFilterProps): import("react").JSX.Element;
