import type { CommandPaletteCommand } from "./CommandPalette.js";
import "./CommandSearch.css";
export type CommandSearchCommand = Omit<CommandPaletteCommand, "argument">;
export interface CommandSearchProps {
    commands: readonly CommandSearchCommand[];
    onSelect: (id: string) => void;
    ariaLabel?: string;
    placeholder?: string;
    className?: string;
    /** One search field per app should own the shortcut. */
    registerShortcut?: boolean;
}
/** In-place command entry. Suggestions never trap focus or cover the workspace. */
export declare function CommandSearch({ commands, onSelect, ariaLabel, placeholder, className, registerShortcut }: CommandSearchProps): import("react").JSX.Element;
