import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { DocumentCollaborationPanel } from "./DocumentCollaborationPanel.js";
import { SidePanelHeader } from "./SidePanelHeader.js";
import { PanelNotifications } from "./PanelNotifications.js";
import { SegmentedControl } from "./SegmentedControl.js";
import "./StudioReview.css";
function DocumentReviewPanel({ connection, initialTab = "comments" }) {
  const [tab, setTab] = useState(initialTab);
  const [tag, setTag] = useState("");
  useEffect(() => {
    setTag("");
    setTab(initialTab);
  }, [connection.key, initialTab]);
  return /* @__PURE__ */ jsx(PanelNotifications, { children: /* @__PURE__ */ jsxs("section", { className: "ps-review-conversation aui-studio-review", "aria-label": "Comments and tasks", children: [
    /* @__PURE__ */ jsx(SidePanelHeader, { title: "Comments & tasks", icon: "comment" }),
    /* @__PURE__ */ jsx(SegmentedControl, { variant: "panel", className: "ps-review-conversation-tabs", ariaLabel: "Review tabs", value: tab, onChange: (value) => setTab(value), options: [{ id: "comments", label: "Comments", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "comment" }) }, { id: "tasks", label: "Tasks", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "tasks" }) }] }),
    /* @__PURE__ */ jsx("div", { className: "aui-studio-review-page", hidden: tab !== "comments", children: /* @__PURE__ */ jsx(DocumentCollaborationPanel, { connection, kind: "comments", variant: "studio", reviewTag: tag, onReviewTag: setTag }) }),
    /* @__PURE__ */ jsx("div", { className: "aui-studio-review-page", hidden: tab !== "tasks", children: /* @__PURE__ */ jsx(DocumentCollaborationPanel, { connection, kind: "tasks", variant: "studio", reviewTag: tag, onReviewTag: setTag }) })
  ] }) });
}
export {
  DocumentReviewPanel
};
