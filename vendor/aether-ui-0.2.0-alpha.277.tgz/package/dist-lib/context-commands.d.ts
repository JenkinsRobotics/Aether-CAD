import { type RefObject } from 'react';
import type { MenuItem } from './Menu.js';
export interface ContextCommand extends Omit<MenuItem, 'children'> {
    run: () => void | Promise<void>;
    order?: number;
}
export declare function rememberContextTarget(target: Element, x: number, y: number): void;
export declare function contextTargetAt(anchor: unknown): Element | null;
/** Product-owned commands. A nearer work area replaces common IDs such as zoom. */
export declare function useContextCommands(commands: readonly ContextCommand[], element?: RefObject<HTMLElement | null>): void;
export declare function contextCommandsFor(target: Element, scopedOnly?: boolean): ContextCommand[];
export declare function runContextCommand(command: ContextCommand): void;
export declare function contextCommandItems(commands: readonly ContextCommand[]): MenuItem[];
