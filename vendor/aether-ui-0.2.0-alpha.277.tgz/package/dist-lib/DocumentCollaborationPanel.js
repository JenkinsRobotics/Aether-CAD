import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { useDocumentMutation } from "./useDocumentMutation.js";
import { StudioCommentsView } from "./StudioCommentsView.js";
import { StudioTasksView } from "./StudioTasksView.js";
import { DocumentCommentsView } from "./DocumentCommentsView.js";
import { ActionItemsView } from "./ActionItemsView.js";
import { DocumentNotesView } from "./DocumentNotesView.js";
import { Button } from "./Button.js";
import { useConfirm } from "./useConfirm.js";
import "./DocumentPanels.css";
const titles = {
  comments: "Comments",
  notes: "Document notes",
  tasks: "Action items",
  reminders: "Reminders"
};
function DocumentCollaborationPanel({
  connection,
  kind,
  variant = "standard",
  reviewTag,
  onReviewTag
}) {
  const [disconnected, setDisconnected] = useState(false);
  const liveAccess = useRef(true), refreshRead = useRef(0);
  const [draftReset, setDraftReset] = useState(0);
  const [notesEditing, setNotesEditing] = useState(false);
  const [taskCollection, setTaskCollection] = useState("tasks");
  const effectiveKind = kind === "tasks" ? taskCollection : kind;
  const [following, setFollowing] = useState(true);
  const followRef = useRef(true);
  const [state, setState] = useState(null), [error, setError] = useState(""), [busy, setBusy] = useState(false);
  const [text, setText] = useState(""), [due, setDue] = useState(""), [assignee, setAssignee] = useState(""), [editing, setEditing] = useState(null), [reply, setReply] = useState(null), [filter, setFilter] = useState("open");
  const dirty = useRef(false), generation = useRef(0), editRevision = useRef(null), editOriginal = useRef(null);
  const [conflicted, setConflicted] = useState(false);
  const [confirm, confirmDialog] = useConfirm();
  const receivedRevision = useRef(-1);
  const receive = (next) => {
    if (next.revision < receivedRevision.current) return;
    receivedRevision.current = next.revision;
    setState(next);
    if (kind === "notes" && !dirty.current) setText(next.notes.text);
  };
  const consumesDraft = useRef(false);
  const mutation = useDocumentMutation(connection, async (_action, result) => {
    if (liveAccess.current) receive(result);
    if (!consumesDraft.current) return;
    dirty.current = false;
    editRevision.current = null;
    setConflicted(false);
    setEditing(null);
    setReply(null);
    setNotesEditing(false);
    setText("");
    setDue("");
    setDraftReset((n) => n + 1);
    setError("");
  }, state?.mutation_replay === "operation_id");
  const refresh = async () => {
    if (!liveAccess.current) return;
    const g = generation.current, request = ++refreshRead.current;
    try {
      const next = await connection.call("collaboration");
      if (g === generation.current && request === refreshRead.current && liveAccess.current) receive(next);
    } catch (e) {
      if (g === generation.current && request === refreshRead.current) setError(e.message);
    }
  };
  useEffect(() => {
    generation.current++;
    liveAccess.current = true;
    setDisconnected(false);
    receivedRevision.current = -1;
    dirty.current = false;
    setState(null);
    setNotesEditing(false);
    setTaskCollection("tasks");
    setBusy(false);
    setConflicted(false);
    editRevision.current = null;
    setText("");
    setEditing(null);
    setReply(null);
    setError("");
    void refresh();
    const subscriptionGeneration = generation.current;
    const unsubscribe = connection.subscribeChanges?.((event) => {
      if (subscriptionGeneration !== generation.current) return;
      const wasUnavailable = !liveAccess.current;
      liveAccess.current = event.kind !== "unavailable";
      setDisconnected(!liveAccess.current);
      refreshRead.current++;
      if (!liveAccess.current) setState(null);
      else if (kind !== "comments" || followRef.current || wasUnavailable) void refresh();
    });
    const timer = setInterval(() => {
      if (kind !== "comments" || followRef.current) void refresh();
    }, 1e4);
    const focus = () => void refresh();
    window.addEventListener("focus", focus);
    return () => {
      generation.current++;
      unsubscribe?.();
      clearInterval(timer);
      window.removeEventListener("focus", focus);
    };
  }, [connection.key, kind]);
  useEffect(() => {
    if (!state?.actor) return;
    let enabled = true;
    try {
      enabled = localStorage.getItem(`aether-comments-follow:${connection.key}:${state.actor}`) !== "false";
    } catch {
    }
    followRef.current = enabled;
    setFollowing(enabled);
  }, [connection.key, state?.actor]);
  const mutate = async (operation, value, item, draft = false, collection = effectiveKind, consumeDraft = false) => {
    if (!state || busy || mutation.uncertain || !liveAccess.current) return false;
    const g = generation.current;
    consumesDraft.current = consumeDraft;
    setBusy(true);
    setError("");
    try {
      const latest = await connection.call("collaboration");
      const original = draft ? editOriginal.current : collection === "notes" ? state.notes.text : state[collection]?.find((i) => i.id === item)?.updated;
      const remote = collection === "notes" ? latest.notes.text : latest[collection]?.find((i) => i.id === item)?.updated;
      const unchanged = operation === "add" || original === remote;
      const expected = unchanged ? latest.revision : draft && editRevision.current !== null ? editRevision.current : state.revision;
      const next = await mutation.send(
        "collaboration_mutate",
        {
          collection,
          operation,
          item,
          value,
          expected_revision: expected
        }
      );
      if (g !== generation.current) return false;
      if (liveAccess.current) receive(next);
      return true;
    } catch (e) {
      if (g === generation.current) {
        setError(e.message);
        if (draft && e.status === 409)
          setConflicted(true);
        await refresh();
      }
      return false;
    } finally {
      if (g === generation.current) setBusy(false);
    }
  };
  const person = (id) => state?.members.find((m) => m.id === id)?.name ?? "Former member";
  const canEdit = (i) => state?.can_manage || state?.actor === state?.owner || i.author === state?.actor;
  const submit = async (metadata = {}) => {
    const ok = await mutate(
      kind === "notes" || editing ? "update" : "add",
      kind === "notes" ? { text } : kind === "comments" ? { text, ...metadata, ...!editing ? { parent: reply } : {} } : { text, due, assignee: assignee || "", ...metadata },
      editing ?? void 0,
      kind === "notes" || !!editing,
      effectiveKind,
      true
    );
    if (ok) {
      dirty.current = false;
      editRevision.current = null;
      setConflicted(false);
      if (kind !== "notes") setText("");
      else setNotesEditing(false);
      setEditing(null);
      setReply(null);
      setDue("");
    }
    return ok;
  };
  const edit = (i) => {
    editOriginal.current = i.updated;
    editRevision.current = state?.revision ?? null;
    setConflicted(false);
    setEditing(i.id);
    setReply(null);
    setText(i.text);
    setDue(i.due ?? "");
    setAssignee(i.assignee ?? "");
    dirty.current = true;
  };
  const deleted = (i, collection = effectiveKind) => {
    void confirm({ title: "Remove item", message: "Remove this item? Its audit history will be retained.", action: "Remove" }).then((ok) => {
      if (ok) void mutate("delete", {}, i.id, false, collection);
    });
  };
  const items = kind === "comments" ? state?.comments.filter(
    (i) => !i.parent && (filter === "all" || (filter === "done" ? i.resolved : !i.resolved))
  ) : kind === "notes" ? [] : state?.[kind].filter(
    (i) => !i.deleted && (filter === "all" || (filter === "done" ? i.status === "done" : i.status !== "done"))
  );
  const conflictPanel = mutation.uncertain ? /* @__PURE__ */ jsxs("div", { role: "group", "aria-label": "Confirm pending change", children: [
    /* @__PURE__ */ jsx("p", { children: "The reply was lost. Confirm the original change before submitting again." }),
    mutation.canRetry ? /* @__PURE__ */ jsx(Button, { disabled: mutation.retrying, onClick: () => void mutation.retry().catch((e) => setError(e.message)), children: "Retry original change" }) : /* @__PURE__ */ jsx("p", { children: "This server cannot safely replay this change. Check the saved discussion before submitting again." })
  ] }) : conflicted && state && /* @__PURE__ */ jsxs("div", { role: "group", "aria-label": "Review conflicting edit", children: [
    /* @__PURE__ */ jsx("p", { children: "The server changed while you were editing. Your draft is still in the editor." }),
    /* @__PURE__ */ jsx("blockquote", { children: effectiveKind === "notes" ? state.notes.text : state[effectiveKind].find((i) => i.id === editing)?.text }),
    /* @__PURE__ */ jsx(
      Button,
      {
        onClick: () => {
          editRevision.current = state.revision;
          editOriginal.current = effectiveKind === "notes" ? state.notes.text : state[effectiveKind].find((i) => i.id === editing)?.updated ?? null;
          setConflicted(false);
          setError("Reviewed latest changes. Save when ready.");
        },
        children: "Keep my draft after review"
      }
    ),
    /* @__PURE__ */ jsx(
      Button,
      {
        onClick: () => {
          setText(
            effectiveKind === "notes" ? state.notes.text : state[effectiveKind].find((i) => i.id === editing)?.text ?? ""
          );
          dirty.current = effectiveKind === "notes";
          editRevision.current = state.revision;
          editOriginal.current = effectiveKind === "notes" ? state.notes.text : state[effectiveKind].find((i) => i.id === editing)?.updated ?? null;
          if (kind === "tasks") {
            const item = state[taskCollection].find((item2) => item2.id === editing);
            setDue(item?.due ?? "");
            setAssignee(item?.assignee ?? "");
          }
          setDraftReset((value) => value + 1);
          setConflicted(false);
        },
        children: "Use latest text"
      }
    )
  ] });
  const connectionError = disconnected ? "Live updates are disconnected. Your draft is kept. Reconnecting\u2026" : error;
  const CommentsView = variant === "studio" ? StudioCommentsView : DocumentCommentsView;
  const TasksView = variant === "studio" ? StudioTasksView : ActionItemsView;
  if (kind === "comments") return /* @__PURE__ */ jsxs(Fragment, { children: [
    confirmDialog,
    /* @__PURE__ */ jsx(
      CommentsView,
      {
        reviewTag,
        onReviewTag,
        connection,
        state,
        draftReset,
        text,
        editing,
        reply,
        busy: busy || mutation.uncertain || disconnected,
        error: connectionError,
        conflicted,
        conflict: conflictPanel,
        following,
        onFollowing: (value) => {
          followRef.current = value;
          setFollowing(value);
          try {
            localStorage.setItem(`aether-comments-follow:${connection.key}:${state?.actor}`, String(value));
          } catch {
          }
          if (value) void refresh();
        },
        onText: (value) => {
          dirty.current = true;
          setText(value);
        },
        onCancel: () => {
          setEditing(null);
          setReply(null);
          setText("");
          dirty.current = false;
          editRevision.current = null;
          setConflicted(false);
        },
        onSubmit: submit,
        onEdit: edit,
        onRemove: deleted,
        onReply: (item) => {
          setReply(item.id);
          setEditing(null);
          setText("");
          dirty.current = false;
          editRevision.current = null;
          setConflicted(false);
        },
        onResolve: (item) => void mutate("update", { resolved: !item.resolved }, item.id)
      }
    )
  ] });
  if (kind === "notes") return /* @__PURE__ */ jsx(
    DocumentNotesView,
    {
      loaded: !!state,
      canEdit: !!state && state.actor === state.owner,
      editing: notesEditing,
      busy: busy || mutation.uncertain || disconnected,
      conflicted,
      text,
      savedText: state?.notes.text ?? "",
      error: connectionError,
      conflict: conflictPanel,
      onRefresh: () => void refresh(),
      onEdit: () => {
        if (!state || state.actor !== state.owner) return;
        setText(state.notes.text);
        setNotesEditing(true);
        setError("");
        dirty.current = true;
        editRevision.current = state.revision;
        editOriginal.current = state.notes.text;
      },
      onChange: (value) => {
        dirty.current = true;
        setText(value);
      },
      onSave: () => void submit(),
      onCancel: () => {
        setNotesEditing(false);
        setText(state?.notes.text ?? "");
        setError("");
        dirty.current = false;
        editRevision.current = null;
        editOriginal.current = null;
        setConflicted(false);
      }
    }
  );
  if (kind === "tasks") return /* @__PURE__ */ jsxs(Fragment, { children: [
    confirmDialog,
    /* @__PURE__ */ jsx(
      TasksView,
      {
        reviewTag,
        onReviewTag,
        documentKey: connection.key,
        state,
        busy: busy || mutation.uncertain || disconnected,
        error: connectionError,
        conflicted,
        conflict: conflictPanel,
        editing,
        collection: taskCollection,
        text,
        due,
        assignee,
        onCollection: setTaskCollection,
        onText: (value) => {
          dirty.current = true;
          setText(value);
        },
        onDue: setDue,
        onAssignee: setAssignee,
        connection,
        draftReset,
        onCard: (operation, value, item) => mutate(operation, value, item, false, "cards"),
        onSubmit: submit,
        onCancel: () => {
          setEditing(null);
          setText("");
          setDue("");
          setAssignee("");
          setError("");
          dirty.current = false;
          editRevision.current = null;
          editOriginal.current = null;
          setConflicted(false);
        },
        onEdit: (item, collection) => {
          setTaskCollection(collection);
          edit(item);
        },
        onRemove: deleted,
        onStatus: (item, collection, status) => void mutate("update", { status }, item.id, false, collection)
      }
    )
  ] });
  return /* @__PURE__ */ jsxs("section", { className: "aui-document-panel", "aria-label": titles[kind], children: [
    confirmDialog,
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsx("h3", { children: titles[kind] }),
      /* @__PURE__ */ jsx(Button, { disabled: busy || mutation.uncertain || disconnected, onClick: () => void refresh(), children: "Refresh" })
    ] }),
    connectionError && /* @__PURE__ */ jsx("p", { role: "alert", children: connectionError }),
    conflictPanel,
    !state && /* @__PURE__ */ jsx("p", { children: "Connecting to this document\u2026" }),
    /* @__PURE__ */ jsxs("label", { children: [
      "Show",
      /* @__PURE__ */ jsxs("select", { "aria-label": `${titles[kind]} filter`, value: filter, onChange: (e) => setFilter(e.target.value), children: [
        /* @__PURE__ */ jsx("option", { value: "open", children: "Open" }),
        /* @__PURE__ */ jsx("option", { value: "done", children: "Completed" }),
        /* @__PURE__ */ jsx("option", { value: "all", children: "All" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit: (e) => {
      e.preventDefault();
      void submit();
    }, children: [
      /* @__PURE__ */ jsxs("label", { children: [
        editing ? "Edit item" : "Reminder",
        /* @__PURE__ */ jsx(
          "textarea",
          {
            "aria-label": `${titles[kind]} text`,
            value: text,
            onChange: (e) => {
              dirty.current = true;
              setText(e.target.value);
            },
            maxLength: 1e3,
            rows: 3
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "Due date",
        /* @__PURE__ */ jsx("input", { "aria-label": "Due date", type: "date", value: due, onChange: (e) => setDue(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "Assigned to",
        /* @__PURE__ */ jsx("select", { "aria-label": "Assigned to", value: assignee || state?.actor || "", onChange: (e) => setAssignee(e.target.value), children: state?.members.map((member) => /* @__PURE__ */ jsx("option", { value: member.id, children: member.name }, member.id)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-document-actions", children: [
        /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", disabled: busy || disconnected || conflicted || !state || !text.trim(), children: editing ? "Save changes" : "Add reminder" }),
        editing && /* @__PURE__ */ jsx(Button, { onClick: () => {
          setEditing(null);
          setText("");
          dirty.current = false;
          editRevision.current = null;
          setConflicted(false);
        }, children: "Cancel edit" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("ul", { "aria-label": titles[kind], children: items?.map((item) => /* @__PURE__ */ jsxs("li", { children: [
      /* @__PURE__ */ jsx("strong", { children: item.text }),
      /* @__PURE__ */ jsxs("small", { children: [
        person(item.assignee ?? item.author),
        item.due ? ` \xB7 Due ${item.due}${item.status !== "done" && item.due < (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA") ? " \xB7 Overdue" : ""}` : ""
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "Status",
        /* @__PURE__ */ jsxs(
          "select",
          {
            "aria-label": `Status for ${item.text}`,
            disabled: busy || !(canEdit(item) || item.assignee === state?.actor),
            value: item.status,
            onChange: (e) => void mutate("update", { status: e.target.value }, item.id),
            children: [
              /* @__PURE__ */ jsx("option", { value: "open", children: "Open" }),
              /* @__PURE__ */ jsx("option", { value: "in_progress", children: "In progress" }),
              /* @__PURE__ */ jsx("option", { value: "done", children: "Done" })
            ]
          }
        )
      ] }),
      canEdit(item) && /* @__PURE__ */ jsxs("div", { className: "aui-document-actions", children: [
        /* @__PURE__ */ jsx(Button, { disabled: busy || mutation.uncertain || disconnected, onClick: () => edit(item), children: "Edit item" }),
        /* @__PURE__ */ jsx(Button, { disabled: busy || mutation.uncertain || disconnected, onClick: () => deleted(item), children: "Remove item" })
      ] })
    ] }, item.id)) }),
    state && !items?.length && /* @__PURE__ */ jsx("p", { children: "No items in this view." }),
    !!state?.activity.length && /* @__PURE__ */ jsxs("details", { children: [
      /* @__PURE__ */ jsx("summary", { children: "Activity" }),
      /* @__PURE__ */ jsx("ol", { children: state.activity.filter((event) => event.collection === kind).map((event) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("small", { children: [
        event.author,
        " \xB7 ",
        event.operation,
        " \xB7 ",
        new Date(event.created * 1e3).toLocaleString()
      ] }) }, event.revision)) })
    ] })
  ] });
}
export {
  DocumentCollaborationPanel
};
