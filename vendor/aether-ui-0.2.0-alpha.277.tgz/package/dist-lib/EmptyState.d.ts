import type { ReactNode } from "react";
export interface EmptyStateProps {
    title: ReactNode;
    description?: ReactNode;
    icon?: ReactNode;
    primaryAction?: ReactNode;
    secondaryAction?: ReactNode;
    compact?: boolean;
    className?: string;
}
/** Reusable empty/new/no-results surface with optional recovery actions. */
export declare function EmptyState({ title, description, icon, primaryAction, secondaryAction, compact, className, }: EmptyStateProps): import("react").JSX.Element;
