import "./WorkflowWidgets.css";
export interface SequenceItem {
    id: string;
    label: string;
    group: string;
}
export interface SequenceMessage {
    id: string;
    title: string;
    description: string;
}
export interface SequenceBrowserProps {
    items: readonly SequenceItem[];
    selected: string;
    onSelect: (id: string) => void;
    onAdd: () => void;
    onRename: (id: string, name: string) => void;
    onCommand: (id: string, command: string) => void;
    messages: readonly SequenceMessage[];
    selectedMessage: string;
    onMessageSelect: (id: string) => void;
    onAddMessage: () => void;
    onGenerate: () => void;
}
export declare function SequenceBrowser({ items, selected, onSelect, onAdd, onRename, onCommand, messages, selectedMessage, onMessageSelect, onAddMessage, onGenerate }: SequenceBrowserProps): import("react").JSX.Element;
