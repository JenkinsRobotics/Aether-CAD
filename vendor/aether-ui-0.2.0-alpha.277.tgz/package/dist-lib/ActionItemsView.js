import { jsx, jsxs } from "react/jsx-runtime";
import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
import { SearchField } from "./SearchField.js";
import { useOverlayHost } from "./OverlayScope.js";
import "./ActionItemsView.css";
function ActionItemsView(props) {
  const { state, busy } = props;
  const [query, setQuery] = useState(""), [type, setType] = useState("all"), [status, setStatus] = useState("all");
  const [assignee, setAssignee] = useState("me"), [dueFilter, setDueFilter] = useState("all"), [sort, setSort] = useState("updated");
  const [open, setOpen] = useState(false);
  const host = useOverlayHost(), latest = useRef(props);
  latest.current = props;
  const close = useCallback(() => {
    if (!latest.current.busy) {
      setOpen(false);
      latest.current.onCancel();
    }
  }, []);
  useEffect(() => {
    setOpen(false);
    setQuery("");
    setType("all");
    setStatus("all");
    setAssignee("me");
    setDueFilter("all");
  }, [props.documentKey]);
  const person = (id) => state?.members.find((member) => member.id === id)?.name ?? "Former member";
  const owner = (item) => state?.actor === state?.owner || state?.actor === item.author;
  const dateKey = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const today = dateKey(/* @__PURE__ */ new Date()), nextWeek = /* @__PURE__ */ new Date();
  nextWeek.setDate(nextWeek.getDate() + 7);
  const rows = ["tasks", "reminders"].flatMap((collection) => (state?.[collection] ?? []).map((item) => ({ item, collection }))).filter(({ item, collection }) => !item.deleted && (type === "all" || type === collection) && (status === "all" || item.status === status) && (assignee === "all" || item.assignee === (assignee === "me" ? state?.actor : assignee)) && (!query.trim() || `${item.text} ${person(item.assignee)}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())) && (dueFilter === "all" || (dueFilter === "none" ? !item.due : dueFilter === "overdue" ? !!item.due && item.due < today && item.status !== "done" : !!item.due && item.due >= today && item.due <= dateKey(nextWeek) && item.status !== "done"))).sort((a, b) => sort === "name" ? a.item.text.localeCompare(b.item.text) : sort === "due" ? (a.item.due || "9999").localeCompare(b.item.due || "9999") : b.item.updated - a.item.updated);
  const filtersActive = !!query || type !== "all" || status !== "all" || assignee !== "all" || dueFilter !== "all";
  return /* @__PURE__ */ jsxs("section", { className: "aui-action-items", "aria-label": "Action items", children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-action-items-header", children: [
      /* @__PURE__ */ jsx("h3", { children: "Action items" }),
      /* @__PURE__ */ jsx(MenuButton, { label: "Sort action items", items: [
        { id: "updated", label: "Recently updated", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "history" }), kind: "radio", checked: sort === "updated" },
        { id: "due", label: "Due date", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "stopwatch" }), kind: "radio", checked: sort === "due" },
        { id: "name", label: "Name", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "text" }), kind: "radio", checked: sort === "name" }
      ], onSelect: setSort, children: /* @__PURE__ */ jsx(AetherIcon, { name: "sort-chevron" }) }),
      /* @__PURE__ */ jsx(IconButton, { label: "Create action item", disabled: !state || busy, onClick: () => {
        props.onCancel();
        props.onCollection(type === "reminders" ? "reminders" : "tasks");
        setOpen(true);
      }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "document-add" }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-action-items-tools", children: [
      /* @__PURE__ */ jsx(SearchField, { value: query, onQueryChange: setQuery, ariaLabel: "Search in Action items", placeholder: "Search in Action items" }),
      /* @__PURE__ */ jsxs("div", { className: "aui-action-items-filters", children: [
        /* @__PURE__ */ jsxs("select", { "aria-label": "Action item type", title: "Type", value: type, onChange: (event) => setType(event.target.value), children: [
          /* @__PURE__ */ jsx("option", { value: "all", children: "Type" }),
          /* @__PURE__ */ jsx("option", { value: "tasks", children: "Tasks" }),
          /* @__PURE__ */ jsx("option", { value: "reminders", children: "Reminders" })
        ] }),
        /* @__PURE__ */ jsxs("select", { "aria-label": "Action item status", title: "Status", value: status, onChange: (event) => setStatus(event.target.value), children: [
          /* @__PURE__ */ jsx("option", { value: "all", children: "Status" }),
          /* @__PURE__ */ jsx("option", { value: "open", children: "Open" }),
          /* @__PURE__ */ jsx("option", { value: "in_progress", children: "In progress" }),
          /* @__PURE__ */ jsx("option", { value: "done", children: "Completed" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-action-assignee", children: [
          /* @__PURE__ */ jsxs("select", { "aria-label": "Action item assignee", title: "Assignee", value: assignee, onChange: (event) => setAssignee(event.target.value), children: [
            /* @__PURE__ */ jsx("option", { value: "all", children: "Assignee" }),
            /* @__PURE__ */ jsx("option", { value: "me", children: "Me" }),
            state?.members.map((member) => /* @__PURE__ */ jsx("option", { value: member.id, children: member.name }, member.id))
          ] }),
          assignee !== "all" && /* @__PURE__ */ jsx("span", { "aria-label": "1 assignee filter", children: "1" })
        ] }),
        /* @__PURE__ */ jsx(MenuButton, { label: "Due date filter", items: [
          { id: "all", label: "Any due date", kind: "radio", checked: dueFilter === "all", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "stopwatch" }) },
          { id: "overdue", label: "Overdue", kind: "radio", checked: dueFilter === "overdue", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "stopwatch" }) },
          { id: "week", label: "Due in the next 7 days", kind: "radio", checked: dueFilter === "week", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "stopwatch" }) },
          { id: "none", label: "No due date", kind: "radio", checked: dueFilter === "none", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "document" }) }
        ], onSelect: setDueFilter, children: /* @__PURE__ */ jsx(AetherIcon, { name: dueFilter === "all" ? "plus-square" : "filter" }) }),
        /* @__PURE__ */ jsx(IconButton, { label: "Clear action item filters", disabled: !filtersActive, onClick: () => {
          setQuery("");
          setType("all");
          setStatus("all");
          setAssignee("all");
          setDueFilter("all");
        }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
      ] })
    ] }),
    props.error && !open && /* @__PURE__ */ jsx("p", { className: "aui-action-items-error", role: "alert", children: props.error }),
    /* @__PURE__ */ jsx("div", { className: "aui-action-items-body", children: !state ? /* @__PURE__ */ jsx("p", { role: "status", children: "Loading action items\u2026" }) : !rows.length ? /* @__PURE__ */ jsxs("div", { className: "aui-action-items-empty", children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "action-items-empty" }),
      /* @__PURE__ */ jsx("p", { children: "No action items found for the current filter." })
    ] }) : /* @__PURE__ */ jsx("ul", { "aria-label": "Action item results", children: rows.map(({ item, collection }) => /* @__PURE__ */ jsxs("li", { children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-action-item-title", children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: collection === "tasks" ? "tasks" : "stopwatch" }),
        /* @__PURE__ */ jsx("strong", { children: item.text }),
        owner(item) && /* @__PURE__ */ jsx(MenuButton, { label: `Actions for ${item.text}`, items: [
          { id: "edit", label: "Edit item", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "pencil" }), disabled: busy },
          { id: "remove", label: "Remove item", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "delete" }), danger: true, disabled: busy }
        ], onSelect: (id) => {
          if (id === "edit") {
            props.onEdit(item, collection);
            setOpen(true);
          } else props.onRemove(item, collection);
        }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
      ] }),
      /* @__PURE__ */ jsxs("small", { children: [
        collection === "tasks" ? "Task" : "Reminder",
        " \xB7 ",
        person(item.assignee),
        item.due ? ` \xB7 Due ${item.due}${item.due < today && item.status !== "done" ? " \xB7 Overdue" : ""}` : ""
      ] }),
      /* @__PURE__ */ jsxs("select", { "aria-label": `Status for ${item.text}`, value: item.status ?? "open", disabled: busy || !(owner(item) || state.actor === item.assignee), onChange: (event) => props.onStatus(item, collection, event.target.value), children: [
        /* @__PURE__ */ jsx("option", { value: "open", children: "Open" }),
        /* @__PURE__ */ jsx("option", { value: "in_progress", children: "In progress" }),
        /* @__PURE__ */ jsx("option", { value: "done", children: "Completed" })
      ] })
    ] }, `${collection}:${item.id}`)) }) }),
    open && createPortal(/* @__PURE__ */ jsx("div", { className: "aui-action-item-dialog", children: /* @__PURE__ */ jsxs(Dialog, { open: true, title: props.editing ? "Edit action item" : "Create action item", onClose: close, children: [
      props.error && /* @__PURE__ */ jsx("p", { role: "alert", children: props.error }),
      props.conflict,
      /* @__PURE__ */ jsxs("form", { onSubmit: (event) => {
        event.preventDefault();
        void props.onSubmit().then((ok) => {
          if (ok) {
            setOpen(false);
            setQuery("");
            setType("all");
            setStatus("all");
            setAssignee("all");
            setDueFilter("all");
          }
        });
      }, children: [
        /* @__PURE__ */ jsxs("label", { children: [
          "Type",
          /* @__PURE__ */ jsxs("select", { "aria-label": "New action item type", value: props.collection, disabled: busy || !!props.editing, onChange: (event) => props.onCollection(event.target.value), children: [
            /* @__PURE__ */ jsx("option", { value: "tasks", children: "Task" }),
            /* @__PURE__ */ jsx("option", { value: "reminders", children: "Reminder" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Description",
          /* @__PURE__ */ jsx("textarea", { "aria-label": "Action items text", value: props.text, disabled: busy, maxLength: 1e3, rows: 4, onChange: (event) => props.onText(event.target.value) })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Due date",
          /* @__PURE__ */ jsx("input", { "aria-label": "Due date", type: "date", value: props.due, disabled: busy, onChange: (event) => props.onDue(event.target.value) })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Assigned to",
          /* @__PURE__ */ jsx("select", { "aria-label": "Assigned to", value: props.assignee || state?.actor || "", disabled: busy, onChange: (event) => props.onAssignee(event.target.value), children: state?.members.map((member) => /* @__PURE__ */ jsx("option", { value: member.id, children: member.name }, member.id)) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-action-item-buttons", children: [
          /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", disabled: busy || props.conflicted || !props.text.trim(), children: props.editing ? "Save changes" : props.collection === "tasks" ? "Add task" : "Add reminder" }),
          /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: close, children: "Cancel" })
        ] })
      ] })
    ] }) }), host ?? document.body)
  ] });
}
export {
  ActionItemsView
};
