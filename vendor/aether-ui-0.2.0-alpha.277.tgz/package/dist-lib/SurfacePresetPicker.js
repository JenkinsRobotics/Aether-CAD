import { jsx, jsxs } from "react/jsx-runtime";
import { MaterialSwatch } from "./MaterialSwatch.js";
import "./SurfacePresetPicker.css";
function SurfacePresetPicker({ presets, selectedId, disabled, onSelect }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-surface-presets", role: "group", "aria-label": "Surface presets", children: presets.map((preset) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-label": `Apply ${preset.name}`, "aria-pressed": preset.id === selectedId, disabled, onClick: () => onSelect(preset.id), children: [
    /* @__PURE__ */ jsx(MaterialSwatch, { color: preset.color, size: "large", roughness: preset.roughness }),
    /* @__PURE__ */ jsx("span", { children: preset.name })
  ] }, preset.id)) });
}
export {
  SurfacePresetPicker
};
