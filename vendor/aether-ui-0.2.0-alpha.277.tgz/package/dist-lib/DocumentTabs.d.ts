import type { ReactNode } from "react";
export interface DocumentTab {
    id: string;
    label: string;
    icon?: ReactNode;
    /** Optional document kind/subtitle. Unlike status, this is not a live update. */
    detail?: string;
    /** Document-specific status, rendered inside its tab rather than the global strip. */
    status?: string;
    statusTitle?: string;
    dirty?: boolean;
    pinned?: boolean;
    preview?: boolean;
    disabled?: boolean;
}
export type DocumentSplitDirection = "horizontal" | "vertical";
export interface DocumentTabsProps {
    tabs: readonly DocumentTab[];
    activeID: string;
    onSelect: (id: string) => void;
    onClose?: (id: string) => void;
    onPinToggle?: (id: string, pinned: boolean) => void;
    onReorder?: (sourceID: string, targetID: string) => void;
    onSplit?: (id: string, direction: DocumentSplitDirection) => void;
    maxVisible?: number;
    allowClosePinned?: boolean;
    ariaLabel?: string;
    className?: string;
    /** Product-owned actions beside each tab, outside its selection button. */
    renderTabActions?: (tab: DocumentTab) => ReactNode;
}
/** Controlled document strip. Products own document lifecycle and split layout;
 * the widget emits stable tab IDs and presentation intent only. */
export declare function DocumentTabs({ tabs, activeID, onSelect, onClose, onPinToggle, onReorder, onSplit, maxVisible, allowClosePinned, ariaLabel, className, renderTabActions }: DocumentTabsProps): import("react").JSX.Element;
