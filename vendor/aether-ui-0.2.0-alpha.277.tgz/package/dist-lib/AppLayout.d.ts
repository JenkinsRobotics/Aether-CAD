import type { CSSProperties, ReactNode } from "react";
import { type WorkspacePanel } from "./WorkspaceShell.js";
import "./AppLayout.css";
/** Shared measurements for the standard docked application. Values are CSS pixels. */
export declare const APP_LAYOUT_METRICS: {
    readonly headerHeight: 56;
    readonly sidebarWidth: 280;
    readonly sidebarMinWidth: 220;
    readonly sidebarMaxWidth: 360;
    readonly centerMinWidth: 360;
    readonly toolbarMinHeight: 44;
    readonly toolbarMaxHeight: 96;
    readonly footerMinHeight: 40;
    readonly footerMaxFraction: 0.3;
    readonly widgetPadding: 12;
    readonly widgetGap: 8;
    readonly minWidth: 960;
    readonly minHeight: 480;
};
export interface AppLayoutProps {
    /** App controls, workspace selection, user, appearance and sharing. */
    header?: ReactNode;
    /** Document navigation, structure, files, history and related controls. */
    left?: readonly WorkspacePanel[];
    /** The primary canvas, editor or viewport. */
    center: ReactNode;
    /** Properties and context for the active workspace or selection. */
    right?: readonly WorkspacePanel[];
    /** Workspace-adjacent content: documents, status, transport, timeline or output. */
    footer?: ReactNode;
    topToolbar?: ReactNode;
    bottomToolbar?: ReactNode;
    storageKey?: string;
    className?: string;
    style?: CSSProperties;
}
/** Standard Header / Left / Center / Right / Footer composition of WorkspaceShell.
 * Shared sidebars retain their existing resize, collapse and editor-state behavior. */
export declare function AppLayout({ header, left, center, right, footer, topToolbar, bottomToolbar, storageKey, className, style }: AppLayoutProps): import("react").JSX.Element;
