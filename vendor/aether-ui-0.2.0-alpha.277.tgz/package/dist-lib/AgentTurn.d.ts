import type { AgentInteraction, AgentJob, AgentService, AgentImage } from './AgentServices.js';
export interface AgentAction {
    id: string;
    name: string;
    state: string;
    image?: AgentImage;
}
interface Options {
    id: string;
    service: AgentService;
    interaction?: AgentInteraction;
    isCurrent: () => boolean;
    onJob: (job: AgentJob) => void;
    onActions: (actions: AgentAction[]) => void;
    onEnd: (error?: string) => void;
}
/** One conversation turn. Products retain all editing/undo/engine semantics.
 * Polling never waits for an engine: a revoked/cancelled job can abort a slow
 * operation before the product's guarded commit. Receipts, not edits, retry.
 */
export declare class AgentTurn {
    private options;
    private controller;
    private actions;
    private pollTimer?;
    private started;
    private imagesUsed;
    constructor(options: Options);
    start(): void;
    /** Synchronous local cancellation. The caller owns best-effort host cancel. */
    stop(): void;
    private current;
    private publish;
    private end;
    private schedule;
    /** Bound waiting even when an older transport cannot abort its network call.
     * Both late success and rejection are observed and cannot restart this turn.
     */
    private request;
    private poll;
    private acknowledgeOther;
    private acknowledge;
    private execute;
    private deliver;
}
export {};
