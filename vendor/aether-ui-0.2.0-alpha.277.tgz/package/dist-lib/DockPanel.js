import { jsx, jsxs } from "react/jsx-runtime";
import { PanelHeading } from "./PanelHeading.js";
function DockPanel({ title, actions, width, children }) {
  const style = width === void 0 ? void 0 : { width, flex: "0 0 auto" };
  return /* @__PURE__ */ jsxs("div", { className: "aui-dock-panel", style, children: [
    title ? /* @__PURE__ */ jsx(PanelHeading, { actions, children: title }) : null,
    /* @__PURE__ */ jsx("div", { className: "aui-dock-panel-body", children })
  ] });
}
export {
  DockPanel
};
