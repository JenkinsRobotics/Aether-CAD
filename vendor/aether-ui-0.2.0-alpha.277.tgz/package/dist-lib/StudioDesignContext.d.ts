/** The approved studio presentation; products continue owning their commands. */
export declare const StudioDesignContext: import("react").Context<boolean>;
