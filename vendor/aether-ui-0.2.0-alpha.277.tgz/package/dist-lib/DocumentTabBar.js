import { jsx, jsxs } from "react/jsx-runtime";
import { useLayoutEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { DocumentTabs } from "./DocumentTabs.js";
import { MenuButton } from "./Menu.js";
import "./DocumentTabBar.css";
function DocumentTabBar({ tabs, addItems = [], onAdd, onAddClick, addLabel = "Insert new tab", addDisabledReason, ariaLabel = "Document tabs", placement = "bottom", variant = "standard", onOverview, overviewLabel = "Document overview", trailing, className, containerProps, renderTabActions, renderTabs }) {
  const studio = variant === "studio";
  const edge = studio ? "bottom" : placement;
  const barRef = useRef(null);
  const actionsRef = useRef(null);
  const [width, setWidth] = useState();
  const [actionsWidth, setActionsWidth] = useState(0);
  const hasAdd = Boolean(onAddClick || addItems.length);
  useLayoutEffect(() => {
    if (!studio || !barRef.current) return;
    const bar = barRef.current;
    const measure = () => {
      setWidth(bar.getBoundingClientRect().width);
      setActionsWidth(actionsRef.current?.getBoundingClientRect().width ?? 0);
    };
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(measure);
    observer.observe(bar);
    if (actionsRef.current) observer.observe(actionsRef.current);
    return () => observer.disconnect();
  }, [studio, Boolean(trailing), Boolean(onOverview)]);
  const room = width == null ? Infinity : width - 14 - (hasAdd ? 54 : 0) - 36 - actionsWidth;
  const maxVisible = studio && room < tabs.length * 174 ? Math.max(1, Math.floor((room - 36) / 174)) : Infinity;
  const enabled = tabs.filter((tab) => !tab.disabled);
  const next = enabled[(enabled.findIndex((tab) => tab.current) + 1) % enabled.length];
  const label = addDisabledReason ?? addLabel;
  const add = onAddClick ? /* @__PURE__ */ jsx("button", { type: "button", className: "aui-document-tabbar-add aui-menu-trigger", "aria-label": label, title: label, disabled: Boolean(addDisabledReason), onClick: onAddClick, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }) : addItems.length > 0 ? /* @__PURE__ */ jsx(MenuButton, { className: "aui-document-tabbar-add", label, disabled: Boolean(addDisabledReason), items: addItems, placement: edge === "header" ? "bottom-start" : "top-start", onSelect: (id) => onAdd?.(id), children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }) : null;
  const byID = (id) => tabs.find((tab) => tab.id === id);
  const tabProps = {
    ariaLabel,
    tabs: tabs.map((tab) => ({ ...tab, detail: studio ? tab.detail : void 0 })),
    maxVisible,
    activeID: tabs.find((tab) => tab.current)?.id ?? "",
    onSelect: (id) => {
      const tab = byID(id);
      if (tab && !tab.current) tab.onSelect?.();
    },
    onClose: tabs.some((tab) => tab.onClose) ? (id) => byID(id)?.onClose?.() : void 0,
    renderTabActions
  };
  return /* @__PURE__ */ jsxs("div", { ...containerProps, ref: barRef, className: ["aui-document-tabbar", studio && "aui-document-tabbar--studio", className].filter(Boolean).join(" "), "data-placement": edge, children: [
    edge === "bottom" ? add : null,
    renderTabs ? renderTabs(tabProps) : /* @__PURE__ */ jsx(DocumentTabs, { ...tabProps }),
    edge === "header" ? add : null,
    studio ? /* @__PURE__ */ jsx(IconButton, { className: "aui-document-tabbar-next", label: "Next document", size: "medium", disabled: enabled.length < 2, onClick: () => next?.onSelect?.(), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right" }) }) : null,
    trailing || studio && onOverview ? /* @__PURE__ */ jsxs("div", { ref: actionsRef, className: "aui-document-tabbar-overview aui-document-tabbar-actions", children: [
      studio && onOverview && /* @__PURE__ */ jsx(IconButton, { label: overviewLabel, size: "medium", onClick: onOverview, children: /* @__PURE__ */ jsx(AetherIcon, { name: "grid-2" }) }),
      trailing
    ] }) : null
  ] });
}
export {
  DocumentTabBar
};
