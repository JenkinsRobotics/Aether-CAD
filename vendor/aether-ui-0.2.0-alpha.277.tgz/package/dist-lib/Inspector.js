import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useContext, useId } from "react";
import { InspectorContext } from "./InspectorContext.js";
import "./Inspector.css";
function Inspector({ children, className }) {
  const nested = useContext(InspectorContext);
  if (nested) return className ? /* @__PURE__ */ jsx("div", { className, children }) : /* @__PURE__ */ jsx(Fragment, { children });
  return /* @__PURE__ */ jsx(InspectorContext.Provider, { value: true, children: /* @__PURE__ */ jsx("div", { className: ["aui-inspector", className].filter(Boolean).join(" "), children }) });
}
function InspectorSection({ title, children, actions, defaultOpen }) {
  const id = useId();
  const body = /* @__PURE__ */ jsx("div", { className: "aui-inspector-section-body", children });
  return defaultOpen === void 0 ? /* @__PURE__ */ jsxs("section", { className: "aui-inspector-section", "aria-labelledby": id, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-inspector-section-heading", children: [
      /* @__PURE__ */ jsx("h3", { id, children: title }),
      actions
    ] }),
    body
  ] }) : /* @__PURE__ */ jsxs("details", { className: "aui-inspector-section", open: defaultOpen, children: [
    /* @__PURE__ */ jsx("summary", { className: "aui-inspector-section-heading", children: title }),
    body
  ] });
}
function InspectorActions({ children, label }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-inspector-actions", role: label ? "group" : void 0, "aria-label": label, children });
}
export {
  Inspector,
  InspectorActions,
  InspectorSection
};
