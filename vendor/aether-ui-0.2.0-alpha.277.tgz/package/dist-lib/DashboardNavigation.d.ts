import type { ReactNode } from "react";
import "./DashboardNavigation.css";
export interface DashboardNavItem {
    id: string;
    label: string;
    icon: ReactNode;
}
/** The standard collapsible sidebar in a compact dashboard rail configuration. */
export declare function DashboardNavigation({ id, brand, mark, items, activeID, onNavigate, secondary, footer }: {
    id: string;
    brand: string;
    mark: ReactNode;
    items: readonly DashboardNavItem[];
    activeID: string;
    onNavigate: (id: string) => void;
    secondary?: ReactNode;
    footer?: ReactNode;
}): import("react").JSX.Element;
