import { jsx, jsxs } from "react/jsx-runtime";
import { useId } from "react";
import "./DashboardCards.css";
function DashboardCard({ title, caption, action, children, className = "", density = "standard", contentOnly = false }) {
  const heading = useId();
  return /* @__PURE__ */ jsxs("section", { className: `aui-dashboard-card ${className}`, "data-density": density, "data-content-only": contentOnly || void 0, "aria-labelledby": heading, children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { id: heading, children: title }),
        caption && /* @__PURE__ */ jsx("div", { className: "aui-dashboard-card__caption", children: caption })
      ] }),
      action
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-dashboard-card__body", children })
  ] });
}
function MetricCard({ label, value, icon, change, trend = "neutral", detail }) {
  return /* @__PURE__ */ jsxs("article", { className: "aui-metric-card", "aria-label": `${label}: ${value}`, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-metric-card__label", children: [
      /* @__PURE__ */ jsx("span", { children: icon }),
      label
    ] }),
    /* @__PURE__ */ jsx("strong", { children: value }),
    /* @__PURE__ */ jsxs("footer", { children: [
      /* @__PURE__ */ jsxs("span", { className: "aui-metric-change", "data-trend": trend, children: [
        /* @__PURE__ */ jsx("b", { "aria-hidden": true, children: trend === "negative" ? "\u2193" : "\u2191" }),
        change
      ] }),
      /* @__PURE__ */ jsx("span", { children: detail })
    ] })
  ] });
}
function GoalProgress({ label, value, target, format = String }) {
  const ratio = target > 0 && Number.isFinite(value) ? Math.max(0, Math.min(100, value / target * 100)) : 0;
  return /* @__PURE__ */ jsxs("article", { className: "aui-goal-progress", children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsx("span", { children: label }),
      /* @__PURE__ */ jsxs("strong", { children: [
        Math.round(ratio),
        "%"
      ] })
    ] }),
    /* @__PURE__ */ jsx("progress", { "aria-label": label, max: 100, value: ratio }),
    /* @__PURE__ */ jsxs("footer", { children: [
      /* @__PURE__ */ jsx("strong", { children: format(value) }),
      /* @__PURE__ */ jsxs("span", { children: [
        "of ",
        format(target)
      ] })
    ] })
  ] });
}
function ActivityList({ items, onSelect }) {
  return /* @__PURE__ */ jsx("ul", { className: "aui-activity-list", children: items.length ? items.map((item) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("button", { type: "button", disabled: !onSelect, onClick: () => onSelect?.(item.id), children: [
    /* @__PURE__ */ jsx("span", { className: "aui-activity-dot", "data-tone": item.tone }),
    /* @__PURE__ */ jsx("span", { children: item.text }),
    /* @__PURE__ */ jsx("time", { children: item.time })
  ] }) }, item.id)) : /* @__PURE__ */ jsx("li", { className: "aui-dashboard-empty", children: "No activity to show." }) });
}
import { DataTable } from "./DataTable.js";
function DashboardTable({ density = "standard", ...props }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-dashboard-table", "data-density": density, children: /* @__PURE__ */ jsx(DataTable, { ...props }) });
}
export {
  ActivityList,
  DashboardCard,
  DashboardTable,
  GoalProgress,
  MetricCard
};
