import type { ReactNode } from "react";
export interface CommandPaletteArgument {
    label: string;
    placeholder?: string;
    submitLabel?: string;
    initialValue?: string;
    required?: boolean;
    help?: ReactNode;
}
export interface CommandPaletteCommand {
    id: string;
    label: string;
    category?: string;
    description?: string;
    keywords?: readonly string[];
    icon?: ReactNode;
    shortcut?: string;
    disabled?: boolean;
    disabledReason?: string;
    recent?: boolean;
    argument?: CommandPaletteArgument;
}
export interface CommandPaletteProps {
    open: boolean;
    commands: readonly CommandPaletteCommand[];
    onSelect: (id: string, argument?: string) => void;
    onClose: () => void;
    title?: string;
    placeholder?: string;
    emptyMessage?: string;
    recentLabel?: string;
    uncategorizedLabel?: string;
}
/** Product-free command chooser. Applications supply command availability and
 * execution; the palette owns only discovery, navigation, and argument entry. */
export declare function CommandPalette({ open, commands, onSelect, onClose, title, placeholder, emptyMessage, recentLabel, uncategorizedLabel, }: CommandPaletteProps): import("react").ReactPortal | null;
