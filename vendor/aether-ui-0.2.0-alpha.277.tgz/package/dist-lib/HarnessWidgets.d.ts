import type { ReactNode } from "react";
import "./HarnessWidgets.css";
export interface HarnessPin {
    side?: "left" | "right";
    id: string;
    label: string;
}
/** SVG presentation primitives. Coordinates, connections and electrical rules belong to the product. */
export declare function HarnessConnectorCard({ title, pins, selected, activePin, onPin, onSelect, portSide, }: {
    title: string;
    pins: readonly HarnessPin[];
    selected?: boolean;
    activePin?: string;
    portSide?: "left" | "right";
    onPin?: (id: string) => void;
    onSelect?: () => void;
}): import("react").JSX.Element;
export declare function ConnectorFace({ pins, title, triangular, }: {
    pins: readonly string[];
    title: string;
    triangular?: boolean;
}): import("react").JSX.Element;
export declare function ConnectorPreview({ title, tone, }: {
    title: string;
    tone?: "neutral" | "green" | "blue" | "orange";
}): import("react").JSX.Element;
export interface HarnessConnectionRow {
    id: string;
    pin: string;
    destination: string;
    color: string;
    part: string;
    length: string;
    contact?: string;
}
export declare function HarnessConnectionTable({ rows, width, contacts, onSelect, }: {
    rows: readonly HarnessConnectionRow[];
    width?: number;
    contacts?: boolean;
    onSelect?: (id: string) => void;
}): import("react").JSX.Element;
export declare function HarnessDrawingScope({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
