import './DocumentSaveGuard.css';
export declare function DocumentSaveGuard({ state, recoveries, onRecover, onKeepSaved, onSignIn, onRetry, onCopy, onDownload, onOpenSaved, recoveryOpensTab }: {
    state: {
        phase: string;
        message?: string;
        status?: number;
        backedUp?: boolean;
    };
    recoveries: {
        id: string;
        updated: number;
        revision?: number | string;
    }[];
    onOpenSaved?: () => void;
    recoveryOpensTab?: boolean;
    onRecover: (id: string) => void;
    onKeepSaved: () => void;
    onSignIn: () => void;
    onRetry: () => void;
    onCopy: () => void;
    onDownload: () => void;
}): import("react").JSX.Element | null;
