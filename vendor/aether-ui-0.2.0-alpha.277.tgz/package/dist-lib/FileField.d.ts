import type { ReactNode } from "react";
export interface FileFieldProps {
    files?: readonly File[];
    defaultFiles?: readonly File[];
    onFilesChange?: (files: readonly File[]) => void;
    label: ReactNode;
    accept?: string;
    multiple?: boolean;
    disabled?: boolean;
    help?: ReactNode;
    error?: ReactNode;
    className?: string;
}
export declare function FileField({ files, defaultFiles, onFilesChange, label, accept, multiple, disabled, help, error, className }: FileFieldProps): import("react").JSX.Element;
