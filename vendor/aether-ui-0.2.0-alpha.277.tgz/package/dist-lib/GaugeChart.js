import { jsx, jsxs } from "react/jsx-runtime";
import { useId } from "react";
import "./GaugeChart.css";
function GaugeChart({ label, value, detail, fraction }) {
  const id = useId().replace(/:/g, "");
  const ratio = Number.isFinite(fraction) ? Math.max(0, Math.min(1, fraction)) : 0;
  const length = Math.PI * 88;
  return /* @__PURE__ */ jsx("div", { className: "aui-gauge-chart", role: "meter", "aria-label": `${label}: ${value}`, "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": Math.round(ratio * 100), "aria-valuetext": `${value}${detail ? `, ${detail}` : ""}`, children: /* @__PURE__ */ jsxs("svg", { viewBox: "0 0 224 136", "aria-hidden": "true", children: [
    /* @__PURE__ */ jsxs("defs", { children: [
      /* @__PURE__ */ jsxs("linearGradient", { id, x1: "0", y1: "0", x2: "0", y2: "1", children: [
        /* @__PURE__ */ jsx("stop", { offset: "72%", stopColor: "white" }),
        /* @__PURE__ */ jsx("stop", { offset: "100%", stopColor: "black" })
      ] }),
      /* @__PURE__ */ jsx("mask", { id: `${id}-mask`, maskUnits: "userSpaceOnUse", x: "0", y: "0", width: "224", height: "136", children: /* @__PURE__ */ jsx("rect", { width: "224", height: "116", fill: `url(#${id})` }) })
    ] }),
    /* @__PURE__ */ jsxs("g", { mask: `url(#${id}-mask)`, fill: "none", strokeWidth: "44", children: [
      /* @__PURE__ */ jsx("path", { d: "M24 112 A88 88 0 0 1 200 112", stroke: "var(--aether-color-warn)" }),
      /* @__PURE__ */ jsx("path", { d: "M24 112 A88 88 0 0 1 200 112", stroke: "var(--aether-color-accent)", strokeDasharray: `${length * ratio} ${length}` }),
      ratio > 0 && ratio < 1 && /* @__PURE__ */ jsx("path", { d: "M24 112 A88 88 0 0 1 200 112", stroke: "var(--aether-color-bg-panel)", strokeDasharray: `0 ${Math.max(0, length * ratio - 1.5)} 3 ${length}` })
    ] }),
    /* @__PURE__ */ jsx("text", { className: "aui-gauge-value", x: "112", y: "94", textAnchor: "middle", children: value }),
    detail && /* @__PURE__ */ jsx("text", { className: "aui-gauge-detail", x: "112", y: "115", textAnchor: "middle", children: detail })
  ] }) });
}
export {
  GaugeChart
};
