import "./WorkflowWidgets.css";
export interface PersonalizationSource {
    kind: string;
    url: string;
    files: readonly File[];
    notes: string;
}
export declare function PersonalizationForm({ onImport }: {
    onImport: (source: PersonalizationSource) => void;
}): import("react").JSX.Element;
