import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { DashboardCard } from "./DashboardCards.js";
import { TextField } from "./TextField.js";
import { PasswordField } from "./PasswordField.js";
import { Checkbox } from "./Checkbox.js";
import { Button } from "./Button.js";
import "./WorkflowWidgets.css";
function AuthenticationForm({ mode, appName, onModeChange, onSubmit, onProvider, onResetPassword, busy }) {
  const [value, setValue] = useState({ name: "", email: "", password: "" });
  const signup = mode === "signup";
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title: signup ? `Create an ${appName} account` : `Log in to ${appName}`, className: "aui-workflow", children: /* @__PURE__ */ jsxs("form", { className: "aui-workflow-stack", onSubmit: (event) => {
    event.preventDefault();
    onSubmit(value);
  }, children: [
    signup && /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Full name",
      /* @__PURE__ */ jsx(TextField, { autoComplete: "name", required: true, value: value.name, onChange: (e) => setValue({ ...value, name: e.target.value }), placeholder: "First and last name" })
    ] }),
    /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Email",
      /* @__PURE__ */ jsx(TextField, { type: "email", autoComplete: "email", required: true, value: value.email, onChange: (e) => setValue({ ...value, email: e.target.value }), placeholder: "you@company.com" })
    ] }),
    /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Password",
      /* @__PURE__ */ jsx(PasswordField, { "aria-label": "Password", autoComplete: signup ? "new-password" : "current-password", required: true, minLength: signup ? 8 : void 0, value: value.password, onChange: (e) => setValue({ ...value, password: e.target.value }), placeholder: signup ? "At least 8 characters" : "Your password" })
    ] }),
    signup ? /* @__PURE__ */ jsx(Checkbox, { required: true, label: "I agree to the privacy policy" }) : onResetPassword && /* @__PURE__ */ jsx(Button, { appearance: "link", onClick: onResetPassword, children: "I forgot my password" }),
    /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", disabled: busy, children: busy ? "Please wait\u2026" : signup ? "Create account" : "Log in" }),
    onProvider && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-workflow-divider", children: [
        "Or ",
        signup ? "sign up" : "log in",
        " with"
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-workflow-actions", children: ["Google", "LinkedIn"].map((provider) => /* @__PURE__ */ jsx(Button, { onClick: () => onProvider(provider), children: provider }, provider)) })
    ] }),
    /* @__PURE__ */ jsx(Button, { appearance: "link", onClick: () => onModeChange(signup ? "login" : "signup"), children: signup ? "Have an account? Log in" : "New here? Create account" })
  ] }) });
}
export {
  AuthenticationForm
};
