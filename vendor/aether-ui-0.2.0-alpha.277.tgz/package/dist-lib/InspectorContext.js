import { createContext } from "react";
const InspectorContext = createContext(false);
export {
  InspectorContext
};
