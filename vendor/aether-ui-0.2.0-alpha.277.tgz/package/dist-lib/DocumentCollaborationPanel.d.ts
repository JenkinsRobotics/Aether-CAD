import type { DocumentConnection } from "./DocumentServices.js";
import "./DocumentPanels.css";
export type CollaborationKind = "comments" | "notes" | "tasks" | "reminders";
export declare function DocumentCollaborationPanel({ connection, kind, variant, reviewTag, onReviewTag, }: {
    connection: DocumentConnection;
    reviewTag?: string;
    onReviewTag?: (tag: string) => void;
    kind: CollaborationKind;
    variant?: "standard" | "studio";
}): import("react").JSX.Element;
