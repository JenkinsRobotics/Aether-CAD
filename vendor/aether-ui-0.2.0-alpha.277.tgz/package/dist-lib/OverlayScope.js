import { jsx, jsxs } from "react/jsx-runtime";
import { createContext, useContext, useState } from "react";
const OverlayHost = createContext(null);
function OverlayScope({ children, ...props }) {
  const [host, setHost] = useState(null);
  return /* @__PURE__ */ jsx("div", { ...props, children: /* @__PURE__ */ jsxs(OverlayHost.Provider, { value: host, children: [
    children,
    /* @__PURE__ */ jsx("div", { ref: setHost, "data-aether-overlay-host": "" })
  ] }) });
}
function useOverlayHost() {
  return useContext(OverlayHost);
}
export {
  OverlayScope,
  useOverlayHost
};
