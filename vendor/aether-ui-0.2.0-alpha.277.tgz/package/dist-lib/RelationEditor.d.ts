import "./RelationEditor.css";
/** Display values only. The owning product converts units and validates/evaluates coupling. */
export interface RelationEditorValue {
    kind: string;
    driver: string;
    driven: string;
    magnitude: number;
    reversed: boolean;
    offset: number;
}
export interface RelationEditorOption {
    value: string;
    label: string;
}
export interface RelationEditorProps {
    value: RelationEditorValue;
    onChange: (value: RelationEditorValue) => void;
    kinds: readonly RelationEditorOption[];
    drivers: readonly RelationEditorOption[];
    driven: readonly RelationEditorOption[];
    ratioLabel: string;
    ratioUnit?: string;
    offsetUnit: string;
    compatibility?: string;
    busy?: boolean;
    editing?: boolean;
    error?: string;
    description?: string;
    valid?: boolean;
    onApply: () => void;
    onCancel: () => void;
    onRemove?: () => void;
}
export declare function RelationEditor(props: RelationEditorProps): import("react").JSX.Element;
