import { type TextFieldProps } from "./TextField.js";
import "./WorkflowElements.css";
export type PasswordFieldProps = Omit<TextFieldProps, "type" | "unit">;
export declare function PasswordField(props: PasswordFieldProps): import("react").JSX.Element;
