export interface SearchFieldScope {
    id: string;
    label: string;
}
export interface SearchFieldProps {
    id?: string;
    value?: string;
    defaultValue?: string;
    onQueryChange?: (query: string) => void;
    onSearch?: (query: string) => void;
    delayMilliseconds?: number;
    placeholder?: string;
    ariaLabel?: string;
    resultCount?: number;
    scopes?: readonly SearchFieldScope[];
    scopeID?: string;
    onScopeChange?: (scopeID: string) => void;
    disabled?: boolean;
    autoFocus?: boolean;
    inputRef?: {
        current: HTMLInputElement | null;
    } | ((element: HTMLInputElement | null) => void);
    className?: string;
}
/** Shared collection search. Products retain matching semantics; this widget
 * owns query entry, delayed search intent, scope selection, and clear/status UI. */
export declare function SearchField({ id, value, defaultValue, onQueryChange, onSearch, delayMilliseconds, placeholder, ariaLabel, resultCount, scopes, scopeID, onScopeChange, disabled, autoFocus, inputRef, className, }: SearchFieldProps): import("react").JSX.Element;
