function treePanelContextItems(controls, options) {
  const unique = controls.filter((entry, index) => controls.findIndex((other) => other.id === entry.id) === index);
  return [
    ...options.extra,
    ...unique.map((control) => ({ ...control, id: `control:${control.id}`, separatorBefore: control.separatorBefore || control === unique[0] && options.extra.length > 0 })),
    ...options.expand || options.collapse ? [
      { id: "tree:expand", label: "Expand all", disabled: !options.expand, separatorBefore: true },
      { id: "tree:collapse", label: "Collapse all", disabled: !options.collapse }
    ] : [],
    ...options.filterOptions ? [{ id: "tree:filter", label: "Show in tree", separatorBefore: true, children: [{ id: "all", label: "All items" }, ...options.filterOptions].map((option) => ({
      id: `filter:${option.id}`,
      label: option.label,
      kind: "radio",
      checked: options.category === option.id
    })) }] : [],
    ...options.query ? [{ id: "tree:clear-filter", label: "Clear search" }] : []
  ];
}
export {
  treePanelContextItems
};
