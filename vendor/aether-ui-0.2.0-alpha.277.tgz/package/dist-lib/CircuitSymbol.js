import { jsx, jsxs } from "react/jsx-runtime";
import {
  circuitPaths
} from "@aether/assets/electronics/symbols";
function CircuitSymbol({
  kind,
  lit = false,
  ...props
}) {
  return /* @__PURE__ */ jsxs(
    "svg",
    {
      viewBox: "-6 -6 122 92",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": "true",
      ...props,
      children: [
        lit && kind === "led" && /* @__PURE__ */ jsx(
          "circle",
          {
            cx: "53",
            cy: "40",
            r: "27",
            fill: "currentColor",
            opacity: ".18",
            stroke: "none"
          }
        ),
        /* @__PURE__ */ jsx("path", { d: circuitPaths[kind] })
      ]
    }
  );
}
export {
  CircuitSymbol
};
