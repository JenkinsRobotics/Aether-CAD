import { jsx } from "react/jsx-runtime";
import { appMarkSources } from "@aether/assets/branding/marks/sources";
function AppMark({ app = "studio", size = 32, alt = "", style, ...props }) {
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: appMarkSources[app],
      alt,
      width: size,
      height: size,
      decoding: "async",
      style: { objectFit: "contain", flexShrink: 0, ...style },
      ...props
    }
  );
}
export {
  AppMark
};
