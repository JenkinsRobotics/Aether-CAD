import type { ReactNode } from "react";
import { type ApplicationUpdate } from "./ApplicationUpdates.js";
export declare function ApplicationWelcome({ name, description, artwork, wideArtwork, badge, updates }: {
    id: string;
    name: string;
    description: string;
    artwork: ReactNode;
    wideArtwork?: ReactNode;
    badge?: string;
    updates?: readonly ApplicationUpdate[];
}): import("react").JSX.Element;
