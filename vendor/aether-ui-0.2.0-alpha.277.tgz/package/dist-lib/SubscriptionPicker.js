import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useId } from "react";
import { DashboardCard } from "./DashboardCards.js";
import { SegmentedControl } from "./SegmentedControl.js";
import { ChoiceCard } from "./ChoiceCard.js";
import { SelectField } from "./SelectField.js";
import { Button } from "./Button.js";
import "./WorkflowWidgets.css";
function SubscriptionPicker({ plans, selected, onSelect, period, onPeriodChange, allowance, allowances, onAllowanceChange, onSubscribe }) {
  const name = useId();
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title: "Subscription", className: "aui-workflow", children: /* @__PURE__ */ jsxs("div", { className: "aui-workflow-stack", children: [
    /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Billing period", value: period, onChange: onPeriodChange, options: [{ id: "yearly", label: "Bill yearly" }, { id: "monthly", label: "Bill monthly" }] }),
    /* @__PURE__ */ jsx("div", { role: "group", "aria-label": "Plans", className: "aui-workflow-stack", children: plans.map((plan) => /* @__PURE__ */ jsx(ChoiceCard, { name, value: plan.id, label: plan.label, description: plan.description, checked: selected === plan.id, onChange: onSelect, detail: /* @__PURE__ */ jsxs(Fragment, { children: [
      plan.price,
      /* @__PURE__ */ jsx("small", { children: plan.detail })
    ] }), children: /* @__PURE__ */ jsxs("div", { className: "aui-workflow-actions", children: [
      /* @__PURE__ */ jsx(SelectField, { "aria-label": "Credit allowance", value: allowance, onChange: (e) => onAllowanceChange(e.target.value), options: allowances }),
      /* @__PURE__ */ jsx(Button, { primary: true, onClick: onSubscribe, children: "Subscribe" })
    ] }) }, plan.id)) }),
    /* @__PURE__ */ jsxs("details", { className: "aui-workflow-details", children: [
      /* @__PURE__ */ jsx("summary", { children: "Compare features" }),
      /* @__PURE__ */ jsx("ul", { children: plans.map((plan) => /* @__PURE__ */ jsxs("li", { children: [
        /* @__PURE__ */ jsx("strong", { children: plan.label }),
        " \u2014 ",
        plan.description,
        " \xB7 ",
        plan.detail
      ] }, plan.id)) })
    ] })
  ] }) });
}
export {
  SubscriptionPicker
};
