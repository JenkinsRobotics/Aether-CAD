import type { ReactNode } from 'react';
import './AgentSetupGuide.css';
export interface AgentSetupGuideProps {
    clients: {
        value: string;
        label: string;
    }[];
    client: string;
    onClientChange: (client: string) => void;
    description?: ReactNode;
    steps: {
        id: string;
        title: string;
        content: ReactNode;
    }[];
}
/** Shared presentation only. The host owns permissions, configuration and tests. */
export declare function AgentSetupGuide({ clients, client, onClientChange, description, steps }: AgentSetupGuideProps): import("react").JSX.Element;
