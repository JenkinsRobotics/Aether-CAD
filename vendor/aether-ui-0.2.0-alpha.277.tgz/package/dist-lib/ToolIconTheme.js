import { jsx } from "react/jsx-runtime";
import { createContext, useContext, useSyncExternalStore } from "react";
const ToolIconContext = createContext(null);
const ICON_PACK_KEY = "aether.tool-icon-pack";
function activeToolIconPack() {
  try {
    return localStorage.getItem(ICON_PACK_KEY) === "graphite-ribbon" ? "graphite-ribbon" : "classic";
  } catch {
    return "classic";
  }
}
function setToolIconPack(pack) {
  try {
    localStorage.setItem(ICON_PACK_KEY, pack);
  } catch {
  }
  window.dispatchEvent(new Event("aether-icon-pack"));
}
function subscribe(listener) {
  window.addEventListener("storage", listener);
  window.addEventListener("aether-icon-pack", listener);
  return () => {
    window.removeEventListener("storage", listener);
    window.removeEventListener("aether-icon-pack", listener);
  };
}
function useGlobalToolIconPack() {
  return useSyncExternalStore(subscribe, activeToolIconPack, () => "classic");
}
function ToolIconTheme({ pack, palette = "auto", children }) {
  return /* @__PURE__ */ jsx(ToolIconContext.Provider, { value: { pack, palette }, children });
}
function useToolIconTheme() {
  const scoped = useContext(ToolIconContext);
  const pack = useGlobalToolIconPack();
  return scoped ?? { pack, palette: "auto" };
}
export {
  ToolIconTheme,
  activeToolIconPack,
  setToolIconPack,
  useGlobalToolIconPack,
  useToolIconTheme
};
