import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Popover } from "./Popover.js";
import { SelectField } from "./SelectField.js";
import { Button } from "./Button.js";
import { useWorkspaceChrome, setWorkspaceChrome } from "./WorkspaceChromePreferences.js";
function WorkspaceLayoutControl({ controls }) {
  const [anchor, setAnchor] = useState(null);
  const chrome = useWorkspaceChrome();
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-icon-button", "aria-label": "Workspace layout", "aria-expanded": !!anchor, onClick: (event) => setAnchor(anchor ? null : event.currentTarget), children: /* @__PURE__ */ jsx(AetherIcon, { name: "layout" }) }),
    /* @__PURE__ */ jsx(Popover, { open: !!anchor, anchor, onClose: () => setAnchor(null), ariaLabel: "Workspace layout", placement: "bottom-end", children: /* @__PURE__ */ jsxs("div", { style: { width: 280, maxHeight: "70vh", overflow: "auto", display: "grid", gap: 10, padding: 10 }, children: [
      /* @__PURE__ */ jsx("strong", { children: "Workspace layout" }),
      /* @__PURE__ */ jsxs("label", { children: [
        "Toolbar density",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Toolbar density", value: chrome.toolbarDensity, options: ["app", "compact", "standard", "expanded"].map((value) => ({ value, label: value === "app" ? "App default" : value })), onChange: (event) => setWorkspaceChrome({ toolbarDensity: event.target.value }) })
      ] }),
      controls.panels.map((panel) => /* @__PURE__ */ jsxs("label", { style: { display: "grid", gridTemplateColumns: "1fr 120px", alignItems: "center", gap: 8 }, children: [
        panel.label,
        /* @__PURE__ */ jsx(SelectField, { "aria-label": `${panel.label} placement`, value: panel.placement, options: [{ value: "docked", label: `Dock ${panel.side}` }, { value: "floating", label: "Float" }, { value: "hidden", label: "Hidden" }], onChange: (event) => controls.place(panel.id, event.target.value) })
      ] }, panel.id)),
      /* @__PURE__ */ jsx(Button, { onClick: controls.reset, children: "Reset panel placements" })
    ] }) })
  ] });
}
export {
  WorkspaceLayoutControl
};
