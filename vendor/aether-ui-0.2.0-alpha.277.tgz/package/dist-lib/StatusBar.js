import { Fragment, jsx, jsxs } from "react/jsx-runtime";
function StatusDot({ kind }) {
  const classes = ["aui-status-dot"];
  if (kind === "ok") classes.push("aui-status-dot--ok");
  if (kind === "error") classes.push("aui-status-dot--error");
  if (kind === "busy") classes.push("aui-status-dot--busy");
  return /* @__PURE__ */ jsx("span", { className: classes.join(" "), "aria-hidden": true });
}
function StatusBar({ leading, center, trailing, children }) {
  const hasRegions = leading !== void 0 || center !== void 0 || trailing !== void 0;
  return /* @__PURE__ */ jsx("div", { className: "aui-status-bar", role: "status", "aria-label": "Workspace status", children: hasRegions ? /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("div", { className: "aui-status-bar__leading", children: leading }),
    /* @__PURE__ */ jsx("div", { className: "aui-status-bar__center", children: center }),
    /* @__PURE__ */ jsx("div", { className: "aui-status-bar__trailing", children: trailing })
  ] }) : children });
}
export {
  StatusBar,
  StatusDot
};
