import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import "./ConceptInspectors.css";
function CompactActionPanel({ primaryLabel = "New Query", primaryShortcut = "\u2318N", settingsShortcut = "\u2318S", initialTheme = "dark", onPrimary, onSettings }) {
  const [theme, setTheme] = useState(initialTheme);
  const [selected, setSelected] = useState("query");
  const [count, setCount] = useState(0);
  return /* @__PURE__ */ jsxs("div", { className: `aui-compact-action-panel is-${theme}`, children: [
    /* @__PURE__ */ jsxs("button", { type: "button", className: "primary", "aria-pressed": selected === "query", onClick: () => {
      setSelected("query");
      setCount((n) => n + 1);
      onPrimary?.();
    }, children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }),
      /* @__PURE__ */ jsx("strong", { children: primaryLabel }),
      /* @__PURE__ */ jsx("kbd", { children: primaryShortcut })
    ] }),
    /* @__PURE__ */ jsxs("button", { type: "button", "aria-pressed": selected === "settings", onClick: () => {
      setSelected("settings");
      onSettings?.();
    }, children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }),
      /* @__PURE__ */ jsx("strong", { children: "Settings" }),
      /* @__PURE__ */ jsx("kbd", { children: settingsShortcut })
    ] }),
    /* @__PURE__ */ jsx("div", { role: "group", "aria-label": "Panel theme", children: ["light", "dark"].map((mode) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-pressed": theme === mode, onClick: () => setTheme(mode), children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: mode === "light" ? "appearance-light" : "appearance-dark" }),
      mode === "light" ? "Light" : "Dark"
    ] }, mode)) }),
    /* @__PURE__ */ jsx("output", { children: count ? `Created query ${count}` : "Commands are interactive" })
  ] });
}
export {
  CompactActionPanel
};
