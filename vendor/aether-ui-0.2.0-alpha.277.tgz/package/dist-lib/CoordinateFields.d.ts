import type { ReactNode } from 'react';
import './CoordinateFields.css';
export interface CoordinateFieldsProps {
    label: string;
    fields: readonly {
        axis: string;
        control: ReactNode;
    }[];
}
/** One compact XY/XYZ row. Products retain units, parsing and commit semantics. */
export declare function CoordinateFields({ label, fields }: CoordinateFieldsProps): import("react").JSX.Element;
/** Same anatomy for existing imperative FeatureWindow clients. Inputs retain
 * their listeners and value state when mounted into the row. */
export declare function createCoordinateFields(label: string, fields: readonly {
    axis: string;
    control: HTMLElement;
}[]): HTMLElement;
