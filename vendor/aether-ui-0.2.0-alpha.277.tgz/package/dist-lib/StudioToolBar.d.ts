import type { WorkspaceRibbonProps } from "./WorkspaceRibbon.js";
/** Defined here rather than in WorkspaceRibbon to avoid a value import cycle;
 * WorkspaceRibbon re-exports it as part of the public API. */
export declare const STUDIO_TOOLBAR_DENSITIES: readonly [{
    readonly id: "compact";
    readonly label: "Compact";
}, {
    readonly id: "standard";
    readonly label: "Standard";
}, {
    readonly id: "expanded";
    readonly label: "Expanded";
}];
/** The demo's command field and floating icon strip, backed by each app's
 * existing command catalog. Categories, variants and overflow remain reachable.
 * Right-click offers toolbar settings: density plus the app's own entries. */
export declare function StudioToolBar(props: WorkspaceRibbonProps): import("react").JSX.Element;
