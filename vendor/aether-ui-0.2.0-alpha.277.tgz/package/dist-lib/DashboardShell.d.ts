import type { ReactNode } from "react";
import "./DashboardShell.css";
export interface DashboardNavigationGroup {
    label: string;
    items: readonly {
        id: string;
        label: string;
        icon: ReactNode;
    }[];
}
/** Business-app template. Collapsing navigation, page header, and a scrolling content canvas. */
export declare function DashboardShell({ id, brand, subtitle, mark, navigation, activeID, onNavigate, search, profile, breadcrumb, title, actions, children }: {
    id: string;
    brand: string;
    subtitle: string;
    mark: ReactNode;
    navigation: readonly DashboardNavigationGroup[];
    activeID: string;
    onNavigate: (id: string) => void;
    search?: ReactNode;
    profile?: ReactNode;
    breadcrumb: ReactNode;
    title: string;
    actions?: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
