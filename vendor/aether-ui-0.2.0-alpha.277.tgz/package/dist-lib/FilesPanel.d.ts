import { type DragEventHandler, type ReactNode } from 'react';
import { type MenuItem } from './Menu.js';
import './FilesPanel.css';
type Actions = {
    items: readonly MenuItem[];
    onSelect: (id: string) => void;
};
/**
 * The list inside a Files panel (CAD's design contents, Map's media pool)
 * declares everything it can create or import here, once. The panel header's
 * "+" then lists exactly that, beside the notification button, so every app's
 * Files header offers its full action list the same way.
 */
export declare function useFilesPanelActions(actions: Actions | null): void;
export interface FilesPanelProps {
    /** The app's own scope: "This design" (CAD), "Media pool" (Map). */
    local: {
        label: string;
        icon: ReactNode;
        content: ReactNode;
        onDragStart?: DragEventHandler<HTMLDivElement>;
    };
    /** The Studio Drive browser, the second scope. */
    drive: ReactNode;
    error?: string;
    /** Files dropped from the computer anywhere on the panel. */
    onFiles?: (files: File[]) => void;
}
/** Standard Files panel: header with "+" and notifications, This-document | Drive, and the chosen list. */
export declare function FilesPanel({ local, drive, error, onFiles }: FilesPanelProps): import("react").JSX.Element;
export {};
