import type { ReactNode } from "react";
export interface DockPanelProps {
    title?: string;
    actions?: ReactNode;
    width?: number | string;
    children: ReactNode;
}
/**
 * A docked side panel: heading + scrollable body. Multi-panel docking
 * layout (drag/split) is the app shell's concern (see the UI framework
 * decision record: use an established docking library there).
 */
export declare function DockPanel({ title, actions, width, children }: DockPanelProps): import("react").JSX.Element;
