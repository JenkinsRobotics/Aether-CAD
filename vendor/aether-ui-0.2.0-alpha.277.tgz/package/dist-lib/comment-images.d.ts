import type { CommentImage } from "./DocumentServices.js";
export declare function commentImage(file: File): Promise<CommentImage>;
/** User-initiated browser chooser; tracks always stop after the selected frame. */
export declare function commentScreenshot(): Promise<CommentImage>;
