import { jsx, jsxs } from "react/jsx-runtime";
import { createContext, useContext, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { Menu, MenuButton } from "./Menu.js";
import { CollectionFooter } from "./CollectionFooter.js";
import "./CollectionView.css";
const CollectionHost = createContext({});
function CollectionActions({ controls = [], primaryControls, label = "Item controls", items, onCommand }) {
  const host = useContext(CollectionHost);
  const all = [...primaryControls ?? [], ...controls, ...host.controls ?? []];
  const creation = (items ?? all.filter((item, index) => all.findIndex((other) => other.id === item.id) === index).filter((item) => item.scope !== "row" && !item.shortcut)).filter((item) => /^(new|add|create|insert|import)\b/i.test(item.label));
  const run = (id) => items ? onCommand?.(id) : all.find((item) => item.id === id && !item.disabled)?.onClick();
  if (!creation.length) return null;
  return /* @__PURE__ */ jsx("div", { className: "aui-collection-actions", role: "group", "aria-label": label, children: creation.length === 1 && !items ? /* @__PURE__ */ jsx(IconButton, { label: creation[0].label, disabled: creation[0].disabled, onClick: () => run(creation[0].id), children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }) : /* @__PURE__ */ jsx(
    MenuButton,
    {
      className: "aui-icon-button",
      label: `Create in ${label}`,
      menuClassName: "aui-collection-popup",
      items: creation,
      onSelect: run,
      children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" })
    }
  ) });
}
function CollectionView({
  title,
  headerActions,
  filter,
  children,
  footer,
  controls,
  primaryControls,
  controlsLabel,
  menuItems,
  onCommand,
  showFooter = true,
  actionPlacement = "footer",
  className = "",
  id,
  onKeyDown,
  onContextMenu
}) {
  const host = useContext(CollectionHost);
  const [context, setContext] = useState(null);
  const commands = [...primaryControls ?? [], ...controls ?? [], ...host.controls ?? []].filter((control) => control.scope !== "row" && !control.shortcut).filter((control, index, all) => all.findIndex((item) => item.id === control.id) === index);
  const items = menuItems ?? commands;
  const run = (id2) => menuItems ? onCommand?.(id2) : commands.find((command) => command.id === id2 && !command.disabled)?.onClick();
  const label = title ?? host.title ?? "Items";
  return /* @__PURE__ */ jsxs("div", { id, className: `aui-collection ${className}`, onKeyDown, onContextMenu: (event) => {
    if (onContextMenu) {
      onContextMenu(event);
      return;
    }
    if (event.target.closest('input, textarea, [contenteditable], [role="menu"], [role="treeitem"], [role="option"], [role="row"], [role="listitem"], li')) return;
    event.preventDefault();
    event.stopPropagation();
    if (items.length) setContext({ x: event.clientX, y: event.clientY });
  }, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-collection-heading", children: [
      /* @__PURE__ */ jsx("strong", { children: label }),
      /* @__PURE__ */ jsxs("span", { className: "aui-collection-heading-actions", children: [
        /* @__PURE__ */ jsx(CollectionActions, { controls, primaryControls, label: controlsLabel, items: menuItems, onCommand: run }),
        actionPlacement === "header" && items.length > 0 && /* @__PURE__ */ jsx(
          MenuButton,
          {
            className: "aui-icon-button",
            label: `${label} options`,
            menuClassName: "aui-collection-popup",
            items,
            onSelect: run,
            children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" })
          }
        )
      ] })
    ] }),
    filter && /* @__PURE__ */ jsx("div", { className: "aui-collection-search", children: filter }),
    children,
    footer,
    showFooter && actionPlacement === "footer" && /* @__PURE__ */ jsx(CollectionFooter, { label, items, onCommand: run, children: headerActions }),
    context && /* @__PURE__ */ jsx(
      Menu,
      {
        className: "aui-collection-popup",
        open: true,
        anchor: context,
        ariaLabel: `${title ?? host.title ?? "Collection"} actions`,
        items,
        onClose: () => setContext(null),
        onSelect: (id2) => {
          run(id2);
          setContext(null);
        }
      }
    )
  ] });
}
export {
  CollectionActions,
  CollectionHost,
  CollectionView
};
