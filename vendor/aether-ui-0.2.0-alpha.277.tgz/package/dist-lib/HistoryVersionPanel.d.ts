import { type ReactNode } from 'react';
import './HistoryPanel.css';
/** One auxiliary slot, with the same panel tabs as Comments / Tasks. Both pages
 * stay mounted so switching tabs never loses expanded rows or version filters. */
export declare function HistoryVersionPanel({ history, versions, initialTab, storageKey }: {
    history?: ReactNode;
    versions: ReactNode;
    initialTab?: 'history' | 'versions';
    /** Per-editor preference; survives the full navigation used to check out a branch. */
    storageKey?: string;
}): import("react").JSX.Element;
