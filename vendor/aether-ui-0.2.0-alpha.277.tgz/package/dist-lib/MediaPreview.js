import { jsx, jsxs } from "react/jsx-runtime";
import "./MediaPreview.css";
function MediaPreview({ label, width, height, background, backgroundImage, backgroundFilter, foreground, playing = false, children }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-media-preview", role: "group", "aria-label": label, "data-playing": playing, style: { aspectRatio: `${Math.max(1, width)} / ${Math.max(1, height)}`, background }, children: [
    backgroundImage && /* @__PURE__ */ jsx("img", { className: "aui-media-preview__background", src: backgroundImage, alt: "", draggable: false, style: { filter: backgroundFilter } }),
    foreground && /* @__PURE__ */ jsx("div", { className: "aui-media-preview__subject", style: { left: `${50 + (foreground.offset ?? 0)}%`, transform: `translateX(-50%) scale(${(foreground.scale ?? 100) / 100})` }, children: /* @__PURE__ */ jsx("img", { src: foreground.src, alt: foreground.alt, draggable: false, style: { transform: foreground.mirrored ? "scaleX(-1)" : void 0, filter: foreground.filter } }) }),
    children
  ] });
}
export {
  MediaPreview
};
