import './GradientControls.css';
/** Controlled presentation contract; products own paint validation and storage. */
export interface GradientControlsProps {
    value: {
        kind: 'linear' | 'radial';
        angleDeg: number;
        stops: {
            offset: number;
            color: string;
            opacity: number;
        }[];
    };
    onChange: (value: GradientControlsProps['value']) => void;
    disabled?: boolean;
}
export declare function GradientControls({ value, onChange, disabled }: GradientControlsProps): import("react").JSX.Element;
