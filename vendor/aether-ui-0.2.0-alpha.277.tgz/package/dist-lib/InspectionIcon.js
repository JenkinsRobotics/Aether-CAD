import { jsx } from "react/jsx-runtime";
import { useContext } from "react";
import { StudioDesignContext } from "./StudioDesignContext.js";
import { AetherIcon } from "./AetherIcon.js";
import measure from "@aether/assets/icons/tools/inspect-measure.svg?raw";
import section from "@aether/assets/icons/tools/inspect-section.svg?raw";
import interference from "@aether/assets/icons/tools/inspect-interference.svg?raw";
const icons = { measure, section, interference };
function InspectionIcon({ kind }) {
  const studio = useContext(StudioDesignContext);
  if (studio) return /* @__PURE__ */ jsx(AetherIcon, { name: kind === "measure" ? "ruler" : kind === "section" ? "cube-transparent" : "cube" });
  return /* @__PURE__ */ jsx("span", { "aria-hidden": "true", "data-inspection-icon": kind, style: { display: "inline-flex", width: "100%", height: "100%" }, dangerouslySetInnerHTML: { __html: icons[kind].replace("<svg ", '<svg width="100%" height="100%" ') } });
}
export {
  InspectionIcon
};
