import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Checkbox } from "./Checkbox.js";
import { ColorField } from "./ColorField.js";
import { NumberField } from "./NumberField.js";
import { SegmentedControl } from "./SegmentedControl.js";
import { SelectField } from "./SelectField.js";
import "./LayoutStyleControls.css";
const defaultLayoutStyle = { direction: "row", alignment: "center", gap: 12, padding: 16, radius: 8, strokeWidth: 1, stroke: "#b8bec8", fill: "#f5f7fa", clip: true };
function LayoutStyleControls({ value, onChange }) {
  const [local, setLocal] = useState(defaultLayoutStyle);
  const v = value ?? local;
  const update = (patch) => {
    const next = { ...v, ...patch };
    if (!value) setLocal(next);
    onChange?.(next);
  };
  const number = (label, key, max = 100) => /* @__PURE__ */ jsxs("label", { children: [
    label,
    /* @__PURE__ */ jsx(NumberField, { "aria-label": label, value: v[key], min: 0, max, unit: "px", onCommit: (n) => update({ [key]: n }) })
  ] });
  const style = { flexDirection: v.direction, alignItems: v.alignment === "start" ? "flex-start" : v.alignment === "end" ? "flex-end" : v.alignment, gap: v.gap, padding: v.padding, borderRadius: v.radius, border: `${v.strokeWidth}px solid ${v.stroke}`, background: v.fill, overflow: v.clip ? "hidden" : "visible" };
  return /* @__PURE__ */ jsxs("section", { className: "aui-layout-style", "aria-label": "Layout and style controls", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("fieldset", { children: [
        /* @__PURE__ */ jsx("legend", { children: "LAYOUT" }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Direction",
          /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Layout direction", value: v.direction, onChange: (direction) => update({ direction }), options: [{ id: "row", label: "Row" }, { id: "column", label: "Column" }] })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Alignment",
          /* @__PURE__ */ jsx(SelectField, { "aria-label": "Layout alignment", value: v.alignment, onChange: (e) => update({ alignment: e.target.value }), options: ["stretch", "center", "start", "end"].map((id) => ({ value: id, label: id[0].toUpperCase() + id.slice(1) })) })
        ] }),
        number("Gap", "gap"),
        number("Padding", "padding")
      ] }),
      /* @__PURE__ */ jsxs("fieldset", { children: [
        /* @__PURE__ */ jsx("legend", { children: "BORDER & BACKGROUND" }),
        number("Radius", "radius"),
        number("Stroke width", "strokeWidth", 12),
        /* @__PURE__ */ jsxs("label", { children: [
          "Stroke",
          /* @__PURE__ */ jsx(ColorField, { ariaLabel: "Layout stroke", value: v.stroke, onChange: (stroke) => update({ stroke }) })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Fill",
          /* @__PURE__ */ jsx(ColorField, { ariaLabel: "Layout fill", value: v.fill, onChange: (fill) => update({ fill }) })
        ] }),
        /* @__PURE__ */ jsx(Checkbox, { label: "Clip content", checked: v.clip, onChange: (e) => update({ clip: e.target.checked }) })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-layout-style__stage", children: /* @__PURE__ */ jsx("div", { className: "aui-layout-style__preview", "aria-label": "Layout preview", style, children: [1, 2, 3].map((i) => /* @__PURE__ */ jsx("span", { children: i }, i)) }) })
  ] });
}
export {
  LayoutStyleControls,
  defaultLayoutStyle
};
