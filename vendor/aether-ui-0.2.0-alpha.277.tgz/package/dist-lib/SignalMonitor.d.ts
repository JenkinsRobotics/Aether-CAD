import "./SignalMonitor.css";
export interface SignalTrace {
    id: string;
    label: string;
    values: readonly number[];
    color?: string;
}
/** Normalized presentation traces, labelled by the caller; no simulated data invented here. */
export declare function SignalMonitor({ traces, caption, duration, }: {
    traces: readonly SignalTrace[];
    caption?: string;
    duration?: string;
}): import("react").JSX.Element;
