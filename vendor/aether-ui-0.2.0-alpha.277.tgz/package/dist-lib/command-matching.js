function normalize(value) {
  return value.toLocaleLowerCase().trim();
}
function fuzzyScore(command, query) {
  const needle = normalize(query);
  if (!needle) return 0;
  const label = normalize(command.label);
  const haystack = normalize([command.label, command.category, command.description, ...command.keywords ?? []].filter(Boolean).join(" "));
  if (label === needle) return 1e3;
  if (label.startsWith(needle)) return 800 - label.length;
  const direct = haystack.indexOf(needle);
  if (direct >= 0) return 600 - direct - haystack.length / 100;
  let cursor = 0;
  let gaps = 0;
  for (const character of needle) {
    const found = haystack.indexOf(character, cursor);
    if (found < 0) return null;
    gaps += found - cursor;
    cursor = found + 1;
  }
  return 300 - gaps - haystack.length / 100;
}
export {
  fuzzyScore,
  normalize
};
