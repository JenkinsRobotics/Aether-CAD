import "./WorkflowWidgets.css";
export interface AuthenticationValues {
    name: string;
    email: string;
    password: string;
}
export interface AuthenticationFormProps {
    mode: "login" | "signup";
    appName: string;
    onModeChange: (mode: "login" | "signup") => void;
    onSubmit: (value: AuthenticationValues) => void;
    onProvider?: (provider: string) => void;
    onResetPassword?: () => void;
    busy?: boolean;
}
export declare function AuthenticationForm({ mode, appName, onModeChange, onSubmit, onProvider, onResetPassword, busy }: AuthenticationFormProps): import("react").JSX.Element;
