export declare function registerFeatureWindow(panel: HTMLElement, viewport: HTMLElement): {
    focus: () => void;
    isFrontmost: () => boolean;
    dispose(): void;
};
