import { jsx, jsxs } from "react/jsx-runtime";
import { DashboardCard } from "./DashboardCards.js";
import { TextField } from "./TextField.js";
import { SettingsLink } from "./SettingsLink.js";
import { Button } from "./Button.js";
import "./WorkflowWidgets.css";
function AccountProfile({ value, email, onChange, onAction, onSave, onCancel }) {
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title: "Account settings", className: "aui-workflow", children: /* @__PURE__ */ jsxs("form", { className: "aui-workflow-stack", onSubmit: (e) => {
    e.preventDefault();
    onSave();
  }, children: [
    /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Your full name",
      /* @__PURE__ */ jsx(TextField, { required: true, value: value.name, autoComplete: "name", onChange: (e) => onChange({ ...value, name: e.target.value }) })
    ] }),
    /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Company name",
      /* @__PURE__ */ jsx(TextField, { value: value.company, autoComplete: "organization", onChange: (e) => onChange({ ...value, company: e.target.value }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-workflow-settings", children: [
      /* @__PURE__ */ jsx(SettingsLink, { label: "API key", description: "Connect with other apps", onClick: () => onAction("api-key") }),
      /* @__PURE__ */ jsx(SettingsLink, { label: "Email", description: email, onClick: () => onAction("email") }),
      /* @__PURE__ */ jsx(SettingsLink, { label: "Password", description: "Update your sign-in password", onClick: () => onAction("password") }),
      /* @__PURE__ */ jsx(SettingsLink, { label: "Delete account", description: "Permanently remove your account data", destructive: true, onClick: () => onAction("delete") })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-workflow-actions", children: [
      /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", children: "Update" }),
      /* @__PURE__ */ jsx(Button, { appearance: "flat", onClick: onCancel, children: "Cancel" })
    ] })
  ] }) });
}
export {
  AccountProfile
};
