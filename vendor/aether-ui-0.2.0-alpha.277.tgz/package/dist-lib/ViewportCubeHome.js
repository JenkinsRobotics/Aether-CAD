import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Menu } from "./Menu.js";
function ViewportCubeHome({ onHome, items, onSelect }) {
  const [anchor, setAnchor] = useState(null);
  const hasMenu = !!items?.length && !!onSelect;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        className: "aui-viewport-cube-home",
        type: "button",
        title: "Home view",
        "aria-label": "Home view",
        "aria-haspopup": hasMenu ? "menu" : void 0,
        "aria-expanded": hasMenu ? !!anchor : void 0,
        onClick: onHome,
        onContextMenu: (event) => {
          if (hasMenu) {
            event.preventDefault();
            event.stopPropagation();
            setAnchor(event.currentTarget);
          }
        },
        onKeyDown: (event) => {
          if (hasMenu && (event.key === "ArrowDown" || event.key === "ContextMenu" || event.shiftKey && event.key === "F10")) {
            event.preventDefault();
            event.stopPropagation();
            setAnchor(event.currentTarget);
          }
        },
        children: /* @__PURE__ */ jsx(AetherIcon, { name: "home" })
      }
    ),
    hasMenu ? /* @__PURE__ */ jsx(Menu, { open: !!anchor, anchor, items, onSelect, onClose: () => setAnchor(null), ariaLabel: "View and graphics options", placement: "bottom-end" }) : null
  ] });
}
export {
  ViewportCubeHome
};
