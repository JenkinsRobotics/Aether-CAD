import { jsx, jsxs } from "react/jsx-runtime";
import { useRef } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
function DocumentTabs({ tabs, activeID, onSelect, onClose, onPinToggle, onReorder, onSplit, maxVisible = Number.POSITIVE_INFINITY, allowClosePinned = false, ariaLabel = "Open documents", className, renderTabActions }) {
  const refs = useRef(/* @__PURE__ */ new Map());
  const enabled = tabs.filter((tab) => !tab.disabled);
  const bounded = Math.max(1, Math.floor(maxVisible));
  const visible = tabs.length <= bounded ? [...tabs] : tabs.slice(0, bounded);
  if (!visible.some((tab) => tab.id === activeID)) {
    const active = tabs.find((tab) => tab.id === activeID);
    if (active) visible[visible.length - 1] = active;
  }
  const visibleIDs = new Set(visible.map((tab) => tab.id));
  const overflow = tabs.filter((tab) => !visibleIDs.has(tab.id));
  const key = (event, id) => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const index = enabled.findIndex((tab2) => tab2.id === id);
    let next = 0;
    if (event.key === "End") next = enabled.length - 1;
    else if (event.key === "ArrowLeft") next = index <= 0 ? enabled.length - 1 : index - 1;
    else if (event.key === "ArrowRight") next = index < 0 || index === enabled.length - 1 ? 0 : index + 1;
    const tab = enabled[next];
    if (!tab) return;
    onSelect(tab.id);
    queueMicrotask(() => refs.current.get(tab.id)?.focus());
  };
  const drop = (event, targetID) => {
    event.preventDefault();
    const sourceID = event.dataTransfer.getData("application/x-aether-document-tab");
    if (sourceID && sourceID !== targetID) onReorder?.(sourceID, targetID);
  };
  return /* @__PURE__ */ jsxs("div", { className: ["aui-document-tabs", className].filter(Boolean).join(" "), children: [
    /* @__PURE__ */ jsx("div", { className: "aui-document-tab-list", role: "tablist", "aria-label": ariaLabel, children: visible.map((tab) => /* @__PURE__ */ jsxs(
      "div",
      {
        "data-document-tab-id": tab.id,
        className: ["aui-document-tab", tab.id === activeID ? "aui-document-tab--active" : "", tab.preview ? "aui-document-tab--preview" : ""].filter(Boolean).join(" "),
        draggable: Boolean(onReorder) && !tab.disabled,
        onDragStart: (event) => event.dataTransfer.setData("application/x-aether-document-tab", tab.id),
        onDragOver: (event) => {
          if (onReorder) event.preventDefault();
        },
        onDrop: (event) => drop(event, tab.id),
        children: [
          /* @__PURE__ */ jsxs(
            "button",
            {
              ref: (element) => {
                if (element) refs.current.set(tab.id, element);
                else refs.current.delete(tab.id);
              },
              type: "button",
              role: "tab",
              title: [tab.label, tab.detail, tab.statusTitle ?? tab.status].filter(Boolean).join(" \xB7 "),
              "aria-selected": tab.id === activeID,
              tabIndex: tab.id === activeID ? 0 : -1,
              disabled: tab.disabled,
              onClick: () => onSelect(tab.id),
              onKeyDown: (event) => key(event, tab.id),
              children: [
                tab.pinned ? /* @__PURE__ */ jsx("span", { className: "aui-document-tab-icon", "aria-label": "Pinned", children: /* @__PURE__ */ jsx(AetherIcon, { name: "pin" }) }) : tab.icon ? /* @__PURE__ */ jsx("span", { className: "aui-document-tab-icon", "aria-hidden": true, children: tab.icon }) : null,
                /* @__PURE__ */ jsx("span", { className: "aui-document-tab-label", children: tab.label }),
                tab.detail ? /* @__PURE__ */ jsx("span", { className: "aui-document-tab-detail", children: tab.detail }) : null,
                tab.status ? /* @__PURE__ */ jsx("span", { className: "aui-document-tab-status", role: "status", "data-save-tone": /^(Saved|Downloaded|All changes saved)/i.test(tab.status) ? "saved" : /error|fail|unavailable/i.test(tab.status) ? "error" : "pending", title: tab.statusTitle ?? tab.status, children: tab.status }) : null,
                tab.dirty ? /* @__PURE__ */ jsx("span", { className: "aui-document-tab-dirty", "aria-label": "Unsaved changes", children: /* @__PURE__ */ jsx(AetherIcon, { name: "circle-filled" }) }) : null
              ]
            }
          ),
          renderTabActions?.(tab),
          onClose && tab.id === activeID ? /* @__PURE__ */ jsx("button", { type: "button", className: "aui-document-tab-close", "aria-label": `Close ${tab.label}`, disabled: tab.pinned && !allowClosePinned, title: tab.pinned && !allowClosePinned ? "Unpin before closing." : void 0, onClick: () => onClose(tab.id), children: "\xD7" }) : null
        ]
      },
      tab.id
    )) }),
    overflow.length > 0 ? /* @__PURE__ */ jsxs(
      MenuButton,
      {
        className: "aui-document-tabs-overflow",
        label: "More documents",
        items: overflow.map((tab) => ({ id: tab.id, label: tab.label, icon: tab.pinned ? /* @__PURE__ */ jsx(AetherIcon, { name: "pin" }) : tab.dirty ? "\u2022" : void 0, disabled: tab.disabled })),
        onSelect,
        children: [
          "+",
          overflow.length
        ]
      }
    ) : null,
    onPinToggle ? /* @__PURE__ */ jsx("button", { type: "button", className: "aui-document-tabs-action", "aria-label": tabs.find((tab) => tab.id === activeID)?.pinned ? "Unpin active document" : "Pin active document", onClick: () => {
      const tab = tabs.find((candidate) => candidate.id === activeID);
      if (tab) onPinToggle(tab.id, !tab.pinned);
    }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "pin" }) }) : null,
    onSplit ? /* @__PURE__ */ jsx(
      MenuButton,
      {
        className: "aui-document-tabs-action",
        label: "Split active document",
        items: [{ id: "horizontal", label: "Split horizontally", icon: "\u2550" }, { id: "vertical", label: "Split vertically", icon: "\u2551" }],
        onSelect: (direction) => onSplit(activeID, direction),
        children: "\u25A5"
      }
    ) : null
  ] });
}
export {
  DocumentTabs
};
