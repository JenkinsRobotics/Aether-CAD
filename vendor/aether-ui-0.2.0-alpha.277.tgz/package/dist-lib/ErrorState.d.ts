import type { ReactNode } from "react";
export interface ErrorStateProps {
    title: ReactNode;
    description?: ReactNode;
    detail?: ReactNode;
    retryAction?: ReactNode;
    secondaryAction?: ReactNode;
    compact?: boolean;
    className?: string;
}
/** Actionable error surface for failed panels, dependencies, and operations. */
export declare function ErrorState({ title, description, detail, retryAction, secondaryAction, compact, className, }: ErrorStateProps): import("react").JSX.Element;
