import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { SharedWorkspaceSettings } from "./SharedWorkspaceSettings.js";
import { SharedAppearanceSettings } from "./SharedAppearanceSettings.js";
import { SharedChromeSettings } from "./SharedChromeSettings.js";
import { SharedHeaderSettings } from "./SharedHeaderSettings.js";
import { AetherIcon } from "./AetherIcon.js";
function SettingsWindow(props) {
  const {
    open,
    title,
    sections,
    activePaneID,
    onSelectPane,
    onClose,
    presentation = "modal",
    size = "large"
  } = props;
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [sharedPane, setSharedPane] = useState(sections.length === 0 ? "appearance" : null);
  useEffect(() => {
    if (!open) setSharedPane(sections.length === 0 ? "appearance" : null);
  }, [open, sections.length]);
  const offsetRef = useRef(offset);
  const drag = useRef(null);
  offsetRef.current = offset;
  useEffect(() => {
    if (!open) return;
    const key = (event) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [open, onClose]);
  if (!open) return null;
  const moveBy = (x, y) => setOffset({ x, y });
  const onPointerDown = (event) => {
    if (event.target.closest("button")) return;
    drag.current = { startX: event.clientX, startY: event.clientY, ...offsetRef.current };
    event.currentTarget.setPointerCapture?.(event.pointerId);
  };
  const onPointerMove = (event) => {
    if (!drag.current) return;
    moveBy(
      drag.current.x + event.clientX - drag.current.startX,
      drag.current.y + event.clientY - drag.current.startY
    );
  };
  const onPointerUp = () => {
    drag.current = null;
  };
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: `aui-settings-scrim aui-settings-scrim--${presentation}`,
      "data-presentation": presentation,
      onClick: presentation === "modal" ? onClose : void 0,
      children: /* @__PURE__ */ jsxs(
        "div",
        {
          className: `aui-settings-window aui-settings-window--${size}`,
          role: "dialog",
          "aria-label": title,
          "aria-modal": presentation === "modal" || void 0,
          style: { transform: `translate(${offset.x}px, ${offset.y}px)` },
          onClick: (event) => event.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxs(
              "header",
              {
                className: "aui-settings-titlebar",
                tabIndex: 0,
                role: "group",
                "aria-label": `Move ${title}`,
                onPointerDown,
                onPointerMove,
                onPointerUp,
                onKeyDown: (event) => {
                  const step = event.shiftKey ? 40 : 10;
                  const delta = {
                    ArrowLeft: [-step, 0],
                    ArrowRight: [step, 0],
                    ArrowUp: [0, -step],
                    ArrowDown: [0, step]
                  }[event.key];
                  if (!delta || event.target !== event.currentTarget) return;
                  event.preventDefault();
                  moveBy(offset.x + delta[0], offset.y + delta[1]);
                },
                children: [
                  /* @__PURE__ */ jsxs("span", { className: "aui-settings-traffic-lights", children: [
                    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-settings-traffic aui-settings-traffic--close", "aria-label": `Close ${title}`, onClick: onClose }),
                    /* @__PURE__ */ jsx("span", { className: "aui-settings-traffic aui-settings-traffic--minimize", "aria-hidden": true }),
                    /* @__PURE__ */ jsx("span", { className: "aui-settings-traffic aui-settings-traffic--zoom", "aria-hidden": true })
                  ] }),
                  /* @__PURE__ */ jsx("strong", { children: title })
                ]
              }
            ),
            /* @__PURE__ */ jsxs("aside", { className: "aui-settings-sidebar", children: [
              sections.map((section) => /* @__PURE__ */ jsxs("div", { className: "aui-settings-section", children: [
                /* @__PURE__ */ jsx("span", { className: "aui-settings-section-title", children: section.title }),
                section.panes.map((pane) => /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: pane.disabled,
                    "aria-current": !sharedPane && pane.id === activePaneID ? "page" : void 0,
                    className: "aui-settings-item" + (!sharedPane && pane.id === activePaneID ? " active" : ""),
                    onClick: () => {
                      setSharedPane(null);
                      onSelectPane(pane.id);
                    },
                    children: [
                      pane.icon,
                      /* @__PURE__ */ jsx("span", { children: pane.label })
                    ]
                  },
                  pane.id
                ))
              ] }, section.title)),
              /* @__PURE__ */ jsxs("div", { className: "aui-settings-section", children: [
                /* @__PURE__ */ jsx("span", { className: "aui-settings-section-title", children: "Aether Studio" }),
                /* @__PURE__ */ jsxs("button", { type: "button", className: `aui-settings-item${sharedPane === "header" ? " active" : ""}`, "aria-current": sharedPane === "header" ? "page" : void 0, onClick: () => setSharedPane("header"), children: [
                  /* @__PURE__ */ jsx(AetherIcon, { name: "pin" }),
                  /* @__PURE__ */ jsx("span", { children: "Header" })
                ] }),
                /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    className: `aui-settings-item${sharedPane === "chrome" ? " active" : ""}`,
                    "aria-current": sharedPane === "chrome" ? "page" : void 0,
                    onClick: () => setSharedPane("chrome"),
                    children: [
                      /* @__PURE__ */ jsx(AetherIcon, { name: "layout" }),
                      /* @__PURE__ */ jsx("span", { children: "Toolbars & tabs" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    className: `aui-settings-item${sharedPane === "appearance" ? " active" : ""}`,
                    "aria-current": sharedPane === "appearance" ? "page" : void 0,
                    onClick: () => setSharedPane("appearance"),
                    children: [
                      /* @__PURE__ */ jsx(AetherIcon, { name: "palette" }),
                      /* @__PURE__ */ jsx("span", { children: "Appearance & icons" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    className: `aui-settings-item${sharedPane === "spacing" ? " active" : ""}`,
                    "aria-current": sharedPane === "spacing" ? "page" : void 0,
                    onClick: () => setSharedPane("spacing"),
                    children: [
                      /* @__PURE__ */ jsx(AetherIcon, { name: "windows" }),
                      /* @__PURE__ */ jsx("span", { children: "Workspace spacing" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "aui-settings-content", children: /* @__PURE__ */ jsx("div", { className: "aui-settings-pane", children: sharedPane === "header" ? /* @__PURE__ */ jsx(SharedHeaderSettings, { appID: props.headerAppID }) : sharedPane === "chrome" ? /* @__PURE__ */ jsx(SharedChromeSettings, {}) : sharedPane === "spacing" ? /* @__PURE__ */ jsx(SharedWorkspaceSettings, {}) : sharedPane === "appearance" ? /* @__PURE__ */ jsx(SharedAppearanceSettings, {}) : props.children }) })
          ]
        }
      )
    }
  );
}
function SettingsCard(props) {
  return /* @__PURE__ */ jsxs("section", { className: "aui-settings-card" + (props.tone ? ` ${props.tone}` : ""), children: [
    props.title ? /* @__PURE__ */ jsxs("span", { className: "aui-settings-card-header", children: [
      props.icon ? /* @__PURE__ */ jsx("span", { className: "aui-settings-card-icon", children: props.icon }) : null,
      /* @__PURE__ */ jsx("strong", { className: "aui-settings-card-title", children: props.title })
    ] }) : null,
    props.caption ? /* @__PURE__ */ jsx("p", { className: "aui-settings-card-caption", children: props.caption }) : null,
    props.children
  ] });
}
function SettingsRow(props) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-settings-row" + (props.disabled ? " disabled" : "") + (props.stacked ? " stacked" : ""), children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-settings-row-main", children: [
      props.icon ? /* @__PURE__ */ jsx("span", { className: "aui-settings-row-icon", children: props.icon }) : null,
      /* @__PURE__ */ jsx("span", { className: "aui-settings-row-label", children: props.label }),
      props.value !== void 0 ? /* @__PURE__ */ jsx("span", { className: "aui-settings-row-value", children: props.value }) : null,
      !props.stacked ? /* @__PURE__ */ jsx("span", { className: "aui-settings-row-control", children: props.children }) : null
    ] }),
    props.stacked ? /* @__PURE__ */ jsx("div", { className: "aui-settings-row-wide", children: props.children }) : null,
    props.caption ? /* @__PURE__ */ jsx("p", { className: "aui-settings-row-caption", children: props.caption }) : null
  ] });
}
export {
  SettingsCard,
  SettingsRow,
  SettingsWindow
};
