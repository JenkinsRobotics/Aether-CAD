import { jsx } from "react/jsx-runtime";
import "./StudioAppFrame.css";
function StudioAppFrame({ children, className = "", style }) {
  return /* @__PURE__ */ jsx("div", { className: `aui-studio-app ${className}`, style, children });
}
export {
  StudioAppFrame
};
