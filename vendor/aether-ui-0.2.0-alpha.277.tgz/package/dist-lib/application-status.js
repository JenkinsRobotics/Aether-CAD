const connectionLabels = {
  connecting: "Connecting to Studio\u2026",
  connected: "Connected to Studio",
  offline: "Studio unavailable",
  local: "Local workspace"
};
function text(node, value) {
  if (node.textContent !== value) node.textContent = value;
}
function updateApplicationStatusBar(row, props) {
  row.classList.add("aui-application-status");
  row.setAttribute("aria-label", "Application status");
  row.dataset.connection = props.connection;
  if (!row.querySelector(".aui-application-status__identity")) {
    const node = (tag, className) => {
      const child = row.ownerDocument.createElement(tag);
      child.className = `aui-application-status__${className}`;
      return child;
    };
    const identity = node("span", "identity");
    const connection = node("span", "connection");
    connection.setAttribute("role", "status");
    connection.setAttribute("aria-atomic", "true");
    const dot = node("span", "dot");
    dot.setAttribute("aria-hidden", "true");
    connection.append(dot, node("span", "connection-label"));
    identity.append(connection, node("strong", "name"));
    row.append(identity, node("span", "message"), node("span", "company"));
  }
  const label = props.connectionLabel || connectionLabels[props.connection];
  const find = (name) => row.querySelector(`.aui-application-status__${name}`);
  find("connection").title = label;
  text(find("connection-label"), label);
  text(find("name"), props.appName);
  find("name").title = props.appName;
  text(find("company"), props.companyName?.trim() || "");
  find("company").title = props.companyName?.trim() || "";
  text(find("message"), props.connection === "offline" ? label : props.message || "");
}
function createApplicationStatusBar(props, owner = document) {
  const row = owner.createElement("footer");
  updateApplicationStatusBar(row, props);
  return row;
}
export {
  createApplicationStatusBar,
  updateApplicationStatusBar
};
