import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { SelectField } from "./SelectField.js";
import "./NewDesignDialog.css";
function NewDesignDialog({
  title = "What do you want to design?",
  kinds,
  defaultKindID,
  units,
  learnMoreHref,
  createLabel = "Create New",
  busy = false,
  onCreate,
  onClose
}) {
  const firstAvailable = kinds.find((kind2) => !kind2.unavailable)?.id ?? kinds[0]?.id ?? "";
  const [chosen, setChosen] = useState(defaultKindID ?? firstAvailable);
  const kind = kinds.find((entry) => entry.id === chosen) ?? kinds[0];
  return /* @__PURE__ */ jsx(
    Dialog,
    {
      open: true,
      title,
      onClose,
      actions: /* @__PURE__ */ jsxs(Fragment, { children: [
        learnMoreHref ? /* @__PURE__ */ jsx("a", { className: "aui-new-design-learn", href: learnMoreHref, target: "_blank", rel: "noreferrer", children: "Learn More" }) : null,
        /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: onClose, children: "Cancel" }),
        /* @__PURE__ */ jsx(Button, { primary: true, disabled: busy || !kind || Boolean(kind.unavailable), onClick: () => kind && onCreate(kind.id), children: busy ? "Creating\u2026" : createLabel })
      ] }),
      children: /* @__PURE__ */ jsxs("div", { className: "aui-new-design", children: [
        /* @__PURE__ */ jsx("div", { className: "aui-new-design-kinds", role: "radiogroup", "aria-label": title, children: kinds.map((entry) => /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            role: "radio",
            "aria-checked": entry.id === chosen,
            className: "aui-new-design-kind",
            "data-chosen": entry.id === chosen || void 0,
            "data-unavailable": entry.unavailable ? "" : void 0,
            onClick: () => setChosen(entry.id),
            onDoubleClick: () => {
              if (!entry.unavailable && !busy) onCreate(entry.id);
            },
            children: [
              /* @__PURE__ */ jsx("span", { className: "aui-new-design-art", "aria-hidden": "true", children: entry.icon }),
              /* @__PURE__ */ jsx("span", { className: "aui-new-design-name", children: entry.title })
            ]
          },
          entry.id
        )) }),
        kind ? /* @__PURE__ */ jsxs("div", { className: "aui-new-design-detail", children: [
          /* @__PURE__ */ jsx("h3", { children: kind.title }),
          /* @__PURE__ */ jsx("p", { children: kind.description ?? kind.summary }),
          kind.unavailable ? /* @__PURE__ */ jsx("p", { className: "aui-new-design-unavailable", role: "note", children: kind.unavailable }) : /* @__PURE__ */ jsxs(Fragment, { children: [
            units ? /* @__PURE__ */ jsxs("label", { className: "aui-new-design-setting", children: [
              units.label,
              /* @__PURE__ */ jsx(
                SelectField,
                {
                  "aria-label": units.label,
                  value: units.value,
                  options: units.options,
                  onChange: (event) => units.onChange(event.target.value)
                }
              )
            ] }) : null,
            kind.settings
          ] })
        ] }) : null
      ] })
    }
  );
}
export {
  NewDesignDialog
};
