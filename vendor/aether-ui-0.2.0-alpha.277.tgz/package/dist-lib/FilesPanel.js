import { jsx, jsxs } from "react/jsx-runtime";
import { createContext, useContext, useLayoutEffect, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
import { PanelNotifications, PanelNotice } from "./PanelNotifications.js";
import { SegmentedControl } from "./SegmentedControl.js";
import { SidePanelHeader } from "./SidePanelHeader.js";
import "./FilesPanel.css";
const RegisterActions = createContext(null);
function useFilesPanelActions(actions) {
  const register = useContext(RegisterActions);
  useLayoutEffect(() => {
    register?.(actions);
  });
  useLayoutEffect(() => () => register?.(null), [register]);
}
function FilesPanel({ local, drive, error, onFiles }) {
  const [scope, setScope] = useState("local");
  const [actions, setActions] = useState(null);
  const dropping = (event) => Boolean(onFiles) && event.dataTransfer.types.includes("Files");
  return /* @__PURE__ */ jsx(PanelNotifications, { children: /* @__PURE__ */ jsx(RegisterActions.Provider, { value: setActions, children: /* @__PURE__ */ jsxs(
    "section",
    {
      className: "aui-files-panel",
      "aria-label": "Files navigation",
      onDragOver: (event) => {
        if (dropping(event)) {
          event.preventDefault();
          event.dataTransfer.dropEffect = "copy";
        }
      },
      onDrop: (event) => {
        if (!dropping(event)) return;
        event.preventDefault();
        const files = [...event.dataTransfer.files];
        if (files.length) onFiles(files);
      },
      children: [
        /* @__PURE__ */ jsx("div", { className: "aui-files-panel-heading", children: /* @__PURE__ */ jsx(SidePanelHeader, { title: "Files", icon: "folder", actions: actions?.items.length ? /* @__PURE__ */ jsx(MenuButton, { className: "aui-files-panel-add", menuClassName: "aui-collection-popup", label: "Add to Files", items: actions.items, onSelect: actions.onSelect, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }) : null }) }),
        /* @__PURE__ */ jsx(PanelNotice, { message: error }),
        /* @__PURE__ */ jsx(SegmentedControl, { variant: "panel", className: "aui-files-panel-scopes", ariaLabel: "Files view", value: scope, onChange: (value) => setScope(value), options: [
          { id: "local", label: local.label, icon: local.icon },
          { id: "drive", label: "Drive", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }) }
        ] }),
        /* @__PURE__ */ jsx("div", { className: "aui-files-panel-content", onDragStart: scope === "local" ? local.onDragStart : void 0, children: scope === "local" ? local.content : drive })
      ]
    }
  ) }) });
}
export {
  FilesPanel,
  useFilesPanelActions
};
