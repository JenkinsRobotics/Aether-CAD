import type { ReactNode } from "react";
export interface SegmentedControlOption {
    id: string;
    label: ReactNode;
    icon?: ReactNode;
    disabled?: boolean;
}
export interface SegmentedControlProps {
    options: readonly SegmentedControlOption[];
    value?: string;
    defaultValue?: string;
    onChange?: (id: string) => void;
    ariaLabel: string;
    disabled?: boolean;
    className?: string;
    /** Full-width panel navigation, shared by Files and Comments/Tasks. */
    variant?: 'default' | 'panel';
}
export declare function SegmentedControl({ options, value, defaultValue, onChange, ariaLabel, disabled, className, variant }: SegmentedControlProps): import("react").JSX.Element;
