import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { AppIcon } from "./AppIcon.js";
import { FILE_TYPES, fileTypeFor } from "./file-types.js";
import "./FileIcon.css";
const nativeApps = {
  part: "cad",
  assembly: "cad",
  drawing: "cad",
  project: "cad",
  show: "map",
  character: "animation",
  clip: "animation",
  workspace: "studio",
  sketch: "sketch",
  circuit: "io",
  vector: "vector"
};
function FileIcon({ file, type, icon, size = 24 }) {
  const identity = type ?? (icon ? FILE_TYPES.find((item) => item.icon === icon) : void 0) ?? fileTypeFor(file ?? { name: "" });
  if (icon && !FILE_TYPES.some((item) => item.icon === icon)) return /* @__PURE__ */ jsx(AetherIcon, { name: icon, width: size, height: size });
  const app = nativeApps[identity.id];
  return /* @__PURE__ */ jsxs("span", { className: "aui-file-icon aui-file-icon--illustrated", "data-icon": identity.icon, "data-file-type": identity.id, "data-file-app": app, "aria-hidden": "true", style: { width: size, height: size }, children: [
    /* @__PURE__ */ jsx(AetherIcon, { name: identity.icon, "data-icon": void 0, "data-file-artwork": identity.id, width: size, height: size }),
    app && /* @__PURE__ */ jsx("span", { className: "aui-file-icon-badge", children: /* @__PURE__ */ jsx(AppIcon, { app, size: size * 0.4 }) })
  ] });
}
export {
  FileIcon
};
