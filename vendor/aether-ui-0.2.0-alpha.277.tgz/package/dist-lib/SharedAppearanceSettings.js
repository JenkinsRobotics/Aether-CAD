import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { InterfaceColorSettings } from "./InterfaceColorSettings.js";
import { useEffect, useState } from "react";
import { activeAetherTheme, activeAetherViewportTheme, setAetherAppearance, setAetherTheme, setAetherViewportTheme, storedAppearance } from "./StudioChrome.js";
import { aetherThemes, aetherViewportThemes } from "./themes.js";
import { setToolIconPack, useGlobalToolIconPack } from "./ToolIconTheme.js";
import { SettingsCard, SettingsRow } from "./SettingsWindow.js";
import { SelectField } from "./SelectField.js";
function SharedAppearanceSettings() {
  const [theme, updateTheme] = useState(activeAetherTheme);
  const [viewport, updateViewport] = useState(activeAetherViewportTheme);
  const [mode, updateMode] = useState(storedAppearance);
  const pack = useGlobalToolIconPack();
  useEffect(() => {
    const follow = () => {
      updateTheme(activeAetherTheme());
      updateViewport(activeAetherViewportTheme());
      updateMode(storedAppearance());
    };
    document.addEventListener("aether-theme", follow);
    document.addEventListener("aether-appearance", follow);
    window.addEventListener("storage", follow);
    return () => {
      document.removeEventListener("aether-theme", follow);
      document.removeEventListener("aether-appearance", follow);
      window.removeEventListener("storage", follow);
    };
  }, []);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(SettingsCard, { title: "Appearance", caption: "Shared across Aether applications on this browser.", children: [
      /* @__PURE__ */ jsx(SettingsRow, { label: "Color mode", children: /* @__PURE__ */ jsx(
        SelectField,
        {
          "aria-label": "Color mode",
          value: mode,
          options: [{ value: "system", label: "System" }, { value: "light", label: "Light" }, { value: "dark", label: "Dark" }],
          onChange: (event) => setAetherAppearance(event.target.value)
        }
      ) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Interface theme", children: /* @__PURE__ */ jsx(
        SelectField,
        {
          "aria-label": "Interface theme",
          value: theme,
          options: aetherThemes.map((theme2) => ({ value: theme2.id, label: theme2.name })),
          onChange: (event) => setAetherTheme(event.target.value)
        }
      ) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Viewport theme", children: /* @__PURE__ */ jsx(
        SelectField,
        {
          "aria-label": "Viewport theme",
          value: viewport ?? "",
          options: [{ value: "", label: "Theme default" }, ...aetherViewportThemes.map((theme2) => ({ value: theme2.id, label: theme2.name }))],
          onChange: (event) => setAetherViewportTheme(event.target.value || null)
        }
      ) }),
      /* @__PURE__ */ jsx(SettingsRow, { label: "Tool icon pack", children: /* @__PURE__ */ jsx(
        SelectField,
        {
          "aria-label": "Tool icon pack",
          value: pack,
          options: [{ value: "classic", label: "Aether Classic" }, { value: "graphite-ribbon", label: "Graphite Ribbon \u2014 Illustrated Ribbon Tools" }],
          onChange: (event) => setToolIconPack(event.target.value)
        }
      ) })
    ] }),
    /* @__PURE__ */ jsx(InterfaceColorSettings, {})
  ] });
}
export {
  SharedAppearanceSettings
};
