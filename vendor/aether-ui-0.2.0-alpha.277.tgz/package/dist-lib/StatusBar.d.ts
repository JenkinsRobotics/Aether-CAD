import type { ReactNode } from "react";
export type StatusKind = "ok" | "busy" | "warn" | "error";
export declare function StatusDot({ kind }: {
    kind: StatusKind;
}): import("react").JSX.Element;
/**
 * Bottom application status strip. Either pass plain children (legacy single
 * row) or the three regions: `leading` (app identity: connection dot, product
 * name, engine), `center` (dynamic notification area, truncates), `trailing`
 * (metrics and ambient controls).
 */
export declare function StatusBar({ leading, center, trailing, children }: {
    leading?: ReactNode;
    center?: ReactNode;
    trailing?: ReactNode;
    children?: ReactNode;
}): import("react").JSX.Element;
