import type { ReactElement, ReactNode } from "react";
export interface ToolHelpContent {
    summary: string;
    steps: readonly string[];
    illustration?: ReactNode;
}
/** Shared, delayed instructional help for ribbon tools and menu entries. */
export declare function ToolHelp({ label, help, disabledReason, children }: {
    label: string;
    help?: ToolHelpContent;
    disabledReason?: string;
    children: ReactElement<{
        "aria-describedby"?: string;
    }>;
}): import("react").JSX.Element;
