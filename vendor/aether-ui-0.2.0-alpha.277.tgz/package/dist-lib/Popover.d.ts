import type { ReactNode } from "react";
import { type OverlayAnchor, type OverlayPlacement } from "./overlay-position.js";
export interface PopoverProps {
    open: boolean;
    anchor: OverlayAnchor | null;
    onClose: () => void;
    children: ReactNode;
    ariaLabel: string;
    placement?: OverlayPlacement;
    /** `first` is useful for small editors; `none` preserves viewport focus. */
    focus?: "none" | "first";
    closeOnOutsidePress?: boolean;
    returnFocus?: boolean;
    className?: string;
    /** Show the shared surface in document flow; no anchor, portal or dismissal listeners. */
    inline?: boolean;
}
/** Anchored nonmodal surface shared by compact editors and explanatory cards. */
export declare function Popover({ open, anchor, onClose, children, ariaLabel, placement, focus, closeOnOutsidePress, returnFocus, className, inline, }: PopoverProps): import("react").JSX.Element | null;
