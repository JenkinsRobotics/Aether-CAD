import { jsx, jsxs } from "react/jsx-runtime";
import { TreeRename } from "./TreeRename.js";
import { AetherIcon } from "./AetherIcon.js";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState
} from "react";
function dropPosition(event) {
  const rect = event.currentTarget.getBoundingClientRect();
  if (rect.height <= 0) return "inside";
  const ratio = (event.clientY - rect.top) / rect.height;
  if (ratio < 0.25) return "before";
  if (ratio > 0.75) return "after";
  return "inside";
}
function Tree({
  nodes,
  selectedIDs,
  onSelect,
  ariaLabel,
  onActivate,
  onContextMenu,
  onAction,
  expandedIDs,
  onToggle,
  defaultCollapsedIDs,
  revealSelection = false,
  filter,
  emptyState,
  renamingID,
  onRename,
  onCancelRename,
  onMove,
  canMove,
  onRetryChildren,
  virtualizeThreshold = 1e3,
  height = 320,
  rowHeight = 28,
  rootInset = 7,
  overscan = 5,
  className,
  style
}) {
  const [internalCollapsed, setInternalCollapsed] = useState(
    () => new Set(defaultCollapsedIDs ?? [])
  );
  const [focusedID, setFocusedID] = useState(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [dragTarget, setDragTarget] = useState(null);
  const anchorRef = useRef(null);
  const dragSourceRef = useRef(null);
  const rowRefs = useRef(/* @__PURE__ */ new Map());
  const scrollerRef = useRef(null);
  const selectionKey = JSON.stringify([...selectedIDs].sort());
  const [revealOverride, setRevealOverride] = useState(
    () => ({ selection: selectionKey, closed: /* @__PURE__ */ new Set() })
  );
  useEffect(() => {
    setRevealOverride((current) => current.selection === selectionKey ? current : { selection: selectionKey, closed: /* @__PURE__ */ new Set() });
  }, [selectionKey]);
  const isExpanded = useCallback(
    (id) => expandedIDs ? expandedIDs.has(id) : !internalCollapsed.has(id),
    [expandedIDs, internalCollapsed]
  );
  const toggle = useCallback(
    (id, currentlyExpanded) => {
      setRevealOverride((current) => {
        const closed = new Set(current.selection === selectionKey ? current.closed : []);
        if (currentlyExpanded) closed.add(id);
        else closed.delete(id);
        return { selection: selectionKey, closed };
      });
      onToggle?.(id, !currentlyExpanded);
      if (!expandedIDs) {
        setInternalCollapsed((current) => {
          const next = new Set(current);
          if (currentlyExpanded) next.add(id);
          else next.delete(id);
          return next;
        });
      }
    },
    [expandedIDs, onToggle, selectionKey]
  );
  const filterText = (filter ?? "").trim().toLocaleLowerCase();
  const matchesFilter = useCallback(
    function matches(node) {
      if (node.label.toLocaleLowerCase().includes(filterText) || node.searchText?.toLocaleLowerCase().includes(filterText)) return true;
      return (node.children ?? []).some(matches);
    },
    [filterText]
  );
  const containsSelection = useCallback(
    function contains(node) {
      return selectedIDs.has(node.id) || (node.children ?? []).some(contains);
    },
    [selectedIDs]
  );
  const rows = useMemo(() => {
    const output = [];
    const walk = (level, depth) => {
      for (const node of level) {
        if (filterText && !matchesFilter(node)) continue;
        const hasChildren = (node.children?.length ?? 0) > 0 || Boolean(node.childrenLoading) || node.childrenError !== void 0;
        const expanded = hasChildren && (filterText ? true : isExpanded(node.id) || revealSelection && !(revealOverride.selection === selectionKey && revealOverride.closed.has(node.id)) && (node.children ?? []).some(containsSelection));
        output.push({ node, depth, hasChildren, expanded });
        if (expanded && node.children?.length) walk(node.children, depth + 1);
      }
    };
    walk(nodes, 0);
    return output;
  }, [containsSelection, filterText, isExpanded, matchesFilter, nodes, revealSelection, revealOverride, selectionKey]);
  const visualRows = useMemo(() => {
    const output = [];
    rows.forEach((row, nodeIndex) => {
      output.push({ kind: "node", row, nodeIndex });
      if (!row.expanded) return;
      if (row.node.childrenLoading) {
        output.push({
          kind: "loading",
          parentID: row.node.id,
          depth: row.depth + 1,
          content: "Loading\u2026"
        });
      } else if (row.node.childrenError !== void 0) {
        output.push({
          kind: "error",
          parentID: row.node.id,
          depth: row.depth + 1,
          content: row.node.childrenError
        });
      }
    });
    return output;
  }, [rows]);
  const virtualized = visualRows.length >= virtualizeThreshold;
  const visibleRows = useMemo(() => {
    if (!virtualized) return visualRows.map((row, visualIndex) => ({ row, visualIndex }));
    const start = Math.max(0, Math.floor(scrollTop / rowHeight) - overscan);
    const end = Math.min(
      visualRows.length,
      Math.ceil((scrollTop + height) / rowHeight) + overscan
    );
    return visualRows.slice(start, end).map((row, offset) => ({
      row,
      visualIndex: start + offset
    }));
  }, [height, overscan, rowHeight, scrollTop, virtualized, visualRows]);
  const applySelect = useCallback(
    (row, event) => {
      if (row.node.disabled || renamingID === row.node.id) return;
      if (event.shiftKey && anchorRef.current) {
        const from = rows.findIndex((entry) => entry.node.id === anchorRef.current);
        const to = rows.findIndex((entry) => entry.node.id === row.node.id);
        if (from >= 0 && to >= 0) {
          const [start, end] = from < to ? [from, to] : [to, from];
          onSelect(
            rows.slice(start, end + 1).filter((entry) => !entry.node.disabled).map((entry) => entry.node.id),
            "range"
          );
          return;
        }
      }
      anchorRef.current = row.node.id;
      onSelect(
        [row.node.id],
        event.metaKey || event.ctrlKey ? "toggle" : "single"
      );
    },
    [onSelect, renamingID, rows]
  );
  const focusRow = useCallback(
    (id) => {
      setFocusedID(id);
      const element = rowRefs.current.get(id);
      if (element) {
        element.focus();
        return;
      }
      if (!virtualized) return;
      const visualIndex = visualRows.findIndex(
        (entry) => entry.kind === "node" && entry.row.node.id === id
      );
      if (visualIndex < 0) return;
      scrollerRef.current?.scrollTo({
        top: Math.max(0, visualIndex * rowHeight - (height - rowHeight) / 2)
      });
      requestAnimationFrame(() => rowRefs.current.get(id)?.focus());
    },
    [height, rowHeight, virtualized, visualRows]
  );
  const onKeyDown = useCallback(
    (event, row, index) => {
      if (event.target !== event.currentTarget) return;
      const enabled = rows.filter((entry) => !entry.node.disabled);
      const enabledIndex = enabled.findIndex((entry) => entry.node.id === row.node.id);
      const move = (target) => target && focusRow(target.node.id);
      if (event.key === "ContextMenu" || event.key === "F10" && event.shiftKey) {
        if (onContextMenu) {
          const box = event.currentTarget.getBoundingClientRect();
          event.preventDefault();
          event.stopPropagation();
          onContextMenu(row.node.id, box.left + 24, box.bottom);
        }
        return;
      }
      switch (event.key) {
        case "ArrowDown":
          move(enabled[enabledIndex + 1]);
          break;
        case "ArrowUp":
          move(enabled[enabledIndex - 1]);
          break;
        case "ArrowRight":
          if (row.hasChildren && !row.expanded) toggle(row.node.id, false);
          else if (row.hasChildren) move(rows[index + 1]);
          break;
        case "ArrowLeft":
          if (row.hasChildren && row.expanded) {
            toggle(row.node.id, true);
          } else {
            for (let previous = index - 1; previous >= 0; previous--) {
              if (rows[previous].depth < row.depth) {
                move(rows[previous]);
                break;
              }
            }
          }
          break;
        case "Home":
          move(enabled[0]);
          break;
        case "End":
          move(enabled[enabled.length - 1]);
          break;
        case "Enter":
        case " ":
          if (event.key === "Enter" && selectedIDs.has(row.node.id)) {
            onActivate?.(row.node.id);
          } else {
            applySelect(row, event);
          }
          break;
        default:
          return;
      }
      event.preventDefault();
    },
    [applySelect, focusRow, onActivate, onContextMenu, rows, selectedIDs, toggle]
  );
  const handleDragOver = (event, targetID) => {
    const sourceID = dragSourceRef.current;
    if (!sourceID || sourceID === targetID) return;
    let position = dropPosition(event);
    if (position === "inside" && rows.find((row) => row.node.id === targetID)?.node.dropMode === "reorder") {
      const rect = event.currentTarget.getBoundingClientRect();
      position = event.clientY < rect.top + rect.height / 2 ? "before" : "after";
    }
    if (canMove && !canMove(sourceID, targetID, position)) {
      setDragTarget(null);
      return;
    }
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    setDragTarget({ id: targetID, position });
  };
  const classes = ["aui-tree", className].filter(Boolean).join(" ");
  if (rows.length === 0) {
    return /* @__PURE__ */ jsx("div", { className: classes, role: "tree", "aria-label": ariaLabel, style, children: /* @__PURE__ */ jsx("div", { className: "aui-tree-empty", children: emptyState ?? "empty" }) });
  }
  const tabbableID = rows.find((entry) => !entry.node.disabled && entry.node.id === focusedID)?.node.id ?? rows.find((entry) => !entry.node.disabled && selectedIDs.has(entry.node.id))?.node.id ?? rows.find((entry) => !entry.node.disabled)?.node.id;
  const renderVisualRow = (visual, visualIndex) => {
    const virtualStyle = virtualized ? {
      position: "absolute",
      top: visualIndex * rowHeight,
      left: 0,
      right: 0,
      height: rowHeight
    } : void 0;
    if (visual.kind !== "node") {
      return /* @__PURE__ */ jsxs(
        "div",
        {
          className: `aui-tree-child-state aui-tree-child-state--${visual.kind}`,
          role: visual.kind === "error" ? "alert" : "status",
          style: { ...virtualStyle, paddingLeft: rootInset + visual.depth * 16 },
          children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: visual.kind === "loading" ? "history" : "status-error" }),
            /* @__PURE__ */ jsx("span", { children: visual.content }),
            visual.kind === "error" && onRetryChildren ? /* @__PURE__ */ jsx("button", { type: "button", onClick: () => onRetryChildren(visual.parentID), children: "Retry" }) : null
          ]
        },
        `${visual.kind}-${visual.parentID}`
      );
    }
    const { row, nodeIndex } = visual;
    const { node } = row;
    const selected = selectedIDs.has(node.id);
    const rowClasses = ["aui-tree-row"];
    if (selected) rowClasses.push("aui-tree-row--selected");
    if (!row.hasChildren) rowClasses.push("aui-tree-row--leaf");
    if (node.dimmed) rowClasses.push("aui-tree-row--dimmed");
    if (node.disabled) rowClasses.push("aui-tree-row--disabled");
    if (node.variant === "divider") rowClasses.push("aui-tree-row--divider");
    if (node.tone === "error") rowClasses.push("aui-tree-row--error");
    if (node.className) rowClasses.push(node.className);
    if (dragTarget?.id === node.id) {
      rowClasses.push(`aui-tree-row--drop-${dragTarget.position}`);
    }
    const isRenaming = renamingID === node.id;
    return /* @__PURE__ */ jsxs(
      "div",
      {
        ref: (element) => {
          if (element) rowRefs.current.set(node.id, element);
          else rowRefs.current.delete(node.id);
        },
        role: "treeitem",
        "aria-label": node.label,
        "data-tree-id": node.id,
        "aria-selected": selected,
        "aria-expanded": row.hasChildren ? row.expanded : void 0,
        "aria-level": row.depth + 1,
        "aria-disabled": node.disabled || void 0,
        className: rowClasses.join(" "),
        style: { ...virtualStyle, paddingLeft: rootInset + row.depth * 16 },
        tabIndex: !node.disabled && tabbableID === node.id ? 0 : -1,
        draggable: Boolean(onMove && node.draggable !== false && !node.disabled && !isRenaming),
        onFocus: () => setFocusedID(node.id),
        onClick: (event) => applySelect(row, event),
        onDoubleClick: () => !node.disabled && !isRenaming && onActivate?.(node.id),
        onContextMenu: (event) => {
          if (event.target.closest("input,textarea,[contenteditable]")) return;
          if (!onContextMenu || node.disabled) return;
          event.preventDefault();
          event.currentTarget.focus();
          onContextMenu(node.id, event.clientX, event.clientY);
        },
        onKeyDown: (event) => onKeyDown(event, row, nodeIndex),
        onDragStart: (event) => {
          dragSourceRef.current = node.id;
          event.dataTransfer.effectAllowed = "move";
          event.dataTransfer.setData("text/plain", node.id);
        },
        onDragOver: (event) => handleDragOver(event, node.id),
        onDragLeave: (event) => {
          if (!event.currentTarget.contains(event.relatedTarget)) {
            setDragTarget(null);
          }
        },
        onDrop: (event) => {
          const sourceID = dragSourceRef.current;
          const target = dragTarget;
          event.preventDefault();
          if (sourceID && target?.id === node.id && (!canMove || canMove(sourceID, node.id, target.position))) {
            onMove?.(sourceID, node.id, target.position);
          }
          dragSourceRef.current = null;
          setDragTarget(null);
        },
        onDragEnd: () => {
          dragSourceRef.current = null;
          setDragTarget(null);
        },
        children: [
          row.hasChildren ? /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              className: "aui-tree-disclosure",
              "aria-label": `${row.expanded ? "Collapse" : "Expand"} ${node.label}`,
              tabIndex: -1,
              disabled: node.disabled,
              onClick: (event) => {
                event.stopPropagation();
                toggle(node.id, row.expanded);
              },
              children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", width: 14, height: 14, style: { transform: row.expanded ? "rotate(90deg)" : void 0 } })
            }
          ) : null,
          /* @__PURE__ */ jsx("span", { className: "aui-tree-icon", "aria-hidden": "true", children: node.icon ?? "" }),
          isRenaming ? /* @__PURE__ */ jsx(
            TreeRename,
            {
              label: node.label,
              onCommit: (value) => {
                onRename?.(node.id, value);
                focusRow(node.id);
              },
              onCancel: () => {
                onCancelRename?.(node.id);
                focusRow(node.id);
              }
            },
            node.id
          ) : /* @__PURE__ */ jsx("span", { className: "aui-tree-label", title: node.label, children: node.label }),
          node.badge || node.status?.length ? /* @__PURE__ */ jsxs("span", { className: "aui-tree-badge", children: [
            node.badge,
            node.status?.map((status) => /* @__PURE__ */ jsx("span", { className: "aui-tree-status", role: "img", title: status.label, "aria-label": status.label, children: status.icon }, status.id))
          ] }) : /* @__PURE__ */ jsx("span", {}),
          node.actions?.length ? /* @__PURE__ */ jsx("span", { className: "aui-tree-actions", children: node.actions.map((action) => /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              title: action.label,
              "aria-label": action.label,
              className: action.pinned ? "aui-tree-action aui-tree-action--pinned" : "aui-tree-action",
              tabIndex: -1,
              disabled: node.disabled,
              onClick: (event) => {
                event.stopPropagation();
                onAction?.(node.id, action.id, event.currentTarget);
              },
              children: action.icon
            },
            action.id
          )) }) : null
        ]
      },
      node.id
    );
  };
  const handleScroll = (event) => {
    if (virtualized) setScrollTop(event.currentTarget.scrollTop);
  };
  return /* @__PURE__ */ jsx(
    "div",
    {
      ref: scrollerRef,
      className: classes,
      role: "tree",
      "aria-label": ariaLabel,
      style: {
        ...style,
        ...virtualized ? { height, overflowY: "auto" } : null
      },
      onScroll: handleScroll,
      children: /* @__PURE__ */ jsx(
        "div",
        {
          className: virtualized ? "aui-tree-window" : void 0,
          style: virtualized ? { height: visualRows.length * rowHeight } : void 0,
          children: visibleRows.map(({ row, visualIndex }) => renderVisualRow(row, visualIndex))
        }
      )
    }
  );
}
export {
  Tree
};
