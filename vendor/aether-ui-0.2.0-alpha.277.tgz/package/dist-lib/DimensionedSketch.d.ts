import "./DimensionedSketch.css";
/** All coordinates are presentation-space SVG units. The owning app supplies
 * geometry, formatted measurements, references and constraint states. */
export type SketchAnnotationPoint = readonly [number, number];
export interface SketchPresentationEntity {
    id: string;
    label: string;
    path: string;
    construction?: boolean;
}
export interface SketchDimensionAnnotation {
    id: string;
    label: string;
    value: string;
    reference?: string;
    readOnly?: boolean;
    accent?: boolean;
    entityIDs: readonly string[];
    position: SketchAnnotationPoint;
    /** A leader follows a repositioned label. */
    anchor: SketchAnnotationPoint;
    lines: readonly {
        from: SketchAnnotationPoint;
        to: SketchAnnotationPoint;
        arrows?: "both" | "end";
        extension?: boolean;
    }[];
}
export interface SketchConstraintAnnotation {
    id: string;
    label: string;
    glyph: string;
    position: SketchAnnotationPoint;
    entityIDs: readonly string[];
}
export type SketchAnnotationSelection = {
    kind: "entity" | "dimension" | "constraint";
    id: string;
} | null;
export interface SketchAnnotationView {
    zoom: number;
    pan: SketchAnnotationPoint;
}
export interface DimensionedSketchProps {
    width: number;
    height: number;
    entities: readonly SketchPresentationEntity[];
    dimensions: readonly SketchDimensionAnnotation[];
    constraints?: readonly SketchConstraintAnnotation[];
    vertices?: readonly SketchAnnotationPoint[];
    origin?: SketchAnnotationPoint;
    selection: SketchAnnotationSelection;
    onSelect: (selection: SketchAnnotationSelection) => void;
    onEditDimension?: (id: string) => void;
    onMoveLabel?: (id: string, position: SketchAnnotationPoint) => void;
    view?: SketchAnnotationView;
    onViewChange?: (view: SketchAnnotationView) => void;
    showGrid?: boolean;
    showConstruction?: boolean;
    showConstraints?: boolean;
    showReferences?: boolean;
    ariaLabel?: string;
}
/** A controlled annotation surface, not a sketch solver. Keyboard selection,
 * label movement and viewport gestures share the same callbacks as pointer use. */
export declare function DimensionedSketch({ width, height, entities, dimensions, constraints, vertices, origin, selection, onSelect, onEditDimension, onMoveLabel, view, onViewChange, showGrid, showConstruction, showConstraints, showReferences, ariaLabel }: DimensionedSketchProps): import("react").JSX.Element;
