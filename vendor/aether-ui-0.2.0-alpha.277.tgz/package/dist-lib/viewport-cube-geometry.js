const viewportCubeProjection = { center: 54, scale: 21, size: 108 };
const viewportCubeAxisOrigin = [-1.15, -1.15, -1.15];
const viewportCubeAxes = ["x", "y", "z"].map((id, index) => ({
  id,
  end: viewportCubeAxisOrigin.map((value, i) => i === index ? 1.25 : value)
}));
function viewportVectorForUpAxis([x, y, z], upAxis) {
  return upAxis === "z" ? [x, -z || 0, y] : [x, y, z];
}
const b = 0.8, c = 0.65;
const axes = [0, 1, 2];
const signs = [-1, 1];
const cross = (a, b2) => [a[1] * b2[2] - a[2] * b2[1], a[2] * b2[0] - a[0] * b2[2], a[0] * b2[1] - a[1] * b2[0]];
const dot = (a, b2) => a.reduce((sum, n, i) => sum + n * b2[i], 0);
const named = (axis, sign) => [["left", "right"], ["bottom", "top"], ["back", "front"]][axis][sign > 0 ? 1 : 0];
const title = (s) => s[0].toUpperCase() + s.slice(1);
function region(normal, vertices, kind, view) {
  const length = Math.hypot(...normal);
  const n = normal.map((v) => v / length);
  const up = Math.abs(n[1]) > 0.99 ? [0, 0, -Math.sign(n[1])] : [0, 1, 0];
  const right = cross(up, n);
  const vertical = cross(n, right);
  const center = vertices[0].map((_, i) => vertices.reduce((sum, v) => sum + v[i], 0) / vertices.length);
  vertices.sort((a, b2) => {
    const relative = (v) => v.map((x, i) => x - center[i]);
    const angle = (v) => Math.atan2(dot(relative(v), vertical), dot(relative(v), right));
    return angle(a) - angle(b2);
  });
  const label = axes.filter((i) => normal[i]).map((i) => title(named(i, normal[i]))).join(" ");
  return { id: view ?? label.toLowerCase().replaceAll(" ", "-"), label, kind, view, normal: n, vertices, ...view ? { right, up: vertical } : {} };
}
const regions = [];
for (const axis of axes) for (const sign of signs) {
  const [u, v] = axes.filter((i) => i !== axis);
  const normal = [0, 0, 0];
  normal[axis] = sign;
  const vertices = [[b, c], [c, b], [-c, b], [-b, c], [-b, -c], [-c, -b], [c, -b], [b, -c]].map(([x, y]) => {
    const p = [0, 0, 0];
    p[axis] = sign;
    p[u] = x;
    p[v] = y;
    return p;
  });
  regions.push(region(normal, vertices, "face", named(axis, sign)));
}
for (const along of axes) {
  const [u, v] = axes.filter((i) => i !== along);
  for (const su of signs) for (const sv of signs) {
    const normal = [0, 0, 0];
    normal[u] = su;
    normal[v] = sv;
    const vertices = [];
    for (const s of signs) for (const swap of [false, true]) {
      const p = [0, 0, 0];
      p[along] = c * s;
      p[u] = (swap ? b : 1) * su;
      p[v] = (swap ? 1 : b) * sv;
      vertices.push(p);
    }
    regions.push(region(normal, vertices, "edge"));
  }
}
for (const x of signs) for (const y of signs) for (const z of signs) {
  const vertices = [[1, b, c], [1, c, b], [b, 1, c], [c, 1, b], [b, c, 1], [c, b, 1]].map((p) => [p[0] * x, p[1] * y, p[2] * z]);
  regions.push(region([x, y, z], vertices, "corner"));
}
const viewportCubeRegions = regions;
const zUpRegions = regions.map((region2) => ({
  ...region2,
  normal: viewportVectorForUpAxis(region2.normal, "z"),
  vertices: region2.vertices.map((vertex) => viewportVectorForUpAxis(vertex, "z")),
  ...region2.right ? { right: viewportVectorForUpAxis(region2.right, "z") } : {},
  ...region2.up ? { up: viewportVectorForUpAxis(region2.up, "z") } : {}
}));
function viewportCubeRegionsForUpAxis(upAxis) {
  return upAxis === "z" ? zUpRegions : viewportCubeRegions;
}
const viewportCubeColorTokens = {
  face: "--aether-color-bg-control-hover",
  edge: "--aether-color-bg-hover",
  corner: "--aether-color-border-control",
  outline: "--aether-color-text-dim",
  label: "--aether-color-text",
  hover: "--aether-color-accent"
};
export {
  viewportCubeAxes,
  viewportCubeAxisOrigin,
  viewportCubeColorTokens,
  viewportCubeProjection,
  viewportCubeRegions,
  viewportCubeRegionsForUpAxis,
  viewportVectorForUpAxis
};
