import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { FieldRow } from "./FieldRow.js";
import { Inspector, InspectorSection } from "./Inspector.js";
import { MenuButton } from "./Menu.js";
import "./FileDetails.css";
const EVENT_WORDS = {
  created: "Created",
  save: "Edited",
  rename: "Renamed",
  move: "Moved",
  copy: "Copied",
  favorite: "Added to favorites",
  grant: "Updated sharing",
  link_create: "Shared a link",
  link_revoke: "Revoked a link",
  redeem: "Opened a shared link",
  trash: "Moved to the recycle bin",
  restore: "Restored",
  delete_forever: "Deleted permanently"
};
function fileEventLabel(action) {
  return EVENT_WORDS[action] ?? action.replaceAll("_", " ");
}
function FileCommandBar({ items, onSelect, inline = 5, label = "File actions", trailing }) {
  const front = items.slice(0, inline), rest = items.slice(inline);
  return /* @__PURE__ */ jsxs("div", { className: "aui-file-command-bar", role: "toolbar", "aria-label": label, children: [
    front.map((item) => /* @__PURE__ */ jsxs(
      "button",
      {
        type: "button",
        className: "aui-file-command",
        disabled: item.disabled,
        title: item.disabled ? item.disabledReason : void 0,
        onClick: () => onSelect(item.id),
        children: [
          item.icon,
          /* @__PURE__ */ jsx("span", { children: item.label })
        ]
      },
      item.id
    )),
    rest.length > 0 && /* @__PURE__ */ jsxs(MenuButton, { className: "aui-file-command", label: "More actions", items: rest, onSelect, children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "more" }),
      /* @__PURE__ */ jsx("span", { children: "More" })
    ] }),
    trailing
  ] });
}
function initials(name) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "?";
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
}
function FileDetails({
  name,
  icon,
  subtitle,
  previewURL,
  previewKind,
  onPreview,
  actions,
  access,
  accessNote,
  onManageAccess,
  activity,
  information
}) {
  const thumbnail = previewURL && previewKind === "image";
  return /* @__PURE__ */ jsxs(Inspector, { className: "aui-file-details", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-file-details-hero", children: [
      onPreview ? /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          className: "aui-file-details-thumb",
          onClick: onPreview,
          "aria-label": `Preview ${name}`,
          "data-image": thumbnail ? "" : void 0,
          children: [
            thumbnail ? /* @__PURE__ */ jsx("img", { src: previewURL, alt: "" }) : icon,
            /* @__PURE__ */ jsxs("span", { className: "aui-file-details-thumb-hint", children: [
              /* @__PURE__ */ jsx(AetherIcon, { name: "search" }),
              " Preview"
            ] })
          ]
        }
      ) : /* @__PURE__ */ jsx("div", { className: "aui-file-details-thumb", children: icon }),
      /* @__PURE__ */ jsx("h2", { children: name }),
      subtitle !== void 0 && /* @__PURE__ */ jsx("p", { children: subtitle })
    ] }),
    actions,
    (access || accessNote || onManageAccess) && /* @__PURE__ */ jsxs(
      InspectorSection,
      {
        title: "Has access",
        actions: onManageAccess && /* @__PURE__ */ jsx(Button, { onClick: onManageAccess, children: "Manage access" }),
        children: [
          access && access.length > 0 && /* @__PURE__ */ jsx("ul", { className: "aui-file-details-people", children: access.map((person) => /* @__PURE__ */ jsxs("li", { children: [
            /* @__PURE__ */ jsx("span", { className: "aui-file-details-avatar", "aria-hidden": "true", children: initials(person.name) }),
            /* @__PURE__ */ jsxs("span", { className: "aui-file-details-person", children: [
              /* @__PURE__ */ jsx("strong", { children: person.name }),
              /* @__PURE__ */ jsx("em", { children: person.role })
            ] })
          ] }, person.id)) }),
          accessNote !== void 0 && /* @__PURE__ */ jsx("p", { className: "aui-file-details-note", children: accessNote })
        ]
      }
    ),
    activity && /* @__PURE__ */ jsx(InspectorSection, { title: "Recent activity", children: activity.length === 0 ? /* @__PURE__ */ jsx("p", { className: "aui-file-details-note", children: "No activity yet." }) : /* @__PURE__ */ jsx("ol", { className: "aui-file-details-activity", children: activity.map((event) => /* @__PURE__ */ jsxs("li", { children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "history" }),
      /* @__PURE__ */ jsxs("span", { children: [
        /* @__PURE__ */ jsx("strong", { children: fileEventLabel(event.action) }),
        /* @__PURE__ */ jsxs("em", { children: [
          event.author,
          " \xB7 ",
          new Date(event.created * 1e3).toLocaleString()
        ] })
      ] })
    ] }, event.id)) }) }),
    information.length > 0 && /* @__PURE__ */ jsx(InspectorSection, { title: "File information", children: information.map((row) => /* @__PURE__ */ jsx(FieldRow, { label: row.label, children: /* @__PURE__ */ jsx("output", { children: row.value }) }, row.label)) })
  ] });
}
export {
  FileCommandBar,
  FileDetails,
  fileEventLabel
};
