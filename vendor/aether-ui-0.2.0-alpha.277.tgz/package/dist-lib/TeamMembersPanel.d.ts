import "./WorkflowWidgets.css";
export interface TeamMember {
    id: string;
    name: string;
    email: string;
    credits: number;
    avatar?: string;
}
export interface TeamMembersPanelProps {
    members: readonly TeamMember[];
    onInvite: (email: string) => void;
    onCreditChange: (id: string, credits: number) => void;
    onRemove: (id: string) => void;
    totalCredits: number;
}
export declare function TeamMembersPanel({ members, onInvite, onCreditChange, onRemove, totalCredits }: TeamMembersPanelProps): import("react").JSX.Element;
