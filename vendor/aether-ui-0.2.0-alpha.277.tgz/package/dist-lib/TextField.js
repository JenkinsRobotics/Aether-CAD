import { jsx, jsxs } from "react/jsx-runtime";
function TextField({ invalid, unit, className, style, ...rest }) {
  const classes = ["aui-text-field"];
  if (invalid) classes.push("aui-text-field--invalid");
  if (className) classes.push(className);
  const input = /* @__PURE__ */ jsx(
    "input",
    {
      className: classes.join(" "),
      "aria-invalid": invalid || void 0,
      style: unit ? void 0 : style,
      ...rest
    }
  );
  if (!unit) return input;
  return /* @__PURE__ */ jsxs("span", { className: "aui-text-field-wrap", style, children: [
    input,
    /* @__PURE__ */ jsx("span", { className: "aui-text-field-unit", "aria-hidden": true, children: unit })
  ] });
}
export {
  TextField
};
