import { type DocumentHistory } from "./DocumentServices.js";
import type { HistoryMilestone } from "./document-history-graph.js";
export declare const HISTORY_LEGEND: readonly [readonly ["workspace", "Workspace"], readonly ["tag", "Version"], readonly ["change", "Change"], readonly ["triangle", "Release candidate"], readonly ["triangle-filled", "Release"], readonly ["obsoletion", "Contains obsoletion"], readonly ["auto-version", "Automatic version"]];
/** Shared graph presentation: visibility is local, history remains server-owned. */
export declare function DocumentHistoryGraph({ history, graph, branch, query, selectedID, selectedSave, onSelect, onSelectSave, onOpenWorkspace, onContextMenu }: {
    history: DocumentHistory | null;
    graph: HistoryMilestone[];
    branch: string;
    query: string;
    selectedID?: string;
    selectedSave: number | null;
    onSelect: (row: HistoryMilestone) => void;
    onSelectSave: (id: number) => void;
    onOpenWorkspace: (name: string) => void;
    onContextMenu: (position: {
        x: number;
        y: number;
    }) => void;
}): import("react").JSX.Element;
