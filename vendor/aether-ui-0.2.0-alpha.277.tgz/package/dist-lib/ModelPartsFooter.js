import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { DocumentTabBar } from "./DocumentTabBar.js";
import { FileManagerPanel } from "./FileManagerPanel.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
import { SelectField } from "./SelectField.js";
import { TextField } from "./TextField.js";
import "./ModelStudioComposition.css";
function ModelPartsFooter({ hidden, name, fileItems, parts, selected, onSelect, onAction, nouns }) {
  const Part = nouns.part[0].toUpperCase() + nouns.part.slice(1);
  const [panel, setPanel] = useState(null);
  const [folders, setFolders] = useState([]);
  const [newFolder, setNewFolder] = useState("");
  useEffect(() => {
    if (hidden) setPanel(null);
  }, [hidden]);
  const folderFor = (id) => folders.find((folder) => folder.parts.includes(id));
  const groups = [
    { id: "ungrouped", label: folders.length ? `Ungrouped ${nouns.part}s` : `${Part}s`, parts: parts.filter((part) => !folderFor(part.id)) },
    ...folders.map((folder) => ({ id: folder.id, label: folder.name || "Untitled folder", parts: parts.filter((part) => folder.parts.includes(part.id)) }))
  ];
  const close = () => setPanel(null);
  return /* @__PURE__ */ jsxs("footer", { className: "ps-parts-footer", "aria-label": `${Part}s footer`, hidden, children: [
    /* @__PURE__ */ jsx(
      DocumentTabBar,
      {
        variant: "studio",
        ariaLabel: nouns.label,
        addLabel: `Add ${nouns.visible.toLowerCase()}`,
        addItems: nouns.addItems,
        onAdd: onAction,
        tabs: [
          { id: "scene", label: name, detail: nouns.study, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "layers" }), current: !selected, onSelect: () => onSelect("") },
          ...groups.flatMap((group) => group.parts.map((part) => ({ id: part.id, label: part.name, detail: folderFor(part.id)?.name || (part.visible ? nouns.visible : `Hidden ${nouns.part}`), icon: /* @__PURE__ */ jsx(AetherIcon, { name: nouns.icon }), current: selected === part.id, onSelect: () => onSelect(part.id) })))
        ],
        trailing: /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(IconButton, { label: "Folder manager", size: "medium", "aria-haspopup": "dialog", "aria-expanded": panel === "folders", onClick: () => setPanel("folders"), children: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }) }),
          /* @__PURE__ */ jsx(IconButton, { label: `${Part} manager`, size: "medium", "aria-haspopup": "dialog", "aria-expanded": panel === "parts", onClick: () => setPanel("parts"), children: /* @__PURE__ */ jsx(AetherIcon, { name: "part-manager" }) }),
          /* @__PURE__ */ jsx(MenuButton, { label: "File menu", className: "aui-icon-button ps-tray-file", "data-size": "medium", "data-appearance": "rounded", items: fileItems, placement: "top-end", onSelect: onAction, children: /* @__PURE__ */ jsx(AetherIcon, { name: "menu" }) })
        ] })
      }
    ),
    /* @__PURE__ */ jsx(Dialog, { open: panel === "parts", title: `${Part} manager`, onClose: close, actions: /* @__PURE__ */ jsx(Button, { onClick: close, children: "Done" }), children: /* @__PURE__ */ jsx("div", { className: "ps-part-manager", children: /* @__PURE__ */ jsx(
      FileManagerPanel,
      {
        ariaLabel: `${nouns.visible}s`,
        documentName: name,
        showLibrary: false,
        activeID: selected,
        documentGroups: groups.map((group) => ({ id: group.id, label: group.label, emptyText: `No ${nouns.part}s in this folder.`, items: group.parts.map((part) => ({ id: part.id, name: part.name, kind: "part", detail: part.visible ? nouns.visible : `Hidden ${nouns.part}`, icon: /* @__PURE__ */ jsx(AetherIcon, { name: nouns.icon }) })) })),
        onOpen: (item) => {
          onSelect(item.id);
          close();
        }
      }
    ) }) }),
    /* @__PURE__ */ jsx(Dialog, { open: panel === "folders", title: "Folder manager", onClose: close, actions: /* @__PURE__ */ jsx(Button, { onClick: close, children: "Done" }), children: /* @__PURE__ */ jsxs("div", { className: "ps-part-folders", children: [
      /* @__PURE__ */ jsxs("p", { children: [
        "Organize this window\u2019s ",
        nouns.part,
        " tabs into folders."
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: (event) => {
        event.preventDefault();
        if (!newFolder.trim()) return;
        setFolders((value) => [...value, { id: crypto.randomUUID(), name: newFolder.trim(), parts: [] }]);
        setNewFolder("");
      }, children: [
        /* @__PURE__ */ jsx(TextField, { "aria-label": `New ${nouns.part} folder name`, placeholder: "Folder name", maxLength: 80, value: newFolder, onChange: (event) => setNewFolder(event.target.value) }),
        /* @__PURE__ */ jsx(Button, { type: "submit", disabled: !newFolder.trim(), children: "New folder" })
      ] }),
      folders.map((folder) => /* @__PURE__ */ jsxs("div", { className: "ps-part-folder-row", children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }),
        /* @__PURE__ */ jsx(TextField, { "aria-label": `Rename folder ${folder.name}`, maxLength: 80, value: folder.name, onChange: (event) => setFolders((value) => value.map((item) => item.id === folder.id ? { ...item, name: event.target.value } : item)) }),
        /* @__PURE__ */ jsx(IconButton, { label: `Ungroup ${folder.name || "Untitled folder"}`, size: "small", onClick: () => setFolders((value) => value.filter((item) => item.id !== folder.id)), children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
      ] }, folder.id)),
      /* @__PURE__ */ jsx("div", { className: "ps-part-folder-assignments", children: parts.map((part) => /* @__PURE__ */ jsxs("label", { children: [
        /* @__PURE__ */ jsx("span", { title: part.name, children: part.name }),
        /* @__PURE__ */ jsx(
          SelectField,
          {
            "aria-label": `Folder for ${part.name}`,
            value: folderFor(part.id)?.id ?? "",
            options: [{ value: "", label: "Ungrouped" }, ...folders.map((folder) => ({ value: folder.id, label: folder.name || "Untitled folder" }))],
            onChange: (event) => setFolders((value) => value.map((folder) => ({ ...folder, parts: [...folder.parts.filter((id) => id !== part.id), ...folder.id === event.target.value ? [part.id] : []] })))
          }
        )
      ] }, part.id)) })
    ] }) })
  ] });
}
export {
  ModelPartsFooter
};
