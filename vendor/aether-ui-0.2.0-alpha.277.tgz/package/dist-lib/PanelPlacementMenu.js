import { jsx } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
const placementItems = (placement) => [
  {
    id: "docked",
    label: "Dock",
    icon: "\u25A6",
    kind: "radio",
    checked: placement === "docked"
  },
  {
    id: "floating",
    label: "Float",
    icon: /* @__PURE__ */ jsx(AetherIcon, { name: "rectangle" }),
    kind: "radio",
    checked: placement === "floating"
  },
  {
    id: "hidden",
    label: "Hide",
    icon: "\u2212",
    kind: "radio",
    checked: placement === "hidden"
  }
];
function PanelPlacementMenu({
  label,
  placement,
  onChange,
  className,
  children = "\u2022\u2022\u2022"
}) {
  return /* @__PURE__ */ jsx(
    MenuButton,
    {
      className,
      label: `${label} placement`,
      items: placementItems(placement),
      onSelect: (id) => onChange(id),
      children
    }
  );
}
export {
  PanelPlacementMenu
};
