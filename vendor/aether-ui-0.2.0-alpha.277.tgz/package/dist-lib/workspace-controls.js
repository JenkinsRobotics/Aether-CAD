import { useEffect, useRef, useSyncExternalStore } from "react";
const clients = /* @__PURE__ */ new Map();
const listeners = /* @__PURE__ */ new Set();
let version = 0;
function emit() {
  version++;
  listeners.forEach((listener) => listener());
}
function useRegisterWorkspaceControls(element, controls) {
  const current = useRef(controls);
  current.current = controls;
  const signature = JSON.stringify(controls.panels);
  useEffect(() => {
    const id = {};
    clients.set(id, { element, current: () => current.current });
    emit();
    return () => {
      clients.delete(id);
      emit();
    };
  }, [element]);
  useEffect(emit, [signature]);
}
function useWorkspaceControls() {
  useSyncExternalStore((listener) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, () => version, () => 0);
  return [...clients.values()].reverse().find((client) => client.element.current && !client.element.current.closest('[hidden],[inert],[aria-hidden="true"]'))?.current();
}
export {
  useRegisterWorkspaceControls,
  useWorkspaceControls
};
