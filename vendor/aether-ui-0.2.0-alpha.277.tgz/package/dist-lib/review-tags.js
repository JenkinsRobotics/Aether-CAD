function parseReviewTags(text) {
  const seen = /* @__PURE__ */ new Set();
  return text.split(",").map((tag) => tag.trim()).filter((tag) => {
    const key = tag.toLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 20);
}
export {
  parseReviewTags
};
