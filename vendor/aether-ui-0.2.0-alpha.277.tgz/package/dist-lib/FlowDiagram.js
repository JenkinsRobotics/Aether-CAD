import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useId } from "react";
import "./FlowDiagram.css";
function FlowDiagram({
  title,
  description,
  routes,
  width = 1160,
  height = 420,
  paused = false,
  playbackRate = 1,
  highlightedRouteIds,
  children,
  className,
  interactive = false,
  selectedRouteId,
  onRouteSelect
}) {
  const id = useId();
  const speed = Number.isFinite(playbackRate) && playbackRate > 0 ? playbackRate : 1;
  return /* @__PURE__ */ jsx("div", { className: ["aui-flow-diagram", className].filter(Boolean).join(" "), "data-paused": paused, children: /* @__PURE__ */ jsx("div", { className: "aui-flow-diagram-scroll", role: "region", "aria-label": `${title} canvas`, tabIndex: 0, children: /* @__PURE__ */ jsxs("svg", { viewBox: `0 0 ${width} ${height}`, role: interactive ? "group" : "img", "aria-labelledby": `${id}-title`, "aria-describedby": `${id}-description`, children: [
    /* @__PURE__ */ jsx("title", { id: `${id}-title`, children: title }),
    /* @__PURE__ */ jsx("desc", { id: `${id}-description`, children: description }),
    /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("pattern", { id: `${id}-dots`, width: "22", height: "22", patternUnits: "userSpaceOnUse", children: /* @__PURE__ */ jsx("circle", { cx: "1", cy: "1", r: "0.8", className: "aui-flow-dot" }) }) }),
    /* @__PURE__ */ jsx("rect", { width, height, fill: `url(#${id}-dots)` }),
    routes.map((route, index) => {
      const duration = route.durationSeconds ?? 6;
      const seconds = Number.isFinite(duration) && duration > 0 ? duration : 6;
      const delay = route.delaySeconds ?? -index * 0.73;
      return /* @__PURE__ */ jsxs(
        "g",
        {
          className: "aui-flow-route",
          "data-tone": route.tone,
          "data-selected": selectedRouteId === route.id,
          role: onRouteSelect ? "button" : void 0,
          tabIndex: onRouteSelect ? 0 : void 0,
          "aria-label": onRouteSelect ? `Connection: ${route.label ?? route.id}` : void 0,
          "aria-pressed": onRouteSelect ? selectedRouteId === route.id : void 0,
          onClick: onRouteSelect ? () => onRouteSelect(route.id) : void 0,
          onKeyDown: onRouteSelect ? (event) => {
            if (event.key === "Enter" || event.key === " ") {
              event.preventDefault();
              onRouteSelect(route.id);
            }
          } : void 0,
          "data-route": route.id,
          "data-muted": highlightedRouteIds !== void 0 && !highlightedRouteIds.includes(route.id),
          style: { "--flow-duration": `${seconds / speed}s`, "--flow-delay": `${(Number.isFinite(delay) ? delay : 0) / speed}s` },
          children: [
            /* @__PURE__ */ jsx("path", { className: "aui-flow-route-clearance", d: route.path }),
            /* @__PURE__ */ jsx("path", { className: "aui-flow-route-line", d: route.path, strokeDasharray: route.dashed ? "6 7" : void 0 }),
            /* @__PURE__ */ jsx("path", { className: "aui-flow-route-signal", d: route.path, pathLength: "1000" }),
            onRouteSelect && /* @__PURE__ */ jsx("path", { className: "aui-flow-route-hit", d: route.path }),
            route.source && /* @__PURE__ */ jsx("circle", { className: "aui-flow-port", cx: route.source.x, cy: route.source.y, r: "5.5" })
          ]
        },
        route.id
      );
    }),
    children
  ] }) }) });
}
function FlowDiagramNode({ x, y, width, height, label, detail, variant = "module", children }) {
  const processor = variant === "processor";
  return /* @__PURE__ */ jsxs("g", { className: "aui-flow-node", "data-variant": variant, transform: `translate(${x} ${y})`, children: [
    processor && /* @__PURE__ */ jsx("g", { className: "aui-flow-pins", children: Array.from({ length: Math.max(0, Math.floor((height - 20) / 13)) }, (_, index) => {
      const pinY = 12 + index * 13;
      return /* @__PURE__ */ jsx("path", { d: `M0 ${pinY}h-9v4h9 M${width} ${pinY}h9v4h-9` }, index);
    }) }),
    /* @__PURE__ */ jsx("rect", { className: "aui-flow-node-body", width, height, rx: variant === "gate" ? width / 2 : 6 }),
    processor && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("rect", { className: "aui-flow-node-inset", x: "9", y: "9", width: width - 94, height: height - 18, rx: "4" }),
      /* @__PURE__ */ jsx("path", { className: "aui-flow-node-notch", d: `M${width / 2 - 8} 0a8 8 0 0 0 16 0` })
    ] }),
    label && /* @__PURE__ */ jsx("text", { className: "aui-flow-node-label", x: processor ? 20 : width / 2, y: processor ? 51 : height / 2 - (detail ? 3 : -4), textAnchor: processor ? "start" : "middle", children: label }),
    detail && /* @__PURE__ */ jsx("text", { className: "aui-flow-node-detail", x: processor ? 20 : width / 2, y: processor ? 72 : height / 2 + 15, textAnchor: processor ? "start" : "middle", children: detail }),
    children
  ] });
}
function FlowDiagramLabel({ x, y, children, subtle = false, anchor = "start" }) {
  return /* @__PURE__ */ jsx("text", { className: "aui-flow-label", "data-subtle": subtle, x, y, textAnchor: anchor, children });
}
export {
  FlowDiagram,
  FlowDiagramLabel,
  FlowDiagramNode
};
