import { jsx, jsxs } from "react/jsx-runtime";
import { useId, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { CollectionFilter } from "./CollectionFilter.js";
import { Menu } from "./Menu.js";
import { SidePanelHeader } from "./SidePanelHeader.js";
import { PanelNotifications } from "./PanelNotifications.js";
import { useHistoryRollback } from "./useHistoryRollback.js";
import "./HistoryPanel.css";
const isTextTarget = (target) => target instanceof Element && !!target.closest('input, textarea, [contenteditable]:not([contenteditable="false"])');
const findAction = (items, id) => {
  for (const item of items) {
    if (item.id === id) return item;
    const child = !item.disabled && item.children && findAction(item.children, id);
    if (child) return child;
  }
};
function HistoryPanel({
  entries,
  onCommand,
  emptyMessage = "Edits will appear here as you work.",
  embedded = false,
  rollbackIndex,
  rollbackEntryIDs,
  onRollback,
  rollbackDisabled = false
}) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [expanded, setExpanded] = useState(null);
  const [context, setContext] = useState(null);
  const prefix = useId();
  const categories = [...new Set(entries.map((entry2) => entry2.category).filter((value) => !!value))];
  const visible = entries.filter((entry2) => (category === "all" || category === entry2.category) && `${entry2.label} ${entry2.description ?? ""}`.toLowerCase().includes(query.trim().toLowerCase()));
  const rollbackIDs = entries.filter((entry2) => !rollbackEntryIDs || rollbackEntryIDs.includes(entry2.id)).map((entry2) => entry2.id);
  const showRollback = rollbackIndex !== void 0 && rollbackIDs.length > 0 && !query.trim() && category === "all";
  const rollback = useHistoryRollback({
    index: rollbackIndex ?? rollbackIDs.length,
    ids: rollbackIDs,
    disabled: !showRollback || rollbackDisabled || !onRollback,
    onChange: onRollback
  });
  const backgroundItems = [
    { id: "collapse", label: "Collapse all", disabled: expanded === null },
    { id: "clear-filter", label: "Clear filters", disabled: !query && category === "all" }
  ];
  const entry = entries.find((item) => item.id === context?.id);
  const run = (entryID, commandID) => {
    const action = findAction(entries.find((item) => item.id === entryID)?.actions ?? [], commandID);
    if (action && !action.disabled) onCommand?.(entryID, commandID);
  };
  return /* @__PURE__ */ jsx(PanelNotifications, { children: /* @__PURE__ */ jsxs("section", { className: `aui-edit-history${embedded ? " aui-edit-history--embedded" : ""}`, "aria-label": "Editing history", onContextMenu: (event) => {
    event.stopPropagation();
    if (isTextTarget(event.target)) return;
    event.preventDefault();
    setContext(backgroundItems.some((item) => !item.disabled) ? { id: null, x: event.clientX, y: event.clientY } : null);
  }, children: [
    !embedded && /* @__PURE__ */ jsx(SidePanelHeader, { title: "History", icon: "history" }),
    /* @__PURE__ */ jsx(
      CollectionFilter,
      {
        ariaLabel: "Search editing history",
        placeholder: "Search history\u2026",
        query,
        onQueryChange: setQuery,
        options: categories.map((id) => ({ id, label: id })),
        value: category,
        onChange: setCategory
      }
    ),
    /* @__PURE__ */ jsxs("div", { ...rollback.listProps, className: "aui-edit-history-list", role: "list", "aria-label": "History steps", children: [
      visible.flatMap((item, index) => {
        const open = expanded === item.id;
        const detailsID = `${prefix}-${index}`;
        const operationIndex = rollbackIDs.indexOf(item.id);
        const row = /* @__PURE__ */ jsxs(
          "article",
          {
            role: "listitem",
            className: "aui-edit-history-entry",
            "data-history-rollback-index": operationIndex < 0 ? void 0 : operationIndex,
            "data-current": item.current || void 0,
            "data-inactive": item.inactive || void 0,
            "data-expanded": open || void 0,
            onContextMenu: (event) => {
              event.stopPropagation();
              if (isTextTarget(event.target)) return;
              event.preventDefault();
              setContext(item.actions?.length ? { id: item.id, x: event.clientX, y: event.clientY } : null);
            },
            onKeyDown: (event) => {
              if (isTextTarget(event.target)) return;
              const command = event.key === "F2" ? "rename" : ["Delete", "Backspace"].includes(event.key) ? "delete" : null;
              if (command) {
                event.preventDefault();
                event.stopPropagation();
                run(item.id, command);
              }
            },
            children: [
              /* @__PURE__ */ jsxs("div", { className: "aui-edit-history-row", children: [
                /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-edit-history-disclosure", "aria-expanded": open, "aria-controls": detailsID, onClick: () => setExpanded(open ? null : item.id), children: [
                  /* @__PURE__ */ jsx("span", { className: "aui-edit-history-icon", "aria-hidden": true, children: item.icon ?? /* @__PURE__ */ jsx(AetherIcon, { name: "history" }) }),
                  /* @__PURE__ */ jsx("span", { className: "aui-edit-history-name", title: item.label, children: item.label }),
                  item.current && /* @__PURE__ */ jsx("span", { className: "aui-edit-history-current", title: "Current step", "aria-label": "Current step" }),
                  /* @__PURE__ */ jsx(AetherIcon, { name: open ? "chevron-down" : "chevron-right" })
                ] }),
                !!item.actions?.length && /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    className: "aui-edit-history-more",
                    "aria-label": `Actions for ${item.label}`,
                    "aria-haspopup": "menu",
                    "aria-expanded": context?.id === item.id,
                    onClick: (event) => {
                      const rect = event.currentTarget.getBoundingClientRect();
                      setContext({ id: item.id, x: rect.right, y: rect.bottom });
                    },
                    children: /* @__PURE__ */ jsx(AetherIcon, { name: "more-circle" })
                  }
                )
              ] }),
              open && /* @__PURE__ */ jsxs("div", { id: detailsID, className: "aui-edit-history-details", children: [
                item.description && /* @__PURE__ */ jsx("p", { children: item.description }),
                item.details,
                !item.description && !item.details && /* @__PURE__ */ jsx("p", { children: item.category ?? "Editing step" }),
                item.inactive && /* @__PURE__ */ jsx("small", { children: "Not applied in the current state." })
              ] })
            ]
          },
          item.id
        );
        if (!showRollback || operationIndex < 0) return [row];
        return [
          ...operationIndex === rollback.position ? [rollback.marker] : [],
          row,
          ...operationIndex === rollbackIDs.length - 1 && rollback.position === rollbackIDs.length ? [rollback.marker] : []
        ];
      }),
      !visible.length && /* @__PURE__ */ jsx("p", { className: "aui-edit-history-empty", children: query || category !== "all" ? "No matching history steps." : emptyMessage })
    ] }),
    context && (context.id === null || entry) && /* @__PURE__ */ jsx(Menu, { open: true, className: "aui-collection-popup", ariaLabel: entry ? `Actions for ${entry.label}` : "History options", anchor: { x: context.x, y: context.y }, items: entry?.actions ?? backgroundItems, onClose: () => setContext(null), onSelect: (command) => {
      if (context.id) run(context.id, command);
      else if (command === "collapse") setExpanded(null);
      else if (command === "clear-filter") {
        setQuery("");
        setCategory("all");
      }
      setContext(null);
    } })
  ] }) });
}
export {
  HistoryPanel
};
