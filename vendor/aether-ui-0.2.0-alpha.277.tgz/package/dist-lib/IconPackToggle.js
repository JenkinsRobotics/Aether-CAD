import { jsx } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
const TOOL_ICON_PACKS = [
  { id: "classic", label: "Aether Classic" },
  { id: "graphite-ribbon", label: "Graphite Ribbon" }
];
function IconPackToggle({ pack, onChange }) {
  const current = TOOL_ICON_PACKS.find((entry) => entry.id === pack)?.label ?? pack;
  return /* @__PURE__ */ jsx(
    MenuButton,
    {
      label: "Icon pack",
      className: "aui-icon-button",
      title: `Icon pack: ${current}`,
      items: TOOL_ICON_PACKS.map((entry) => ({ id: entry.id, label: entry.label, checked: entry.id === pack })),
      onSelect: (id) => onChange(id),
      children: /* @__PURE__ */ jsx(AetherIcon, { name: "grid-2" })
    }
  );
}
export {
  IconPackToggle,
  TOOL_ICON_PACKS
};
