export interface BreadcrumbItem {
    id: string;
    label: string;
    disabled?: boolean;
}
export interface BreadcrumbsProps {
    items: readonly BreadcrumbItem[];
    onNavigate: (id: string) => void;
    ariaLabel?: string;
    maxVisible?: number;
    className?: string;
}
/** Stable-path navigation. The last item is the current page; long paths use
 * the shared Menu for intermediate locations rather than a second popup. */
export declare function Breadcrumbs({ items, onNavigate, ariaLabel, maxVisible, className, }: BreadcrumbsProps): import("react").JSX.Element | null;
