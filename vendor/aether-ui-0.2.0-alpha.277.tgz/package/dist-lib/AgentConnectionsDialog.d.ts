import type { AgentAccessService, AgentEditorSharing, AgentPlugin, AgentService } from './AgentServices.js';
interface Props {
    open: boolean;
    onClose: () => void;
    app: string;
    service: AgentService;
    access?: AgentAccessService;
    sharing?: AgentEditorSharing;
    plugins: AgentPlugin[];
    onChanged: () => void;
    provider: string;
    onProvider: (id: string) => void;
    models: {
        id: string;
        name: string;
    }[];
    model: string;
    onModel: (id: string) => void;
    busy: boolean;
}
/** Connection presentation; all auth, installation policy and transport belong to Studio. */
export declare function AgentConnectionsDialog({ open, onClose, app, service, access, sharing, plugins, onChanged, provider, onProvider, models, model, onModel, busy }: Props): import("react").JSX.Element;
export {};
