import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
import { TextField } from "./TextField.js";
import "./FloatingToolbar.css";
function FloatingToolbar({ ariaLabel, variant = "tools", groups, onAction, leading, trailing, command, className }) {
  const focusAction = (event) => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    if (!(event.target instanceof HTMLElement) || event.target.closest('[role="menu"]')) return;
    const buttons = Array.from(event.currentTarget.querySelectorAll("button:not(:disabled)"));
    const index = buttons.indexOf(event.target);
    if (index < 0) return;
    const next = event.key === "Home" ? 0 : event.key === "End" ? buttons.length - 1 : (index + (event.key === "ArrowRight" ? 1 : -1) + buttons.length) % buttons.length;
    event.preventDefault();
    buttons[next]?.focus();
    buttons[next]?.scrollIntoView?.({ block: "nearest", inline: "nearest" });
  };
  return /* @__PURE__ */ jsxs("div", { className: ["aui-floating-toolbar", className].filter(Boolean).join(" "), "data-variant": variant, children: [
    command && /* @__PURE__ */ jsxs(
      "form",
      {
        className: "aui-floating-toolbar-command",
        role: "search",
        "aria-label": command.label ?? "Find a command",
        onSubmit: (event) => {
          event.preventDefault();
          command.onSubmit(command.value.trim());
        },
        children: [
          /* @__PURE__ */ jsxs("label", { className: "aui-floating-toolbar-input", children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "search" }),
            /* @__PURE__ */ jsx(
              TextField,
              {
                type: "search",
                "aria-label": command.label ?? "Command",
                placeholder: command.placeholder ?? "Command",
                value: command.value,
                onChange: (event) => command.onValueChange(event.target.value),
                onKeyDown: (event) => {
                  if (event.key === "Escape") {
                    event.preventDefault();
                    command.onValueChange("");
                  }
                }
              }
            )
          ] }),
          command.shortcuts && /* @__PURE__ */ jsx("div", { className: "aui-floating-toolbar-shortcuts", "aria-label": "Suggested commands", children: command.shortcuts.map((action) => /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              "data-tone": action.tone ?? "neutral",
              disabled: action.disabled,
              "aria-pressed": action.pressed,
              onClick: () => onAction(action.id),
              children: action.label
            },
            action.id
          )) })
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "aui-floating-toolbar-strip", role: "toolbar", "aria-label": ariaLabel, "aria-orientation": "horizontal", onKeyDown: focusAction, children: [
      leading && /* @__PURE__ */ jsx("div", { className: "aui-floating-toolbar-leading", children: leading }),
      groups.map((group) => /* @__PURE__ */ jsx(
        "div",
        {
          className: "aui-floating-toolbar-group",
          role: "group",
          "aria-label": group.label,
          "data-capsule": group.capsule || void 0,
          "data-separated": group.separatorBefore || void 0,
          children: group.actions.map((action) => /* @__PURE__ */ jsx(
            IconButton,
            {
              label: action.label,
              appearance: "rounded",
              size: variant === "document" || group.capsule ? "small" : "large",
              "aria-pressed": action.pressed,
              disabled: action.disabled,
              onClick: () => onAction(action.id),
              children: action.icon
            },
            action.id
          ))
        },
        group.id
      )),
      trailing && /* @__PURE__ */ jsx("div", { className: "aui-floating-toolbar-trailing", children: trailing })
    ] })
  ] });
}
function FloatingToolbarMenu({ iconOnly, className, ...props }) {
  return /* @__PURE__ */ jsx(MenuButton, { ...props, className: ["aui-floating-toolbar-menu", className].filter(Boolean).join(" "), "data-icon-only": iconOnly || void 0 });
}
export {
  FloatingToolbar,
  FloatingToolbarMenu
};
