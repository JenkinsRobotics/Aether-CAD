import "./PanelResizeHandle.css";
export interface PanelResizeHandleProps {
    edge: "left" | "right" | "top" | "bottom";
    label: string;
    value: number | (() => number);
    min?: number;
    max?: number;
    /** Centered cards grow equally on both sides. */
    scale?: number;
    onChange: (size: number) => void;
    onReset?: () => void;
}
/** Pointer-captured and keyboard-operable sizing shared by workspace cards. */
export declare function PanelResizeHandle({ edge, label, value, min, max, scale, onChange, onReset }: PanelResizeHandleProps): import("react").JSX.Element;
