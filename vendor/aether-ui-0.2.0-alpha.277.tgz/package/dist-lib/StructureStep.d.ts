import "./WorkflowElements.css";
export interface StructureStepProps {
    title: string;
    description: string;
    position: number;
}
export declare function StructureStep({ title, description, position }: StructureStepProps): import("react").JSX.Element;
