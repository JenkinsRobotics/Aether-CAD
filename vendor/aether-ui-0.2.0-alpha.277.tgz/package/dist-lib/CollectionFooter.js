import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
function CollectionFooter({ label, items, onCommand, children }) {
  if (!items.length && !children) return null;
  const folder = items.find((item) => /^(new|create|add) folder\b/i.test(item.label) && !item.children);
  return /* @__PURE__ */ jsxs("footer", { className: "aui-collection-footer", "aria-label": `${label} panel controls`, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-collection-footer-start", children: [
      folder && /* @__PURE__ */ jsx(IconButton, { label: folder.label, disabled: folder.disabled, onClick: () => onCommand(folder.id), children: /* @__PURE__ */ jsx(AetherIcon, { name: "folder-add" }) }),
      children
    ] }),
    items.length > 0 && /* @__PURE__ */ jsx(
      MenuButton,
      {
        className: "aui-icon-button",
        label: `${label} options`,
        menuClassName: "aui-collection-popup",
        items,
        onSelect: onCommand,
        children: /* @__PURE__ */ jsx(AetherIcon, { name: "more-circle" })
      }
    )
  ] });
}
export {
  CollectionFooter
};
