import type { ButtonHTMLAttributes } from "react";
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    /** Accent-filled call-to-action variant. */
    primary?: boolean;
    /** Pressed/latched state (e.g. an armed tool). */
    active?: boolean;
    /** Standard, soft filled, or text-only action. */
    appearance?: "standard" | "flat" | "link";
}
/** The standard Aether push button. */
export declare function Button({ primary, active, appearance, className, ...rest }: ButtonProps): import("react").JSX.Element;
