import type { ReactNode } from "react";
import "./MediaPreview.css";
export interface MediaPreviewProps {
    label: string;
    width: number;
    height: number;
    background?: string;
    backgroundImage?: string;
    backgroundFilter?: string;
    foreground?: {
        src: string;
        alt: string;
        scale?: number;
        offset?: number;
        mirrored?: boolean;
        filter?: string;
    };
    playing?: boolean;
    children?: ReactNode;
}
/** Aspect-correct presentation widget; apps own scene, playback and editing state. */
export declare function MediaPreview({ label, width, height, background, backgroundImage, backgroundFilter, foreground, playing, children }: MediaPreviewProps): import("react").JSX.Element;
