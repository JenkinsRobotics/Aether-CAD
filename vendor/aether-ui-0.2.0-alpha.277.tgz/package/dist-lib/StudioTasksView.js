import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ReviewFilterBar } from "./ReviewFilterBar.js";
import { PanelNotice } from "./PanelNotifications.js";
import { useEffect, useRef, useState } from "react";
import { parseReviewTags } from "./review-tags.js";
import { AetherIcon } from "./AetherIcon.js";
import { Avatar } from "./Avatar.js";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
import { SelectField } from "./SelectField.js";
import { TextField } from "./TextField.js";
import { ReviewComposer } from "./ReviewComposer.js";
import { commentScreenshot } from "./comment-images.js";
import "./StudioReview.css";
const statuses = [{ value: "open", label: "Open" }, { value: "in_progress", label: "In progress" }, { value: "done", label: "Completed" }];
function StudioTasksView(props) {
  const { state, busy } = props;
  const [filter, setFilter] = useState("all"), [localTag, setLocalTag] = useState(""), [query, setQuery] = useState(""), [assignee, setAssignee] = useState("all"), [sort, setSort] = useState("status"), [completed, setCompleted] = useState(false);
  const tag = props.reviewTag ?? localTag, setTag = props.onReviewTag ?? setLocalTag;
  const addingCard = useRef(null);
  const [target, setTarget] = useState(""), [cardEditor, setCardEditor] = useState(null), [details, setDetails] = useState(false), [history, setHistory] = useState(null), [metadata, setMetadata] = useState({});
  useEffect(() => {
    let live = true;
    setFilter("all");
    setQuery("");
    setAssignee("all");
    setHistory(null);
    setTarget("");
    setDetails(false);
    setCardEditor(null);
    setMetadata({});
    void props.connection?.call("history").then((value) => {
      if (live) setHistory(value);
    }).catch(() => {
    });
    return () => {
      live = false;
    };
  }, [props.documentKey]);
  useEffect(() => {
    const item = state?.[props.collection].find((item2) => item2.id === props.editing);
    setMetadata(item ? { tags: item.tags ?? [], mentions: item.mentions ?? [], card: item.card ?? "", status: item.status ?? "open", attachments: item.attachments ?? [], revision: item.revision, reference_name: item.reference_name ?? "" } : {});
  }, [props.editing, props.draftReset]);
  useEffect(() => {
    const available = (state?.cards ?? []).filter((card) => !card.deleted);
    if (addingCard.current) {
      const added = available.find((card) => !addingCard.current.includes(card.id));
      if (added) {
        setTarget(added.id);
        addingCard.current = null;
      }
    } else if (!available.length && target !== "reminders") setTarget("");
    else if ((!target || !available.some((card) => card.id === target)) && target !== "reminders" && available.length && !state?.tasks.some((item) => !item.deleted && !item.card)) setTarget(available[0].id);
  }, [state?.cards]);
  const canEdit = (item) => !!state && (state.can_manage || state.actor === state.owner || state.actor === item.author);
  const person = (id) => state?.members.find((member) => member.id === id);
  const tasks = state?.tasks.filter((item) => !item.deleted) ?? [], reminders = state?.reminders.filter((item) => !item.deleted) ?? [];
  const tags = [...new Set([...tasks, ...reminders, ...state?.comments ?? []].flatMap((item) => item.tags ?? []))].sort();
  const cards = [...!(state?.cards ?? []).some((card) => !card.deleted) || tasks.some((item) => !item.card) ? [{ id: "", text: "Tasks" }] : [], ...(state?.cards ?? []).filter((item) => !item.deleted), ...reminders.length ? [{ id: "reminders", text: "Reminders" }] : []];
  const rows = [...tasks, ...reminders].filter((item) => (filter === "all" || item.status === filter) && (!tag || item.tags?.includes(tag)) && (assignee === "all" || item.assignee === assignee) && `${item.text} ${item.reference_name ?? ""}`.toLowerCase().includes(query.toLowerCase())).sort((a, b) => sort === "due" ? (a.due || "9999").localeCompare(b.due || "9999") : statuses.findIndex((s) => s.value === a.status) - statuses.findIndex((s) => s.value === b.status));
  const collection = (item) => reminders.some((reminder) => reminder.id === item.id) ? "reminders" : "tasks";
  const belongs = (item, id) => id === "reminders" ? collection(item) === "reminders" : collection(item) === "tasks" && (item.card ?? "") === id;
  const views = cards.map((card) => {
    const members = [...tasks, ...reminders].filter((item) => belongs(item, card.id)), done = members.filter((item) => item.status === "done").length, progress = members.filter((item) => item.status === "in_progress").length;
    return { ...card, members, done, progress, complete: members.length > 0 && done === members.length, items: rows.filter((item) => belongs(item, card.id)) };
  });
  const options = cards.filter((card) => card.id !== "reminders").map((card) => ({ value: card.id, label: card.text }));
  const visible = views.filter((card) => (!card.complete || completed || filter === "done") && (card.items.length || !card.members.length && !query && !tag && filter === "all" && assignee === "all"));
  const versions = [...history?.branches.map((branch) => ({ id: branch.head_revision, label: `${branch.name} \xB7 current saved state` })) ?? [], ...history?.versions.map((version) => ({ id: version.revision, label: version.name })) ?? []];
  async function saveCard() {
    if (!cardEditor?.text.trim() || !props.onCard) return;
    if (!cardEditor.id) addingCard.current = (state?.cards ?? []).map((card) => card.id);
    if (await props.onCard(cardEditor.id ? "update" : "add", { text: cardEditor.text }, cardEditor.id)) setCardEditor(null);
  }
  function edit(item) {
    props.onEdit(item, collection(item));
    setDetails(true);
  }
  function row(item) {
    const statusAllowed = canEdit(item) || state?.actor === item.assignee;
    return /* @__PURE__ */ jsxs("div", { className: "ps-review-task-row", "data-task-id": item.id, "data-status": item.status, children: [
      /* @__PURE__ */ jsx("input", { type: "checkbox", "aria-label": `Complete ${item.text}`, checked: item.status === "done", disabled: busy || !statusAllowed, onChange: () => props.onStatus(item, collection(item), item.status === "done" ? "open" : "done") }),
      /* @__PURE__ */ jsx("button", { className: "ps-review-task-title", type: "button", title: item.text, "aria-label": `Edit task: ${item.text}`, onClick: () => edit(item), children: /* @__PURE__ */ jsxs("strong", { children: [
        item.source === "ai" ? "AI \xB7 " : "",
        item.text
      ] }) }),
      /* @__PURE__ */ jsx("span", { className: "ps-review-task-person", title: person(item.assignee)?.name ?? "Unassigned", children: /* @__PURE__ */ jsx("span", { className: "ps-review-avatar", children: /* @__PURE__ */ jsx(Avatar, { name: person(item.assignee)?.name ?? "Unassigned", src: person(item.assignee)?.avatar, size: "small" }) }) }),
      /* @__PURE__ */ jsx("time", { className: "ps-review-task-due", dateTime: item.due, title: item.due ? `Due ${item.due}` : "No due date", children: item.due ? (/* @__PURE__ */ new Date(`${item.due}T12:00:00`)).toLocaleDateString(void 0, { month: "short", day: "numeric" }) : "No date" }),
      /* @__PURE__ */ jsx(MenuButton, { className: "ps-review-task-status", label: `Status for ${item.text}`, disabled: busy || !statusAllowed, items: statuses.map((status) => ({ id: status.value, label: status.label, kind: "radio", checked: status.value === item.status })), onSelect: (status) => props.onStatus(item, collection(item), status), children: /* @__PURE__ */ jsx("span", { children: statuses.find((status) => status.value === item.status)?.label }) }),
      /* @__PURE__ */ jsx(MenuButton, { className: "ps-review-more", label: `Actions for ${item.text}`, disabled: busy, items: [{ id: "edit", label: canEdit(item) ? "Edit task" : "View task" }, ...canEdit(item) ? [{ id: "remove", label: "Remove task", danger: true }] : []], onSelect: (action) => action === "edit" ? edit(item) : props.onRemove(item, collection(item)), children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
    ] }, item.id);
  }
  const edited = state?.[props.collection].find((item) => item.id === props.editing), editable = !edited || canEdit(edited);
  return /* @__PURE__ */ jsxs("section", { className: "aui-studio-review-view", "aria-label": "Tasks", children: [
    /* @__PURE__ */ jsx(
      ReviewFilterBar,
      {
        subject: "tasks",
        query,
        onQueryChange: setQuery,
        groups: [
          { id: "status", label: "Status", value: filter, defaultValue: "all", onChange: setFilter, options: [{ value: "all", label: "All" }, ...statuses] },
          { id: "tag", label: "Tags", value: tag, defaultValue: "", onChange: setTag, options: [{ value: "", label: "All tags" }, ...tags.map((value) => ({ value, label: value }))] },
          { id: "assignee", label: "Assignee", value: assignee, defaultValue: "all", onChange: setAssignee, options: [{ value: "all", label: "Everyone" }, { value: "", label: "Unassigned" }, ...state?.members.map((member) => ({ value: member.id, label: member.name })) ?? []] },
          { id: "sort", label: "Sort", value: sort, defaultValue: "status", onChange: setSort, options: [{ value: "status", label: "By status" }, { value: "due", label: "By due date" }] }
        ],
        actions: [{ id: "completed", label: "Show completed cards", kind: "checkbox", checked: completed, separatorBefore: true }],
        onAction: () => setCompleted(!completed),
        onReset: () => {
          setFilter("all");
          setTag("");
          setAssignee("all");
          setSort("status");
          setCompleted(false);
        }
      }
    ),
    /* @__PURE__ */ jsx(PanelNotice, { message: props.error, children: props.conflict }),
    /* @__PURE__ */ jsxs("div", { className: "ps-review-stream", "aria-label": "Design tasks", children: [
      !state ? /* @__PURE__ */ jsx("p", { role: "status", children: "Loading tasks\u2026" }) : visible.map((card) => /* @__PURE__ */ jsxs("section", { className: "ps-review-task-card", "aria-label": `${card.text} tasks`, "data-current": target === card.id, "data-completed": card.complete, children: [
        /* @__PURE__ */ jsxs("header", { children: [
          /* @__PURE__ */ jsx("span", { className: "ps-review-progress", style: { "--review-done": `${card.members.length ? card.done / card.members.length * 100 : 0}%`, "--review-progress": `${card.members.length ? (card.done + card.progress) / card.members.length * 100 : 0}%` } }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("button", { className: "ps-review-card-title", type: "button", onClick: () => setTarget(card.id), children: card.text }),
            /* @__PURE__ */ jsx("small", { children: card.complete ? "Completed" : `${card.members.length - card.done - card.progress} Open \xB7 ${card.progress} In progress` })
          ] }),
          /* @__PURE__ */ jsx(MenuButton, { className: "ps-review-more", label: `Card actions: ${card.text}`, disabled: busy, items: [{ id: "add", label: "Add task to card" }, ..."author" in card && canEdit(card) ? [{ id: "rename", label: "Rename card" }, { id: "remove", label: "Remove empty card", disabled: !!card.members.length, danger: true }] : []], onSelect: (action) => {
            if (action === "rename") setCardEditor({ id: card.id, text: card.text });
            else if (action === "remove") void props.onCard?.("delete", {}, card.id);
            else {
              setTarget(card.id);
              props.onCollection(card.id === "reminders" ? "reminders" : "tasks");
            }
          }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
        ] }),
        card.items.filter((item) => item.status !== "done").map(row),
        card.items.some((item) => item.status === "done") && /* @__PURE__ */ jsxs("details", { className: "ps-review-completed-tasks", open: card.complete || filter === "done" || void 0, children: [
          /* @__PURE__ */ jsxs("summary", { children: [
            "Completed ",
            /* @__PURE__ */ jsx("span", { children: card.items.filter((item) => item.status === "done").length })
          ] }),
          card.items.filter((item) => item.status === "done").map(row)
        ] }),
        !card.members.length && /* @__PURE__ */ jsx("p", { className: "ps-review-empty", children: "Add the first task below." })
      ] }, card.id)),
      state && !visible.length && /* @__PURE__ */ jsx("p", { className: "ps-review-empty", children: "No tasks in this view." })
    ] }),
    /* @__PURE__ */ jsxs("small", { className: "ps-review-task-count", children: [
      views.filter((card) => !card.complete).length,
      " active cards \xB7 ",
      views.filter((card) => card.complete).length,
      " completed"
    ] }),
    /* @__PURE__ */ jsx(
      ReviewComposer,
      {
        task: true,
        value: props.editing ? "" : props.text,
        onChange: props.onText,
        busy: busy || !state || !!props.editing || props.conflicted,
        selectedName: props.connection?.name,
        referenceLabel: "Reference document",
        members: state?.members,
        versions,
        initialTags: tag ? [tag] : [],
        resetKey: `${props.documentKey}:${props.draftReset}`,
        onCapture: commentScreenshot,
        onCancelReply: props.onCancel,
        context: /* @__PURE__ */ jsxs(Fragment, { children: [
          tag && /* @__PURE__ */ jsxs("button", { className: "ps-review-context-chip", type: "button", "aria-label": `Clear tag filter: ${tag}`, onClick: () => setTag(""), children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "tag" }),
            tag,
            /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "ps-review-card-target", children: [
            /* @__PURE__ */ jsx("label", { children: "Add to" }),
            /* @__PURE__ */ jsx(SelectField, { "aria-label": "Add task to card", value: target, options, onChange: (e) => {
              setTarget(e.target.value);
              props.onCollection("tasks");
            } }),
            /* @__PURE__ */ jsx(IconButton, { label: "New task card", size: "small", disabled: busy || !state, onClick: () => setCardEditor({ text: "" }), children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }),
            /* @__PURE__ */ jsx(IconButton, { label: "Task details", size: "small", disabled: busy || !state, onClick: () => setDetails(true), children: /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }) })
          ] })
        ] }),
        onSubmit: (attachments, reference, revision, meta) => props.onSubmit({ ...metadata, ...meta, tags: meta.tags.length ? meta.tags : tag ? [tag] : [], attachments, revision: revision ?? null, reference_name: reference ? props.connection?.name ?? "" : "", card: target === "reminders" ? "" : target })
      }
    ),
    /* @__PURE__ */ jsxs(Dialog, { open: !!cardEditor, title: cardEditor?.id ? "Rename task card" : "New task card", onClose: () => {
      if (!busy) setCardEditor(null);
    }, actions: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: () => setCardEditor(null), children: "Cancel" }),
      /* @__PURE__ */ jsx(Button, { primary: true, disabled: busy || !cardEditor?.text.trim(), onClick: () => void saveCard(), children: cardEditor?.id ? "Save name" : "Create card" })
    ] }), children: [
      /* @__PURE__ */ jsx(TextField, { "aria-label": "Task card name", autoFocus: true, maxLength: 160, value: cardEditor?.text ?? "", onChange: (e) => setCardEditor((current) => current ? { ...current, text: e.target.value } : current) }),
      props.error && /* @__PURE__ */ jsx("p", { role: "alert", children: props.error })
    ] }),
    /* @__PURE__ */ jsxs(Dialog, { open: details, title: props.editing ? "Task details" : "New task details", onClose: () => {
      if (!busy) {
        setDetails(false);
        props.onCancel();
      }
    }, actions: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: () => {
        setDetails(false);
        props.onCancel();
      }, children: "Cancel" }),
      editable && /* @__PURE__ */ jsx(Button, { primary: true, disabled: busy || !props.text.trim() || props.conflicted || !state, onClick: () => void (props.editing ? props.onSubmit(metadata) : Promise.resolve(true)).then((ok) => {
        if (ok) setDetails(false);
      }), children: props.editing ? "Save changes" : "Done" })
    ] }), children: [
      props.error && /* @__PURE__ */ jsx("p", { role: "alert", children: props.error }),
      props.conflict,
      /* @__PURE__ */ jsxs("fieldset", { className: "aui-studio-task-editor", disabled: busy || !editable, children: [
        /* @__PURE__ */ jsxs("label", { children: [
          "Task",
          /* @__PURE__ */ jsx(TextField, { "aria-label": "Task text", value: props.text, maxLength: 1e3, onChange: (e) => props.onText(e.target.value) })
        ] }),
        props.editing && /* @__PURE__ */ jsxs("label", { children: [
          "Tags",
          /* @__PURE__ */ jsx(TextField, { "aria-label": "Review item tags", defaultValue: metadata.tags?.join(", ") ?? "", onChange: (e) => setMetadata((value) => ({ ...value, tags: parseReviewTags(e.target.value) })) }, `${props.editing}:${props.draftReset}`)
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Card",
          /* @__PURE__ */ jsx(SelectField, { "aria-label": "Task card", value: props.editing ? metadata.card ?? "" : target, options, onChange: (e) => {
            if (props.editing) setMetadata((value) => ({ ...value, card: e.target.value }));
            else {
              setTarget(e.target.value);
              props.onCollection("tasks");
            }
          } })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Status",
          /* @__PURE__ */ jsx(SelectField, { "aria-label": "Task status", value: metadata.status ?? "open", options: statuses, onChange: (e) => setMetadata((value) => ({ ...value, status: e.target.value })) })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Due date",
          /* @__PURE__ */ jsx(TextField, { "aria-label": "Task due date", type: "date", value: props.due, onChange: (e) => props.onDue(e.target.value) })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Assignee",
          /* @__PURE__ */ jsx(SelectField, { "aria-label": "Task assignee", value: props.assignee, options: [{ value: "", label: "Unassigned" }, ...state?.members.map((member) => ({ value: member.id, label: member.name })) ?? []], onChange: (e) => props.onAssignee(e.target.value) })
        ] }),
        metadata.reference_name && /* @__PURE__ */ jsx("small", { children: metadata.reference_name }),
        metadata.attachments?.map((image) => /* @__PURE__ */ jsx("a", { className: "ps-review-image", href: image.data_url, download: image.name, children: /* @__PURE__ */ jsx("img", { src: image.data_url, alt: image.name }) }, image.name))
      ] })
    ] })
  ] });
}
export {
  StudioTasksView
};
