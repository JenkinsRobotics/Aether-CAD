import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Avatar } from "./Avatar.js";
import { Button } from "./Button.js";
import { IconButton } from "./IconButton.js";
import { Popover } from "./Popover.js";
import "./StudioAppFrame.css";
function StudioAccountControl({ name = "Local user", detail = "Local workspace", onViewAccount, onSettings, onSignOut }) {
  const [anchor, setAnchor] = useState(null);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(IconButton, { label: `Account: ${name}`, appearance: "glyph", className: "aui-studio-account-trigger", "aria-haspopup": "dialog", "aria-expanded": !!anchor, onClick: (event) => setAnchor(anchor ? null : event.currentTarget), children: /* @__PURE__ */ jsx(Avatar, { name, size: "small" }) }),
    /* @__PURE__ */ jsxs(Popover, { open: !!anchor, anchor, onClose: () => setAnchor(null), ariaLabel: `${name} account`, placement: "bottom-end", focus: "first", className: "aui-studio-account-card", children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-studio-account-card-top", children: [
        /* @__PURE__ */ jsx("strong", { children: "Aether Studio" }),
        /* @__PURE__ */ jsx(Button, { appearance: "flat", disabled: !onSignOut, onClick: onSignOut, title: !onSignOut ? "No connected account in this local workspace." : void 0, children: "Sign out" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-studio-account-identity", children: [
        /* @__PURE__ */ jsx(Avatar, { name }),
        /* @__PURE__ */ jsx("strong", { children: name }),
        /* @__PURE__ */ jsx("small", { children: detail }),
        /* @__PURE__ */ jsx(Button, { appearance: "flat", disabled: !onViewAccount, onClick: () => {
          setAnchor(null);
          onViewAccount?.();
        }, children: "View account" }),
        onSettings && /* @__PURE__ */ jsx(Button, { appearance: "flat", onClick: () => {
          setAnchor(null);
          onSettings();
        }, children: "Settings" })
      ] })
    ] })
  ] });
}
export {
  StudioAccountControl
};
