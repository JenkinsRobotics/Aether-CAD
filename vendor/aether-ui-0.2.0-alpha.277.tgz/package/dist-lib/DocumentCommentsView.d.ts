import { type ReactNode } from "react";
import type { CollaborationItem, DocumentCollaboration, DocumentConnection } from "./DocumentServices.js";
import "./DocumentCommentsView.css";
export interface CommentsViewProps {
    reviewTag?: string;
    onReviewTag?: (tag: string) => void;
    connection: DocumentConnection;
    state: DocumentCollaboration | null;
    draftReset: number;
    text: string;
    editing: string | null;
    reply: string | null;
    busy: boolean;
    error: string;
    conflicted: boolean;
    conflict: ReactNode;
    following: boolean;
    onFollowing: (value: boolean) => void;
    onText: (text: string) => void;
    onCancel: () => void;
    onSubmit: (metadata: Record<string, unknown>) => Promise<boolean>;
    onEdit: (item: CollaborationItem) => void;
    onReply: (item: CollaborationItem) => void;
    onRemove: (item: CollaborationItem) => void;
    onResolve: (item: CollaborationItem) => void;
}
/** The shared comment surface; mutation/conflict handling stays in its controller. */
export declare function DocumentCommentsView(props: CommentsViewProps): import("react").JSX.Element;
