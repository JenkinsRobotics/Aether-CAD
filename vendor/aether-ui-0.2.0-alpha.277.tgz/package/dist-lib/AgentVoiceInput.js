import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
function AgentVoiceInput({ onText, onError, disabled }) {
  const active = useRef(null), callbacks = useRef({ onText, onError });
  callbacks.current = { onText, onError };
  const [listening, setListening] = useState(false);
  const Constructor = typeof window === "undefined" ? void 0 : window.SpeechRecognition ?? window.webkitSpeechRecognition;
  useEffect(() => () => {
    const previous = active.current;
    active.current = null;
    previous?.abort();
  }, []);
  useEffect(() => {
    if (disabled) {
      active.current?.abort();
      active.current = null;
      setListening(false);
    }
  }, [disabled]);
  function toggle() {
    if (active.current) {
      active.current.stop();
      return;
    }
    if (!Constructor) return;
    const recognition = new Constructor();
    active.current = recognition;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = navigator.language;
    recognition.onresult = (event) => {
      if (active.current === recognition) callbacks.current.onText(Array.from(event.results).map((result) => result[0]?.transcript ?? "").join(" ").trim());
    };
    recognition.onerror = (event) => {
      if (active.current === recognition && event.error !== "aborted") callbacks.current.onError(event.error === "not-allowed" ? "Microphone permission was denied. Enable it in your browser to use voice typing." : `Voice typing stopped: ${event.error}.`);
    };
    recognition.onend = () => {
      if (active.current === recognition) {
        active.current = null;
        setListening(false);
      }
    };
    try {
      recognition.start();
      setListening(true);
    } catch {
      active.current = null;
      setListening(false);
      callbacks.current.onError("Voice typing could not start. Check browser microphone access.");
    }
  }
  return /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-agent-composer-pill aui-agent-composer-voice", "aria-label": listening ? "Stop voice typing" : "Voice typing", "aria-pressed": listening, disabled: disabled || !Constructor, title: !Constructor ? "Voice typing is unavailable in this browser" : "Dictate your prompt", onClick: toggle, children: [
    /* @__PURE__ */ jsx(AetherIcon, { name: listening ? "stop" : "waveform" }),
    /* @__PURE__ */ jsx("span", { children: listening ? "Stop" : "Voice" })
  ] });
}
export {
  AgentVoiceInput
};
