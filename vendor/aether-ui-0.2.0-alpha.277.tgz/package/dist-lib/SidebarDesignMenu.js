import { jsx } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
import { setWorkspaceChrome, useWorkspaceChrome } from "./WorkspaceChromePreferences.js";
const sidebarDesignOptions = [
  { id: "rail", label: "Side rail" },
  { id: "tabs-top", label: "Top tabs" },
  { id: "tabs-bottom", label: "Bottom tabs" }
];
function SidebarDesignMenu({ value: appValue, onChange }) {
  const chrome = useWorkspaceChrome();
  const value = chrome.sidebarDesign === "app" ? appValue : chrome.sidebarDesign;
  return /* @__PURE__ */ jsx(
    MenuButton,
    {
      label: `Sidebar design: ${sidebarDesignOptions.find((option) => option.id === value)?.label}`,
      className: "aui-icon-button",
      placement: "bottom-end",
      items: sidebarDesignOptions.map((option) => ({ ...option, kind: "radio", checked: option.id === value })),
      onSelect: (id) => {
        if (chrome.sidebarDesign !== "app") setWorkspaceChrome({ sidebarDesign: id });
        onChange(id);
      },
      children: /* @__PURE__ */ jsx(AetherIcon, { name: "layout" })
    }
  );
}
export {
  SidebarDesignMenu,
  sidebarDesignOptions
};
