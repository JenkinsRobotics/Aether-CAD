import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef } from "react";
import "./ApplicationFileTable.css";
import { selectListItems } from "./list-selection.js";
function ApplicationFileTable({
  rows,
  selectedIds,
  onSelect,
  onOpen,
  onContextMenu,
  renderActions,
  onToggle,
  onSelectAll,
  dateLabel = "Opened",
  label = "Files",
  columns,
  compact = false,
  sort,
  onSort,
  onSelectedIdsChange
}) {
  const selectionAnchor = useRef(null);
  const toggle = onToggle ?? (onSelectedIdsChange ? (row, checked) => {
    const next = new Set(selectedIds);
    if (checked) next.add(row.id);
    else next.delete(row.id);
    selectionAnchor.current = row.id;
    onSelectedIdsChange(next);
  } : void 0);
  const selectAll = onSelectAll ?? (onSelectedIdsChange ? (checked) => onSelectedIdsChange(new Set(checked ? rows.map((row) => row.id) : [])) : void 0);
  const all = rows.length > 0 && rows.every((row) => selectedIds.has(row.id));
  const some = rows.some((row) => selectedIds.has(row.id));
  const checkbox = useRef(null);
  useEffect(() => {
    if (checkbox.current) checkbox.current.indeterminate = some && !all;
  }, [all, some]);
  const metadata = columns ?? [
    { id: "date", label: dateLabel, render: (row) => row.date },
    { id: "owner", label: "Owner", render: (row) => row.owner, secondary: true }
  ];
  const direction = (id) => sort?.id === id ? sort.ascending ? "ascending" : "descending" : void 0;
  const heading = (id, title, sortable = true) => onSort && sortable ? /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-application-file-sort", onClick: () => onSort(id), children: [
    title,
    /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: sort?.id === id ? sort.ascending ? " \u2191" : " \u2193" : " \u2304" })
  ] }) : title;
  return /* @__PURE__ */ jsxs("table", { className: "aui-application-file-table", "data-compact": compact || void 0, "data-has-selection": some || void 0, "aria-label": label, children: [
    /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
      /* @__PURE__ */ jsx("th", { scope: "col", "aria-label": "Name", "aria-sort": direction("name"), children: /* @__PURE__ */ jsxs("span", { className: "aui-application-file-table-heading", children: [
        selectAll && /* @__PURE__ */ jsx("input", { ref: checkbox, type: "checkbox", "aria-label": "Select all files", checked: all, onChange: (event) => selectAll(event.target.checked) }),
        heading("name", "Name")
      ] }) }),
      metadata.map((col) => /* @__PURE__ */ jsx("th", { scope: "col", "aria-sort": direction(col.id), "data-secondary": col.secondary || void 0, children: heading(col.id, col.label, col.sortable ?? false) }, col.id))
    ] }) }),
    /* @__PURE__ */ jsx("tbody", { children: rows.map((row) => /* @__PURE__ */ jsxs(
      "tr",
      {
        "data-selected": selectedIds.has(row.id) || void 0,
        onMouseDown: (event) => {
          if (onSelectedIdsChange && (event.shiftKey || event.metaKey || event.ctrlKey)) event.preventDefault();
        },
        onClick: (event) => {
          if (event.detail < 2) {
            onSelect(row, event);
            if (onSelectedIdsChange) {
              onSelectedIdsChange(selectListItems(rows.map((item) => item.id), selectedIds, selectionAnchor.current, row.id, event.shiftKey, event.metaKey || event.ctrlKey));
              if (!event.shiftKey) selectionAnchor.current = row.id;
            }
          }
        },
        onDoubleClick: () => onOpen(row),
        onContextMenu: onContextMenu ? (event) => onContextMenu(row, event) : void 0,
        children: [
          /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsxs("div", { className: "aui-application-file-cell", children: [
            toggle && /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                "aria-label": `Select ${row.name}`,
                checked: selectedIds.has(row.id),
                onClick: (event) => event.stopPropagation(),
                onDoubleClick: (event) => event.stopPropagation(),
                onChange: (event) => toggle(row, event.target.checked)
              }
            ),
            /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-application-file-name", onKeyDown: (event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                onOpen(row);
              }
            }, children: [
              row.icon,
              /* @__PURE__ */ jsxs("span", { children: [
                /* @__PURE__ */ jsx("strong", { children: row.name }),
                row.location && /* @__PURE__ */ jsx("small", { children: row.location })
              ] })
            ] }),
            renderActions && /* @__PURE__ */ jsx("div", { className: "aui-application-file-actions", onClick: (event) => event.stopPropagation(), onDoubleClick: (event) => event.stopPropagation(), children: renderActions(row) })
          ] }) }),
          metadata.map((col) => /* @__PURE__ */ jsx("td", { "data-secondary": col.secondary || void 0, children: col.render(row) }, col.id))
        ]
      },
      row.id
    )) })
  ] });
}
export {
  ApplicationFileTable
};
