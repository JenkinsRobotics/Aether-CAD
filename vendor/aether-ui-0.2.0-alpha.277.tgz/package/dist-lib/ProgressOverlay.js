import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef } from "react";
const FOCUSABLE = 'button:not(:disabled), [href], [tabindex]:not([tabindex="-1"])';
function ProgressOverlay({
  open,
  label,
  detail,
  phase,
  value,
  max = 100,
  onCancel,
  onBackground,
  inline
}) {
  const cardRef = useRef(null);
  useEffect(() => {
    if (!open || inline) return;
    const opener = document.activeElement;
    const card = cardRef.current;
    card?.querySelector(FOCUSABLE)?.focus();
    const onKeyDown = (event) => {
      if (event.key === "Escape" && onCancel) {
        event.preventDefault();
        event.stopPropagation();
        onCancel();
        return;
      }
      if (event.key !== "Tab" || !card) return;
      const focusables = Array.from(card.querySelectorAll(FOCUSABLE));
      if (focusables.length === 0) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      const current = document.activeElement;
      if (event.shiftKey && (current === first || !card.contains(current))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (current === last || !card.contains(current))) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown, true);
    return () => {
      document.removeEventListener("keydown", onKeyDown, true);
      opener?.focus?.();
    };
  }, [inline, onCancel, open]);
  if (!open) return null;
  const determinate = value !== void 0;
  return /* @__PURE__ */ jsx("div", { className: `aui-progress-surface${inline ? " aui-progress-surface--inline" : ""}`, children: /* @__PURE__ */ jsxs(
    "section",
    {
      ref: cardRef,
      className: "aui-progress-card",
      role: inline ? void 0 : "dialog",
      "aria-modal": inline ? void 0 : "true",
      "aria-label": !inline && typeof label === "string" ? label : void 0,
      "aria-live": "polite",
      children: [
        /* @__PURE__ */ jsxs("div", { className: "aui-progress-heading", children: [
          /* @__PURE__ */ jsx("strong", { children: label }),
          phase ? /* @__PURE__ */ jsx("span", { children: phase }) : null
        ] }),
        detail ? /* @__PURE__ */ jsx("p", { children: detail }) : null,
        /* @__PURE__ */ jsx(
          "div",
          {
            className: `aui-progress-track${determinate ? "" : " aui-progress-track--indeterminate"}`,
            role: "progressbar",
            "aria-label": typeof label === "string" ? label : void 0,
            "aria-valuemin": determinate ? 0 : void 0,
            "aria-valuemax": determinate ? max : void 0,
            "aria-valuenow": determinate ? value : void 0,
            children: /* @__PURE__ */ jsx("span", { style: determinate ? { width: `${Math.min(100, Math.max(0, value / max * 100))}%` } : void 0 })
          }
        ),
        onCancel || onBackground ? /* @__PURE__ */ jsxs("div", { className: "aui-state-actions", children: [
          onBackground ? /* @__PURE__ */ jsx("button", { type: "button", onClick: onBackground, children: "Run in background" }) : null,
          onCancel ? /* @__PURE__ */ jsx("button", { type: "button", onClick: onCancel, children: "Cancel" }) : null
        ] }) : null
      ]
    }
  ) });
}
export {
  ProgressOverlay
};
