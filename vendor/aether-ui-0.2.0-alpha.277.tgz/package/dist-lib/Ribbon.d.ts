import type { ComponentPropsWithoutRef, ReactNode } from "react";
/** The horizontal tool ribbon strip (groups with captions).
 *  ←/→ move focus across enabled tools, spanning group boundaries. */
export declare function Ribbon({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function RibbonGroup({ label, children }: {
    label: string;
    children: ReactNode;
}): import("react").JSX.Element;
export interface RibbonToolProps extends Omit<ComponentPropsWithoutRef<"button">, "onClick"> {
    icon: ReactNode;
    label: string;
    active?: boolean;
    disabled?: boolean;
    onClick?: () => void;
}
/** Icon-over-label ribbon tool button. */
export declare function RibbonTool({ icon, label, active, disabled, onClick, ...buttonProps }: RibbonToolProps): import("react").JSX.Element;
