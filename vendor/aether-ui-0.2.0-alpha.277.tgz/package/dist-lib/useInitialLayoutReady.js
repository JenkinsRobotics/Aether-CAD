import { useLayoutEffect, useState } from "react";
function useInitialLayoutReady() {
  const [ready, setReady] = useState(false);
  useLayoutEffect(() => {
    if (typeof requestAnimationFrame === "undefined") {
      setReady(true);
      return;
    }
    let next = 0;
    const first = requestAnimationFrame(() => {
      next = requestAnimationFrame(() => setReady(true));
    });
    return () => {
      cancelAnimationFrame(first);
      cancelAnimationFrame(next);
    };
  }, []);
  return ready;
}
export {
  useInitialLayoutReady
};
