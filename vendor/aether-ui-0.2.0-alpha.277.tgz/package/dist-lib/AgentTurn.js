import { agentToolReply } from "./AgentToolResult.js";
const POLL_MS = 400;
const REQUEST_MS = 15e3;
const ACTION_MS = 12e4;
const MAX_RECEIPT_FAILURES = 3;
const message = (error) => error instanceof Error ? error.message.slice(0, 1e3) : "The agent could not complete this action.";
class RequestTimeout extends Error {
}
class AgentTurn {
  constructor(options) {
    this.options = options;
  }
  controller = new AbortController();
  actions = /* @__PURE__ */ new Map();
  pollTimer;
  started = false;
  imagesUsed = 0;
  start() {
    if (this.started || this.controller.signal.aborted) return;
    this.started = true;
    this.schedule();
  }
  /** Synchronous local cancellation. The caller owns best-effort host cancel. */
  stop() {
    if (this.controller.signal.aborted) return;
    this.controller.abort();
    clearTimeout(this.pollTimer);
    for (const action of this.actions.values()) {
      clearTimeout(action.timer);
      if (action.state === "Working") action.state = "Cancelled";
      else if (action.state === "Returning result" || action.state === "Retrying result") action.state = "Result unconfirmed";
    }
    this.publish();
  }
  current() {
    return !this.controller.signal.aborted && this.options.isCurrent();
  }
  publish() {
    this.options.onActions([...this.actions.values()].map((action) => ({
      id: action.call.id,
      name: action.call.name,
      state: action.state,
      image: action.state === "Done" && action.reply?.ok ? action.reply.images?.[0] : void 0
    })));
  }
  end(error) {
    if (this.controller.signal.aborted) return;
    this.stop();
    this.options.onEnd(error);
  }
  schedule() {
    if (!this.controller.signal.aborted) this.pollTimer = setTimeout(() => void this.poll(), POLL_MS);
  }
  /** Bound waiting even when an older transport cannot abort its network call.
   * Both late success and rejection are observed and cannot restart this turn.
   */
  request(action, data) {
    return new Promise((resolve, reject) => {
      const signal = this.controller.signal;
      const finish = (error, value) => {
        clearTimeout(timer);
        signal.removeEventListener("abort", abort);
        if (error) reject(error);
        else resolve(value);
      };
      const abort = () => finish(new Error("Agent stopped."));
      const timer = setTimeout(() => finish(new RequestTimeout("Studio did not respond within 15 seconds. The agent stopped; check the document before trying again.")), REQUEST_MS);
      if (signal.aborted) {
        abort();
        return;
      }
      signal.addEventListener("abort", abort, { once: true });
      Promise.resolve().then(() => this.options.service.call(action, data)).then((value) => finish(null, value), (error) => finish(error));
    });
  }
  async poll() {
    if (this.controller.signal.aborted) return;
    if (!this.options.isCurrent()) {
      this.end("The active workspace changed. The agent stopped.");
      return;
    }
    try {
      const job = await this.request("job", { id: this.options.id });
      if (!this.current()) {
        if (!this.controller.signal.aborted) this.end("The active workspace changed. The agent stopped.");
        return;
      }
      if (job.id !== this.options.id) throw new Error("Studio returned a different agent job. The agent stopped.");
      this.options.onJob(job);
      if (job.state !== "running") {
        this.end(job.error || void 0);
        return;
      }
      const call = job.tool_call;
      const working = [...this.actions.values()].find((action) => !action.reply);
      if (working && call?.id !== working.call.id) throw new Error("The agent replaced an unfinished action. The agent stopped.");
      if (call) {
        const fingerprint = JSON.stringify([call.name, call.arguments]);
        let action = this.actions.get(call.id);
        if (action && action.fingerprint !== fingerprint) throw new Error("An agent action changed while retrying. The agent stopped without repeating it.");
        this.acknowledgeOther(call.id);
        if (!action) {
          if (this.actions.size >= 48) throw new Error("The agent reached its 48-action limit.");
          action = { call, fingerprint, state: "Working", failures: 0 };
          this.actions.set(call.id, action);
          this.execute(action, job.tool_result_format === "images-v1");
        }
        if (action.reply) await this.deliver(action);
      } else this.acknowledgeOther();
    } catch (error) {
      if (!this.controller.signal.aborted) this.end(message(error));
    }
    this.schedule();
  }
  acknowledgeOther(currentId) {
    for (const action of this.actions.values()) {
      if (action.call.id !== currentId && action.reply && (action.state === "Returning result" || action.state === "Retrying result")) this.acknowledge(action);
    }
  }
  acknowledge(action) {
    action.state = action.reply?.ok ? "Done" : "Failed: " + (action.reply?.error || "The editor could not complete this action.");
    this.publish();
  }
  execute(action, imagesSupported) {
    this.publish();
    action.timer = setTimeout(() => this.end("An editor action exceeded 2 minutes. The agent stopped; check the document before trying again."), ACTION_MS);
    void (async () => {
      try {
        const interaction = this.options.interaction;
        if (!this.current()) return;
        if (!interaction || !interaction.tools.some((tool) => tool.name === action.call.name)) throw new Error("This editor tool is not available.");
        const value = await interaction.execute(action.call, this.controller.signal);
        if (!this.current()) return;
        action.reply = agentToolReply(value, imagesSupported, this.imagesUsed);
        if (action.reply.ok && action.reply.images) this.imagesUsed += action.reply.images.length;
      } catch (error) {
        if (!this.current()) return;
        action.reply = { ok: false, error: message(error) };
      } finally {
        clearTimeout(action.timer);
      }
      if (!this.current()) return;
      action.state = "Returning result";
      this.publish();
    })();
  }
  async deliver(action) {
    try {
      await this.request("tool_result", { id: this.options.id, call_id: action.call.id, result: action.reply });
      if (this.current()) this.acknowledge(action);
    } catch (error) {
      if (!this.current()) return;
      action.state = "Retrying result";
      action.failures++;
      this.publish();
      if (action.failures >= MAX_RECEIPT_FAILURES) throw new Error("Studio could not confirm the action result after 3 attempts. The agent stopped; check the document before trying again.");
      if (error instanceof RequestTimeout) throw error;
    }
  }
}
export {
  AgentTurn
};
