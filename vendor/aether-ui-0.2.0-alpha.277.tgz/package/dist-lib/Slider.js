import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import "./Slider.css";
function Slider({ value, defaultValue, onChange, min = 0, max = 100, step = 1, unit = "", ariaLabel, showValue = true, disabled = false, className, range }) {
  const [internal, setInternal] = useState(defaultValue ?? min);
  const current = value ?? internal;
  const update = (next) => {
    if (value === void 0) setInternal(next);
    onChange?.(next);
  };
  const percent = max === min ? 0 : Math.max(0, Math.min(100, (current - min) / (max - min) * 100));
  return /* @__PURE__ */ jsxs("div", { className: ["aui-slider aui-slider-control", className].filter(Boolean).join(" "), style: { "--aui-slider-fill": `${percent}%` }, children: [
    /* @__PURE__ */ jsxs("span", { className: "aui-slider-track", children: [
      /* @__PURE__ */ jsx("input", { type: "range", "aria-label": ariaLabel, "aria-valuetext": `${current}${unit}`, value: current, min, max, step, disabled, onChange: (event) => update(Number(event.target.value)) }),
      range && [range.min, range.max].map((limit, index) => /* @__PURE__ */ jsx(
        "span",
        {
          "aria-hidden": true,
          className: "aui-slider-range-mark",
          style: { left: `${max === min ? 0 : Math.max(0, Math.min(100, (limit - min) / (max - min) * 100))}%` }
        },
        index
      ))
    ] }),
    showValue ? /* @__PURE__ */ jsxs("output", { children: [
      current.toLocaleString(),
      unit
    ] }) : null
  ] });
}
export {
  Slider
};
