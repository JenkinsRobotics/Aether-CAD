import { modelStudioEnvironment, modelStudioSurfaces } from "@aether/assets/themes/rendering/model-studio";
const modelStudioCamera = {
  target: [0, 1.85, 0],
  views: { perspective: [5, 3.5, 7.7], front: [0, 2, 9], right: [9, 2, 0], top: [0.01, 11, 0.01] }
};
export {
  modelStudioCamera,
  modelStudioEnvironment,
  modelStudioSurfaces
};
