import { jsx, jsxs } from "react/jsx-runtime";
import "./ApplicationList.css";
import { MenuButton } from "./Menu.js";
import { AetherIcon } from "./AetherIcon.js";
function ApplicationListHeading({ children, description }) {
  return /* @__PURE__ */ jsxs("header", { className: "aui-application-list-heading", children: [
    /* @__PURE__ */ jsx("h2", { children }),
    description && /* @__PURE__ */ jsx("p", { children: description })
  ] });
}
function ApplicationListControls({ filters, search, actions }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-application-list-controls", children: [
    filters && /* @__PURE__ */ jsx("div", { className: "aui-application-list-filters", children: filters }),
    search && /* @__PURE__ */ jsx("div", { className: "aui-application-list-search", children: search }),
    actions && /* @__PURE__ */ jsx("div", { className: "aui-application-list-actions", children: actions })
  ] });
}
function ListToolMenu({ label, ariaLabel, icon, items, onPick }) {
  return /* @__PURE__ */ jsxs(MenuButton, { className: "aui-list-tool-menu", label: ariaLabel ?? (typeof label === "string" ? label : "Options"), items: items.map((item) => ({ ...item, kind: item.checked === void 0 ? "command" : "radio" })), onSelect: onPick, placement: "bottom-end", children: [
    icon,
    label,
    /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right" })
  ] });
}
export {
  ApplicationListControls,
  ApplicationListHeading,
  ListToolMenu
};
