import { useEffect, useState, useSyncExternalStore } from "react";
const HEADER_PINS_KEY = "aether-header-pins-v1";
const LEGACY_HEADER_PINS_KEY = "aether-workspace-quick-controls";
const DEFAULT_HEADER_PINS = ["theme", "share", "apps"];
const aliases = { "cad-control-2": "plugins", "cad-control-3": "layout", "cad-control-4": "comments", "cad-control-5": "reminders" };
const memory = /* @__PURE__ */ new Map();
const validPins = (value) => Array.isArray(value) && value.every((id) => typeof id === "string");
const normalize = (ids) => [...new Set(ids.map((id) => aliases[id] ?? id))].filter((id) => id !== "settings");
function savedPins() {
  try {
    const data = JSON.parse(localStorage.getItem(HEADER_PINS_KEY) ?? "null");
    if (data?.version === 1 && data.apps && typeof data.apps === "object" && !Array.isArray(data.apps))
      return Object.fromEntries(Object.entries(data.apps).filter((entry) => validPins(entry[1])));
  } catch {
  }
  return {};
}
function readHeaderPins(appID, defaults = DEFAULT_HEADER_PINS) {
  if (memory.has(appID)) return memory.get(appID);
  const saved = savedPins();
  if (Object.hasOwn(saved, appID)) return normalize(saved[appID]);
  try {
    const legacy = JSON.parse(localStorage.getItem(LEGACY_HEADER_PINS_KEY) ?? "null");
    if (validPins(legacy)) return normalize(legacy);
  } catch {
  }
  return normalize(defaults);
}
function setHeaderPins(appID, ids) {
  const pins = normalize(ids);
  try {
    localStorage.setItem(HEADER_PINS_KEY, JSON.stringify({ version: 1, apps: { ...savedPins(), [appID]: pins } }));
    memory.delete(appID);
  } catch {
    memory.set(appID, pins);
  }
  document.dispatchEvent(new Event(HEADER_PINS_KEY));
}
function useHeaderPins(appID, defaults = DEFAULT_HEADER_PINS) {
  const defaultsKey = JSON.stringify(defaults);
  const [pins, setPins] = useState(() => readHeaderPins(appID, defaults));
  useEffect(() => {
    const sync = () => setPins(readHeaderPins(appID, JSON.parse(defaultsKey)));
    sync();
    document.addEventListener(HEADER_PINS_KEY, sync);
    document.addEventListener(LEGACY_HEADER_PINS_KEY, sync);
    window.addEventListener("storage", sync);
    return () => {
      document.removeEventListener(HEADER_PINS_KEY, sync);
      document.removeEventListener(LEGACY_HEADER_PINS_KEY, sync);
      window.removeEventListener("storage", sync);
    };
  }, [appID, defaultsKey]);
  return pins;
}
const registrations = /* @__PURE__ */ new Map();
const listeners = /* @__PURE__ */ new Set();
let snapshot = [];
function emit() {
  snapshot = [...new Map([...registrations.values()].map((config) => [config.appID, config])).values()];
  listeners.forEach((listener) => listener());
}
function registerHeaderControls(owner, config) {
  registrations.set(owner, config);
  emit();
  return () => {
    registrations.delete(owner);
    emit();
  };
}
const subscribe = (listener) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};
function useAvailableHeaderControls() {
  return useSyncExternalStore(subscribe, () => snapshot, () => snapshot);
}
export {
  DEFAULT_HEADER_PINS,
  HEADER_PINS_KEY,
  LEGACY_HEADER_PINS_KEY,
  readHeaderPins,
  registerHeaderControls,
  setHeaderPins,
  useAvailableHeaderControls,
  useHeaderPins
};
