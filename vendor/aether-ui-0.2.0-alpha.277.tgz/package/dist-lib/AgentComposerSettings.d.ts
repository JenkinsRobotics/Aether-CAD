import { type ReactNode } from 'react';
import { type AgentMode } from './AgentMode.js';
import type { AgentPlugin } from './AgentServices.js';
interface Props {
    providers: AgentPlugin[];
    provider: string;
    onProvider: (id: string) => void;
    models: {
        id: string;
        name: string;
    }[];
    model: string;
    onModel: (id: string) => void;
    mode: AgentMode;
    onMode: (mode: AgentMode) => void;
    busy: boolean;
    loadingModels: boolean;
    onConnections: () => void;
    onTools: () => void;
    style: string;
    onStyle: (style: string) => void;
    contextText: string;
    context?: ReactNode;
    detail?: string;
    messageCount: number;
    tools: readonly {
        name: string;
        description: string;
    }[];
    attachments: readonly {
        name: string;
        text: string;
    }[];
    sharingMessage?: string;
}
/** Compact controls shared by every WorkspaceAgent; no provider catalog is hard-coded. */
export declare function AgentComposerSettings(props: Props): import("react").JSX.Element;
export {};
