import { jsx, jsxs } from "react/jsx-runtime";
import { WorkspaceShell } from "./WorkspaceShell.js";
import "./AppLayout.css";
const APP_LAYOUT_METRICS = {
  headerHeight: 56,
  sidebarWidth: 280,
  sidebarMinWidth: 220,
  sidebarMaxWidth: 360,
  centerMinWidth: 360,
  toolbarMinHeight: 44,
  toolbarMaxHeight: 96,
  footerMinHeight: 40,
  footerMaxFraction: 0.3,
  widgetPadding: 12,
  widgetGap: 8,
  minWidth: 960,
  minHeight: 480
};
function AppLayout({ header, left = [], center, right = [], footer, topToolbar, bottomToolbar, storageKey, className, style }) {
  const m = APP_LAYOUT_METRICS;
  const metrics = Object.fromEntries(Object.entries(m).map(([key, value]) => [`--aui-app-${key}`, key === "footerMaxFraction" ? `${value * 100}%` : `${value}px`]));
  const panels = (items, side) => items.map((panel) => ({
    ...panel,
    contentLayout: panel.contentLayout ?? "custom",
    content: /* @__PURE__ */ jsx("div", { className: "aui-app-layout-widgets", "data-app-region": side, children: panel.content })
  }));
  return /* @__PURE__ */ jsxs("div", { className: ["aui-app-layout", className].filter(Boolean).join(" "), style: { ...metrics, ...style }, children: [
    header && /* @__PURE__ */ jsx("header", { className: "aui-app-layout-header", "aria-label": "Header", "data-app-region": "header", children: header }),
    /* @__PURE__ */ jsx(
      WorkspaceShell,
      {
        preset: "docked",
        toolbarSpan: "center",
        sidebarVariant: "tabs-top",
        sidebarAttachment: "attached",
        inheritChromePreferences: false,
        animatePanels: false,
        storageKey,
        sidebarSizing: { width: m.sidebarWidth, minWidth: m.sidebarMinWidth, maxWidth: m.sidebarMaxWidth, minCenterWidth: m.centerMinWidth + 4 },
        leftPanels: panels(left, "left"),
        rightPanels: panels(right, "right"),
        defaultOpenLeft: left[0] ? [left[0].id] : [],
        defaultOpenRight: right[0] ? [right[0].id] : [],
        toolbar: topToolbar && /* @__PURE__ */ jsx("div", { className: "aui-app-layout-toolbar", "data-app-region": "top-toolbar", role: "region", "aria-label": "Top toolbar", children: topToolbar }),
        centerBottom: bottomToolbar && /* @__PURE__ */ jsx("div", { className: "aui-app-layout-toolbar aui-app-layout-toolbar--bottom", "data-app-region": "bottom-toolbar", role: "region", "aria-label": "Bottom toolbar", children: bottomToolbar }),
        children: /* @__PURE__ */ jsx("main", { className: "aui-app-layout-center", "aria-label": "Center", "data-app-region": "center", children: center })
      }
    ),
    footer && /* @__PURE__ */ jsx("footer", { className: "aui-app-layout-footer", "aria-label": "Footer", "data-app-region": "footer", children: footer })
  ] });
}
export {
  APP_LAYOUT_METRICS,
  AppLayout
};
