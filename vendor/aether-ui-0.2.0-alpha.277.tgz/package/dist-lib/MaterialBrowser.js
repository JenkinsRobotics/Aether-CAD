import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useMemo, useState } from "react";
import { SegmentedControl } from "./SegmentedControl.js";
import "./ConceptWidgets.css";
import "./MaterialBrowser.css";
function MaterialBrowser({
  materials,
  selectedID,
  onSelect,
  usedIDs = [],
  assignmentLabel,
  environments = [],
  environmentID,
  onEnvironmentSelect,
  environmentControls,
  initialTab = "material",
  showTabs = true
}) {
  const [selectedTab, setTab] = useState(initialTab);
  const tab = showTabs ? selectedTab : "material";
  const [query, setQuery] = useState("");
  const shown = useMemo(() => materials.filter((item) => [item.name, item.category, item.finish, item.color].join(" ").toLowerCase().includes(query.trim().toLowerCase())), [materials, query]);
  const groups = [...new Set(shown.map((item) => item.category))];
  const used = materials.filter((item) => usedIDs.includes(item.id));
  const sphere = (material) => /* @__PURE__ */ jsx("span", { className: "aui-material-browser__sphere", style: { "--material-color": material.color } });
  return /* @__PURE__ */ jsxs("section", { className: "aui-material-browser", "aria-label": "Material browser", children: [
    showTabs && /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Visualization", value: tab, onChange: (id) => setTab(id), options: [{ id: "material", label: "Material" }, { id: "environment", label: "Environment" }] }),
    tab === "material" ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("input", { className: "aui-material-browser__search", "aria-label": "Search materials", placeholder: "Search Materials", value: query, onChange: (event) => setQuery(event.target.value) }),
      assignmentLabel && /* @__PURE__ */ jsxs("p", { className: "aui-material-browser__assignment", children: [
        "Applying to ",
        assignmentLabel
      ] }),
      !query && used.length > 0 && /* @__PURE__ */ jsxs("section", { className: "aui-material-browser__used", children: [
        /* @__PURE__ */ jsxs("h4", { children: [
          "Used Materials (",
          used.length,
          ")"
        ] }),
        used.map((material) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-pressed": selectedID === material.id, onClick: () => onSelect?.(material.id), children: [
          sphere(material),
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsx("small", { children: material.finish }),
            /* @__PURE__ */ jsx("strong", { children: material.name }),
            /* @__PURE__ */ jsx("small", { children: material.color })
          ] })
        ] }, material.id))
      ] }),
      groups.map((group) => /* @__PURE__ */ jsxs("section", { children: [
        /* @__PURE__ */ jsx("h4", { children: group }),
        /* @__PURE__ */ jsx("div", { className: "aui-material-browser__grid", children: shown.filter((item) => item.category === group).map((material) => /* @__PURE__ */ jsxs("button", { className: "aui-material-browser__item", type: "button", "aria-pressed": selectedID === material.id, onClick: () => onSelect?.(material.id), children: [
          sphere(material),
          /* @__PURE__ */ jsx("span", { children: material.finish }),
          /* @__PURE__ */ jsx("strong", { children: material.name })
        ] }, material.id)) })
      ] }, group)),
      !shown.length && /* @__PURE__ */ jsx("p", { role: "status", children: "No matching materials." })
    ] }) : /* @__PURE__ */ jsxs("div", { className: "aui-material-browser__environments", children: [
      environments.map((environment) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-pressed": environmentID === environment.id, onClick: () => onEnvironmentSelect?.(environment.id), children: [
        /* @__PURE__ */ jsx("span", { className: environment.transparent ? "is-transparent" : void 0, style: { background: environment.transparent ? void 0 : `linear-gradient(135deg, ${environment.color}, ${environment.secondaryColor ?? environment.color})` } }),
        /* @__PURE__ */ jsx("strong", { children: environment.name })
      ] }, environment.id)),
      environmentControls,
      !environments.length && !environmentControls && /* @__PURE__ */ jsx("p", { role: "status", children: "No environments supplied." })
    ] })
  ] });
}
export {
  MaterialBrowser
};
