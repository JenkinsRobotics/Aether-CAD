import { jsx } from "react/jsx-runtime";
import "./StudioViewportControls.css";
function StudioViewportControls({ children, className = "" }) {
  return /* @__PURE__ */ jsx("div", { className: `aui-studio-viewport-controls ${className}`.trim(), children });
}
export {
  StudioViewportControls
};
