import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useLayoutEffect, useRef } from "react";
import { WorkspaceShell } from "./WorkspaceShell.js";
import { FloatingToolbar } from "./FloatingToolbar.js";
import "./StudioAppFrame.css";
import { StudioDesignContext } from "./StudioDesignContext.js";
function StudioToolTray({ children }) {
  const ref = useRef(null);
  useLayoutEffect(() => {
    const node = ref.current;
    const center = node?.closest(".aui-shell-center");
    if (!node || !center) return;
    const measure = () => center.style.setProperty("--aui-studio-tools-clearance", `${Math.max(0, center.getBoundingClientRect().bottom - node.getBoundingClientRect().top + 12)}px`);
    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(node);
    observer?.observe(center);
    return () => {
      observer?.disconnect();
      center.style.removeProperty("--aui-studio-tools-clearance");
    };
  }, []);
  return /* @__PURE__ */ jsx("div", { ref, className: "aui-studio-tool-tray", children });
}
function StudioWorkspace({ preset = "floating", workspaceControls, toolPosition = "bottom", toolbar, centerBottom, ...props }) {
  const tools = toolbar ? /* @__PURE__ */ jsx(StudioToolTray, { children: toolbar }) : null;
  return /* @__PURE__ */ jsx(StudioDesignContext.Provider, { value: true, children: /* @__PURE__ */ jsx(
    WorkspaceShell,
    {
      ...props,
      design: "studio",
      preset,
      sidebarSizing: props.sidebarSizing ?? { width: 216, minWidth: 180, maxWidth: 520, minCenterWidth: 240 },
      inheritChromePreferences: false,
      sidebarAttachment: "detached",
      frameToolbar: false,
      toolbar: workspaceControls || toolPosition === "top" && tools ? /* @__PURE__ */ jsxs("div", { className: "aui-studio-workspace-tools", children: [
        workspaceControls && /* @__PURE__ */ jsx(FloatingToolbar, { variant: "document", ariaLabel: "Workspace controls", groups: [], onAction: () => {
        }, leading: workspaceControls }),
        toolPosition === "top" && tools
      ] }) : void 0,
      centerBottom: centerBottom || toolPosition === "bottom" && tools ? /* @__PURE__ */ jsxs(Fragment, { children: [
        centerBottom,
        toolPosition === "bottom" && tools
      ] }) : void 0
    }
  ) });
}
export {
  StudioWorkspace
};
