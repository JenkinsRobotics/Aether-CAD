export interface ColorFieldProps {
    value?: string;
    defaultValue?: string;
    onChange?: (hex: string) => void;
    ariaLabel: string;
    disabled?: boolean;
    invalidMessage?: string;
    className?: string;
}
export declare function ColorField({ value, defaultValue, onChange, ariaLabel, disabled, invalidMessage, className }: ColorFieldProps): import("react").JSX.Element;
