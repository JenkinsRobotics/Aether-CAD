function parseNumberExpression(source) {
  let index = 0;
  const skipWhitespace = () => {
    while (/\s/.test(source[index] ?? "")) index += 1;
  };
  const parsePrimary = () => {
    skipWhitespace();
    if (source[index] === "(") {
      index += 1;
      const value3 = parseExpression();
      skipWhitespace();
      if (value3 === null || source[index] !== ")") return null;
      index += 1;
      return value3;
    }
    const match = source.slice(index).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?/i);
    if (!match) return null;
    index += match[0].length;
    const value2 = Number(match[0]);
    return Number.isFinite(value2) ? value2 : null;
  };
  const parseUnary = () => {
    skipWhitespace();
    if (source[index] === "+" || source[index] === "-") {
      const negative = source[index] === "-";
      index += 1;
      const value2 = parseUnary();
      return value2 === null ? null : negative ? -value2 : value2;
    }
    return parsePrimary();
  };
  const parseTerm = () => {
    let value2 = parseUnary();
    if (value2 === null) return null;
    while (true) {
      skipWhitespace();
      const operator = source[index];
      if (operator !== "*" && operator !== "/") return value2;
      index += 1;
      const right = parseUnary();
      if (right === null) return null;
      value2 = operator === "*" ? value2 * right : value2 / right;
      if (!Number.isFinite(value2)) return null;
    }
  };
  const parseExpression = () => {
    let value2 = parseTerm();
    if (value2 === null) return null;
    while (true) {
      skipWhitespace();
      const operator = source[index];
      if (operator !== "+" && operator !== "-") return value2;
      index += 1;
      const right = parseTerm();
      if (right === null) return null;
      value2 = operator === "+" ? value2 + right : value2 - right;
    }
  };
  const value = parseExpression();
  skipWhitespace();
  return value !== null && index === source.length && Number.isFinite(value) ? value : null;
}
export {
  parseNumberExpression
};
