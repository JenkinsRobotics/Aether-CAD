/** One device preference surface, reused by every application settings window. */
export declare function SharedAppearanceSettings(): import("react").JSX.Element;
