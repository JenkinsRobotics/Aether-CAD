import { jsx, jsxs } from "react/jsx-runtime";
import { useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Menu } from "./Menu.js";
import "./CollectionView.css";
function CollectionFilter({ query, onQueryChange, options = [], value = "all", onChange, ariaLabel, inputRef, inputID, resultCount, placeholder, menu }) {
  const countLabel = resultCount === void 0 ? null : `${resultCount.toLocaleString()} ${resultCount === 1 ? "result" : "results"}`;
  const anchor = useRef(null), [open, setOpen] = useState(false);
  const choices = [{ id: "all", label: "All Items", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "items" }) }, ...options.filter((o) => o.id !== "all")];
  const current = choices.find((o) => o.id === value) ?? choices[0];
  const menuLabel = menu?.label ?? `${ariaLabel} types`;
  return /* @__PURE__ */ jsxs("div", { className: "aui-collection-filter", ref: anchor, children: [
    /* @__PURE__ */ jsx("span", { className: "aui-collection-filter-icon", "aria-hidden": true, children: query ? /* @__PURE__ */ jsx(AetherIcon, { name: "search" }) : current.icon ?? /* @__PURE__ */ jsx(AetherIcon, { name: "items" }) }),
    /* @__PURE__ */ jsx(
      "input",
      {
        id: inputID,
        ref: inputRef,
        type: "search",
        "aria-label": ariaLabel,
        placeholder: placeholder ?? current.label,
        value: query,
        onChange: (e) => onQueryChange(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Escape" && query) {
            e.preventDefault();
            e.stopPropagation();
            onQueryChange("");
          }
          if (e.key === "ArrowDown" && e.altKey) {
            e.preventDefault();
            setOpen(true);
          }
        }
      }
    ),
    countLabel ? /* @__PURE__ */ jsx("output", { className: "aui-collection-filter-count", "aria-live": "polite", children: countLabel }) : null,
    query && /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Clear ${ariaLabel}`, onClick: () => onQueryChange(""), children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) }),
    /* @__PURE__ */ jsx("button", { type: "button", "aria-label": menuLabel, title: menu?.summary ?? menuLabel, "data-filtered": menu?.active || void 0, "aria-haspopup": "menu", "aria-expanded": open, onClick: () => setOpen(!open), children: /* @__PURE__ */ jsx(AetherIcon, { name: menu ? "filter" : "sort-chevron" }) }),
    open && /* @__PURE__ */ jsx("div", { className: "aui-collection-filter-menu", children: /* @__PURE__ */ jsx(
      Menu,
      {
        className: "aui-collection-popup",
        open: true,
        style: { width: Math.max(200, anchor.current?.getBoundingClientRect().width ?? 240) },
        anchor: anchor.current,
        ariaLabel: menuLabel,
        onClose: () => setOpen(false),
        items: menu?.items ?? choices.map((o) => ({ ...o, kind: "radio", checked: o.id === current.id })),
        onSelect: (id) => {
          if (menu) menu.onSelect(id);
          else onChange?.(id);
          setOpen(false);
        }
      }
    ) })
  ] });
}
export {
  CollectionFilter
};
