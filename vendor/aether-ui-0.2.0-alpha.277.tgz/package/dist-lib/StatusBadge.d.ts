import type { ReactNode } from "react";
import "./AnalyticsElements.css";
/** A concise state or change label; meaning and wording come from the caller. */
export declare function StatusBadge({ children, tone }: {
    children: ReactNode;
    tone?: "positive" | "negative" | "warning" | "neutral";
}): import("react").JSX.Element;
