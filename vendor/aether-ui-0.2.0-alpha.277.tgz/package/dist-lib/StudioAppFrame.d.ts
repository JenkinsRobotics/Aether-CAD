import type { CSSProperties, ReactNode } from "react";
import "./StudioAppFrame.css";
/** Approved Model Studio composition. Products supply their real document and tools. */
export declare function StudioAppFrame({ children, className, style }: {
    children: ReactNode;
    className?: string;
    style?: CSSProperties;
}): import("react").JSX.Element;
