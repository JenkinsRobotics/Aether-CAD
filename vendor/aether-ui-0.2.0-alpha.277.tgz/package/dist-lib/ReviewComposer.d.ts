import type { CommentImage } from "./DocumentServices.js";
import { type ReactNode } from "react";
import "./StudioReview.css";
export declare function ReviewComposer({ task, value, onChange, onSubmit, busy, selectedName, reply, onCancelReply, context, members, versions, initialImages, initialRevision, resetKey, onCapture, initialTags, initialMentions, initialReference, referenceLabel }: {
    initialTags?: string[];
    initialMentions?: string[];
    initialReference?: boolean;
    referenceLabel?: string;
    members?: {
        id: string;
        name: string;
    }[];
    versions?: {
        id: number;
        label: string;
    }[];
    initialImages?: CommentImage[];
    initialRevision?: number;
    resetKey?: string | number;
    onCapture?: () => Promise<CommentImage>;
    context?: ReactNode;
    task: boolean;
    value: string;
    onChange: (text: string) => void;
    busy: boolean;
    selectedName?: string;
    reply?: string;
    onCancelReply: () => void;
    onSubmit: (attachments: CommentImage[], reference: boolean, revision: number | undefined, metadata: {
        tags: string[];
        mentions: string[];
    }) => Promise<boolean>;
}): import("react").JSX.Element;
