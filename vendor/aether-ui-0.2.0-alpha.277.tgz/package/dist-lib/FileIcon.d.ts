import { type FileIdentity, type FileTypeDefinition } from './file-types.js';
import './FileIcon.css';
/** A document bearing its application's actual identity, never a redrawn A. */
export declare function FileIcon({ file, type, icon, size }: {
    file?: FileIdentity;
    type?: FileTypeDefinition;
    icon?: string;
    size?: number;
}): import("react").JSX.Element;
