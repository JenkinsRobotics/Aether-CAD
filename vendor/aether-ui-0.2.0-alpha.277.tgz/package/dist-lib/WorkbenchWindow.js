import { jsx, jsxs } from "react/jsx-runtime";
import { useId, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { SplitPane } from "./SplitPane.js";
import "./WorkbenchWindow.css";
function WorkbenchWindow({
  title,
  subtitle,
  sidebar,
  sidebarTitle = "Files",
  sidebarActions,
  sidebarFooter,
  toolbar,
  statusBar,
  canvasOverlay,
  canvasFooter,
  children,
  sidebarCollapsed,
  defaultSidebarCollapsed = false,
  onSidebarCollapsedChange,
  sidebarWidth,
  defaultSidebarWidth = 265,
  onSidebarWidthChange,
  className
}) {
  const sidebarID = useId();
  const [localCollapsed, setLocalCollapsed] = useState(defaultSidebarCollapsed);
  const collapsed = sidebarCollapsed ?? localCollapsed;
  const changeCollapsed = (next) => {
    if (sidebarCollapsed === void 0) setLocalCollapsed(next);
    onSidebarCollapsedChange?.(next);
  };
  return /* @__PURE__ */ jsx("section", { className: ["aui-workbench-window", className].filter(Boolean).join(" "), "aria-label": title, children: /* @__PURE__ */ jsx(
    SplitPane,
    {
      defaultPrimarySize: defaultSidebarWidth,
      primarySize: sidebarWidth,
      minPrimarySize: 220,
      maxPrimarySize: 340,
      onResize: onSidebarWidthChange,
      collapsed,
      onCollapsedChange: changeCollapsed,
      collapseSide: "primary",
      separatorLabel: "Resize workspace sidebar",
      primary: /* @__PURE__ */ jsxs("aside", { id: sidebarID, className: "aui-workbench-sidebar", "aria-label": sidebarTitle, children: [
        /* @__PURE__ */ jsxs("header", { children: [
          /* @__PURE__ */ jsx("strong", { children: sidebarTitle }),
          sidebarActions
        ] }),
        /* @__PURE__ */ jsx("div", { className: "aui-workbench-sidebar-content", children: sidebar }),
        sidebarFooter ? /* @__PURE__ */ jsx("footer", { children: sidebarFooter }) : null
      ] }),
      secondary: /* @__PURE__ */ jsxs("div", { className: "aui-workbench-detail", children: [
        /* @__PURE__ */ jsxs("header", { className: "aui-workbench-toolbar", children: [
          /* @__PURE__ */ jsx("button", { type: "button", className: "aui-icon-button", "aria-label": collapsed ? "Show sidebar" : "Hide sidebar", "aria-expanded": !collapsed, "aria-controls": sidebarID, onClick: () => changeCollapsed(!collapsed), children: /* @__PURE__ */ jsx(AetherIcon, { name: "sidebar" }) }),
          /* @__PURE__ */ jsxs("div", { className: "aui-workbench-heading", children: [
            /* @__PURE__ */ jsx("strong", { children: title }),
            subtitle ? /* @__PURE__ */ jsx("small", { children: subtitle }) : null
          ] }),
          toolbar ? /* @__PURE__ */ jsx("div", { className: "aui-workbench-actions", role: "group", "aria-label": "Workspace actions", children: toolbar }) : null
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-workbench-canvas", children: [
          /* @__PURE__ */ jsx("div", { className: "aui-workbench-content", children }),
          canvasOverlay ? /* @__PURE__ */ jsx("div", { className: "aui-workbench-overlay", children: canvasOverlay }) : null,
          canvasFooter ? /* @__PURE__ */ jsx("div", { className: "aui-workbench-canvas-footer", children: canvasFooter }) : null
        ] }),
        statusBar ? /* @__PURE__ */ jsx("footer", { className: "aui-workbench-status", children: statusBar }) : null
      ] })
    }
  ) });
}
export {
  WorkbenchWindow
};
