import "./GaugeChart.css";
/** A bounded proportion; the displayed metric and target description stay caller-owned. */
export declare function GaugeChart({ label, value, detail, fraction }: {
    label: string;
    value: string;
    detail?: string;
    fraction: number;
}): import("react").JSX.Element;
