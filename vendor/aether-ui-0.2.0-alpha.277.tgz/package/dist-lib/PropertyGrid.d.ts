import type { ReactNode } from "react";
export interface PropertyGridItem {
    id: string;
    label: string;
    editor: ReactNode;
    help?: ReactNode;
    error?: ReactNode;
    modified?: boolean;
    mixed?: boolean;
    readOnly?: boolean;
    onReset?: () => void;
}
export interface PropertyGridSection {
    id: string;
    label: string;
    badge?: string;
    properties: readonly PropertyGridItem[];
}
export interface PropertyGridProps {
    sections: readonly PropertyGridSection[];
    ariaLabel: string;
    filter?: string;
    modifiedOnly?: boolean;
    collapsedIDs?: ReadonlySet<string>;
    defaultCollapsedIDs?: readonly string[];
    onToggleSection?: (id: string, expanded: boolean) => void;
    emptyState?: ReactNode;
    className?: string;
}
/** Shared inspector composition; applications supply editors and transactions. */
export declare function PropertyGrid({ sections, ariaLabel, filter, modifiedOnly, collapsedIDs, defaultCollapsedIDs, onToggleSection, emptyState, className, }: PropertyGridProps): import("react").JSX.Element;
