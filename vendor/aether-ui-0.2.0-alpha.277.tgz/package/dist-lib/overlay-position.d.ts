import type { CSSProperties, RefObject } from "react";
export interface OverlayPoint {
    x: number;
    y: number;
}
export type OverlayAnchor = HTMLElement | OverlayPoint;
export type OverlayPlacement = "bottom-start" | "bottom-end" | "top-start" | "top-end" | "right-start" | "left-start";
interface OverlayPositionOptions {
    open: boolean;
    overlayRef: RefObject<HTMLElement | null>;
    anchor: OverlayAnchor | null;
    placement?: OverlayPlacement;
    gap?: number;
    viewportPadding?: number;
    /** Search suggestions attach to their field, not the enclosing tool row. */
    respectToolbarBoundary?: boolean;
}
/** Positions a fixed overlay beside an element or pointer location and clamps
 * it inside the viewport. Bottom/top placements flip when the preferred side
 * has insufficient space. */
export declare function useOverlayPosition({ open, overlayRef, anchor, placement, gap, viewportPadding, respectToolbarBoundary, }: OverlayPositionOptions): CSSProperties;
export {};
