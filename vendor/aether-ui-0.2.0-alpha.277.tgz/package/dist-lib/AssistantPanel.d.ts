import { type ReactNode } from "react";
import "./ConceptWidgets.css";
import "./AdvisorPanel.css";
import "./StudioAgent.css";
export interface AssistantMessage {
    id: string;
    role: "assistant" | "user";
    text: string;
    rating?: number;
}
export interface AssistantPanelProps {
    title: string;
    heading?: string;
    welcome?: ReactNode;
    onRate?: (id: string, rating: number) => void;
    detail?: string;
    status?: ReactNode;
    appearance?: "default" | "studio";
    messages: readonly AssistantMessage[];
    suggestions?: readonly string[];
    showModes?: boolean;
    density?: "compact" | "comfortable";
    layout?: "card" | "agent";
    toolbar?: ReactNode;
    headerActions?: ReactNode;
    context?: ReactNode;
    composerActions?: ReactNode;
    renderComposerActions?: (append: (text: string) => void) => ReactNode;
    notice?: string;
    busy?: boolean;
    disabled?: boolean;
    onStop?: () => void;
    onSubmit?: (text: string) => void | boolean | Promise<void | boolean>;
}
export declare function AssistantPanel({ title, heading, welcome, onRate, detail, status, appearance, messages, suggestions, showModes, density, layout, toolbar, headerActions, context, composerActions, renderComposerActions, notice, busy, disabled, onStop, onSubmit }: AssistantPanelProps): import("react").JSX.Element;
