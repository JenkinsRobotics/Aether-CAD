import type { ReactNode } from "react";
import { type MenuButtonProps } from "./Menu.js";
import "./FloatingToolbar.css";
export interface FloatingToolbarAction {
    id: string;
    label: string;
    icon?: ReactNode;
    /** Omit for a command; supply a boolean for a toggle or selected tool. */
    pressed?: boolean;
    disabled?: boolean;
    tone?: "neutral" | "amber" | "blue" | "green";
}
export interface FloatingToolbarGroup {
    id: string;
    label: string;
    actions: readonly FloatingToolbarAction[];
    /** A quiet shared capsule for related switches. */
    capsule?: boolean;
    separatorBefore?: boolean;
}
export interface FloatingToolbarProps {
    ariaLabel: string;
    variant?: "tools" | "document";
    groups: readonly FloatingToolbarGroup[];
    onAction: (id: string) => void;
    leading?: ReactNode;
    trailing?: ReactNode;
    command?: {
        value: string;
        onValueChange: (value: string) => void;
        onSubmit: (value: string) => void;
        label?: string;
        placeholder?: string;
        shortcuts?: readonly FloatingToolbarAction[];
    };
    className?: string;
}
/** Compact floating chrome. Consumers own command matching, active state and
 * document operations; this component handles presentation and keyboard focus. */
export declare function FloatingToolbar({ ariaLabel, variant, groups, onAction, leading, trailing, command, className }: FloatingToolbarProps): import("react").JSX.Element;
/** The same shared menu behavior for the leading menu and trailing document picker. */
export declare function FloatingToolbarMenu({ iconOnly, className, ...props }: MenuButtonProps & {
    iconOnly?: boolean;
}): import("react").JSX.Element;
