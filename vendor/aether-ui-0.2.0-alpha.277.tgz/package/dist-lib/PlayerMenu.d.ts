import "./PlayerMenu.css";
/**
 * One player menu for every output: a PC's output window, a cast tab, and the
 * layout the Pi's native menu draws. A TV menu: one top row, a progress bar
 * only while something loads, the show on one line, big tiles moved between
 * with the arrow keys, and pop-ups that answer in a word.
 */
export interface MenuTile {
    id: string;
    icon: string;
    label: string;
    confirm?: {
        title: string;
        detail: string;
    };
}
export interface MenuPopup {
    kind: 'info' | 'ok' | 'bad' | 'warn';
    title: string;
    detail?: string;
    lines?: string[];
    onYes?: () => void;
}
export declare function PlayerMenu({ appName, name, link, linked, detail, show, progress, tiles, columns, onAction, info, infoTitle, keys, popup, onPopupClose, contained }: {
    /** The app the menu belongs to, first in the top row. */
    appName?: string;
    /** The info pop-up's title and the key hints along the bottom. */
    infoTitle?: string;
    keys?: string;
    /** Inside its parent (a gallery, a preview) instead of covering the screen. */
    contained?: boolean;
    /** The output or device this menu belongs to. */
    name: string;
    /** Its connection, in a word or two, and whether it is good. */
    link: string;
    linked: boolean;
    /** One more fact for the top row: a resolution, a player version. */
    detail?: string;
    /** The show line: what plays and its state. */
    show?: string;
    progress?: {
        title: string;
        percent?: number;
        detail: string;
    } | null;
    tiles: MenuTile[];
    columns?: number;
    onAction: (id: string) => void;
    /** The details behind the info tile. */
    info: string[];
    popup?: MenuPopup | null;
    onPopupClose?: () => void;
}): import("react").JSX.Element;
