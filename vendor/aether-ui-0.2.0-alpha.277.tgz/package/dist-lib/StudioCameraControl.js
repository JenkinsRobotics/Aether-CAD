import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import "./StudioAppFrame.css";
import "./StudioCameraControl.css";
function StudioCameraControl({ projection = "Perspective", children, expanded, onExpandedChange }) {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = expanded ?? internalOpen;
  const setOpen = (next) => {
    setInternalOpen(next);
    onExpandedChange?.(next);
  };
  const button = useRef(null);
  const id = useId();
  useEffect(() => {
    if (!open) return;
    const close = (event) => {
      if (event.key !== "Escape" || event.defaultPrevented) return;
      const focused = event.target instanceof Element ? event.target : document.activeElement;
      if (focused?.closest(".aui-environment-control")) return;
      setOpen(false);
      button.current?.focus();
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [open, onExpandedChange]);
  return /* @__PURE__ */ jsxs("div", { className: "aui-studio-camera-control", "data-expanded": open, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-studio-camera-surface", children: [
      /* @__PURE__ */ jsx("div", { id, className: "aui-studio-camera-content", role: "group", "aria-label": "Camera navigation", "aria-hidden": !open, inert: !open, children }),
      /* @__PURE__ */ jsx("button", { ref: button, className: "aui-studio-camera-toggle", type: "button", "aria-label": "Camera view", title: open ? "Collapse view cube" : "Expand view cube", "aria-expanded": open, "aria-controls": id, onClick: () => setOpen(!open), children: /* @__PURE__ */ jsx(AetherIcon, { name: "view-cube" }) })
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-studio-camera-projection", children: projection })
  ] });
}
export {
  StudioCameraControl
};
