import type { CSSProperties } from "react";
import { freecadIconCatalog } from "@aether/assets/icon-packs/freecad-graphite/catalog";
import { freecadToolIconMap } from "@aether/assets/icon-packs/freecad-graphite/tool-map";
import "./FreeCADIcon.css";
export { freecadIconCatalog, freecadToolIconMap };
export type FreeCADToolIconName = keyof typeof freecadToolIconMap;
export type FreeCADIconName = typeof freecadIconCatalog[number]["id"] | FreeCADToolIconName;
/** Separate, attributed FreeCAD-derived artwork. Existing ToolIcon packs stay unchanged. */
export declare function FreeCADIcon({ name, palette, size, label, className, style }: {
    name: FreeCADIconName;
    palette?: "auto" | "light" | "dark";
    size?: number;
    label?: string;
    className?: string;
    style?: CSSProperties;
}): import("react").JSX.Element;
