import type { SVGProps } from "react";
import { type CircuitSymbolKind } from "@aether/assets/electronics/symbols";
export type { CircuitSymbolKind } from "@aether/assets/electronics/symbols";
/** Scalable shared electrical artwork; this component assigns no electrical meaning. */
export declare function CircuitSymbol({ kind, lit, ...props }: Omit<SVGProps<SVGSVGElement>, "ref"> & {
    kind: CircuitSymbolKind;
    lit?: boolean;
}): import("react").JSX.Element;
