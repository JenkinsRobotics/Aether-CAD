import { useEffect, useRef, useState } from "react";
function useDocumentMutation(connection, recovered, replaySafe = false) {
  const pending = useRef(null);
  const context = useRef(connection.key);
  context.current = connection.key;
  const [uncertain, setUncertain] = useState(false);
  const [retrying, setRetrying] = useState(false);
  useEffect(() => {
    pending.current = null;
    setUncertain(false);
  }, [connection.key]);
  useEffect(() => {
    if (!uncertain) return;
    const warn = (event) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [uncertain]);
  const execute = async (command) => {
    let result;
    try {
      result = await connection.call(command.action, command.data);
    } catch (error) {
      if (context.current !== command.key) throw error;
      if (error.detail?.code === "outcome_unknown") {
        pending.current = command;
        setUncertain(true);
      } else {
        pending.current = null;
        setUncertain(false);
      }
      throw error;
    }
    if (context.current === command.key) {
      pending.current = null;
      setUncertain(false);
    }
    return result;
  };
  return {
    uncertain,
    retrying,
    canRetry: uncertain && pending.current?.replaySafe === true,
    async send(action, data) {
      if (pending.current) throw new Error("Resolve the previous change before making another one.");
      const command = { key: connection.key, action, replaySafe, data: JSON.parse(JSON.stringify({ ...data, operation_id: crypto.randomUUID() })) };
      pending.current = command;
      return await execute(command);
    },
    async retry() {
      const command = pending.current;
      if (!command || !command.replaySafe || retrying || command.key !== connection.key) return;
      setRetrying(true);
      try {
        const result = await execute(command);
        await recovered(command.action, result);
      } finally {
        setRetrying(false);
      }
    }
  };
}
export {
  useDocumentMutation
};
