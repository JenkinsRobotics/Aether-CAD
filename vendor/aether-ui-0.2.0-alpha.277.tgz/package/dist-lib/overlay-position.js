import { useLayoutEffect, useState } from "react";
function isPoint(anchor) {
  return "x" in anchor && "y" in anchor;
}
function useOverlayPosition({
  open,
  overlayRef,
  anchor,
  placement = "bottom-start",
  gap = 5,
  viewportPadding = 8,
  respectToolbarBoundary = true
}) {
  const [position, setPosition] = useState(
    null
  );
  useLayoutEffect(() => {
    if (!open || !anchor || !overlayRef.current) {
      setPosition(null);
      return;
    }
    const update = () => {
      const overlay = overlayRef.current;
      if (!overlay) return;
      const overlayRect = overlay.getBoundingClientRect();
      const width = overlayRect.width || overlay.offsetWidth;
      const height = overlayRect.height || overlay.offsetHeight;
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      let left;
      let top;
      if (isPoint(anchor)) {
        left = anchor.x;
        top = anchor.y;
      } else {
        const anchorRect = anchor.getBoundingClientRect();
        const toolbar = respectToolbarBoundary && anchor instanceof HTMLElement ? anchor.closest("[data-toolbar-menu-boundary]") : null;
        const boundary = toolbar?.getBoundingClientRect();
        const rect = {
          left: anchorRect.left,
          right: anchorRect.right,
          top: boundary?.top ?? anchorRect.top,
          bottom: boundary?.bottom ?? anchorRect.bottom
        };
        switch (placement) {
          case "bottom-end":
            left = rect.right - width;
            top = rect.bottom + gap;
            break;
          case "top-start":
            left = rect.left;
            top = rect.top - height - gap;
            break;
          case "top-end":
            left = rect.right - width;
            top = rect.top - height - gap;
            break;
          case "right-start":
            left = rect.right + gap;
            top = rect.top;
            break;
          case "left-start":
            left = rect.left - width - gap;
            top = rect.top;
            break;
          case "bottom-start":
          default:
            left = rect.left;
            top = rect.bottom + gap;
            break;
        }
        const requestsBottom = placement.startsWith("bottom");
        const requestsTop = placement.startsWith("top");
        if (requestsBottom && top + height > viewportHeight - viewportPadding && rect.top - gap - height >= viewportPadding) {
          top = rect.top - gap - height;
        } else if (requestsTop && top < viewportPadding && rect.bottom + gap + height <= viewportHeight - viewportPadding) {
          top = rect.bottom + gap;
        }
      }
      left = Math.min(
        Math.max(viewportPadding, left),
        Math.max(viewportPadding, viewportWidth - width - viewportPadding)
      );
      top = Math.min(
        Math.max(viewportPadding, top),
        Math.max(viewportPadding, viewportHeight - height - viewportPadding)
      );
      setPosition({ left, top });
    };
    update();
    const resize = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(update);
    resize?.observe(overlayRef.current);
    if (anchor instanceof HTMLElement) resize?.observe(anchor);
    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, true);
    return () => {
      resize?.disconnect();
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update, true);
    };
  }, [anchor, gap, open, overlayRef, placement, viewportPadding, respectToolbarBoundary]);
  return {
    position: "fixed",
    left: position?.left ?? 0,
    top: position?.top ?? 0,
    visibility: position ? "visible" : "hidden"
  };
}
export {
  useOverlayPosition
};
