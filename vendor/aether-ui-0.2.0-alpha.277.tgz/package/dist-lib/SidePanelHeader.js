import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { PanelNotificationButton } from "./PanelNotifications.js";
import "./SidePanelHeader.css";
function SidePanelHeader({ title, icon, actions }) {
  return /* @__PURE__ */ jsxs("header", { className: "aui-side-panel-header", children: [
    /* @__PURE__ */ jsx(AetherIcon, { name: icon }),
    /* @__PURE__ */ jsx("h2", { children: title }),
    /* @__PURE__ */ jsxs("div", { className: "aui-side-panel-header-actions", children: [
      actions,
      /* @__PURE__ */ jsx(PanelNotificationButton, {})
    ] })
  ] });
}
export {
  SidePanelHeader
};
