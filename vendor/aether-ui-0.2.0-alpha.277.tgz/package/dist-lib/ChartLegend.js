import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import "./AnalyticsElements.css";
function ChartLegend({ series, hidden = [], onToggle, label = "Chart series" }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-chart-legend", role: "group", "aria-label": label, children: series.map((item) => {
    const contents = /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("span", { className: "aui-chart-swatch", style: { "--series-color": item.color } }),
      item.label
    ] });
    return onToggle ? /* @__PURE__ */ jsx("button", { type: "button", "aria-pressed": !hidden.includes(item.id), onClick: () => onToggle(item.id), children: contents }, item.id) : /* @__PURE__ */ jsx("span", { children: contents }, item.id);
  }) });
}
export {
  ChartLegend
};
