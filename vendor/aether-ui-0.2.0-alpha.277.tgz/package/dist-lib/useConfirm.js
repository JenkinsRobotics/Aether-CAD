import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useCallback, useState } from "react";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { TextField } from "./TextField.js";
function useConfirm() {
  const [request, setRequest] = useState(null);
  const confirm = useCallback((value) => new Promise((resolve) => setRequest({ ...value, resolve: (answer) => resolve(answer !== null) })), []);
  const prompt = useCallback((value) => new Promise((resolve) => setRequest({ ...value, resolve })), []);
  const text = request?.value?.trim();
  const close = (ok) => {
    request?.resolve(ok ? text ?? "" : null);
    setRequest(null);
  };
  const dialog = /* @__PURE__ */ jsx(
    Dialog,
    {
      open: !!request,
      title: request?.title ?? "",
      onClose: () => close(false),
      actions: /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(Button, { onClick: () => close(false), children: "Cancel" }),
        /* @__PURE__ */ jsx(Button, { primary: true, disabled: request?.value !== void 0 && !text, onClick: () => close(true), children: request?.action })
      ] }),
      children: request?.value === void 0 ? /* @__PURE__ */ jsx("p", { children: request?.message }) : /* @__PURE__ */ jsx("form", { onSubmit: (e) => {
        e.preventDefault();
        if (text) close(true);
      }, children: /* @__PURE__ */ jsx(TextField, { "aria-label": request.message, autoFocus: true, maxLength: 160, value: request.value, onChange: (e) => setRequest({ ...request, value: e.target.value }) }) })
    }
  );
  return [confirm, dialog, prompt];
}
export {
  useConfirm
};
