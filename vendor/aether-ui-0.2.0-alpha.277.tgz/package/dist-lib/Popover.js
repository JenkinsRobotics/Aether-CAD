import { jsx } from "react/jsx-runtime";
import { createPortal } from "react-dom";
import { useOverlayHost } from "./OverlayScope.js";
import { useEffect, useRef } from "react";
import {
  useOverlayPosition
} from "./overlay-position.js";
const FOCUSABLE = 'button:not(:disabled), [href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])';
function Popover({
  open,
  anchor,
  onClose,
  children,
  ariaLabel,
  placement = "bottom-start",
  focus = "none",
  closeOnOutsidePress = true,
  returnFocus = true,
  className,
  inline = false
}) {
  const overlayHost = useOverlayHost();
  const popoverRef = useRef(null);
  const position = useOverlayPosition({
    open: open && !inline,
    overlayRef: popoverRef,
    anchor,
    placement
  });
  useEffect(() => {
    if (!open || inline) return;
    const opener = document.activeElement;
    const onKeyDown = (event) => {
      if (event.key !== "Escape") return;
      event.stopPropagation();
      onClose();
    };
    const onPointerDown = (event) => {
      if (!closeOnOutsidePress) return;
      const target = event.target;
      if (popoverRef.current?.contains(target)) return;
      if (anchor instanceof HTMLElement && anchor.contains(target)) return;
      onClose();
    };
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("pointerdown", onPointerDown, true);
    return () => {
      document.removeEventListener("keydown", onKeyDown, true);
      document.removeEventListener("pointerdown", onPointerDown, true);
      if (returnFocus) opener?.focus?.();
    };
  }, [anchor, closeOnOutsidePress, focus, onClose, open, returnFocus, inline]);
  useEffect(() => {
    if (open && !inline && focus === "first" && position.visibility === "visible") {
      popoverRef.current?.querySelector(FOCUSABLE)?.focus();
    }
  }, [open, focus, position.visibility, inline]);
  if (!open || !inline && !anchor || typeof document === "undefined") return null;
  const classes = ["aui-popover"];
  if (className) classes.push(className);
  if (inline) classes.push("aui-popover--inline");
  const surface = /* @__PURE__ */ jsx(
    "div",
    {
      ref: popoverRef,
      className: classes.join(" "),
      role: "dialog",
      "aria-modal": "false",
      "aria-label": ariaLabel,
      style: inline ? void 0 : position,
      children
    }
  );
  return inline ? surface : createPortal(surface, overlayHost ?? document.body);
}
export {
  Popover
};
