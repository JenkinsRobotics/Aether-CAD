import { type ReactNode } from "react";
import "./ConceptWidgets.css";
import "./MaterialBrowser.css";
export interface MaterialOption {
    id: string;
    name: string;
    category: string;
    color: string;
    finish?: string;
}
export interface MaterialEnvironmentOption {
    id: string;
    name: string;
    color: string;
    secondaryColor?: string;
    transparent?: boolean;
}
export interface MaterialBrowserProps {
    materials: readonly MaterialOption[];
    selectedID?: string;
    onSelect?: (id: string) => void;
    usedIDs?: readonly string[];
    assignmentLabel?: string;
    environments?: readonly MaterialEnvironmentOption[];
    environmentID?: string;
    onEnvironmentSelect?: (id: string) => void;
    environmentControls?: ReactNode;
    initialTab?: "material" | "environment";
    /** Embed only the material library when the host supplies its own navigation. */
    showTabs?: boolean;
}
/** Presentation-only library: callers own material assignment and renderer settings. */
export declare function MaterialBrowser({ materials, selectedID, onSelect, usedIDs, assignmentLabel, environments, environmentID, onEnvironmentSelect, environmentControls, initialTab, showTabs }: MaterialBrowserProps): import("react").JSX.Element;
