import type { ReactNode } from "react";
export interface BottomPanelTab {
    id: string;
    label: string;
    badge?: string | number;
    icon?: ReactNode;
    content: ReactNode;
}
export interface BottomPanelProps {
    tabs: readonly BottomPanelTab[];
    activeID: string;
    onSelect: (id: string) => void;
    collapsed?: boolean;
    onCollapsedChange?: (collapsed: boolean) => void;
    actions?: ReactNode;
    ariaLabel?: string;
}
export declare function BottomPanel({ tabs, activeID, onSelect, collapsed, onCollapsedChange, actions, ariaLabel, }: BottomPanelProps): import("react").JSX.Element | null;
