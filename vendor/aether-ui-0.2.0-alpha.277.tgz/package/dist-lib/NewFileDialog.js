import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useId, useRef, useState } from "react";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { TextField } from "./TextField.js";
function NewFileDialog({ title, directory, onCreate, onClose }) {
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const formID = useId();
  const submit = async () => {
    if (submitting.current || !name.trim()) return;
    submitting.current = true;
    setBusy(true);
    setError("");
    try {
      await onCreate(name.trim());
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "The file could not be created.");
    } finally {
      submitting.current = false;
      setBusy(false);
    }
  };
  return /* @__PURE__ */ jsx(Dialog, { open: true, title, onClose: () => {
    if (!submitting.current) onClose();
  }, actions: /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: onClose, children: "Cancel" }),
    /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", form: formID, disabled: busy || !name.trim(), children: busy ? "Creating\u2026" : "Create" })
  ] }), children: /* @__PURE__ */ jsxs("form", { id: formID, onSubmit: (event) => {
    event.preventDefault();
    void submit();
  }, children: [
    /* @__PURE__ */ jsxs("p", { children: [
      "Create in ",
      directory
    ] }),
    /* @__PURE__ */ jsxs("label", { children: [
      "Name",
      /* @__PURE__ */ jsx(TextField, { "aria-label": "Name", autoFocus: true, required: true, maxLength: 180, disabled: busy, value: name, onChange: (event) => setName(event.target.value) })
    ] }),
    error && /* @__PURE__ */ jsx("p", { role: "alert", children: error })
  ] }) });
}
export {
  NewFileDialog
};
