import type { OverlayPlacement } from "./overlay-position.js";
export interface LaunchableApp {
    id: string;
    name: string;
    description?: string;
    /** Where the app opens. */
    url: string;
    /** Registered but not built yet: listed, described, not openable. */
    comingSoon?: boolean;
}
export interface AppLauncherProps {
    apps: readonly LaunchableApp[];
    /** The app whose window this is, marked as current in the list. */
    currentID?: string;
    /** The suite home, offered above the list. */
    homeUrl?: string;
    homeName?: string;
    /** Text beside the icon (sidebar row form); hidden when its sidebar collapses. */
    label?: string;
    className?: string;
    placement?: OverlayPlacement;
}
/**
 * The suite's app launcher: the first control in an application header, the
 * way Microsoft 365's waffle is. Every Aether application is one click away
 * from every other.
 *
 * Presentational by design — it takes the list rather than fetching it, so the
 * design system stays free of host semantics and the owning application keeps
 * deciding which apps a person may see.
 */
export declare function AppLauncher({ apps, currentID, homeUrl, homeName, label, className, placement, }: AppLauncherProps): import("react").JSX.Element;
