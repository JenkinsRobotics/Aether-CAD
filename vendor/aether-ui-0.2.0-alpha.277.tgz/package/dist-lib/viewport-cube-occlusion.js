function cubeAxisOccluders(facets, start, end = start) {
  const dx = end[0] - start[0], dy = end[1] - start[1];
  const lengthSquared = dx * dx + dy * dy;
  const depthDifference = (point) => {
    const t = lengthSquared > 1e-12 ? ((point[0] - start[0]) * dx + (point[1] - start[1]) * dy) / lengthSquared : 0;
    return point[2] - (start[2] + t * (end[2] - start[2]));
  };
  return facets.map((facet) => {
    const clipped = [];
    for (let i = 0; i < facet.length; i++) {
      const a = facet[i], b = facet[(i + 1) % facet.length];
      const da = depthDifference(a), db = depthDifference(b);
      const aInFront = da > 1e-9, bInFront = db > 1e-9;
      if (aInFront) clipped.push(a);
      if (aInFront !== bInFront) {
        const t = da / (da - db);
        clipped.push([a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]), a[2] + t * (b[2] - a[2])]);
      }
    }
    return clipped;
  }).filter((polygon) => polygon.length >= 3);
}
export {
  cubeAxisOccluders
};
