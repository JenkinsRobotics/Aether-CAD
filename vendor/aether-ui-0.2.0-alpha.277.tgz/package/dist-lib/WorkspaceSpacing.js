import { useMemo, useSyncExternalStore } from "react";
const DEFAULT_WORKSPACE_SPACING = Object.freeze({ margin: 10, clearance: 22 });
const KEY = "aether.workspace-spacing";
const EVENT = "aether-workspace-spacing";
function snapshot() {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}
function readWorkspaceSpacing(raw) {
  try {
    const value = JSON.parse(raw ?? "{}");
    const number = (key) => typeof value?.[key] === "number" && Number.isFinite(value[key]) ? Math.round(Math.max(0, Math.min(64, value[key]))) : DEFAULT_WORKSPACE_SPACING[key];
    return { margin: number("margin"), clearance: number("clearance") };
  } catch {
    return { ...DEFAULT_WORKSPACE_SPACING };
  }
}
function setWorkspaceSpacing(patch) {
  const next = readWorkspaceSpacing(JSON.stringify({ ...readWorkspaceSpacing(snapshot()), ...patch }));
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
  }
  window.dispatchEvent(new Event(EVENT));
}
function subscribe(listener) {
  window.addEventListener(EVENT, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(EVENT, listener);
    window.removeEventListener("storage", listener);
  };
}
function useWorkspaceSpacing() {
  const raw = useSyncExternalStore(subscribe, snapshot, () => null);
  return useMemo(() => readWorkspaceSpacing(raw), [raw]);
}
export {
  DEFAULT_WORKSPACE_SPACING,
  readWorkspaceSpacing,
  setWorkspaceSpacing,
  useWorkspaceSpacing
};
