import { jsx } from "react/jsx-runtime";
import "./IconButton.css";
function IconButton({ label, children, className, appearance = "rounded", size, ...rest }) {
  const classes = ["aui-icon-button"];
  if (className) classes.push(className);
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      className: classes.join(" "),
      "data-appearance": appearance === "glyph" || appearance === "cell" ? appearance : "rounded",
      "data-size": size,
      title: label,
      "aria-label": label,
      ...rest,
      children
    }
  );
}
export {
  IconButton
};
