/** Browser voice typing only; it never claims a provider voice conversation. */
export declare function AgentVoiceInput({ onText, onError, disabled }: {
    onText: (text: string) => void;
    onError: (message: string) => void;
    disabled?: boolean;
}): import("react").JSX.Element;
