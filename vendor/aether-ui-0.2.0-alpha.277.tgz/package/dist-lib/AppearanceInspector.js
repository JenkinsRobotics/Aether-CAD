import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Inspector, InspectorSection } from "./Inspector.js";
import { FieldRow } from "./FieldRow.js";
import { TextField } from "./TextField.js";
import { Slider } from "./Slider.js";
import { SegmentedControl } from "./SegmentedControl.js";
import "./ConceptInspectors.css";
function AppearanceInspector({ value, onChange, showTessellation = true }) {
  const [local, setLocal] = useState({ color: "#9dcfed", opacity: 100, tessellation: "auto" });
  const [mode, setMode] = useState("palette");
  const [draft, setDraft] = useState(null);
  const current = value ?? local;
  const update = (patch) => {
    const next = { ...current, ...patch };
    setLocal(next);
    onChange?.(next);
  };
  const colors = ["#000000", "#009dff", "#ff3045", "#ffffff", "#999999", "#ff9634", "#ffca00", "#c52dd9", "#55565b", "#447db2", "#51ad94", "#9dcfed", "#c85d36", "#e89b22", "#6659d4", "#b156a6"];
  const rgb = /^#[\da-f]{6}$/i.test(current.color) ? [1, 3, 5].map((n) => parseInt(current.color.slice(n, n + 2), 16)) : [0, 0, 0];
  return /* @__PURE__ */ jsx(Inspector, { children: /* @__PURE__ */ jsx("section", { "aria-label": "Appearance inspector", children: /* @__PURE__ */ jsxs(InspectorSection, { title: "Appearance", children: [
    /* @__PURE__ */ jsx(FieldRow, { label: "Mode", children: /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Appearance mode", value: mode, onChange: setMode, options: [{ id: "palette", label: "Palette" }, { id: "mixer", label: "Mixer" }] }) }),
    mode === "palette" ? /* @__PURE__ */ jsx("div", { className: "aui-appearance-swatches", children: colors.map((color) => /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Use color ${color}`, "aria-pressed": current.color === color, style: { background: color }, onClick: () => {
      setDraft(null);
      update({ color });
    }, children: current.color === color ? "\u2713" : null }, color)) }) : /* @__PURE__ */ jsx(FieldRow, { label: "Color", children: /* @__PURE__ */ jsx("input", { "aria-label": "Appearance color", type: "color", value: current.color, onChange: (e) => {
      setDraft(null);
      update({ color: e.target.value });
    } }) }),
    /* @__PURE__ */ jsx(FieldRow, { label: "Hex", children: /* @__PURE__ */ jsx(TextField, { "aria-label": "Hex", value: draft ?? current.color.toUpperCase(), "aria-invalid": draft !== null && !/^#[\da-f]{6}$/i.test(draft), onChange: (e) => {
      setDraft(e.target.value);
      if (/^#[\da-f]{6}$/i.test(e.target.value)) update({ color: e.target.value.toLowerCase() });
    }, onBlur: () => setDraft(null) }) }),
    /* @__PURE__ */ jsx(FieldRow, { label: "RGB", children: /* @__PURE__ */ jsx("output", { children: rgb.join(" \xB7 ") }) }),
    /* @__PURE__ */ jsx(FieldRow, { label: "Opacity", children: /* @__PURE__ */ jsx(Slider, { ariaLabel: "Appearance opacity", min: 0, max: 100, value: current.opacity, unit: "%", onChange: (opacity) => update({ opacity }) }) }),
    showTessellation && /* @__PURE__ */ jsx(FieldRow, { label: "Tessellation", children: /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Tessellation", value: current.tessellation, onChange: (id) => update({ tessellation: id }), options: [{ id: "auto", label: "Auto" }, { id: "high", label: "High" }] }) })
  ] }) }) });
}
export {
  AppearanceInspector
};
