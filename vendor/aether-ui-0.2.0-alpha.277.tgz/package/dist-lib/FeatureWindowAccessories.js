import helpIcon from "@aether/assets/icons/help.svg?raw";
import { createFeatureWindowHelp } from "./FeatureWindowHelp.js";
function createFeatureWindowAccessories(options) {
  const element = document.createElement("div");
  element.className = "aui-feature-accessories";
  const footer = document.createElement("div");
  footer.className = "aui-feature-footer";
  footer.setAttribute("role", "group");
  footer.setAttribute("aria-label", "Feature accessories");
  const button = (iconSvg, title, onToggle, active = false) => {
    const action = document.createElement("button");
    action.type = "button";
    action.className = "aui-feature-action-icon";
    action.title = title;
    action.setAttribute("aria-label", title);
    action.setAttribute("aria-pressed", String(active));
    action.innerHTML = iconSvg;
    for (const svg of action.querySelectorAll("svg")) {
      svg.setAttribute("aria-hidden", "true");
      svg.setAttribute("focusable", "false");
    }
    action.onclick = () => {
      const next = action.getAttribute("aria-pressed") !== "true";
      action.setAttribute("aria-pressed", String(next));
      onToggle(next);
    };
    return action;
  };
  const helpButton = button(helpIcon, "Help", (active) => {
    setHelpActive(active);
    options.onHelpToggle?.(active);
  }, options.helpActive);
  const help = createFeatureWindowHelp(options.title, helpButton, () => {
    setHelpActive(false);
    options.onHelpToggle?.(false);
  });
  const setHelpActive = (active) => {
    helpButton.setAttribute("aria-pressed", String(active));
    if (active) help.show();
    else help.hide();
  };
  if (options.help) {
    help.add(options.help.summary);
    if (options.help.steps?.length) {
      const steps = document.createElement("ol");
      for (const text of options.help.steps) {
        const step = document.createElement("li");
        step.textContent = text;
        steps.append(step);
      }
      help.add(steps);
    }
  }
  if (options.helpActive) queueMicrotask(() => {
    if (helpButton.isConnected) setHelpActive(true);
  });
  footer.append(helpButton);
  element.append(footer);
  element.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " " || event.key === "Escape") event.stopPropagation();
    if (event.key === "Escape" && helpButton.getAttribute("aria-pressed") === "true") {
      event.preventDefault();
      setHelpActive(false);
      options.onHelpToggle?.(false);
    }
  });
  return {
    element,
    /** Synchronize app-owned state without firing the user-toggle callback. */
    setHelpActive,
    addHelp: help.add,
    dispose: help.dispose,
    actionIcon(iconSvg, title, onToggle, active = false) {
      const action = button(iconSvg, title, onToggle, active);
      footer.insertBefore(action, helpButton);
      return action;
    }
  };
}
export {
  createFeatureWindowAccessories
};
