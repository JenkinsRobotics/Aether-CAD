import { type ReactNode } from 'react';
import type { DocumentElementTab } from './DocumentTabBar.js';
import { type DocumentTabControls } from './DocumentTabTray.js';
import './DocumentTabBrowser.css';
/** A browser row: a document tab plus an optional preview image URL. */
export type DocumentBrowserTab = DocumentElementTab & {
    thumbnail?: string;
};
/**
 * The document tray's contents as a side-panel browser (Fusion's Data panel,
 * Jonathan 2026-10-25): breadcrumbs, folders, previews, list or gallery. It
 * takes the tray's own controls, so adding, organizing, the per-tab menu and
 * drag to a folder or to reorder behave the same in both places.
 */
export declare function DocumentTabBrowser(props: Omit<DocumentTabControls, "tabs"> & {
    tabs: readonly DocumentBrowserTab[];
    title?: string;
    rootLabel: string;
    actions?: ReactNode;
}): import("react").JSX.Element;
