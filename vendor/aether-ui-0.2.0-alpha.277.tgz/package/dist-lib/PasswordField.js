import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { TextField } from "./TextField.js";
import { IconButton } from "./IconButton.js";
import { AetherIcon } from "./AetherIcon.js";
import "./WorkflowElements.css";
function PasswordField(props) {
  const [revealed, setRevealed] = useState(false);
  return /* @__PURE__ */ jsxs("span", { className: "aui-password-field", children: [
    /* @__PURE__ */ jsx(TextField, { ...props, type: revealed ? "text" : "password" }),
    /* @__PURE__ */ jsx(IconButton, { appearance: "glyph", label: revealed ? "Hide password" : "Show password", "aria-pressed": revealed, disabled: props.disabled, onClick: () => setRevealed((value) => !value), children: /* @__PURE__ */ jsx(AetherIcon, { name: revealed ? "hidden" : "view" }) })
  ] });
}
export {
  PasswordField
};
