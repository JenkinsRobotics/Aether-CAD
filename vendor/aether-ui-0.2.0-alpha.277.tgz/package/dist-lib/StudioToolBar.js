import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useMemo, useState } from "react";
import { FloatingToolbar, FloatingToolbarMenu } from "./FloatingToolbar.js";
import { AetherIcon } from "./AetherIcon.js";
import { Menu, MenuButton } from "./Menu.js";
import { IconButton } from "./IconButton.js";
import { ToolHelp } from "./ToolHelp.js";
const STUDIO_TOOLBAR_DENSITIES = [
  { id: "compact", label: "Compact" },
  { id: "standard", label: "Standard" },
  { id: "expanded", label: "Expanded" }
];
function StudioToolBar(props) {
  const [query, setQuery] = useState("");
  const [settingsMenu, setSettingsMenu] = useState(null);
  const density = props.density ?? props.defaultDensity ?? "standard";
  const settingsItems = [
    ...STUDIO_TOOLBAR_DENSITIES.map((entry, index) => ({ id: `density:${entry.id}`, label: entry.label, kind: "radio", checked: density === entry.id, heading: index === 0 ? "Density" : void 0 })),
    ...(props.moreItems ?? []).map((item, index) => index === 0 ? { ...item, separatorBefore: true, heading: item.heading ?? "Toolbar" } : item)
  ];
  const active = props.tabs.find((tab) => tab.id === props.activeTabID) ?? props.tabs[0];
  const groups = props.compactGroups ?? active?.groups ?? [];
  const all = useMemo(() => {
    const unique = /* @__PURE__ */ new Map();
    for (const tab of props.tabs) for (const group of tab.groups) for (const tool of group.tools) {
      unique.set(tool.id, tool);
      for (const variant of tool.variants ?? []) unique.set(variant.id, variant);
    }
    return [...unique.values()];
  }, [props.tabs]);
  const matches = query.trim() ? all.filter((tool) => tool.label.toLowerCase().includes(query.trim().toLowerCase())) : [];
  const run = (id) => {
    props.onCommand(id);
    setQuery("");
  };
  const categories = props.tabs.map((tab) => ({ id: tab.id, label: tab.label, kind: "radio", checked: active?.id === tab.id, disabled: tab.disabled }));
  const overflow = groups.flatMap((group) => group.menuItems?.length ? [{ id: `group:${group.id}`, label: group.label, children: group.menuItems }] : []);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "aui-studio-command-tools",
      "data-active-category": active?.id,
      "data-density": density,
      onContextMenu: (event) => {
        event.preventDefault();
        setSettingsMenu({ x: event.clientX, y: event.clientY });
      },
      children: [
        /* @__PURE__ */ jsx(
          Menu,
          {
            open: !!settingsMenu,
            anchor: settingsMenu,
            ariaLabel: "Toolbar settings",
            applicationCommands: false,
            items: settingsItems,
            onClose: () => setSettingsMenu(null),
            onSelect: (id) => {
              setSettingsMenu(null);
              if (id.startsWith("density:")) props.onDensityChange?.(id.slice(8));
              else props.onCommand(id);
            }
          }
        ),
        query.trim() && /* @__PURE__ */ jsx("div", { className: "aui-studio-command-results", role: "group", "aria-label": "Matching commands", children: matches.length ? matches.map((tool) => /* @__PURE__ */ jsxs("button", { type: "button", disabled: tool.disabled, title: tool.disabledReason, onClick: () => run(tool.id), children: [
          tool.icon,
          /* @__PURE__ */ jsx("span", { children: tool.label })
        ] }, tool.id)) : /* @__PURE__ */ jsx("span", { children: "No matching commands" }) }),
        /* @__PURE__ */ jsx(
          FloatingToolbar,
          {
            ariaLabel: active?.label ? `${active.label} tools` : "Workspace tools",
            className: "aui-studio-model-toolbar",
            groups: [],
            onAction: run,
            command: { value: query, onValueChange: setQuery, onSubmit: () => {
              if (matches.length === 1 && !matches[0].disabled) run(matches[0].id);
            }, shortcuts: props.commandShortcuts },
            leading: props.toolRow ?? /* @__PURE__ */ jsxs(Fragment, { children: [
              props.tabs.length > 1 && /* @__PURE__ */ jsx(FloatingToolbarMenu, { iconOnly: true, label: `Tool category: ${active?.label ?? "Tools"}`, items: categories, onSelect: props.onTabSelect, children: /* @__PURE__ */ jsx(AetherIcon, { name: "layers" }) }),
              groups.map((group, index) => /* @__PURE__ */ jsx("div", { className: "aui-floating-toolbar-group", role: "group", "aria-label": group.label, "data-separated": index > 0 || void 0, children: group.tools.map((tool) => /* @__PURE__ */ jsxs("span", { className: "aui-studio-tool-family", "data-tool-id": tool.id, children: [
                /* @__PURE__ */ jsx(ToolHelp, { label: tool.label, help: tool.help, disabledReason: tool.disabled ? tool.disabledReason : void 0, children: /* @__PURE__ */ jsx(IconButton, { label: tool.label, size: "large", appearance: "rounded", "aria-pressed": tool.active, disabled: tool.disabled, title: tool.disabledReason ?? tool.label, onClick: () => run(tool.id), children: tool.icon }) }),
                /* @__PURE__ */ jsx("span", { className: "aui-studio-tool-label", "aria-hidden": "true", children: tool.label }),
                !!tool.variants?.length && /* @__PURE__ */ jsx(
                  MenuButton,
                  {
                    className: "aui-studio-tool-variants",
                    label: `${tool.variants.find((variant) => variant.id === tool.id)?.label ?? tool.label} variants`,
                    placement: "top-start",
                    items: tool.variants.map((variant) => ({ id: variant.id, label: variant.label, icon: variant.icon, disabled: variant.disabled, disabledReason: variant.disabledReason, kind: "radio", checked: variant.id === (tool.selectedVariantID ?? tool.id) })),
                    onSelect: (id) => props.onVariantSelect ? props.onVariantSelect(tool.id, id) : run(id),
                    children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" })
                  }
                )
              ] }, tool.id)) }, group.id)),
              !!overflow.length && /* @__PURE__ */ jsx(FloatingToolbarMenu, { iconOnly: true, label: "All tools", items: overflow, onSelect: run, placement: "top-end", children: /* @__PURE__ */ jsx(AetherIcon, { name: "tools" }) }),
              !!props.moreItems?.length && /* @__PURE__ */ jsx(FloatingToolbarMenu, { iconOnly: true, label: props.moreLabel ?? "More tools", items: props.moreItems, onSelect: run, placement: "top-end", children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
            ] })
          }
        )
      ]
    }
  );
}
export {
  STUDIO_TOOLBAR_DENSITIES,
  StudioToolBar
};
