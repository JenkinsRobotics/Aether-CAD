import type { ReactNode } from "react";
export declare function PanelHeading({ children, actions, }: {
    children: ReactNode;
    actions?: ReactNode;
}): import("react").JSX.Element;
