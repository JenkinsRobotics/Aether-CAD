import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { createContext, useCallback, useContext, useEffect, useId, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { Popover } from "./Popover.js";
import "./SidePanelHeader.css";
const Register = createContext(null);
const Notices = createContext(/* @__PURE__ */ new Map());
function PanelNotifications({ children }) {
  const parent = useContext(Register);
  const [notices, setNotices] = useState(/* @__PURE__ */ new Map());
  const register = useCallback((id, notice) => setNotices((previous) => {
    if (!notice && !previous.has(id)) return previous;
    const next = new Map(previous);
    if (notice) next.set(id, notice);
    else next.delete(id);
    return next;
  }), []);
  if (parent) return /* @__PURE__ */ jsx(Fragment, { children });
  return /* @__PURE__ */ jsx(Register.Provider, { value: register, children: /* @__PURE__ */ jsx(Notices.Provider, { value: notices, children }) });
}
function PanelNotice({ message, children }) {
  const register = useContext(Register), id = useId();
  useEffect(() => {
    if (register) register(id, message || children ? { message, content: children } : null);
    return () => register?.(id, null);
  }, [register, id, message, children]);
  if (!register && (message || children)) return /* @__PURE__ */ jsx("div", { className: "aui-panel-notifications-fallback", children: /* @__PURE__ */ jsxs(PanelNotifications, { children: [
    /* @__PURE__ */ jsx(PanelNotificationButton, {}),
    /* @__PURE__ */ jsx(PanelNotice, { message, children })
  ] }) });
  return null;
}
function PanelNotificationButton() {
  const notices = useContext(Notices);
  const [anchor, setAnchor] = useState(null);
  const [open, setOpen] = useState(false);
  const entries = [...notices.values()];
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(IconButton, { label: "Panel notifications", title: entries.length ? `${entries.length} notification${entries.length === 1 ? "" : "s"}` : "No notifications", className: "aui-panel-notifications-button", "aria-haspopup": "dialog", "aria-expanded": open, onClick: (event) => {
      setAnchor(event.currentTarget);
      setOpen((value) => !value);
    }, children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "bell" }),
      entries.length > 0 && /* @__PURE__ */ jsx("span", { className: "aui-panel-notifications-dot" })
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-panel-notifications-live", role: "status", "aria-live": "polite", children: entries.map((entry) => entry.message).filter(Boolean).join(" ") }),
    /* @__PURE__ */ jsxs(Popover, { open, anchor, onClose: () => setOpen(false), ariaLabel: "Panel notifications", placement: "bottom-end", className: "aui-panel-notifications-popover", children: [
      /* @__PURE__ */ jsx("strong", { children: "Notifications" }),
      entries.length ? entries.map((entry, index) => /* @__PURE__ */ jsxs("div", { children: [
        entry.message && /* @__PURE__ */ jsx("p", { children: entry.message }),
        entry.content
      ] }, index)) : /* @__PURE__ */ jsx("p", { children: "No notifications." })
    ] })
  ] });
}
export {
  PanelNotice,
  PanelNotificationButton,
  PanelNotifications
};
