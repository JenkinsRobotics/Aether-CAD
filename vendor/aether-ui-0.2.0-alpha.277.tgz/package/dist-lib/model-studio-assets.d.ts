/** Original display artwork; seven named mesh groups, meters, Y up. */
export declare const modelStudioSample: {
    readonly id: "scifirobot";
    readonly name: "Scifirobot";
    readonly url: string;
    readonly filename: "scifirobot.glb";
    readonly format: "glb";
    readonly units: "meters";
    readonly kind: "mesh-study";
};
/** Native feature-authored reconstruction, generated and verified by Aether CAD. */
export declare const modelStudioFeatureSample: {
    readonly id: "scifirobot-parametric";
    readonly name: "Scifirobot";
    readonly url: string;
    readonly stepURL: string;
    readonly filename: "Scifirobot.acpart";
    readonly format: "acpart";
    readonly units: "millimeters";
    readonly kind: "feature-model";
};
