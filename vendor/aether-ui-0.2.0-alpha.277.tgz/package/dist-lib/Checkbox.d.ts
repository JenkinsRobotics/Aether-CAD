import type { InputHTMLAttributes, ReactNode } from "react";
export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
    label: ReactNode;
    description?: ReactNode;
    indeterminate?: boolean;
}
/** Checkbox with a consistent label/description and native form behavior. */
export declare function Checkbox({ label, description, indeterminate, className, ...inputProps }: CheckboxProps): import("react").JSX.Element;
