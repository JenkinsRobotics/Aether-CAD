import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Button } from "./Button.js";
import { TextField } from "./TextField.js";
import { NumberField } from "./NumberField.js";
import { SelectField } from "./SelectField.js";
import { Checkbox } from "./Checkbox.js";
import { FLOW_SIDES, FLOW_TONES, flowConnectionError, flowEndpoint, flowMoveNode, flowNodeBounds } from "./flow-diagram-model.js";
function FlowDiagramInspector({ value, selection, onChange, onSelect, onDelete, onNotice }) {
  const node = selection?.kind === "node" ? value.nodes.find((n) => n.id === selection.id) : selection?.kind === "port" ? value.nodes.find((n) => n.id === selection.nodeId) : void 0;
  const port = selection?.kind === "port" ? node?.ports.find((p) => p.id === selection.id) : void 0;
  const bounds = node ? flowNodeBounds(value, node) : void 0;
  const edge = selection?.kind === "connection" ? value.connections.find((e) => e.id === selection.id) : void 0;
  const editNode = (patch, field) => node && onChange({ ...value, nodes: value.nodes.map((n) => n.id === node.id ? { ...n, ...patch } : n) }, { mergeKey: field ? `node:${node.id}:${field}` : void 0 });
  const editPort = (patch, field) => node && port && editNode({ ports: node.ports.map((p) => p.id === port.id ? { ...p, ...patch } : p) }, field ? `port:${port.id}:${field}` : void 0);
  const editEdge = (patch, field) => edge && onChange({ ...value, connections: value.connections.map((e) => e.id === edge.id ? { ...e, ...patch } : e) }, { mergeKey: field ? `connection:${edge.id}:${field}` : void 0 });
  const colors = FLOW_TONES.map((tone) => ({ value: tone, label: tone[0].toUpperCase() + tone.slice(1) }));
  const notes = (text, onEdit) => /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
    "Notes",
    /* @__PURE__ */ jsx("textarea", { className: "aui-text-field", "aria-label": "Notes", maxLength: 4e3, rows: 3, value: text, onChange: (event) => onEdit(event.target.value), placeholder: "Describe this part of the flow\u2026" })
  ] });
  const addPort = (direction) => {
    if (!node || node.ports.length >= 40) return;
    const added = { id: crypto.randomUUID(), label: `${direction === "input" ? "Input" : "Output"} ${node.ports.length + 1}`, direction, side: direction === "input" ? "left" : "right", offset: 0.5 };
    editNode({ ports: [...node.ports, added] });
    onSelect({ kind: "port", nodeId: node.id, id: added.id });
  };
  const endpoints = (direction) => value.nodes.flatMap((n) => n.ports.filter((p) => p.direction === direction).map((p) => ({ value: JSON.stringify([n.id, p.id]), label: `${n.label} / ${p.label}` })));
  const reconnect = (which, encoded) => {
    if (!edge) return;
    const [nodeId, portId] = JSON.parse(encoded);
    const endpoint = { nodeId, portId };
    const error = flowConnectionError(value, which === "source" ? endpoint : edge.source, which === "target" ? endpoint : edge.target, edge.id);
    if (error) {
      onNotice(error);
      return;
    }
    editEdge({ [which]: endpoint });
    onNotice("Connection endpoint updated.");
  };
  return /* @__PURE__ */ jsxs("aside", { className: "aui-flow-editor-inspector", "aria-label": "Diagram inspector", children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsx("strong", { children: port ? "Connection point" : node ? "Node" : edge ? "Connection" : "Diagram" }),
      selection && /* @__PURE__ */ jsx(Button, { onClick: () => onSelect(null), children: "Done" })
    ] }),
    !node && !edge && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("p", { children: "Select a node, point or line to edit it." }),
      /* @__PURE__ */ jsx("p", { children: "Drag nodes to reposition them. Drag connection points around a node\u2019s edge. Use Connect to join an output to an input." }),
      /* @__PURE__ */ jsx("p", { children: "Arrow keys move selected nodes; Shift moves by 10. Escape cancels a drag or pending connection." })
    ] }),
    node && !port && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "Label",
        /* @__PURE__ */ jsx(TextField, { "aria-label": "Node label", maxLength: 160, value: node.label, onChange: (e) => editNode({ label: e.target.value }, "label") })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "Detail",
        /* @__PURE__ */ jsx(TextField, { "aria-label": "Node detail", maxLength: 160, value: node.detail, onChange: (e) => editNode({ detail: e.target.value }, "detail") })
      ] }),
      notes(node.notes, (text) => editNode({ notes: text }, "notes")),
      /* @__PURE__ */ jsxs("div", { className: "aui-flow-editor-pair", children: [
        /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
          "X",
          /* @__PURE__ */ jsx(NumberField, { "aria-label": "Node X", value: node.x, min: bounds.minX, max: bounds.maxX, onCommit: (x) => onChange(flowMoveNode(value, node.id, { x, y: node.y })) })
        ] }),
        /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
          "Y",
          /* @__PURE__ */ jsx(NumberField, { "aria-label": "Node Y", value: node.y, min: bounds.minY, max: bounds.maxY, onCommit: (y) => onChange(flowMoveNode(value, node.id, { x: node.x, y })) })
        ] }),
        /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
          "Width",
          /* @__PURE__ */ jsx(NumberField, { "aria-label": "Node width", value: node.width, min: node.kind === "processor" ? 120 : 16, max: value.width - node.x, onCommit: (width) => editNode({ width }) })
        ] }),
        /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
          "Height",
          /* @__PURE__ */ jsx(NumberField, { "aria-label": "Node height", value: node.height, min: node.kind === "processor" ? 96 : 20, max: value.height - node.y, onCommit: (height) => editNode({ height }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "Color",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Node color", value: node.tone, options: colors, onChange: (e) => editNode({ tone: e.target.value }) })
      ] }),
      /* @__PURE__ */ jsxs("strong", { children: [
        "Connection points \xB7 ",
        node.ports.length
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-flow-editor-port-list", children: node.ports.map((p) => /* @__PURE__ */ jsxs(Button, { onClick: () => onSelect({ kind: "port", nodeId: node.id, id: p.id }), children: [
        p.label,
        /* @__PURE__ */ jsx("span", { children: p.direction })
      ] }, p.id)) }),
      /* @__PURE__ */ jsxs("div", { className: "aui-flow-editor-actions", children: [
        /* @__PURE__ */ jsx(Button, { disabled: node.ports.length >= 40, onClick: () => addPort("input"), children: "Add input" }),
        /* @__PURE__ */ jsx(Button, { disabled: node.ports.length >= 40, onClick: () => addPort("output"), children: "Add output" })
      ] })
    ] }),
    node && port && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs(Button, { onClick: () => onSelect({ kind: "node", id: node.id }), children: [
        "Back to ",
        node.label
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "Label",
        /* @__PURE__ */ jsx(TextField, { "aria-label": "Point label", maxLength: 160, value: port.label, onChange: (e) => editPort({ label: e.target.value }, "label") })
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        port.direction === "input" ? "Input" : "Output",
        " \xB7 ",
        value.connections.filter((e) => [e.source, e.target].some((end) => end.nodeId === node.id && end.portId === port.id)).length,
        " attached connections"
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "Side",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Point side", value: port.side, options: FLOW_SIDES.map((side) => ({ value: side, label: side })), onChange: (e) => editPort({ side: e.target.value }) })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "Position along edge",
        /* @__PURE__ */ jsx(NumberField, { "aria-label": "Point position", value: Math.round(port.offset * 100), min: 0, max: 100, unit: "%", onCommit: (offset) => editPort({ offset: offset / 100 }) })
      ] }),
      /* @__PURE__ */ jsx("p", { children: "Drag the point to another edge, or enter an exact position. Attached connections follow it." })
    ] }),
    edge && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "Label",
        /* @__PURE__ */ jsx(TextField, { "aria-label": "Connection label", value: edge.label, maxLength: 160, onChange: (e) => editEdge({ label: e.target.value }, "label") })
      ] }),
      notes(edge.notes, (text) => editEdge({ notes: text }, "notes")),
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "From",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Connection source", value: JSON.stringify([edge.source.nodeId, edge.source.portId]), options: endpoints("output"), onChange: (e) => reconnect("source", e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "To",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Connection target", value: JSON.stringify([edge.target.nodeId, edge.target.portId]), options: endpoints("input"), onChange: (e) => reconnect("target", e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "aui-flow-editor-field", children: [
        "Color",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Connection color", value: edge.tone, options: colors, onChange: (e) => editEdge({ tone: e.target.value }) })
      ] }),
      /* @__PURE__ */ jsx(Checkbox, { label: "Dashed connection", checked: edge.dashed, onChange: (e) => editEdge({ dashed: e.target.checked }) }),
      /* @__PURE__ */ jsxs("strong", { children: [
        "Route bends \xB7 ",
        edge.waypoints.length
      ] }),
      edge.waypoints.map((point, index) => /* @__PURE__ */ jsxs("div", { className: "aui-flow-editor-bend", children: [
        /* @__PURE__ */ jsx(NumberField, { "aria-label": `Bend ${index + 1} X`, value: point.x, min: 0, max: value.width, onCommit: (x) => editEdge({ waypoints: edge.waypoints.map((p, i) => i === index ? { ...p, x } : p) }) }),
        /* @__PURE__ */ jsx(NumberField, { "aria-label": `Bend ${index + 1} Y`, value: point.y, min: 0, max: value.height, onCommit: (y) => editEdge({ waypoints: edge.waypoints.map((p, i) => i === index ? { ...p, y } : p) }) }),
        /* @__PURE__ */ jsx(Button, { "aria-label": `Remove bend ${index + 1}`, onClick: () => editEdge({ waypoints: edge.waypoints.filter((_, i) => i !== index) }), children: "\xD7" })
      ] }, index)),
      /* @__PURE__ */ jsxs("div", { className: "aui-flow-editor-actions", children: [
        /* @__PURE__ */ jsx(Button, { disabled: edge.waypoints.length >= 20, onClick: () => {
          const a = edge.waypoints.at(-1) ?? flowEndpoint(value, edge.source).point, b = flowEndpoint(value, edge.target).point;
          editEdge({ waypoints: [...edge.waypoints, { x: Math.round((a.x + b.x) / 2), y: Math.round((a.y + b.y) / 2) }] });
        }, children: "Add bend" }),
        /* @__PURE__ */ jsx(Button, { disabled: !edge.waypoints.length, onClick: () => editEdge({ waypoints: [] }), children: "Auto route" })
      ] })
    ] }),
    (node || edge) && /* @__PURE__ */ jsxs(Button, { className: "aui-flow-editor-delete", onClick: onDelete, children: [
      "Delete ",
      port ? "point" : node ? "node" : "connection"
    ] }),
    node && /* @__PURE__ */ jsx("small", { children: "Deleting a node or point also removes its attached connections. Undo restores them." })
  ] });
}
export {
  FlowDiagramInspector
};
