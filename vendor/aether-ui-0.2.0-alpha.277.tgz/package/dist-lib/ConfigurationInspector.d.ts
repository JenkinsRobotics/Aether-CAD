import "./ConceptInspectors.css";
export interface ConfigurationKind {
    id: string;
    label: string;
    detail?: string;
    offset?: boolean;
    rotation?: boolean;
    limits?: boolean;
}
export interface ConfigurationValue {
    name: string;
    kind: string;
    connector?: string;
    offset: boolean;
    limits: boolean;
    simulation: boolean;
    x: number;
    y: number;
    z: number;
    angle: number;
    min: number;
    max: number;
}
export interface ConfigurationInspectorProps {
    kinds: readonly ConfigurationKind[];
    value?: ConfigurationValue;
    initialValue?: ConfigurationValue;
    connectors?: readonly {
        value: string;
        label: string;
    }[];
    offsetUnit?: string;
    rotationUnit?: string;
    onChange?: (value: ConfigurationValue) => void;
    onApply?: (value: ConfigurationValue) => void;
    onCancel?: () => void;
    title?: string;
}
/** Presentation only. Kind capabilities and units are supplied by the owner. */
export declare function ConfigurationInspector({ kinds, value, initialValue, connectors, offsetUnit, rotationUnit, onChange, onApply, onCancel, title }: ConfigurationInspectorProps): import("react").JSX.Element;
