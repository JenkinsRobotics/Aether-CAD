import { jsx, jsxs } from "react/jsx-runtime";
import { useId } from "react";
import { appMarkSources } from "@aether/assets/branding/marks/sources";
import { appWordmarkData } from "@aether/assets/branding/wordmarks/data";
import "./AppWordmark.css";
function resolveAppWordmark(identity) {
  const value = identity.trim().toLowerCase();
  return Object.keys(appWordmarkData.apps).find((app) => app === value || `aether ${appWordmarkData.apps[app].name}`.toLowerCase() === value);
}
function AppWordmark({ app, size = 36, appearance = "auto", decorative = false, className, style, ...props }) {
  const id = `aether-wordmark-${useId().replaceAll(":", "")}`;
  const item = appWordmarkData.apps[app], { layout, word } = appWordmarkData;
  const colors = { "--aui-wordmark-light-start": item.accents[0], "--aui-wordmark-light-end": item.accents[1], "--aui-wordmark-dark-start": item.accents[2], "--aui-wordmark-dark-end": item.accents[3] };
  const suffixX = layout.textX + word.advance * layout.scale + layout.gap;
  return /* @__PURE__ */ jsxs(
    "svg",
    {
      ...props,
      className: ["aui-app-wordmark", className].filter(Boolean).join(" "),
      "data-app": app,
      "data-appearance": appearance,
      width: item.width * size / layout.height,
      height: size,
      viewBox: `0 0 ${item.width} ${layout.height}`,
      preserveAspectRatio: "xMinYMid meet",
      role: decorative ? void 0 : "img",
      "aria-label": decorative ? void 0 : `Aether ${item.name}`,
      "aria-hidden": decorative || void 0,
      focusable: "false",
      style: { ...colors, ...style },
      children: [
        /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsxs("linearGradient", { id, x1: "0", y1: "1", x2: "0", y2: "0", children: [
          /* @__PURE__ */ jsx("stop", { className: "aui-app-wordmark-accent-start" }),
          /* @__PURE__ */ jsx("stop", { className: "aui-app-wordmark-accent-end", offset: "1" })
        ] }) }),
        /* @__PURE__ */ jsx("image", { href: appMarkSources[app], width: layout.markSize, height: layout.markSize }),
        /* @__PURE__ */ jsx("path", { className: "aui-app-wordmark-name", d: word.path, transform: `translate(${layout.textX} ${layout.baseline}) scale(${layout.scale} -${layout.scale})` }),
        /* @__PURE__ */ jsx("path", { d: item.outline.path, transform: `translate(${suffixX} ${layout.baseline}) scale(${layout.scale} -${layout.scale})`, fill: `url(#${id})` })
      ]
    }
  );
}
export {
  AppWordmark,
  resolveAppWordmark
};
