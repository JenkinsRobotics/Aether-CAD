import { jsx } from "react/jsx-runtime";
import { CollectionFilter } from "./CollectionFilter.js";
function ReviewFilterBar({ subject, query, onQueryChange, groups, actions = [], onAction, onReset }) {
  const active = groups.filter((group) => group.value !== group.defaultValue);
  const summary = active.map((group) => `${group.label}: ${group.options.find((option) => option.value === group.value)?.label ?? group.value}`).join(" \xB7 ");
  const handlers = /* @__PURE__ */ new Map();
  const items = groups.map((group) => ({
    id: group.id,
    label: `${group.label}: ${group.options.find((option) => option.value === group.value)?.label ?? group.value}`,
    children: group.options.map((option) => {
      const id = `${group.id}:${option.value}`;
      handlers.set(id, () => group.onChange(option.value));
      return { id, label: option.label, kind: "radio", checked: option.value === group.value };
    })
  }));
  items.push(...actions, { id: "reset", label: "Clear filters", separatorBefore: true });
  return /* @__PURE__ */ jsx(
    CollectionFilter,
    {
      ariaLabel: `Search ${subject}`,
      query,
      onQueryChange,
      placeholder: summary || `Search ${subject}\u2026`,
      menu: {
        label: `${subject === "comments" ? "Comment" : "Task"} filters`,
        items,
        active: !!active.length,
        summary: summary || `All ${subject}`,
        onSelect: (id) => {
          if (id === "reset") {
            onQueryChange("");
            onReset();
          } else if (handlers.has(id)) handlers.get(id)();
          else onAction?.(id);
        }
      }
    }
  );
}
export {
  ReviewFilterBar
};
