/** What a file list shows about the file you picked.
 *
 *  Two pieces, both driven by the app's own data: the command bar that appears
 *  above the table once something is selected, and the details pane beside it —
 *  a preview, who has access, recent activity and the file's own information.
 *  Presentation only; the app loads the data and decides what the actions do.
 */
import { type ReactNode } from "react";
import { type MenuItem } from "./Menu.js";
import { type PreviewKind } from "./FilePreview.js";
import "./FileDetails.css";
/** Someone the file is shared with. */
export interface FileAccess {
    id: string;
    name: string;
    role: string;
}
/** One thing that happened to the file. */
export interface FileActivity {
    id: string | number;
    /** The host's own verb for what happened. */
    action: string;
    author: string;
    /** Seconds since the epoch, as the host reports times. */
    created: number;
}
export declare function fileEventLabel(action: string): string;
export interface FileInformationRow {
    label: string;
    value: ReactNode;
}
/**
 * The selection command bar: the first few actions as buttons, the rest behind
 * one overflow menu. The items are the same ones the row's own context menu
 * uses, so an action never means two different things.
 */
export declare function FileCommandBar({ items, onSelect, inline, label, trailing }: {
    items: readonly MenuItem[];
    onSelect: (id: string) => void;
    /** How many actions to show as buttons before the overflow menu. */
    inline?: number;
    label?: string;
    trailing?: ReactNode;
}): import("react").JSX.Element;
export interface FileDetailsProps {
    name: string;
    /** The file's own icon, drawn by the app — it knows its document kinds. */
    icon?: ReactNode;
    subtitle?: ReactNode;
    /** An image to stand in for the icon, and the kind that decides whether it can. */
    previewURL?: string;
    previewKind?: PreviewKind;
    /** Opens the full preview. Omitted where the file has none. */
    onPreview?: () => void;
    actions?: ReactNode;
    /** Who else can reach the file. Undefined where the viewer may not ask. */
    access?: readonly FileAccess[];
    /** What the sharing amounts to in words, shown whether or not grants loaded. */
    accessNote?: ReactNode;
    onManageAccess?: () => void;
    /** Recent events, newest first. Undefined while they load. */
    activity?: readonly FileActivity[];
    information: readonly FileInformationRow[];
}
export declare function FileDetails({ name, icon, subtitle, previewURL, previewKind, onPreview, actions, access, accessNote, onManageAccess, activity, information, }: FileDetailsProps): import("react").JSX.Element;
