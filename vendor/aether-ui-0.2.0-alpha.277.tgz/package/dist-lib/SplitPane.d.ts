import type { CSSProperties, ReactNode } from "react";
export interface SplitPaneProps {
    primary: ReactNode;
    secondary: ReactNode;
    orientation?: "horizontal" | "vertical";
    primarySize?: number;
    defaultPrimarySize?: number;
    minPrimarySize?: number;
    maxPrimarySize?: number;
    collapsed?: boolean;
    defaultCollapsed?: boolean;
    collapseSide?: "primary" | "secondary";
    onResize?: (primarySize: number) => void;
    onCollapsedChange?: (collapsed: boolean) => void;
    separatorLabel?: string;
    className?: string;
    style?: CSSProperties;
}
export declare function SplitPane({ primary, secondary, orientation, primarySize, defaultPrimarySize, minPrimarySize, maxPrimarySize, collapsed, defaultCollapsed, collapseSide, onResize, onCollapsedChange, separatorLabel, className, style, }: SplitPaneProps): import("react").JSX.Element;
