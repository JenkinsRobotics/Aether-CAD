import { type MouseEvent, type ReactNode } from "react";
import "./ApplicationFileTable.css";
export interface ApplicationFileRow {
    id: string;
    name: string;
    icon: ReactNode;
    location?: ReactNode;
    date: ReactNode;
    owner: ReactNode;
}
export interface ApplicationFileColumn<T> {
    id: string;
    label: string;
    render: (row: T) => ReactNode;
    sortable?: boolean;
    /** Hide lower-priority metadata on narrow screens. */
    secondary?: boolean;
}
/** App-home file presentation. Storage, permissions and commands belong to the caller. */
export declare function ApplicationFileTable<T extends ApplicationFileRow>({ rows, selectedIds, onSelect, onOpen, onContextMenu, renderActions, onToggle, onSelectAll, dateLabel, label, columns, compact, sort, onSort, onSelectedIdsChange, }: {
    rows: readonly T[];
    selectedIds: ReadonlySet<string>;
    onSelectedIdsChange?: (selected: Set<string>) => void;
    onSelect: (row: T, event: MouseEvent) => void;
    onOpen: (row: T) => void;
    onContextMenu?: (row: T, event: MouseEvent) => void;
    renderActions?: (row: T) => ReactNode;
    onToggle?: (row: T, selected: boolean) => void;
    onSelectAll?: (selected: boolean) => void;
    dateLabel?: string;
    label?: string;
    columns?: readonly ApplicationFileColumn<T>[];
    compact?: boolean;
    sort?: {
        id: string;
        ascending: boolean;
    };
    onSort?: (id: string) => void;
}): import("react").JSX.Element;
