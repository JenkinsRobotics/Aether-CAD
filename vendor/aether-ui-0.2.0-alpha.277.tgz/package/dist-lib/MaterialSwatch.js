import { jsx } from "react/jsx-runtime";
import "./MaterialSwatch.css";
function MaterialSwatch({ color, roughness = 0.5, size = "small", label }) {
  return /* @__PURE__ */ jsx(
    "span",
    {
      className: "aui-material-swatch",
      "data-size": size,
      role: label ? "img" : void 0,
      "aria-label": label,
      "aria-hidden": label ? void 0 : true,
      style: { "--material-swatch-color": color, "--material-swatch-shine": 1 - Math.max(0, Math.min(1, roughness)) }
    }
  );
}
export {
  MaterialSwatch
};
