import type { AgentInteraction } from './AgentServices.js';
export type AgentMode = 'agent' | 'ask' | 'plan';
export declare const agentModes: readonly [{
    readonly id: "agent";
    readonly label: "Agent";
    readonly description: "Inspect and edit with enabled tools.";
}, {
    readonly id: "ask";
    readonly label: "Ask";
    readonly description: "Answer questions without changing the workspace.";
}, {
    readonly id: "plan";
    readonly label: "Plan";
    readonly description: "Inspect and propose steps without making changes.";
}];
export declare function agentModeContext(context: string, mode: AgentMode): string;
/** Limit both the advertised tools and the actual local executor for this turn. */
export declare function agentModeInteraction(interaction: AgentInteraction | undefined, mode: AgentMode, disabled: readonly string[]): AgentInteraction | undefined;
