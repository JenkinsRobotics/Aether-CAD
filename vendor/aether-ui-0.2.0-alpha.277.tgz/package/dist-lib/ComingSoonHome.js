import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { CollapsibleSidebar, SidebarLabel } from "./CollapsibleSidebar.js";
import { AppearanceToggle } from "./StudioChrome.js";
import { ThemeMenu } from "./ThemeMenu.js";
import { EmptyState } from "./EmptyState.js";
import { ApplicationWelcome } from "./ApplicationWelcome.js";
import { ApplicationSettings } from "./ApplicationChrome.js";
import { ApplicationSidebar } from "./ApplicationSidebar.js";
import "./ComingSoonHome.css";
function ComingSoonHome({ id, name, description, icon, artwork, wideArtwork, homeUrl, suiteUrl, suiteName, navigation = "header" }) {
  return /* @__PURE__ */ jsxs("div", { className: `aui-coming-home${navigation === "sidebar" ? " aui-coming-home--sidebar" : ""}`, children: [
    navigation === "header" && /* @__PURE__ */ jsxs("header", { className: "aui-coming-top", children: [
      /* @__PURE__ */ jsx("a", { href: homeUrl, "aria-label": `${name} home`, children: icon }),
      /* @__PURE__ */ jsx("strong", { children: name }),
      /* @__PURE__ */ jsx("span", { className: "aui-coming-status", children: "Coming soon" }),
      /* @__PURE__ */ jsxs("div", { className: "aui-coming-account", children: [
        /* @__PURE__ */ jsx(ThemeMenu, {}),
        /* @__PURE__ */ jsx(AppearanceToggle, {}),
        /* @__PURE__ */ jsx("div", { "data-aether-account": "" })
      ] })
    ] }),
    navigation === "sidebar" ? /* @__PURE__ */ jsx(ApplicationSidebar, { id: `${id}-home`, name, icon, homeUrl, children: /* @__PURE__ */ jsxs("section", { children: [
      /* @__PURE__ */ jsx("h2", { className: "aui-application-sidebar-caption", children: /* @__PURE__ */ jsx(SidebarLabel, { children: "Workspace" }) }),
      /* @__PURE__ */ jsxs("nav", { "aria-label": `${name} navigation`, children: [
        /* @__PURE__ */ jsxs("a", { href: homeUrl, "aria-current": "page", title: "Home", "aria-label": "Home", children: [
          /* @__PURE__ */ jsx(AetherIcon, { name: "home" }),
          /* @__PURE__ */ jsx(SidebarLabel, { children: "Home" })
        ] }),
        /* @__PURE__ */ jsxs("a", { href: suiteUrl, title: suiteName, "aria-label": suiteName, children: [
          /* @__PURE__ */ jsx(AetherIcon, { name: "items" }),
          /* @__PURE__ */ jsx(SidebarLabel, { children: suiteName })
        ] })
      ] })
    ] }) }) : /* @__PURE__ */ jsx(CollapsibleSidebar, { id: `${id}-home`, ariaLabel: `${name} sidebar`, className: "aui-coming-nav", children: /* @__PURE__ */ jsxs("nav", { "aria-label": `${name} navigation`, children: [
      /* @__PURE__ */ jsxs("a", { href: homeUrl, "aria-current": "page", title: "Home", "aria-label": "Home", children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "home" }),
        /* @__PURE__ */ jsx(SidebarLabel, { children: "Home" })
      ] }),
      /* @__PURE__ */ jsxs("a", { href: suiteUrl, title: suiteName, "aria-label": suiteName, children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "items" }),
        /* @__PURE__ */ jsx(SidebarLabel, { children: suiteName })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("main", { className: "aui-coming-main", children: [
      /* @__PURE__ */ jsx(ApplicationWelcome, { id, name, description, artwork, wideArtwork, badge: "Coming soon" }),
      /* @__PURE__ */ jsxs("section", { className: "aui-coming-library", "aria-labelledby": `${id}-work`, children: [
        /* @__PURE__ */ jsx("h2", { id: `${id}-work`, children: "Your workspace" }),
        /* @__PURE__ */ jsx(EmptyState, { title: "Room for your next idea", description: "Creation tools and your document library are coming soon.", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder", width: 42, height: 42 }) })
      ] })
    ] }),
    navigation === "sidebar" && /* @__PURE__ */ jsx(ApplicationSettings, { name })
  ] });
}
export {
  ComingSoonHome
};
