import { useEffect, useLayoutEffect, useState } from "react";
function read(key) {
  try {
    const raw = key ? JSON.parse(localStorage.getItem(`${key}.sidebar-sizes`) ?? "{}") : {};
    const result = {};
    for (const side of ["left", "right"]) {
      const size = {};
      for (const dimension of ["width", "height"]) {
        const value = raw?.[side]?.[dimension];
        if (typeof value === "number" && Number.isFinite(value) && value >= 72) size[dimension] = value;
      }
      result[side] = size;
    }
    return result;
  } catch {
    return {};
  }
}
function useSidebarSizes(storageKey, area) {
  const [availableWidth, setAvailableWidth] = useState(1200);
  useLayoutEffect(() => {
    const node = area?.current;
    if (!node) return;
    const measure = () => setAvailableWidth(node.clientWidth || 1200);
    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(node);
    return () => observer?.disconnect();
  }, [area]);
  const [sizes, setSizes] = useState(() => read(storageKey));
  useEffect(() => {
    setSizes(read(storageKey));
  }, [storageKey]);
  const update = (side, patch) => setSizes((old) => {
    const next = { ...old, [side]: { ...old[side], ...patch } };
    try {
      if (storageKey) localStorage.setItem(`${storageKey}.sidebar-sizes`, JSON.stringify(next));
    } catch {
    }
    return next;
  });
  return { sizes, update, availableWidth };
}
export {
  useSidebarSizes
};
