import { type ReactNode } from "react";
import { type WorkspaceShellProps } from "./WorkspaceShell.js";
import "./StudioAppFrame.css";
export interface StudioWorkspaceProps extends Omit<WorkspaceShellProps, "preset" | "design"> {
    preset?: WorkspaceShellProps["preset"];
    /** Workspace selection and view-state buttons; never document/app identity. */
    workspaceControls?: ReactNode;
    /** Dense specialist workspaces may retain a top ribbon. */
    toolPosition?: "top" | "bottom";
}
/** Shared floating cards, matched side widths and center tool trays. */
export declare function StudioWorkspace({ preset, workspaceControls, toolPosition, toolbar, centerBottom, ...props }: StudioWorkspaceProps): import("react").JSX.Element;
