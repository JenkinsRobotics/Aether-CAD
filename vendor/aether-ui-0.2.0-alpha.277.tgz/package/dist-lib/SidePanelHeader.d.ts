import type { ReactNode } from 'react';
import { type AetherIconName } from './AetherIcon.js';
import './SidePanelHeader.css';
/** One title, icon and action treatment for the workspace's auxiliary panels. */
export declare function SidePanelHeader({ title, icon, actions }: {
    title: string;
    icon: AetherIconName;
    actions?: ReactNode;
}): import("react").JSX.Element;
