import { jsx, jsxs } from "react/jsx-runtime";
import { DashboardCard } from "./DashboardCards.js";
import { TextField } from "./TextField.js";
import { StructureStep } from "./StructureStep.js";
import { Button } from "./Button.js";
import "./WorkflowWidgets.css";
function TemplateEditor({ stage, name, example, steps, onNameChange, onExampleChange, onImport, onSave, onCancel }) {
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title: stage === "import" ? "Import framework" : "Confirm structure", className: "aui-workflow", children: /* @__PURE__ */ jsxs("form", { className: "aui-workflow-stack", onSubmit: (e) => {
    e.preventDefault();
    if (stage === "import") onImport();
    else onSave();
  }, children: [
    /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Framework name",
      /* @__PURE__ */ jsx(TextField, { required: true, value: name, onChange: (e) => onNameChange(e.target.value) })
    ] }),
    stage === "import" ? /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
      "Example message",
      /* @__PURE__ */ jsx("textarea", { required: true, value: example, onChange: (e) => onExampleChange(e.target.value), placeholder: "Enter a sample message to extract its structure" })
    ] }) : /* @__PURE__ */ jsx("ol", { className: "aui-workflow-steps", children: steps.map((step, index) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(StructureStep, { ...step, position: index + 1 }) }, step.id)) }),
    /* @__PURE__ */ jsxs("div", { className: "aui-workflow-actions", children: [
      /* @__PURE__ */ jsx(Button, { type: "submit", primary: true, disabled: stage === "structure" && !steps.length, children: stage === "import" ? "Import structure" : "Save framework" }),
      /* @__PURE__ */ jsx(Button, { appearance: "flat", onClick: onCancel, children: "Cancel" })
    ] })
  ] }) });
}
export {
  TemplateEditor
};
