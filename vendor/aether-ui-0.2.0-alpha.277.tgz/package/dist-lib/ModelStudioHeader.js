import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { AppMark } from "./AppMark.js";
import { AppWordmark } from "./AppWordmark.js";
import { Button } from "./Button.js";
import { CommandPalette } from "./CommandPalette.js";
import { DocumentBar } from "./DocumentBar.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
import "./ModelStudioHeader.css";
import "./ModelStudioComposition.css";
const APP_NAMES = { cad: "Aether CAD", sketch: "Aether Sketch", map: "Aether Map", io: "Aether IO" };
function ModelStudioHeader({ app = "cad", title = "Model Studio", homeUrl = `/${app}/`, onHome, name, workspaceName, commands, onAction, utilities }) {
  const [search, setSearch] = useState(false);
  useEffect(() => {
    const key = (event) => {
      if (!(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== "k") return;
      if (event.target instanceof Element && event.target.closest('[role="dialog"], [role="menu"]')) return;
      event.preventDefault();
      setSearch(true);
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, []);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(DocumentBar, { variant: "transparent", windowChrome: false, className: "ps-app-header", leading: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("a", { className: "ps-header-home", href: homeUrl, onClick: onHome, "aria-label": `${APP_NAMES[app]} home`, title: `${APP_NAMES[app]} home`, children: [
        /* @__PURE__ */ jsx(AppWordmark, { app, size: 32, appearance: "dark", decorative: true }),
        /* @__PURE__ */ jsx("span", { className: "ps-header-mark", "aria-hidden": "true", children: /* @__PURE__ */ jsx(AppMark, { app, size: 28 }) })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "ps-header-divider", "aria-hidden": "true" }),
      /* @__PURE__ */ jsx("strong", { className: "ps-header-title", title: name, children: name }),
      /* @__PURE__ */ jsxs(MenuButton, { label: `Workspace version: ${workspaceName}`, className: "ps-header-workspace", items: [
        { id: "current", label: workspaceName, kind: "radio", checked: true },
        { id: "file:properties", label: "Workspace properties\u2026", separatorBefore: true }
      ], onSelect: (id) => {
        if (id !== "current") onAction(id);
      }, children: [
        workspaceName,
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" })
      ] }),
      /* @__PURE__ */ jsx(IconButton, { label: "Share document link", size: "medium", disabled: true, title: "Save to Aether Studio to obtain a shareable document link.", children: /* @__PURE__ */ jsx(AetherIcon, { name: "link" }) }),
      /* @__PURE__ */ jsxs("span", { className: "ps-header-local", children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "cloud" }),
        "Local preview"
      ] })
    ] }), trailing: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs(Button, { className: "ps-header-search", "aria-label": "Search tools, features, or help", onClick: () => setSearch(true), children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "search" }),
        /* @__PURE__ */ jsx("span", { children: "Search tools, features, or help\u2026" }),
        /* @__PURE__ */ jsx("kbd", { children: "\u2318 K" })
      ] }),
      utilities
    ] }) }),
    /* @__PURE__ */ jsx(CommandPalette, { open: search, title: `Search ${title}`, placeholder: "Search tools and document actions\u2026", commands: [...commands, { id: "about", label: `${title} help`, category: "Help" }], onClose: () => setSearch(false), onSelect: (id) => {
      setSearch(false);
      onAction(id);
    } })
  ] });
}
export {
  ModelStudioHeader
};
