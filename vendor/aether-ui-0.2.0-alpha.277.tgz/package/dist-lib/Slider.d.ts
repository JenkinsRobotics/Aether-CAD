import './Slider.css';
export interface SliderProps {
    value?: number;
    defaultValue?: number;
    onChange?: (value: number) => void;
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
    ariaLabel: string;
    showValue?: boolean;
    disabled?: boolean;
    className?: string;
    /** Read-only markers for an assigned range; the owning editor adjusts its limits. */
    range?: {
        min: number;
        max: number;
    };
}
export declare function Slider({ value, defaultValue, onChange, min, max, step, unit, ariaLabel, showValue, disabled, className, range }: SliderProps): import("react").JSX.Element;
