import { jsx, jsxs } from "react/jsx-runtime";
import { useRef } from "react";
function Tabs({ tabs, activeID, onSelect }) {
  const refs = useRef(/* @__PURE__ */ new Map());
  const enabledIndexes = tabs.flatMap((tab, index) => tab.disabled ? [] : [index]);
  const onKeyDown = (event, index) => {
    const current = Math.max(0, enabledIndexes.indexOf(index));
    let nextIndex;
    switch (event.key) {
      case "ArrowRight":
        nextIndex = enabledIndexes[(current + 1) % enabledIndexes.length];
        break;
      case "ArrowLeft":
        nextIndex = enabledIndexes[(current - 1 + enabledIndexes.length) % enabledIndexes.length];
        break;
      case "Home":
        nextIndex = enabledIndexes[0];
        break;
      case "End":
        nextIndex = enabledIndexes[enabledIndexes.length - 1];
        break;
      default:
        return;
    }
    event.preventDefault();
    const id = tabs[nextIndex].id;
    onSelect(id);
    refs.current.get(id)?.focus();
  };
  return /* @__PURE__ */ jsx("div", { className: "aui-tabs", role: "tablist", children: tabs.map((tab, index) => /* @__PURE__ */ jsxs(
    "button",
    {
      type: "button",
      role: "tab",
      "aria-label": tab.label,
      "aria-selected": tab.id === activeID,
      tabIndex: !tab.disabled && tab.id === activeID ? 0 : -1,
      disabled: tab.disabled,
      title: tab.title,
      ref: (el) => {
        if (el) refs.current.set(tab.id, el);
        else refs.current.delete(tab.id);
      },
      className: tab.id === activeID ? "aui-tab aui-tab--active" : "aui-tab",
      onClick: () => !tab.disabled && onSelect(tab.id),
      onKeyDown: (event) => onKeyDown(event, index),
      children: [
        tab.icon ? /* @__PURE__ */ jsx("span", { className: "aui-tab-icon", "aria-hidden": "true", children: tab.icon }) : null,
        /* @__PURE__ */ jsx("span", { children: tab.label })
      ]
    },
    tab.id
  )) });
}
export {
  Tabs
};
