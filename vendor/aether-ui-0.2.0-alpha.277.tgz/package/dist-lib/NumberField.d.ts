import type { InputHTMLAttributes } from "react";
export interface NumberFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "value" | "defaultValue" | "onChange" | "onInput" | "onBlur" | "min" | "max" | "step"> {
    value?: number | null;
    defaultValue?: number;
    min?: number;
    max?: number;
    step?: number;
    precision?: number;
    unit?: string;
    mixed?: boolean;
    invalid?: boolean;
    scrubLabel?: string;
    onValueChange?: (value: number | null) => void;
    onCommit?: (value: number) => void;
    onCancel?: (value: number | null) => void;
}
/** Numeric authoring input with expression commit, explicit units, stepping,
 * mixed values, and an optional drag-to-scrub handle. */
export declare function NumberField({ value, defaultValue, min, max, step, precision, unit, mixed, invalid: invalidProp, scrubLabel, onValueChange, onCommit, onCancel, className, disabled, readOnly, placeholder, onKeyDown, ...inputProps }: NumberFieldProps): import("react").JSX.Element;
