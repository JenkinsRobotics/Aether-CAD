import { createContext } from "react";
const WorkspaceLayoutContext = createContext(null);
export {
  WorkspaceLayoutContext
};
