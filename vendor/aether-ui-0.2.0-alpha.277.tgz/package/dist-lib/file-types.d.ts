/** File presentation only. Recognition never grants permission or chooses an editor. */
export interface FileIdentity {
    name: string;
    kind?: string;
    mime?: string;
    app?: string;
}
export interface FileTypeDefinition {
    id: string;
    label: string;
    plural: string;
    icon: string;
    extensions: readonly string[];
    mimes?: readonly string[];
}
export declare const FILE_TYPES: readonly FileTypeDefinition[];
export declare const fileTypeDefinition: (id: string) => FileTypeDefinition;
export declare function fileTypeFor(file: FileIdentity): FileTypeDefinition;
