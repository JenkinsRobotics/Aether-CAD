import "./MaterialSwatch.css";
export interface MaterialSwatchProps {
    color: string;
    roughness?: number;
    size?: "small" | "large";
    label?: string;
}
/** A compact illustrative surface sample. The owning renderer supplies the actual material preview. */
export declare function MaterialSwatch({ color, roughness, size, label }: MaterialSwatchProps): import("react").JSX.Element;
