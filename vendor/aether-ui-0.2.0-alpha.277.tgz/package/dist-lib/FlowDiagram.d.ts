import { type ReactNode } from "react";
import "./FlowDiagram.css";
export type FlowDiagramTone = "green" | "violet" | "red" | "neutral" | "teal" | "blue" | "amber";
export interface FlowDiagramRoute {
    id: string;
    label?: string;
    /** SVG path in the diagram's coordinate system; routing belongs to the caller. */
    path: string;
    tone: FlowDiagramTone;
    source?: {
        x: number;
        y: number;
    };
    dashed?: boolean;
    durationSeconds?: number;
    delaySeconds?: number;
}
export interface FlowDiagramProps {
    title: string;
    /** A text equivalent of the connections, including their direction. */
    description: string;
    routes: readonly FlowDiagramRoute[];
    width?: number;
    height?: number;
    paused?: boolean;
    playbackRate?: number;
    /** Omit to emphasize every route. Other routes remain visible for context. */
    highlightedRouteIds?: readonly string[];
    children?: ReactNode;
    className?: string;
    interactive?: boolean;
    selectedRouteId?: string;
    onRouteSelect?: (id: string) => void;
}
/** Presentation only: signal movement illustrates direction, never live telemetry. */
export declare function FlowDiagram({ title, description, routes, width, height, paused, playbackRate, highlightedRouteIds, children, className, interactive, selectedRouteId, onRouteSelect, }: FlowDiagramProps): import("react").JSX.Element;
export interface FlowDiagramNodeProps {
    x: number;
    y: number;
    width: number;
    height: number;
    label?: string;
    detail?: string;
    variant?: "module" | "gate" | "processor";
    children?: ReactNode;
}
/** Positioned SVG node; children use local coordinates inside this node. */
export declare function FlowDiagramNode({ x, y, width, height, label, detail, variant, children }: FlowDiagramNodeProps): import("react").JSX.Element;
export interface FlowDiagramLabelProps {
    x: number;
    y: number;
    children: ReactNode;
    subtle?: boolean;
    anchor?: "start" | "middle" | "end";
}
export declare function FlowDiagramLabel({ x, y, children, subtle, anchor }: FlowDiagramLabelProps): import("react").JSX.Element;
