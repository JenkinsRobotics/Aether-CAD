/** Header control: the interface theme from the pack, and the viewport theme
 * on top of it. Persists per device and follows changes made anywhere else. */
export declare function ThemeMenu(): import("react").JSX.Element;
