import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { DashboardCard } from "./DashboardCards.js";
import { Button } from "./Button.js";
import { IconButton } from "./IconButton.js";
import { AetherIcon } from "./AetherIcon.js";
import { TextField } from "./TextField.js";
import { Menu } from "./Menu.js";
import "./WorkflowWidgets.css";
function SequenceBrowser({ items, selected, onSelect, onAdd, onRename, onCommand, messages, selectedMessage, onMessageSelect, onAddMessage, onGenerate }) {
  const [query, setQuery] = useState(""), [searching, setSearching] = useState(false);
  const [menu, setMenu] = useState(null);
  const [renaming, setRenaming] = useState(null);
  const [collapsed, setCollapsed] = useState(/* @__PURE__ */ new Set());
  const groups = [...new Set(items.map((item) => item.group))];
  return /* @__PURE__ */ jsxs(DashboardCard, { contentOnly: true, density: "compact", title: "Sequences", className: "aui-workflow aui-workflow-sequences", action: /* @__PURE__ */ jsxs("div", { className: "aui-workflow-actions", children: [
    /* @__PURE__ */ jsx(IconButton, { appearance: "glyph", label: "Search sequences", "aria-pressed": searching, onClick: () => {
      setSearching((value) => !value);
      setQuery("");
    }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "search" }) }),
    /* @__PURE__ */ jsx(IconButton, { appearance: "glyph", label: "New sequence", onClick: onAdd, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) })
  ] }), children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-workflow-columns", children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-workflow-sequence-list", children: [
        searching && /* @__PURE__ */ jsx(TextField, { "aria-label": "Find sequence", value: query, onChange: (e) => setQuery(e.target.value), placeholder: "Find sequence" }),
        groups.map((group) => /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-workflow-group", "aria-expanded": !collapsed.has(group), onClick: () => setCollapsed((old) => {
            const next = new Set(old);
            if (next.has(group)) next.delete(group);
            else next.add(group);
            return next;
          }), children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: collapsed.has(group) ? "chevron-right" : "chevron-down" }),
            group
          ] }),
          (!collapsed.has(group) || query) && items.filter((item) => item.group === group && item.label.toLowerCase().includes(query.toLowerCase())).map((item) => /* @__PURE__ */ jsxs("div", { className: "aui-workflow-sequence-row", "data-selected": selected === item.id, children: [
            renaming?.id === item.id ? /* @__PURE__ */ jsx("form", { onSubmit: (e) => {
              e.preventDefault();
              if (renaming.name.trim()) onRename(item.id, renaming.name.trim());
              setRenaming(null);
            }, children: /* @__PURE__ */ jsx(TextField, { autoFocus: true, "aria-label": "Sequence name", value: renaming.name, onChange: (e) => setRenaming({ ...renaming, name: e.target.value }), onKeyDown: (e) => {
              if (e.key === "Escape") setRenaming(null);
            } }) }) : /* @__PURE__ */ jsx("button", { type: "button", title: item.label, "aria-pressed": selected === item.id, onClick: () => onSelect(item.id), children: item.label }),
            /* @__PURE__ */ jsx(IconButton, { appearance: "glyph", label: `Options for ${item.label}`, onClick: (e) => setMenu({ id: item.id, anchor: e.currentTarget }), children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
          ] }, item.id))
        ] }, group)),
        query && !items.some((item) => item.label.toLowerCase().includes(query.toLowerCase())) && /* @__PURE__ */ jsx("p", { className: "aui-workflow-hint", children: "No sequences found." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-workflow-message-list", children: [
        /* @__PURE__ */ jsxs("header", { children: [
          /* @__PURE__ */ jsx("strong", { children: "Messages" }),
          /* @__PURE__ */ jsx(IconButton, { appearance: "glyph", label: "New message", onClick: onAddMessage, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) })
        ] }),
        messages.map((message) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-pressed": selectedMessage === message.id, onClick: () => onMessageSelect(message.id), children: [
          /* @__PURE__ */ jsx("strong", { children: message.title }),
          /* @__PURE__ */ jsx("small", { children: message.description })
        ] }, message.id)),
        !messages.length && /* @__PURE__ */ jsx("p", { className: "aui-workflow-hint", children: "Add your first message." }),
        /* @__PURE__ */ jsx(Button, { onClick: onGenerate, disabled: !messages.length, children: "Generate all" })
      ] })
    ] }),
    /* @__PURE__ */ jsx(Menu, { open: Boolean(menu), anchor: menu?.anchor ?? null, ariaLabel: "Sequence commands", applicationCommands: false, onClose: () => setMenu(null), items: [{ id: "rename", label: "Rename", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "notes" }) }, { id: "duplicate", label: "Duplicate", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "copy" }) }, { id: "move", label: "Move to team space", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "collection-folder" }) }, { id: "delete", label: "Delete", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "delete" }) }], onSelect: (command) => {
      if (menu) {
        if (command === "rename") setRenaming({ id: menu.id, name: items.find((item) => item.id === menu.id)?.label ?? "" });
        else onCommand(menu.id, command);
      }
      setMenu(null);
    } })
  ] });
}
export {
  SequenceBrowser
};
