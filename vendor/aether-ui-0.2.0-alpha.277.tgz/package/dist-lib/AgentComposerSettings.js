import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { Menu } from "./Menu.js";
import { agentModes } from "./AgentMode.js";
function AgentComposerSettings(props) {
  const [menu, setMenu] = useState(null);
  const [contextOpen, setContextOpen] = useState(false);
  const modeName = agentModes.find((mode) => mode.id === props.mode).label;
  const modelName = props.loadingModels ? "Loading models\u2026" : props.models.find((model) => model.id === props.model)?.name ?? (props.provider ? "Account default" : "Connect model");
  const modelItems = [
    ...props.provider ? [
      { id: "model:", label: "Account default", heading: "Model", kind: "radio", checked: !props.model, disabled: props.loadingModels },
      ...props.models.map((model) => ({ id: `model:${model.id}`, label: model.name, kind: "radio", checked: props.model === model.id }))
    ] : [],
    ...props.providers.map((provider, index) => ({ id: `provider:${provider.id}`, label: provider.name, heading: index === 0 ? "Provider" : void 0, separatorBefore: index === 0, kind: "radio", checked: props.provider === provider.id })),
    { id: "connections", label: "Add / manage connections\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }), separatorBefore: true }
  ];
  const modeItems = [
    ...agentModes.map((mode) => ({ id: mode.id, label: mode.label, kind: "radio", checked: props.mode === mode.id, help: { summary: mode.description, steps: [] } })),
    { id: "tools", label: "Enabled tools\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "sliders" }), separatorBefore: true },
    { id: "style", label: "Response style", children: ["Normal", "Concise", "Detailed"].map((style) => ({ id: `style:${style}`, label: style, kind: "radio", checked: props.style === style })) }
  ];
  function select(id) {
    setMenu(null);
    if (id === "connections") props.onConnections();
    else if (id === "tools") props.onTools();
    else if (id.startsWith("model:")) props.onModel(id.slice(6));
    else if (id.startsWith("provider:")) props.onProvider(id.slice(9));
    else if (id.startsWith("style:")) props.onStyle(id.slice(6));
    else if (agentModes.some((mode) => mode.id === id)) props.onMode(id);
  }
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-agent-settings", "aria-label": "Chat settings", children: [
      /* @__PURE__ */ jsxs("button", { type: "button", "aria-label": `Chat mode: ${modeName}`, "aria-haspopup": "menu", "aria-expanded": menu?.kind === "mode", disabled: props.busy, onClick: (event) => setMenu({ kind: "mode", anchor: event.currentTarget }), children: [
        /* @__PURE__ */ jsx("span", { children: modeName }),
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" })
      ] }),
      /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-agent-settings-model", "aria-label": `Choose model: ${modelName}`, title: modelName, "aria-haspopup": "menu", "aria-expanded": menu?.kind === "model", disabled: props.busy, onClick: (event) => setMenu({ kind: "model", anchor: event.currentTarget }), children: [
        /* @__PURE__ */ jsx("span", { children: modelName }),
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" })
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-agent-settings-context", "aria-label": "Chat context", title: "View chat context", onClick: () => setContextOpen(true), children: /* @__PURE__ */ jsx(AetherIcon, { name: "info" }) })
    ] }),
    /* @__PURE__ */ jsx(Menu, { open: !!menu, anchor: menu?.anchor ?? null, placement: menu?.kind === "model" ? "top-end" : "top-start", ariaLabel: menu?.kind === "model" ? "Models and connections" : "Chat mode", items: menu?.kind === "model" ? modelItems : modeItems, onSelect: select, onClose: () => setMenu(null), applicationCommands: false }),
    /* @__PURE__ */ jsx(Dialog, { open: contextOpen, title: "Chat context", onClose: () => setContextOpen(false), actions: /* @__PURE__ */ jsx(Button, { onClick: () => setContextOpen(false), children: "Done" }), children: /* @__PURE__ */ jsxs("div", { className: "aui-agent-context-details", children: [
      (props.context || props.detail) && /* @__PURE__ */ jsxs("section", { children: [
        /* @__PURE__ */ jsx("strong", { children: "Workspace" }),
        /* @__PURE__ */ jsx("div", { children: props.context || props.detail })
      ] }),
      /* @__PURE__ */ jsxs("dl", { children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("dt", { children: "Conversation" }),
          /* @__PURE__ */ jsxs("dd", { children: [
            props.messageCount,
            " messages"
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("dt", { children: "Enabled tools" }),
          /* @__PURE__ */ jsx("dd", { children: props.tools.length })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("dt", { children: "Attachments" }),
          /* @__PURE__ */ jsx("dd", { children: props.attachments.length })
        ] })
      ] }),
      !!props.attachments.length && /* @__PURE__ */ jsx("ul", { children: props.attachments.map((file, index) => /* @__PURE__ */ jsxs("li", { children: [
        file.name,
        " \xB7 ",
        file.text.length.toLocaleString(),
        " characters"
      ] }, index)) }),
      props.sharingMessage && /* @__PURE__ */ jsx("p", { children: props.sharingMessage }),
      /* @__PURE__ */ jsxs("details", { children: [
        /* @__PURE__ */ jsx("summary", { children: "Workspace instructions" }),
        /* @__PURE__ */ jsx("pre", { children: props.contextText })
      ] }),
      /* @__PURE__ */ jsxs("details", { children: [
        /* @__PURE__ */ jsxs("summary", { children: [
          "Tools available in ",
          modeName,
          " mode"
        ] }),
        /* @__PURE__ */ jsx("ul", { children: props.tools.map((tool) => /* @__PURE__ */ jsxs("li", { children: [
          /* @__PURE__ */ jsx("strong", { children: tool.name }),
          /* @__PURE__ */ jsx("p", { children: tool.description })
        ] }, tool.name)) }),
        !props.tools.length && /* @__PURE__ */ jsx("p", { children: "No editor tools are enabled in this mode." })
      ] })
    ] }) })
  ] });
}
export {
  AgentComposerSettings
};
