import { type ReactNode } from 'react';
import './SidePanelHeader.css';
/** Panel notices never occupy content rows or displace the panel's controls. */
export declare function PanelNotifications({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function PanelNotice({ message, children }: {
    message?: string;
    children?: ReactNode;
}): import("react").JSX.Element | null;
export declare function PanelNotificationButton(): import("react").JSX.Element;
