import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import "./ConceptWidgets.css";
function AnnouncementCard({ badge, title, detail, items = [], onDismiss }) {
  return /* @__PURE__ */ jsxs("section", { className: "aui-announcement-card", "aria-label": title, children: [
    onDismiss ? /* @__PURE__ */ jsx("button", { className: "aui-announcement-card__close", type: "button", "aria-label": "Dismiss announcement", onClick: onDismiss, children: "\xD7" }) : null,
    badge ? /* @__PURE__ */ jsx("small", { children: badge }) : null,
    /* @__PURE__ */ jsx("strong", { children: title }),
    /* @__PURE__ */ jsx("p", { children: detail }),
    items.length ? /* @__PURE__ */ jsx("div", { className: "aui-announcement-card__items", children: items.map((item) => /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: item.icon ?? "hardware" }),
      /* @__PURE__ */ jsxs("span", { children: [
        item.title,
        /* @__PURE__ */ jsx("small", { children: item.detail })
      ] }),
      item.selected ? /* @__PURE__ */ jsx(AetherIcon, { name: "status-incomplete" }) : null
    ] }, item.id)) }) : null
  ] });
}
export {
  AnnouncementCard
};
