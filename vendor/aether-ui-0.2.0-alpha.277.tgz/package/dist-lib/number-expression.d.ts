/** Small arithmetic parser for authoring fields. It intentionally supports
 * only numeric literals, parentheses, and + - * /; unit conversion remains a
 * Core responsibility. */
export declare function parseNumberExpression(source: string): number | null;
