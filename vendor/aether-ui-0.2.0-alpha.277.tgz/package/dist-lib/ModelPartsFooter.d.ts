import { type AetherIconName } from "./AetherIcon.js";
import { type MenuItem } from "./Menu.js";
import "./ModelStudioComposition.css";
type FooterPart = {
    id: string;
    name: string;
    visible: boolean;
};
/** Labels for apps whose footer lists something other than CAD scene parts. */
export type PartsFooterNouns = {
    part: string;
    study: string;
    label: string;
    visible: string;
    icon: AetherIconName;
    addItems?: readonly MenuItem[];
};
/** Part selection and window-local tab organization share the existing scene bodies. */
export declare function ModelPartsFooter({ hidden, name, fileItems, parts, selected, onSelect, onAction, nouns }: {
    hidden: boolean;
    name: string;
    fileItems: readonly MenuItem[];
    parts: readonly FooterPart[];
    selected: string;
    onSelect: (id: string) => void;
    onAction: (id: string) => void;
    nouns: PartsFooterNouns;
}): import("react").JSX.Element;
export {};
