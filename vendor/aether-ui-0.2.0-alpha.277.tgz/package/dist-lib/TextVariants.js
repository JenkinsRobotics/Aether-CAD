import { jsx, jsxs } from "react/jsx-runtime";
import { DashboardCard } from "./DashboardCards.js";
import { SelectField } from "./SelectField.js";
import { Slider } from "./Slider.js";
import { Button } from "./Button.js";
import "./WorkflowWidgets.css";
function TextVariants({ tone, onToneChange, length, onLengthChange, variants, selected, onSelect, onMore }) {
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title: "Message variants", className: "aui-workflow", children: /* @__PURE__ */ jsxs("div", { className: "aui-workflow-stack", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-workflow-actions", children: [
      /* @__PURE__ */ jsx(SelectField, { "aria-label": "Tone", value: tone, onChange: (e) => onToneChange(e.target.value), options: [{ value: "direct", label: "Direct" }, { value: "friendly", label: "Friendly" }, { value: "formal", label: "Formal" }] }),
      /* @__PURE__ */ jsx(Slider, { ariaLabel: "Message length", value: length, onChange: onLengthChange, min: 1, max: 3, showValue: false })
    ] }),
    /* @__PURE__ */ jsx("ul", { className: "aui-workflow-variants", children: variants.map((variant) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("button", { type: "button", "aria-pressed": selected === variant.id, onClick: () => onSelect(variant.id), children: variant.text }) }, variant.id)) }),
    /* @__PURE__ */ jsx(Button, { appearance: "link", onClick: onMore, children: "More variants" })
  ] }) });
}
export {
  TextVariants
};
