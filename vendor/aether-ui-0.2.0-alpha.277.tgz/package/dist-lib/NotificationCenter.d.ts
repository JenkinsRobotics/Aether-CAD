import type { NotificationItem } from "./Toast.js";
export interface NotificationCenterProps {
    items: readonly NotificationItem[];
    onAction?: (id: string) => void;
    onDismiss?: (id: string) => void;
    onMarkRead?: (id: string) => void;
    onClear?: () => void;
    emptyMessage?: string;
    ariaLabel?: string;
}
export declare function NotificationCenter({ items, onAction, onDismiss, onMarkRead, onClear, emptyMessage, ariaLabel }: NotificationCenterProps): import("react").JSX.Element;
