import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef } from "react";
import { AetherIcon } from "./AetherIcon.js";
const FOCUSABLE = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
function Dialog({ open, title, onClose, actions, children, inline = false }) {
  const dialogRef = useRef(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!open || inline) return;
    const opener = document.activeElement;
    const dialog = dialogRef.current;
    const wanted = dialog?.querySelector("[autofocus]") ?? dialog?.querySelector(".aui-dialog-body " + FOCUSABLE.split(", ").join(", .aui-dialog-body ")) ?? dialog?.querySelector(FOCUSABLE);
    wanted?.focus();
    const onKey = (event) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        closeRef.current();
        return;
      }
      if (event.key !== "Tab" || !dialog) return;
      const focusables = Array.from(
        dialog.querySelectorAll(FOCUSABLE)
      ).filter((el) => !el.hasAttribute("disabled"));
      if (focusables.length === 0) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      const current = document.activeElement;
      if (event.shiftKey && (current === first || !dialog.contains(current))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (current === last || !dialog.contains(current))) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKey, true);
    return () => {
      document.removeEventListener("keydown", onKey, true);
      opener?.focus?.();
    };
  }, [open, inline]);
  if (!open) return null;
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: `aui-dialog-scrim${inline ? " aui-dialog-scrim--inline" : ""}`,
      onClick: (event) => {
        if (!inline && event.target === event.currentTarget) onClose();
      },
      children: /* @__PURE__ */ jsxs(
        "div",
        {
          ref: dialogRef,
          className: "aui-dialog",
          role: "dialog",
          "aria-modal": !inline,
          "aria-label": title,
          children: [
            /* @__PURE__ */ jsxs("div", { className: "aui-dialog-title", children: [
              /* @__PURE__ */ jsx("span", { children: title }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  className: "aui-icon-button",
                  "aria-label": "Close",
                  onClick: onClose,
                  children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
                }
              )
            ] }),
            /* @__PURE__ */ jsx("div", { className: "aui-dialog-body", children }),
            actions ? /* @__PURE__ */ jsx("div", { className: "aui-dialog-actions", children: actions }) : null
          ]
        }
      )
    }
  );
}
export {
  Dialog
};
