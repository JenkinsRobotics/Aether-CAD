import { type ReactNode } from "react";
import "./ThumbnailPicker.css";
export interface ThumbnailOption {
    id: string;
    label: string;
    detail?: string;
    preview: ReactNode;
    disabled?: boolean;
}
/** A controlled visual collection. Selection has native button and pressed semantics. */
export declare function ThumbnailPicker({ label, items, value, onChange }: {
    label: string;
    items: readonly ThumbnailOption[];
    value: string;
    onChange: (id: string) => void;
}): import("react").JSX.Element;
