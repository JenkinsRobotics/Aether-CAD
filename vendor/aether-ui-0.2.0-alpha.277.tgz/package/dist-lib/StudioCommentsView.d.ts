import type { CommentsViewProps } from "./DocumentCommentsView.js";
import "./StudioReview.css";
/** Approved conversation presentation, driven by the existing guarded controller. */
export declare function StudioCommentsView(props: CommentsViewProps): import("react").JSX.Element;
