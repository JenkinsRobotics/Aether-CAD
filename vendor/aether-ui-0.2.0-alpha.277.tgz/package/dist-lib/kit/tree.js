import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Menu } from "../Menu.js";
import { Sym } from "./icons.js";
import { addFolder, deleteNodes, groupSelection, moveIntoFolder, moveNode, renameNode, toggleExpanded, toggleVisible, treeNode } from "./state.js";
import { AD, PanelAction, TreeRow } from "./widgets.js";
function TreeView({ model, onChange, onActivate, ariaLabel = "Tree" }) {
  const [dropTarget, setDropTarget] = useState(null);
  const [menu, setMenu] = useState(null);
  const update = (f) => onChange(f(model));
  const dragged = (e) => e.dataTransfer.getData("text/animation-node");
  const activate = (node) => {
    onChange({ ...model, selection: [node.id] });
    if (!node.isFolder) onActivate?.(node);
  };
  const rows = (node, depth) => /* @__PURE__ */ jsxs("div", { role: "group", children: [
    model.renaming === node.id ? /* @__PURE__ */ jsxs("div", { className: "aui-kit-tree-rename", style: { paddingLeft: depth * 15 + 10 }, children: [
      /* @__PURE__ */ jsx(Sym, { name: node.isFolder ? "folder" : node.icon, size: 12, style: { color: AD.accent2, width: 16 } }),
      /* @__PURE__ */ jsx(
        "input",
        {
          autoFocus: true,
          "aria-label": "Name",
          defaultValue: node.name,
          onKeyDown: (e) => {
            if (e.key === "Enter") update((s) => renameNode(s, node.id, e.currentTarget.value));
            if (e.key === "Escape") update((s) => ({ ...s, renaming: null }));
          },
          onBlur: (e) => update((s) => renameNode(s, node.id, e.currentTarget.value))
        }
      ),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain", "aria-label": "Done", style: { color: AD.accent }, children: /* @__PURE__ */ jsx(Sym, { name: "check", size: 10, weight: "bold" }) })
    ] }) : /* @__PURE__ */ jsx(
      "div",
      {
        className: "aui-kit-tree-drop",
        "data-drop": dropTarget === node.id || void 0,
        draggable: true,
        onDragStart: (e) => {
          e.dataTransfer.setData("text/animation-node", node.id);
          e.dataTransfer.effectAllowed = "move";
        },
        onDragOver: (e) => {
          e.preventDefault();
          setDropTarget(node.id);
        },
        onDragLeave: () => setDropTarget((t) => t === node.id ? null : t),
        onDrop: (e) => {
          e.preventDefault();
          setDropTarget(null);
          const id = dragged(e);
          if (id) update((s) => moveNode(s, id, node.id, node.isFolder));
        },
        onContextMenu: (e) => {
          e.preventDefault();
          setMenu({ node, x: e.clientX, y: e.clientY });
        },
        children: /* @__PURE__ */ jsx(
          TreeRow,
          {
            depth,
            icon: node.isFolder ? "folder" : node.icon,
            title: node.name,
            detail: node.detail,
            expandable: node.isFolder,
            expanded: model.expanded.includes(node.id),
            selected: model.selection.includes(node.id),
            bold: node.isFolder,
            visible: node.visible,
            onToggleVisible: () => update((s) => toggleVisible(s, node.id)),
            onToggleExpand: () => update((s) => toggleExpanded(s, node.id)),
            onTap: () => activate(node)
          }
        )
      }
    ),
    node.isFolder && model.expanded.includes(node.id) && node.children.map((child) => rows(child, depth + 1))
  ] }, node.id);
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-tree", role: "tree", "aria-label": ariaLabel, children: [
    model.nodes.map((node) => rows(node, 0)),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-tree-tail", onDragOver: (e) => e.preventDefault(), onDrop: (e) => {
      e.preventDefault();
      const id = dragged(e);
      if (id) update((s) => moveIntoFolder(s, id, null));
    } }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-divider", style: { marginTop: 2 } }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-tree-actions", children: [
      /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-plain aui-kit-t2 aui-kit-s115 aui-kit-hstack-5", onClick: () => update((s) => addFolder(s)), children: [
        /* @__PURE__ */ jsx(Sym, { name: "folder-add", size: 11 }),
        "New Folder"
      ] }),
      model.selection.length > 1 && /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-plain aui-kit-t2 aui-kit-s115 aui-kit-hstack-5", onClick: () => update((s) => groupSelection(s)), children: [
        /* @__PURE__ */ jsx(Sym, { name: "stack-3d", size: 11 }),
        "Group"
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      model.selection.length > 0 && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain", "aria-label": "Delete selection", title: "Delete selection", style: { color: AD.danger }, onClick: () => update((s) => deleteNodes(s, s.selection)), children: /* @__PURE__ */ jsx(Sym, { name: "delete", size: 12 }) })
    ] }),
    /* @__PURE__ */ jsx(
      Menu,
      {
        open: menu !== null,
        anchor: menu ? { x: menu.x, y: menu.y } : null,
        ariaLabel: "Tree item",
        onClose: () => setMenu(null),
        items: [
          { id: "rename", label: "Rename" },
          ...menu?.node.isFolder ? [{ id: "folder-inside", label: "New Folder Inside" }] : [],
          ...model.selection.length > 1 ? [{ id: "group", label: "Group Selection" }] : [],
          { id: "delete", label: "Delete", danger: true, separatorBefore: true }
        ],
        onSelect: (id) => {
          const node = menu?.node;
          setMenu(null);
          if (!node) return;
          if (id === "rename") onChange({ ...model, selection: [node.id], renaming: node.id });
          if (id === "folder-inside") {
            const folder = treeNode("New Folder", "folder", { isFolder: true });
            update((s) => moveIntoFolder({ ...s, nodes: [...s.nodes, folder] }, folder.id, node.id));
          }
          if (id === "group") update((s) => groupSelection(s));
          if (id === "delete") update((s) => deleteNodes(s, s.selection.includes(node.id) ? s.selection : [node.id]));
        }
      }
    )
  ] });
}
const TreeFooter = ({ onAdd, onFolder, addLabel = "Add" }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-hstack-8", style: { padding: 10 }, children: [
  /* @__PURE__ */ jsx(PanelAction, { icon: "plus", label: addLabel, onClick: onAdd }),
  /* @__PURE__ */ jsx(PanelAction, { icon: "folder-add", label: "Folder", onClick: onFolder })
] });
export {
  TreeFooter,
  TreeView
};
