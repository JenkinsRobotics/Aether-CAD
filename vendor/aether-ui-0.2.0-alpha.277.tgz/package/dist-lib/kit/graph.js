import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { MenuButton } from "../Menu.js";
import { Sym } from "./icons.js";
import { MaterialSphere } from "./viewport.js";
import { AD, Badge, Diamond, Divider, Field, LabeledSlider, LiveBar, PanelCard, Pill, PropertyField, Range, SearchField, Segmented, StepperField, Switch, ToggleLine, tintStyle, Panel } from "./widgets.js";
function GraphNode({ title, icon, sub, tint, width = 140, big = false, selected = false, badge, onTap }) {
  return /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-graph-node", "data-big": big || void 0, "data-selected": selected || void 0, "aria-pressed": selected, style: tintStyle(tint, { width }), onClick: onTap, children: [
    /* @__PURE__ */ jsxs("span", { className: "aui-kit-graph-node-title", children: [
      /* @__PURE__ */ jsx(Sym, { name: icon, size: big ? 14 : 12, className: "aui-kit-tinted" }),
      /* @__PURE__ */ jsx("strong", { children: title })
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-graph-node-sub", children: sub }),
    badge && /* @__PURE__ */ jsxs("span", { className: "aui-kit-graph-node-badge", children: [
      /* @__PURE__ */ jsx("i", { style: { background: badge.on ? AD.ok : AD.text3 } }),
      badge.text
    ] }),
    /* @__PURE__ */ jsx("i", { className: "aui-kit-port aui-kit-port-in" }),
    /* @__PURE__ */ jsx("i", { className: "aui-kit-port aui-kit-port-out" })
  ] });
}
function ServoTrack({ name, channel, degrees, fraction, selected = false, armed = false, onTap }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-servo-track", "data-selected": selected || void 0, role: onTap ? "button" : void 0, onClick: onTap, children: [
    /* @__PURE__ */ jsxs("span", { className: "aui-kit-servo-ch", children: [
      "CH",
      channel
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-servo-name", children: name }),
    /* @__PURE__ */ jsxs("span", { className: "aui-kit-servo-bar", children: [
      /* @__PURE__ */ jsx("span", { style: { width: `${fraction * 100}%` } }),
      /* @__PURE__ */ jsx("i", { style: { left: `calc(${fraction * 100}% - 6.5px)` } })
    ] }),
    /* @__PURE__ */ jsxs("span", { className: "aui-kit-servo-deg", children: [
      Math.round(degrees),
      "\xB0"
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-dot", style: { background: armed ? AD.ok : AD.text3 } })
  ] });
}
const clock = (t) => `${String(Math.floor(t / 60)).padStart(2, "0")}:${(t % 60).toFixed(1).padStart(4, "0")}`;
function DopeSheetTimeline({ tracks, progress, duration = 8, isPlaying = false, onScrub, onTogglePlay, onRewind, onAddKey, style, audio, badge }) {
  const scrub = (e) => {
    const box = e.currentTarget.getBoundingClientRect();
    onScrub?.(Math.max(0, Math.min(1, (e.clientX - box.left) / Math.max(box.width, 1))));
  };
  const transport = (icon, label, big, action) => /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-transport", "data-big": big || void 0, "aria-label": label, onClick: action, children: /* @__PURE__ */ jsx(Sym, { name: icon, size: big ? 15 : 12 }) });
  return /* @__PURE__ */ jsxs(Panel, { className: "aui-kit-timeline", style, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-transport", children: [
      transport("skip-back", "Rewind", false, onRewind),
      transport(isPlaying ? "pause" : "play-filled", isPlaying ? "Pause" : "Play", true, onTogglePlay),
      transport("skip-forward", "To end", false, () => onScrub?.(1)),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 18, marginLeft: 2 } }),
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-mono aui-kit-s12", children: [
        clock(progress * duration),
        " / ",
        clock(duration)
      ] }),
      badge && /* @__PURE__ */ jsx(Badge, { text: badge.text, tint: badge.tint ?? AD.ok }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      /* @__PURE__ */ jsx(Pill, { icon: "plus", label: "Key", tint: AD.warn, onClick: onAddKey }),
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-t3 aui-kit-s11", children: [
        tracks.length,
        " tracks"
      ] })
    ] }),
    /* @__PURE__ */ jsx(Divider, {}),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-ruler", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", style: { width: 120, paddingLeft: 14 }, children: "CHANNELS" }),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-scale", onPointerDown: (e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        scrub(e);
      }, onPointerMove: (e) => e.buttons && scrub(e), role: "slider", "aria-label": "Playhead", "aria-valuenow": Math.round(progress * 100), children: [
        Array.from({ length: 12 }, (_, i) => /* @__PURE__ */ jsx("span", { children: i }, i)),
        /* @__PURE__ */ jsx("i", { className: "aui-kit-playhead", style: { left: `${progress * 100}%` } })
      ] })
    ] }),
    /* @__PURE__ */ jsx(Divider, {}),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-tracks", children: [
      tracks.length === 0 && /* @__PURE__ */ jsx("p", { className: "aui-kit-hint", style: { padding: "22px 0" }, children: "No mates yet \u2014 author mates in Rig to get animation tracks." }),
      tracks.map((track) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-track", children: [
        /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-track-head", children: [
          /* @__PURE__ */ jsx("span", { className: "aui-kit-dot", style: { background: track.color, width: 7, height: 7 } }),
          /* @__PURE__ */ jsx("span", { children: track.name }),
          /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
          /* @__PURE__ */ jsx("span", { className: "aui-kit-mono aui-kit-t3", style: { fontSize: 9.5 }, children: track.keys.length })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-lane", style: { background: `color-mix(in srgb, ${track.color} 10%, transparent)` }, children: [
          track.keys.map((pos, i) => /* @__PURE__ */ jsx(Diamond, { size: 9, fill: track.color, className: "aui-kit-key", style: { left: `calc(${pos * 100}% - 4.5px)` } }, i)),
          /* @__PURE__ */ jsx("i", { className: "aui-kit-playhead", style: { left: `${progress * 100}%` } })
        ] })
      ] }, track.id)),
      audio && /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-track", children: [
        /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-track-head", children: [
          /* @__PURE__ */ jsx(Sym, { name: "waveform", size: 11, style: { color: audio.color ?? AD.warn } }),
          /* @__PURE__ */ jsx("span", { children: audio.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-kit-timeline-lane", children: [
          /* @__PURE__ */ jsx(WaveformLane, { color: audio.color ?? AD.warn }),
          /* @__PURE__ */ jsx("i", { className: "aui-kit-playhead", style: { left: `${progress * 100}%` } })
        ] })
      ] })
    ] })
  ] });
}
function LogicNode({ title, subtitle, icon, color, inputs = [], outputs = [], selected = false, warning = false }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-logic-node", "data-selected": selected || void 0, style: tintStyle(color), children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-logic-node-head", children: [
      /* @__PURE__ */ jsx(Sym, { name: icon, size: 12, className: "aui-kit-tinted" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: title }),
        /* @__PURE__ */ jsx("span", { children: subtitle })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      /* @__PURE__ */ jsx(Sym, { name: warning ? "status-error" : "more", size: 10, style: { color: warning ? AD.warn : AD.text3 } })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-logic-node-ports", children: [
      /* @__PURE__ */ jsx("div", { children: inputs.map((p) => /* @__PURE__ */ jsxs("span", { children: [
        /* @__PURE__ */ jsx("i", { style: { background: AD.text3 } }),
        p
      ] }, p)) }),
      /* @__PURE__ */ jsx("div", { "data-out": true, children: outputs.map((p) => /* @__PURE__ */ jsxs("span", { children: [
        p,
        /* @__PURE__ */ jsx("i", { className: "aui-kit-tinted-bg" })
      ] }, p)) })
    ] })
  ] });
}
const NodeLibraryRow = ({ title, category, icon, color, onAdd }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-node-library-row", style: tintStyle(color), children: [
  /* @__PURE__ */ jsx("span", { className: "aui-kit-icon-badge", children: /* @__PURE__ */ jsx(Sym, { name: icon, size: 11, weight: "medium" }) }),
  /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx("span", { children: title }),
    /* @__PURE__ */ jsx("small", { children: category })
  ] }),
  /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
  /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t3", "aria-label": `Add ${title}`, onClick: onAdd, children: /* @__PURE__ */ jsx(Sym, { name: "plus-circle", size: 11 }) })
] });
function FeatureTimeline({ items, selectedID, onSelect, onPlay, onAdd }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-feature-timeline", role: "toolbar", "aria-label": "Feature timeline", children: [
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t2 aui-kit-ft-btn", "aria-label": "Replay history", onClick: onPlay, children: /* @__PURE__ */ jsx(Sym, { name: "play-filled", size: 11 }) }),
    items.map((item, i) => /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
      /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-feature-chip", "data-active": selectedID === item.id || void 0, "aria-pressed": selectedID === item.id, onClick: () => onSelect?.(item.id), children: [
        /* @__PURE__ */ jsx(Sym, { name: item.icon, size: 12 }),
        /* @__PURE__ */ jsx("span", { children: item.title })
      ] }),
      i < items.length - 1 && /* @__PURE__ */ jsx(Sym, { name: "more", size: 10, className: "aui-kit-t3", style: { transform: "rotate(90deg)" } })
    ] }, item.id)),
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t2 aui-kit-ft-btn", "aria-label": "Add feature", onClick: onAdd, children: /* @__PURE__ */ jsx(Sym, { name: "plus", size: 12, weight: "medium" }) })
  ] });
}
function DocumentTabBar({ tabs, selectedID, onSelect, onAdd }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-doc-tab-bar", role: "tablist", children: [
    tabs.map((tab, i) => /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
      /* @__PURE__ */ jsxs("button", { type: "button", role: "tab", "aria-selected": selectedID === tab.id, className: "aui-kit-doc-tab-pill", "data-active": selectedID === tab.id || void 0, onClick: () => onSelect?.(tab.id), children: [
        /* @__PURE__ */ jsx(Sym, { name: "document", size: 11 }),
        /* @__PURE__ */ jsx("span", { children: tab.name })
      ] }),
      i < tabs.length - 1 && /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 18 } })
    ] }, tab.id)),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 18 } }),
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t2", style: { width: 34, height: 34 }, "aria-label": "New document", onClick: onAdd, children: /* @__PURE__ */ jsx(Sym, { name: "plus", size: 12, weight: "medium" }) })
  ] });
}
function CurveInspector() {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-12", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-curve-editor", children: [
      /* @__PURE__ */ jsx("svg", { viewBox: "0 0 100 100", preserveAspectRatio: "none", "aria-hidden": true, children: /* @__PURE__ */ jsx("path", { d: "M0 80 C40 90 60 10 100 25", stroke: "var(--aether-color-accent)", strokeWidth: 2, fill: "none", vectorEffect: "non-scaling-stroke" }) }),
      [[0, 0.8], [0.5, 0.5], [1, 0.25]].map(([x, y]) => /* @__PURE__ */ jsx("i", { style: { left: `${x * 100}%`, top: `${y * 100}%` } }, x))
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-hstack-9", children: [
      /* @__PURE__ */ jsx(Field, { label: "Interp", value: "B\xE9zier" }),
      /* @__PURE__ */ jsx(Field, { label: "Frame", value: "43" })
    ] }),
    /* @__PURE__ */ jsx(Field, { label: "Value", value: "42.0", unit: "\xB0" }),
    /* @__PURE__ */ jsx(Field, { label: "Ease", value: "In / Out" })
  ] });
}
const CurveCard = ({ onClose }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-curve-card", children: [
  /* @__PURE__ */ jsxs("div", { className: "aui-kit-curve-card-head", children: [
    /* @__PURE__ */ jsx(Sym, { name: "pulse", size: 12, weight: "semibold", style: { color: AD.accent } }),
    /* @__PURE__ */ jsx("strong", { children: "Curve \xB7 Knee" }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t3", "aria-label": "Close", onClick: onClose, children: /* @__PURE__ */ jsx(Sym, { name: "close", size: 10, weight: "bold" }) })
  ] }),
  /* @__PURE__ */ jsx(Divider, {}),
  /* @__PURE__ */ jsx("div", { style: { padding: 14 }, children: /* @__PURE__ */ jsx(CurveInspector, {}) })
] });
const MATE_TYPES = [
  { id: "fastened", label: "Fastened", icon: "link", driven: false, unit: "\xB0" },
  { id: "revolute", label: "Revolute", icon: "revolute", driven: true, unit: "\xB0" },
  { id: "slider", label: "Slider", icon: "arrows-vertical", driven: true, unit: "mm" },
  { id: "cylindrical", label: "Cylindrical", icon: "cylindrical", driven: true, unit: "mm" },
  { id: "planar", label: "Planar", icon: "stack-3d", driven: false, unit: "\xB0" },
  { id: "ball", label: "Ball", icon: "grid-dots", driven: false, unit: "\xB0" }
];
const mateType = (id) => MATE_TYPES.find((t) => t.id === id);
function MateInspector({ mate, onChange, parentName, childName, onDelete }) {
  const type = mateType(mate.type);
  const lo = Math.min(mate.minValue, mate.maxValue), hi = Math.max(mate.minValue, mate.maxValue);
  return /* @__PURE__ */ jsx(PanelCard, { contentOnly: true, title: mate.name, subtitle: type.label, icon: type.icon, tint: AD.accent, children: /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-11", style: { padding: 12 }, children: [
    /* @__PURE__ */ jsx(PropertyField, { label: "Parent", value: parentName }),
    /* @__PURE__ */ jsx(PropertyField, { label: "Child", value: childName }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-between", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-property-label", children: "Axis" }),
      /* @__PURE__ */ jsx(Segmented, { options: ["X", "Y", "Z"].map((a) => ({ id: a, label: a })), value: mate.axis, onChange: (axis) => onChange({ ...mate, axis }), ariaLabel: "Axis" })
    ] }),
    type.driven ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Divider, {}),
      /* @__PURE__ */ jsx(LabeledSlider, { label: "Value", value: mate.value, onChange: (value) => onChange({ ...mate, value }), min: lo, max: lo < hi ? hi : lo + 1, unit: type.unit }),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-hstack-8", children: [
        /* @__PURE__ */ jsx(StepperField, { label: "Min", value: mate.minValue, step: 5, unit: type.unit, onChange: (minValue) => onChange({ ...mate, minValue }) }),
        /* @__PURE__ */ jsx(StepperField, { label: "Max", value: mate.maxValue, step: 5, unit: type.unit, onChange: (maxValue) => onChange({ ...mate, maxValue }) })
      ] })
    ] }) : /* @__PURE__ */ jsxs("p", { className: "aui-kit-t3", style: { fontSize: 9.5, margin: 0 }, children: [
      type.label,
      " mates have no driven axis."
    ] }),
    /* @__PURE__ */ jsx(Divider, {}),
    /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-wide-btn", "data-danger": true, onClick: onDelete, children: [
      /* @__PURE__ */ jsx(Sym, { name: "delete", size: 11 }),
      "Delete mate"
    ] })
  ] }) });
}
function PerformanceHUD({ engine, fps, cpuPercent, memoryMB, loadMs = 0, triangles = 0, kernel = "OCCT 7.8.1", onClose }) {
  const row = (label, value) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-hud-row", children: [
    /* @__PURE__ */ jsx("span", { children: label }),
    /* @__PURE__ */ jsx("strong", { children: value })
  ] }, label);
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-hud", role: "status", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-between", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", children: "PERFORMANCE" }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t3", "aria-label": "Unpin", onClick: onClose, children: /* @__PURE__ */ jsx(Sym, { name: "unpin", size: 9, weight: "semibold" }) })
    ] }),
    row("ENGINE", engine),
    row("LOAD", `${loadMs.toFixed(0)} ms`),
    row("FPS", fps.toFixed(0)),
    row("CPU", `${cpuPercent.toFixed(1)} %`),
    row("MEMORY", `${memoryMB.toFixed(1)} MB`),
    row("TRIANGLES", String(triangles)),
    row("KERNEL", kernel)
  ] });
}
const RENDER_ENGINES = ["RealityKit", "Metal", "Ray Traced", "WebGPU", "Three.js"];
const BENCH_THEMES = ["Studio Blue", "Graphite", "Blueprint", "High Contrast"];
const defaultRenderPrefs = () => ({ themeName: "Studio Blue", engine: "RealityKit", background: "#292b30", keyLight: 3200, showOrigin: true, showViewCube: true, keepColors: true, showGrid: true, groundShadow: true, deflection: 0.2, pinPerformance: false });
function EnvironmentPanel({ prefs, onChange }) {
  const row = (label, control) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-between", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-t2 aui-kit-s11", children: label }),
    control
  ] });
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-environment", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", children: "ENVIRONMENT" }),
    row("Theme", /* @__PURE__ */ jsxs(MenuButton, { className: "aui-kit-menu-btn", label: "Theme", items: BENCH_THEMES.map((t) => ({ id: t, label: t, kind: "radio", checked: prefs.themeName === t })), onSelect: (id) => onChange({ ...prefs, themeName: id }), children: [
      prefs.themeName,
      /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 8 })
    ] })),
    row("Engine", /* @__PURE__ */ jsxs(MenuButton, { className: "aui-kit-menu-btn", label: "Engine", items: RENDER_ENGINES.map((e) => ({ id: e, label: e === "Ray Traced" ? "Ray Traced (unavailable)" : e, kind: "radio", checked: prefs.engine === e, disabled: e === "Ray Traced" })), onSelect: (id) => onChange({ ...prefs, engine: id }), children: [
      prefs.engine,
      /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 8 })
    ] })),
    /* @__PURE__ */ jsx(Divider, {}),
    row("Background", /* @__PURE__ */ jsx("input", { type: "color", className: "aui-kit-color", "aria-label": "Background", value: prefs.background, onChange: (e) => onChange({ ...prefs, background: e.target.value }) })),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-between", children: [
        /* @__PURE__ */ jsx("span", { className: "aui-kit-t2 aui-kit-s11", children: "Key light" }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-mono aui-kit-t3 aui-kit-s10", children: Math.round(prefs.keyLight) })
      ] }),
      /* @__PURE__ */ jsx(Range, { value: prefs.keyLight, min: 0, max: 6e3, step: 10, onChange: (keyLight) => onChange({ ...prefs, keyLight }), ariaLabel: "Key light" })
    ] }),
    /* @__PURE__ */ jsx(ToggleLine, { label: "Show origin", isOn: prefs.showOrigin, onChange: (showOrigin) => onChange({ ...prefs, showOrigin }) }),
    /* @__PURE__ */ jsx(ToggleLine, { label: "View cube", isOn: prefs.showViewCube, onChange: (showViewCube) => onChange({ ...prefs, showViewCube }) }),
    /* @__PURE__ */ jsx(ToggleLine, { label: "Keep STEP colors", isOn: prefs.keepColors, onChange: (keepColors) => onChange({ ...prefs, keepColors }) })
  ] });
}
const MATERIALS = [
  { name: "ABS", category: "Plastic", finish: "Glossy", color: [0.9, 0.13, 0.15] },
  { name: "ABS", category: "Plastic", finish: "Matte", color: [0.85, 0.15, 0.17] },
  { name: "Nylon", category: "Plastic", finish: "Matte", color: [0.16, 0.16, 0.17] },
  { name: "Carbon", category: "Plastic", finish: "Glossy", color: [0.08, 0.08, 0.09] },
  { name: "Aluminium", category: "Metal", finish: "Glossy", color: [0.78, 0.79, 0.82] },
  { name: "Anodised", category: "Metal", finish: "Matte", color: [0.35, 0.4, 0.48] },
  { name: "Brass", category: "Metal", finish: "Glossy", color: [0.83, 0.68, 0.32] },
  { name: "Steel", category: "Metal", finish: "Matte", color: [0.55, 0.57, 0.6] },
  { name: "Clear Glass \u2014 Thin", category: "Glass", finish: "Glossy", color: [1, 1, 1] }
];
const ENVIRONMENTS = [
  { name: "Default", background: [0.16, 0.17, 0.19] },
  { name: "Transparent", background: [0.55, 0.55, 0.57], checkered: true },
  { name: "Colored Mood", background: [0, 0.65, 1] },
  { name: "Gradient Mood", background: [0.95, 0.95, 0.95] },
  { name: "Black and White Stage", background: [1, 1, 1] }
];
const hex = (c) => `#${c.map((v) => Math.round(v * 255).toString(16).padStart(2, "0")).join("").toUpperCase()}`;
const materialID = (m) => `${m.category}/${m.finish} ${m.name}`;
function VisualizationPanel({ onMaterial, onEnvironment }) {
  const [tab, setTab] = useState("material");
  const [search, setSearch] = useState("");
  const [used, setUsed] = useState(MATERIALS.slice(0, 3));
  const [active, setActive] = useState(null);
  const [environment, setEnvironment] = useState("Default");
  const results = search ? MATERIALS.filter((m) => `${m.name} ${m.category}`.toLowerCase().includes(search.toLowerCase())) : MATERIALS;
  const categories = Array.from(new Set(MATERIALS.map((m) => m.category)));
  const apply = (m) => {
    setActive(materialID(m));
    setUsed([m, ...used.filter((u) => materialID(u) !== materialID(m))].slice(0, 3));
    onMaterial?.(m);
  };
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-visualization", children: [
    /* @__PURE__ */ jsx(Segmented, { options: [{ id: "material", label: "Material" }, { id: "environment", label: "Environment" }], value: tab, onChange: setTab, ariaLabel: "Visualization", size: "regular" }),
    tab === "material" ? /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-10", children: [
      /* @__PURE__ */ jsx(SearchField, { placeholder: "Search Materials", text: search, onChange: setSearch }),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-scroll aui-kit-stack-14", children: [
        !search && used.length > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("strong", { className: "aui-kit-s115", children: [
            "Used Materials (",
            used.length,
            ")"
          ] }),
          used.map((m) => /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-used-material", onClick: () => apply(m), children: [
            /* @__PURE__ */ jsx(MaterialSphere, { color: m.color, glossy: m.finish === "Glossy", size: 38 }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("small", { children: m.finish }),
              /* @__PURE__ */ jsx("strong", { children: m.name }),
              /* @__PURE__ */ jsxs("span", { children: [
                /* @__PURE__ */ jsx("i", { style: { background: hex(m.color) } }),
                hex(m.color)
              ] })
            ] }),
            /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
            /* @__PURE__ */ jsx(Sym, { name: "chevron-right", size: 9, className: "aui-kit-t3" })
          ] }, materialID(m)))
        ] }),
        categories.map((category) => {
          const items = results.filter((m) => m.category === category);
          return items.length ? /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-8", children: [
            /* @__PURE__ */ jsx("strong", { className: "aui-kit-s115", children: category }),
            /* @__PURE__ */ jsx("div", { className: "aui-kit-swatch-grid", children: items.map((m) => /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-swatch", "data-active": active === materialID(m) || void 0, onClick: () => apply(m), children: [
              /* @__PURE__ */ jsx(MaterialSphere, { color: m.color, glossy: m.finish === "Glossy", size: 74 }),
              /* @__PURE__ */ jsx("small", { children: m.finish }),
              /* @__PURE__ */ jsx("strong", { children: m.name })
            ] }, materialID(m))) })
          ] }, category) : null;
        })
      ] })
    ] }) : /* @__PURE__ */ jsxs("div", { className: "aui-kit-scroll aui-kit-stack-8", children: [
      /* @__PURE__ */ jsx("strong", { className: "aui-kit-s115", children: "Studio" }),
      ENVIRONMENTS.map((item) => /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-environment-row", "data-active": environment === item.name || void 0, onClick: () => {
        setEnvironment(item.name);
        onEnvironment?.(item.name);
      }, children: [
        /* @__PURE__ */ jsx(MaterialSphere, { color: [0.72, 0.73, 0.76], glossy: true, size: 46, checkered: item.checkered }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("strong", { children: [
            item.name,
            environment === item.name && /* @__PURE__ */ jsx(Sym, { name: "status-ok", size: 9, style: { color: AD.accent, marginLeft: 5 } })
          ] }),
          /* @__PURE__ */ jsx("small", { className: "aui-kit-mono", children: hex(item.background) })
        ] })
      ] }, item.name))
    ] })
  ] });
}
function PropSection({ title, defaultOpen = true, children }) {
  const [open, setOpen] = useState(defaultOpen);
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-prop-section", children: [
    /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-prop-section-head", "aria-expanded": open, onClick: () => setOpen(!open), children: [
      /* @__PURE__ */ jsx(Sym, { name: "chevron-right", size: 9, weight: "semibold", className: "aui-kit-t3", style: { transform: open ? "rotate(90deg)" : void 0 } }),
      /* @__PURE__ */ jsx("strong", { children: title })
    ] }),
    open && children
  ] });
}
const MATERIAL_OPTIONS = ["Not set", "Aluminum", "Steel", "ABS Plastic", "PLA"];
const APPEARANCE_OPTIONS = ["Not set", "Painted", "Anodized", "Brushed", "Matte"];
function PartPropertiesPanel({ shape, onChange, onDelete }) {
  const row = (label, control) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-prop-row", children: [
    /* @__PURE__ */ jsx("span", { children: label }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
    control
  ] });
  const menuRow = (label, value, options, set) => row(
    label,
    /* @__PURE__ */ jsxs(MenuButton, { className: "aui-kit-menu-btn", label, items: options.map((o) => ({ id: o, label: o, kind: "radio", checked: o === value })), onSelect: set, children: [
      /* @__PURE__ */ jsx("span", { style: { color: value === "Not set" ? AD.text3 : AD.text }, children: value }),
      /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 8, className: "aui-kit-t3" })
    ] })
  );
  const numberRow = (label, value, unit, set, step = 1) => row(
    label,
    /* @__PURE__ */ jsxs("span", { className: "aui-kit-number-row", children: [
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-number-box", children: [
        value.toFixed(2),
        " ",
        unit
      ] }),
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-mini-stepper", children: [
        /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Increase ${label}`, onClick: () => set(value + step), children: /* @__PURE__ */ jsx(Sym, { name: "chevron-up", size: 7, weight: "bold" }) }),
        /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Decrease ${label}`, onClick: () => set(value - step), children: /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 7, weight: "bold" }) })
      ] })
    ] })
  );
  const mm = (unit) => unit * 200 - 100;
  const rot = (i, v) => {
    const r = [...shape.rotation];
    r[i] = v;
    onChange({ ...shape, rotation: r });
  };
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-part-props", children: [
    /* @__PURE__ */ jsxs(PropSection, { title: "General", children: [
      menuRow("Material", shape.material, MATERIAL_OPTIONS, (material) => onChange({ ...shape, material })),
      menuRow("Appearance", shape.appearance, APPEARANCE_OPTIONS, (appearance) => onChange({ ...shape, appearance })),
      row("Opacity", /* @__PURE__ */ jsxs("span", { className: "aui-kit-hstack-8", children: [
        /* @__PURE__ */ jsx(Range, { value: shape.opacity, onChange: (opacity) => onChange({ ...shape, opacity }), ariaLabel: "Opacity", style: { width: 90 } }),
        /* @__PURE__ */ jsxs("span", { className: "aui-kit-mono aui-kit-t2", style: { fontSize: 10.5, width: 34, textAlign: "right" }, children: [
          Math.round(shape.opacity * 100),
          " %"
        ] })
      ] })),
      row("Visible", /* @__PURE__ */ jsx(Switch, { checked: shape.visible, onChange: (visible) => onChange({ ...shape, visible }), label: "Visible", size: "mini" }))
    ] }),
    /* @__PURE__ */ jsxs(PropSection, { title: "Transform", children: [
      numberRow("Position X", mm(shape.x), "mm", (v) => onChange({ ...shape, x: (v + 100) / 200 })),
      numberRow("Position Y", mm(shape.y), "mm", (v) => onChange({ ...shape, y: (v + 100) / 200 })),
      numberRow("Position Z", 0, "mm", () => {
      }),
      numberRow("Rotation X", shape.rotation[0], "deg", (v) => rot(0, v)),
      numberRow("Rotation Y", shape.rotation[1], "deg", (v) => rot(1, v)),
      numberRow("Rotation Z", shape.rotation[2], "deg", (v) => rot(2, v))
    ] }),
    /* @__PURE__ */ jsxs(PropSection, { title: "Information", children: [
      row("Type", /* @__PURE__ */ jsx("span", { className: "aui-kit-t2 aui-kit-s11", children: "Solid body" })),
      row("Volume", /* @__PURE__ */ jsx("span", { className: "aui-kit-t2 aui-kit-s11", children: "\u2014" })),
      row("Mass", /* @__PURE__ */ jsx("span", { className: "aui-kit-t2 aui-kit-s11", children: "\u2014" }))
    ] }),
    /* @__PURE__ */ jsx(Divider, { style: { margin: "8px 0" } }),
    /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-plain aui-kit-delete-link", onClick: () => onDelete?.(shape.id), children: [
      /* @__PURE__ */ jsx(Sym, { name: "delete", size: 11 }),
      "Delete"
    ] })
  ] });
}
const CHARACTER_KINDS = [
  { id: "3d", title: "3D Character", detail: "An assembly of rigid model parts connected with mates.", icon: "cube", available: true },
  { id: "2d", title: "2D (Live2D-style)", detail: "Layered 2D character authoring \u2014 coming later.", icon: "layers", available: false }
];
function NewCharacterDialog({ onCreate, onCancel }) {
  const [name, setName] = useState("");
  const [kind, setKind] = useState("3d");
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-sheet", role: "dialog", "aria-label": "New Character", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-sheet-head", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-icon-badge", style: tintStyle(AD.accent, { width: 34, height: 34 }), children: /* @__PURE__ */ jsx(Sym, { name: "character-card", size: 17 }) }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: "New Character" }),
        /* @__PURE__ */ jsx("p", { children: "Creates a project-local Character. Publish it to the Character Library to reuse it." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("label", { className: "aui-kit-stack-6", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", children: "NAME" }),
      /* @__PURE__ */ jsx("input", { className: "aui-kit-input", placeholder: "Character name", value: name, onChange: (e) => setName(e.target.value), autoFocus: true })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-8", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", children: "CHARACTER TYPE" }),
      CHARACTER_KINDS.map((option) => /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-kind-row", role: "radio", "aria-checked": kind === option.id, disabled: !option.available, "data-active": kind === option.id || void 0, onClick: () => setKind(option.id), children: [
        /* @__PURE__ */ jsx(Sym, { name: option.icon, size: 15, style: { color: option.available ? AD.accent : AD.text3, width: 26 } }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("span", { className: "aui-kit-hstack-7", children: [
            /* @__PURE__ */ jsx("strong", { children: option.title }),
            !option.available && /* @__PURE__ */ jsx(Badge, { text: "coming later" })
          ] }),
          /* @__PURE__ */ jsx("small", { children: option.detail })
        ] }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
        /* @__PURE__ */ jsx(Sym, { name: kind === option.id ? "status-ok" : "circle", size: 14, style: { color: kind === option.id ? AD.accent : AD.text3 } })
      ] }, option.id))
    ] }),
    /* @__PURE__ */ jsxs("p", { className: "aui-kit-sheet-note", children: [
      /* @__PURE__ */ jsx(Sym, { name: "info", size: 11 }),
      "The current 3D pipeline is for rigid parts and mates. Skinned meshes and skeletons are not supported yet."
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-dialog-actions", children: [
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-capsule-btn", onClick: onCancel, children: "Cancel" }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-capsule-btn", "data-primary": true, onClick: () => onCreate(name.trim() || "Untitled Character"), children: "Create" })
    ] })
  ] });
}
const SettingsPage = ({ title, subtitle, children }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-settings-page", children: [
  /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx("h2", { children: title }),
    subtitle && /* @__PURE__ */ jsx("p", { children: subtitle })
  ] }),
  children
] });
const SettingsSection = ({ title, icon, footnote, children }) => /* @__PURE__ */ jsxs("section", { className: "aui-kit-settings-section", children: [
  /* @__PURE__ */ jsxs("header", { children: [
    /* @__PURE__ */ jsx(Sym, { name: icon, size: 12, weight: "medium", className: "aui-kit-t2" }),
    /* @__PURE__ */ jsx("strong", { children: title })
  ] }),
  /* @__PURE__ */ jsx("div", { className: "aui-kit-divider" }),
  /* @__PURE__ */ jsxs("div", { className: "aui-kit-settings-section-body", children: [
    children,
    footnote && /* @__PURE__ */ jsx("p", { className: "aui-kit-footnote", children: footnote })
  ] })
] });
const SettingsSlider = ({ label, value, onChange, min = 0, max = 1, format = (v) => v.toFixed(2), step }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-settings-slider", children: [
  /* @__PURE__ */ jsx("span", { children: label }),
  /* @__PURE__ */ jsx(Range, { value, onChange, min, max, step: step ?? (max - min) / 200, ariaLabel: label }),
  /* @__PURE__ */ jsx("span", { className: "aui-kit-mono aui-kit-t2", children: format(value) })
] });
const SettingsColorRow = ({ label, color, onChange }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-between aui-kit-s12", children: [
  /* @__PURE__ */ jsx("span", { children: label }),
  /* @__PURE__ */ jsx("input", { type: "color", className: "aui-kit-color", "aria-label": label, value: color, onChange: (e) => onChange(e.target.value) })
] });
const SettingsLabeledRow = ({ label, children }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-between aui-kit-s12", children: [
  /* @__PURE__ */ jsx("span", { children: label }),
  children
] });
const SettingsCheck = ({ label, checked, onChange }) => /* @__PURE__ */ jsxs("label", { className: "aui-kit-check", children: [
  /* @__PURE__ */ jsx("input", { type: "checkbox", checked, onChange: (e) => onChange(e.target.checked) }),
  /* @__PURE__ */ jsx("span", { children: label })
] });
const ThemeSwatchStrip = ({ colors }) => /* @__PURE__ */ jsx("div", { className: "aui-kit-swatch-strip", children: colors.map((c, i) => /* @__PURE__ */ jsx("span", { style: { background: c } }, i)) });
const MaterialPreviewSphere = ({ roughness, metallic, size = 62 }) => /* @__PURE__ */ jsx("span", { className: "aui-kit-material-sphere", style: { width: size, height: size, background: `radial-gradient(circle at 34% 28%, rgba(255,255,255,${0.95 - roughness * 0.55}) 0%, ${`rgb(${Math.round((0.55 - metallic * 0.2) * 255)},${Math.round((0.55 - metallic * 0.2) * 255)},${Math.round((0.55 - metallic * 0.2) * 255)})`} ${55 + roughness * 50}%, rgb(31,31,31) 100%)` } });
function WaveformLane({ color = AD.warn, samples = 180 }) {
  const points = Array.from({ length: samples + 1 }, (_, i) => `${i / samples * 100},${50 + Math.sin(i * 0.42) * Math.sin(i * 0.071) * 30}`).join(" ");
  return /* @__PURE__ */ jsx("svg", { className: "aui-kit-waveform", viewBox: "0 0 100 100", preserveAspectRatio: "none", "aria-hidden": true, children: /* @__PURE__ */ jsx("polyline", { points, fill: "none", stroke: color, strokeOpacity: 0.8, strokeWidth: 1, vectorEffect: "non-scaling-stroke" }) });
}
function CueTimeline({ tracks, timecode = "00:00:08.12", badge = { text: "REHEARSAL", tint: AD.warn }, onPlay, onStop, onRewind, style }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-cue-timeline", style, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-cue-transport", children: [
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain", "aria-label": "Rewind", onClick: onRewind, children: /* @__PURE__ */ jsx(Sym, { name: "skip-back", size: 11 }) }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain", "aria-label": "Play", onClick: onPlay, children: /* @__PURE__ */ jsx(Sym, { name: "play-filled", size: 11 }) }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain", "aria-label": "Stop", onClick: onStop, children: /* @__PURE__ */ jsx(Sym, { name: "stop", size: 11 }) }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 18 } }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-mono aui-kit-s10", children: timecode }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      badge && /* @__PURE__ */ jsx(Badge, { text: badge.text, tint: badge.tint })
    ] }),
    tracks.map((track) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-cue-track", children: [
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-cue-track-name", children: [
        /* @__PURE__ */ jsx("span", { className: "aui-kit-dot", style: { background: track.color, width: 7, height: 7 } }),
        track.name
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-kit-cue-lane", children: track.blocks.map((b) => /* @__PURE__ */ jsx("span", { className: "aui-kit-cue-block", style: tintStyle(track.color, { left: `${b.start * 100}%`, width: `${b.length * 100}%` }), children: b.label }, `${b.start}-${b.label}`)) })
    ] }, track.name))
  ] });
}
const NodePortRow = ({ direction, name, type, color }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-port-row", children: [
  /* @__PURE__ */ jsx("span", { className: "aui-kit-dot", style: { background: color, width: 8, height: 8 } }),
  /* @__PURE__ */ jsx("b", { children: direction }),
  /* @__PURE__ */ jsx("span", { children: name }),
  /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
  /* @__PURE__ */ jsx("small", { children: type })
] });
const connectionPath = (x1, y1, x2, y2) => `M${x1} ${y1}C${x1 + (x2 - x1) * 0.45} ${y1} ${x1 + (x2 - x1) * 0.55} ${y2} ${x2} ${y2}`;
function NodeCanvas({ nodes, links, title = "BEHAVIOR GRAPH", status = { text: "VALID", tint: AD.ok }, zoom = "100%", height = 380, style }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-node-canvas", style: { height, ...style }, role: "img", "aria-label": title, children: [
    /* @__PURE__ */ jsx("svg", { className: "aui-kit-node-links", viewBox: "0 0 100 100", preserveAspectRatio: "none", "aria-hidden": true, children: links.map((l, i) => /* @__PURE__ */ jsx("path", { d: connectionPath(l.from[0] * 100, l.from[1] * 100, l.to[0] * 100, l.to[1] * 100), fill: "none", stroke: l.color, strokeOpacity: 0.8, strokeWidth: 2.4, vectorEffect: "non-scaling-stroke" }, i)) }),
    nodes.map((n) => /* @__PURE__ */ jsx("div", { className: "aui-kit-node-slot", style: { left: `${n.x * 100}%`, top: `${n.y * 100}%`, width: n.width ?? 196 }, children: /* @__PURE__ */ jsx(LogicNode, { title: n.title, subtitle: n.subtitle, icon: n.icon, color: n.color, inputs: n.inputs, outputs: n.outputs, selected: n.selected, warning: n.warning }) }, n.id)),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-node-canvas-top", children: [
      /* @__PURE__ */ jsx(Badge, { text: title }),
      status && /* @__PURE__ */ jsx(Badge, { text: status.text, tint: status.tint ?? AD.ok })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-node-canvas-bottom", children: [
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-hstack-5", children: [
        /* @__PURE__ */ jsx(Sym, { name: "zoom-out", size: 10 }),
        zoom
      ] }),
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-hstack-5", children: [
        /* @__PURE__ */ jsx(Sym, { name: "ai-generate", size: 10 }),
        "Auto Layout"
      ] })
    ] })
  ] });
}
function ChannelMapTable({ rows, style }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-channel-map", style, role: "table", "aria-label": "Channel mapping", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-channel-row", "data-header": true, role: "row", children: [
      /* @__PURE__ */ jsx("span", { children: "MOTION" }),
      /* @__PURE__ */ jsx("span", { children: "DEVICE / CHANNEL" }),
      /* @__PURE__ */ jsx("span", { children: "RANGE" }),
      /* @__PURE__ */ jsx("span", { children: "LIVE" })
    ] }),
    rows.map((r) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-channel-row", role: "row", children: [
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-hstack-6", children: [
        /* @__PURE__ */ jsx("span", { className: "aui-kit-dot", style: { background: r.color, width: 7, height: 7 } }),
        r.motion
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-t2", children: r.channel }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-mono", style: { fontSize: 9 }, children: r.range }),
      /* @__PURE__ */ jsx("span", { children: /* @__PURE__ */ jsx(LiveBar, { fraction: r.live, tint: r.color }) })
    ] }, r.motion))
  ] });
}
function ThemeTileGrid({ themes, activeID, onSelect }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-theme-tiles", role: "radiogroup", "aria-label": "Theme", children: themes.map((t) => /* @__PURE__ */ jsxs("button", { type: "button", role: "radio", "aria-checked": t.id === activeID, "data-active": t.id === activeID || void 0, onClick: () => onSelect?.(t.id), children: [
    /* @__PURE__ */ jsx("span", { style: { background: t.panel, boxShadow: `inset 0 0 0 1.5px ${t.id === activeID ? t.accent : t.line ?? "rgba(128,128,128,0.3)"}` }, children: /* @__PURE__ */ jsx("i", { style: { background: t.accent } }) }),
    /* @__PURE__ */ jsx("small", { children: t.label })
  ] }, t.id)) });
}
export {
  BENCH_THEMES,
  ChannelMapTable,
  CueTimeline,
  CurveCard,
  CurveInspector,
  DocumentTabBar,
  DopeSheetTimeline,
  ENVIRONMENTS,
  EnvironmentPanel,
  FeatureTimeline,
  GraphNode,
  LogicNode,
  MATERIALS,
  MATE_TYPES,
  MateInspector,
  MaterialPreviewSphere,
  NewCharacterDialog,
  NodeCanvas,
  NodeLibraryRow,
  NodePortRow,
  PartPropertiesPanel,
  PerformanceHUD,
  PropSection,
  RENDER_ENGINES,
  ServoTrack,
  SettingsCheck,
  SettingsColorRow,
  SettingsLabeledRow,
  SettingsPage,
  SettingsSection,
  SettingsSlider,
  ThemeSwatchStrip,
  ThemeTileGrid,
  VisualizationPanel,
  WaveformLane,
  connectionPath,
  defaultRenderPrefs,
  mateType
};
