/** The kit's icons come from the shared packs: `Sym` is the sized interface glyph
 * (core/assets/icons via AetherIcon, the kit's `.font(.system(size:))` shorthand),
 * `ToolGlyph` is a tool's icon — the illustrated ToolIcon pack when the name is a
 * tool, the interface glyph otherwise. Names are pack names, never SF names. */
import type { CSSProperties } from "react";
import { type AetherIconName } from "../AetherIcon.js";
import { type ToolIconName } from "../ToolIcon.js";
export type SymName = AetherIconName;
export interface SymProps {
    name: SymName;
    size?: number;
    /** SF weight → stroke width. */
    weight?: "light" | "regular" | "medium" | "semibold" | "bold" | "heavy";
    className?: string;
    style?: CSSProperties;
}
/** One SF-named glyph, sized like `.font(.system(size:))`. */
export declare function Sym({ name, size, weight, className, style }: SymProps): import("react").JSX.Element;
export declare const isToolIconName: (name: string) => name is ToolIconName;
/** A tool's icon: illustrated when the pack has it, else the interface glyph. */
export declare function ToolGlyph({ name, size, weight, className, style }: SymProps): import("react").JSX.Element;
