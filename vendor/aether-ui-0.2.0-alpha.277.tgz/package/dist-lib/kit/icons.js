import { jsx } from "react/jsx-runtime";
import { AetherIcon } from "../AetherIcon.js";
import { ToolIcon, graphiteToolIconNames, toolIconNames } from "../ToolIcon.js";
const STROKE = {
  light: 1.3,
  regular: 1.6,
  medium: 1.9,
  semibold: 2.2,
  bold: 2.5,
  heavy: 2.9
};
function Sym({ name, size = 12, weight = "regular", className, style }) {
  return /* @__PURE__ */ jsx(AetherIcon, { name, width: size, height: size, strokeWidth: STROKE[weight], className: className ? `aui-kit-sym ${className}` : "aui-kit-sym", style: { flexShrink: 0, ...style } });
}
const TOOL_NAMES = /* @__PURE__ */ new Set([...toolIconNames, ...graphiteToolIconNames]);
const isToolIconName = (name) => TOOL_NAMES.has(name);
function ToolGlyph({ name, size = 16, weight, className, style }) {
  return isToolIconName(name) ? /* @__PURE__ */ jsx(ToolIcon, { name, width: size, height: size, className, style: { flexShrink: 0, ...style } }) : /* @__PURE__ */ jsx(Sym, { name, size, weight, className, style });
}
export {
  Sym,
  ToolGlyph,
  isToolIconName
};
