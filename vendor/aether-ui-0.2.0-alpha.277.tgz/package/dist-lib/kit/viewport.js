import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { mountTransformManipulator } from "../TransformManipulator.js";
import { Popover } from "../Popover.js";
import { Sym } from "./icons.js";
import { AD, tintStyle } from "./widgets.js";
function PerspectiveGrid({ className }) {
  const w = 1e3, h = 600, cx = w / 2, cy = h * 0.6;
  const lines = [];
  for (let i = -9; i <= 9; i += 1) lines.push(`M${cx + i * 18} ${cy}L${cx + i * 54} ${h}`);
  for (let j = 0; j <= 8; j += 1) {
    const y = cy + j * j * 3.6;
    lines.push(`M0 ${y}H${w}`);
  }
  return /* @__PURE__ */ jsx("svg", { className: ["aui-kit-perspective-grid", className].filter(Boolean).join(" "), viewBox: `0 0 ${w} ${h}`, preserveAspectRatio: "none", "aria-hidden": true, children: /* @__PURE__ */ jsx("path", { d: lines.join(""), stroke: "var(--aether-viewport-grid)", strokeWidth: 1, fill: "none", vectorEffect: "non-scaling-stroke" }) });
}
const DotGrid = ({ step = 24, opacity = 1 }) => /* @__PURE__ */ jsx("div", { className: "aui-kit-dot-grid", "aria-hidden": true, style: { backgroundSize: `${step}px ${step}px`, opacity } });
function ViewportMock({ showGizmo = false, selected = true, onTapPart, onTapCanvas, children, className }) {
  const [showRadial, setShowRadial] = useState(false);
  return /* @__PURE__ */ jsxs("div", { className: ["aui-kit-viewport", className].filter(Boolean).join(" "), onClick: onTapCanvas, onDoubleClick: () => setShowRadial((v) => !v), children: [
    /* @__PURE__ */ jsx(PerspectiveGrid, {}),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-part-stage", children: /* @__PURE__ */ jsxs("div", { className: "aui-kit-part", "data-selected": selected || void 0, onClick: (e) => {
      e.stopPropagation();
      onTapPart?.();
    }, role: onTapPart ? "button" : void 0, "aria-label": onTapPart ? "Part" : void 0, children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-part-bore" }),
      selected && /* @__PURE__ */ jsx("span", { className: "aui-kit-part-face" }),
      showGizmo && selected && /* @__PURE__ */ jsxs("span", { className: "aui-kit-gizmo", children: [
        /* @__PURE__ */ jsx(GizmoArrow, { color: AD.danger, angle: 0 }),
        /* @__PURE__ */ jsx(GizmoArrow, { color: AD.ok, angle: -90 }),
        /* @__PURE__ */ jsx(GizmoArrow, { color: AD.accent, angle: 135 })
      ] })
    ] }) }),
    showRadial && /* @__PURE__ */ jsx(RadialMenu, { onDismiss: () => setShowRadial(false) }),
    children
  ] });
}
const GizmoArrow = ({ color, angle }) => /* @__PURE__ */ jsx("span", { className: "aui-kit-gizmo-arrow", style: { transform: `rotate(${angle}deg)`, background: color, color }, children: /* @__PURE__ */ jsx("i", {}) });
const EmptyStage = ({ status, importAction, importLabel = "Import STEP\u2026" }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-viewport aui-kit-empty-stage", children: [
  /* @__PURE__ */ jsx(Sym, { name: "cube-transparent", size: 46, className: "aui-kit-t3" }),
  /* @__PURE__ */ jsx("strong", { children: "No model loaded" }),
  /* @__PURE__ */ jsx("p", { children: status }),
  importAction && /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-capsule-btn", "data-primary": true, onClick: importAction, children: [
    /* @__PURE__ */ jsx(Sym, { name: "plus", size: 12 }),
    importLabel
  ] })
] });
const RADIAL_ITEMS = [
  { icon: "move", label: "Move" },
  { icon: "rotate-3d", label: "Rotate" },
  { icon: "link", label: "Mate" },
  { icon: "hidden", label: "Hide" },
  { icon: "palette", label: "Material" },
  { icon: "delete", label: "Delete", danger: true }
];
function RadialMenu({ onDismiss, onPick }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-radial", role: "menu", "aria-label": "Part actions", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-radial-center", "aria-label": "Close", onClick: onDismiss, children: /* @__PURE__ */ jsx(Sym, { name: "cube-transparent", size: 18, weight: "light" }) }),
    RADIAL_ITEMS.map((item, i) => {
      const angle = i / RADIAL_ITEMS.length * Math.PI * 2 - Math.PI / 2;
      return /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          role: "menuitem",
          className: "aui-kit-radial-item",
          "data-danger": item.danger || void 0,
          style: { transform: `translate(${Math.cos(angle) * 76}px, ${Math.sin(angle) * 76}px)` },
          onClick: () => {
            onPick?.(item.label);
            onDismiss();
          },
          children: [
            /* @__PURE__ */ jsx(Sym, { name: item.icon, size: 15, weight: "medium" }),
            /* @__PURE__ */ jsx("span", { children: item.label })
          ]
        },
        item.label
      );
    })
  ] });
}
function CenterTray({ items, active }) {
  const [open, setOpen] = useState(null);
  const anchors = useRef({});
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-center-tray", role: "toolbar", "aria-label": "Viewport tray", children: items.map((item, i) => /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
    i > 0 && /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 30 } }),
    /* @__PURE__ */ jsxs(
      "button",
      {
        type: "button",
        ref: (el) => {
          anchors.current[item.label] = el;
        },
        className: "aui-kit-tray-item",
        "data-active": open === item.label || active === item.label || void 0,
        "aria-haspopup": item.popover ? "dialog" : void 0,
        "aria-expanded": item.popover ? open === item.label : void 0,
        onClick: () => item.popover ? setOpen(open === item.label ? null : item.label) : item.onSelect?.(),
        children: [
          /* @__PURE__ */ jsx(Sym, { name: item.icon, size: 16, weight: "medium" }),
          /* @__PURE__ */ jsx("span", { children: item.label })
        ]
      }
    ),
    item.popover && /* @__PURE__ */ jsx(Popover, { open: open === item.label, anchor: anchors.current[item.label], onClose: () => setOpen(null), ariaLabel: item.label, placement: "top-start", className: "aui-kit-popover", children: item.popover })
  ] }, item.label)) });
}
function AxisGizmo({ size = 54 }) {
  const axis = (angle, color, label) => /* @__PURE__ */ jsxs("g", { transform: `rotate(${angle} ${size / 2} ${size / 2})`, children: [
    /* @__PURE__ */ jsx("line", { x1: size / 2, y1: size / 2, x2: size / 2, y2: size / 2 - size * 0.36, stroke: color, strokeWidth: 2 }),
    /* @__PURE__ */ jsx("text", { x: size / 2, y: size / 2 - size * 0.42 + 3, fill: color, fontSize: 8, fontWeight: 700, textAnchor: "middle", transform: `rotate(${-angle} ${size / 2} ${size / 2 - size * 0.42})`, children: label })
  ] }, label);
  return /* @__PURE__ */ jsxs("svg", { width: size, height: size, viewBox: `0 0 ${size} ${size}`, className: "aui-kit-axis-gizmo", "aria-label": "Axes", children: [
    axis(0, AD.danger, "X"),
    axis(-90, AD.ok, "Y"),
    axis(135, AD.accent, "Z"),
    /* @__PURE__ */ jsx("circle", { cx: size / 2, cy: size / 2, r: 2.5, fill: "var(--aether-color-text-faint)", opacity: 0.5 })
  ] });
}
const FACE = {
  front: { normal: [0, 0, 1], vertices: [[-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]], camera: [0, 0] },
  back: { normal: [0, 0, -1], vertices: [[1, -1, -1], [-1, -1, -1], [-1, 1, -1], [1, 1, -1]], camera: [Math.PI, 0] },
  right: { normal: [1, 0, 0], vertices: [[1, -1, 1], [1, -1, -1], [1, 1, -1], [1, 1, 1]], camera: [Math.PI / 2, 0] },
  left: { normal: [-1, 0, 0], vertices: [[-1, -1, -1], [-1, -1, 1], [-1, 1, 1], [-1, 1, -1]], camera: [-Math.PI / 2, 0] },
  top: { normal: [0, 1, 0], vertices: [[-1, 1, 1], [1, 1, 1], [1, 1, -1], [-1, 1, -1]], camera: [0, 1.5] },
  bottom: { normal: [0, -1, 0], vertices: [[-1, -1, -1], [1, -1, -1], [1, -1, 1], [-1, -1, 1]], camera: [0, -1.5] }
};
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => {
  const l = Math.hypot(...a) || 1;
  return [a[0] / l, a[1] / l, a[2] / l];
};
function cubeBasis(direction) {
  const forward = norm(direction).map((v) => -v);
  let right = cross(forward, [0, 1, 0]);
  right = dot(right, right) < 1e-4 ? [1, 0, 0] : norm(right);
  const up = norm(cross(right, forward));
  return { right, up };
}
const cubeDirection = (yaw, pitch) => [Math.cos(pitch) * Math.sin(yaw), Math.sin(pitch), Math.cos(pitch) * Math.cos(yaw)];
function cubeFaces(size, direction) {
  const b = cubeBasis(direction), scale = size * 0.3;
  const project = (p) => ({ x: size / 2 + dot(p, b.right) * scale, y: size / 2 - dot(p, b.up) * scale });
  return Object.keys(FACE).filter((f) => dot(FACE[f].normal, direction) > 1e-3).map((face) => ({ face, points: FACE[face].vertices.map(project), depth: FACE[face].vertices.reduce((s, v) => s + dot(v, direction), 0) / 4 })).sort((a, c) => a.depth - c.depth);
}
function ViewCube({ yaw, pitch, size = 72, onSelect }) {
  const [hovered, setHovered] = useState(null);
  const direction = cubeDirection(yaw, pitch);
  const faces = cubeFaces(size, direction);
  const light = norm([0.4, 0.9, 0.5]);
  const b = cubeBasis(direction), scale = size * 0.3;
  const origin = { x: size / 2, y: size / 2 };
  const axes = [[[1, 0, 0], "#ff453a", "X"], [[0, 1, 0], "#30d158", "Y"], [[0, 0, 1], "#0a84ff", "Z"]];
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-view-cube", children: [
    /* @__PURE__ */ jsxs("svg", { width: size, height: size, viewBox: `0 0 ${size} ${size}`, role: "group", "aria-label": "View cube", children: [
      faces.map(({ face, points }) => {
        const on = hovered === face;
        const lambert = Math.max(dot(FACE[face].normal, light), 0);
        const cx = points.reduce((s, p) => s + p.x, 0) / 4, cy = points.reduce((s, p) => s + p.y, 0) / 4;
        return /* @__PURE__ */ jsxs("g", { onMouseEnter: () => setHovered(face), onMouseLeave: () => setHovered(null), onClick: () => onSelect?.(...FACE[face].camera), style: { cursor: "pointer" }, role: "button", "aria-label": `Look at ${face}`, children: [
          /* @__PURE__ */ jsx(
            "polygon",
            {
              points: points.map((p) => `${p.x},${p.y}`).join(" "),
              fill: on ? "var(--aether-color-accent)" : "var(--aether-color-bg-control)",
              fillOpacity: on ? 0.34 : 0.72 + lambert * 0.22,
              stroke: on ? "var(--aether-color-accent)" : "var(--aether-color-border-control)",
              strokeWidth: on ? 1.6 : 1
            }
          ),
          /* @__PURE__ */ jsx("text", { x: cx, y: cy + 2.5, textAnchor: "middle", fontSize: 7.5, fontWeight: 700, fill: on ? "var(--aether-color-accent)" : "var(--aether-color-text-dim)", style: { pointerEvents: "none" }, children: face.toUpperCase() })
        ] }, face);
      }),
      axes.sort((p, q) => dot(p[0], direction) - dot(q[0], direction)).map(([vec, color, letter]) => {
        const tip = { x: size / 2 + dot(vec, b.right) * scale * 1.55, y: size / 2 - dot(vec, b.up) * scale * 1.55 };
        return /* @__PURE__ */ jsxs("g", { style: { pointerEvents: "none" }, children: [
          /* @__PURE__ */ jsx("line", { x1: origin.x, y1: origin.y, x2: tip.x, y2: tip.y, stroke: color, strokeWidth: 1.8 }),
          /* @__PURE__ */ jsx("circle", { cx: tip.x, cy: tip.y, r: 5.5, fill: color }),
          /* @__PURE__ */ jsx("text", { x: tip.x, y: tip.y + 2.5, textAnchor: "middle", fontSize: 7, fontWeight: 800, fill: "#fff", children: letter })
        ] }, letter);
      })
    ] }),
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-iso", title: "Isometric view", onClick: () => onSelect?.(0.7, 0.42), children: "ISO" })
  ] });
}
function MoveGizmo({ onNudge, onDismiss, onRotate, onCopy }) {
  const host = useRef(null);
  const callbacks = useRef({ onNudge, onDismiss, onRotate, onCopy });
  callbacks.current = { onNudge, onDismiss, onRotate, onCopy };
  useEffect(() => {
    if (!host.current) return;
    let copied = false, offset = { x: 0, y: 0 }, start = { x: 0, y: 0 }, previous = { x: 0, y: 0 }, total = { x: 0, y: 0 }, angle = 0;
    const directions = [{ x: 45, y: 27 }, { x: -45, y: 27 }, { x: 0, y: -54 }];
    const handles = () => [
      ...directions.map((v, i) => ({ id: `move${"XYZ"[i]}`, kind: "axis", label: `Move along ${"XYZ"[i]}`, x: 80 + offset.x + v.x, y: 78 + offset.y + v.y, angle: Math.atan2(v.y, v.x) * 180 / Math.PI + 90 })),
      ...[{ x: 0, y: 24 }, { x: 22, y: -16 }, { x: -22, y: -16 }].map((v, i) => ({ id: `plane${i}`, kind: "plane", label: `Move in ${["XY", "XZ", "YZ"][i]} plane`, x: 80 + offset.x + v.x, y: 78 + offset.y + v.y, angle: i === 0 ? 90 : 0 })),
      ...[{ x: 0, y: 49 }, { x: 40, y: -33 }, { x: -40, y: -33 }].map((v, i) => ({ id: `rotate${i}`, kind: "rotation", label: `Rotate around ${"ZXY"[i]}`, x: 80 + offset.x + v.x, y: 78 + offset.y + v.y, angle: i === 0 ? 45 : i === 1 ? 0 : 180 })),
      { id: "pivot", kind: "pivot", label: "Move pivot \xB7 double-click to recenter", x: 80 + offset.x, y: 78 + offset.y }
    ];
    const render = () => widget.update(handles(), { copy: copied, copyPosition: { x: 80 + offset.x, y: 155 + offset.y } });
    const widget = mountTransformManipulator(host.current, {
      onStart(_handle, e) {
        start = { ...offset };
        previous = { x: e.clientX, y: e.clientY };
        total = { x: 0, y: 0 };
        angle = 0;
      },
      onMove(handle, e) {
        let dx = e.clientX - previous.x, dy = e.clientY - previous.y;
        previous = { x: e.clientX, y: e.clientY };
        if (handle.kind === "pivot") {
          offset = { x: offset.x + dx, y: offset.y + dy };
          render();
          return;
        }
        if (handle.kind === "rotation") {
          angle += dx;
          callbacks.current.onRotate?.(dx);
          return;
        }
        const direction = directions["XYZ".indexOf(handle.id.slice(-1))];
        if (direction) {
          const length = Math.hypot(direction.x, direction.y), x = direction.x / length, y = direction.y / length, step = dx * x + dy * y;
          dx = x * step;
          dy = y * step;
        }
        total.x += dx;
        total.y += dy;
        callbacks.current.onNudge?.(dx, dy);
      },
      onEnd(handle, cancelled) {
        if (cancelled) {
          offset = start;
          if (handle.kind !== "pivot") {
            callbacks.current.onNudge?.(-total.x, -total.y);
            callbacks.current.onRotate?.(-angle);
          }
        }
        render();
      },
      onCopy() {
        copied = !copied;
        callbacks.current.onCopy?.();
        render();
      },
      onResetPivot() {
        offset = { x: 0, y: 0 };
        render();
      },
      onKey(handle, e) {
        if (!e.key.startsWith("Arrow")) return;
        e.preventDefault();
        const step = ["ArrowUp", "ArrowRight"].includes(e.key) ? 1 : -1;
        if (handle.kind === "rotation") callbacks.current.onRotate?.(step * 15);
        else if (handle.kind === "axis") callbacks.current.onNudge?.(e.key.includes("Left") || e.key.includes("Right") ? step : 0, e.key.includes("Up") || e.key.includes("Down") ? -step : 0);
      }
    });
    render();
    return () => widget.dispose();
  }, []);
  return /* @__PURE__ */ jsx("div", { ref: host, className: "aui-kit-move-gizmo", onDoubleClick: (event) => {
    if (event.target === event.currentTarget) onDismiss?.();
  } });
}
function MaterialSphere({ color, glossy, size = 54, checkered = false }) {
  const base = `rgb(${color.map((c) => Math.round(c * 255)).join(",")})`;
  return /* @__PURE__ */ jsx("span", { className: "aui-kit-material-sphere", "data-checkered": checkered || void 0, style: {
    width: size,
    height: size,
    background: `radial-gradient(circle at 34% 26%, rgba(255,255,255,${glossy ? 0.95 : 0.42}) 0%, ${base} ${glossy ? 30 : 45}%, color-mix(in srgb, ${base} 55%, transparent) 70%, rgba(0,0,0,0.55) 100%)`
  }, children: /* @__PURE__ */ jsx("i", {}) });
}
const VisualizationIcon = ({ size = 22 }) => /* @__PURE__ */ jsx("span", { className: "aui-kit-visualization-icon", style: { width: size, height: size }, "aria-hidden": true });
const checkerStyle = tintStyle;
function RobotViewport({ mode = "RIG VIEW", selected = "Head Pan Assembly", showsStage = false, hud, onToggleHud, display = "Shaded with edges", className, style, children }) {
  return /* @__PURE__ */ jsxs("div", { className: ["aui-kit-viewport aui-kit-robot-viewport", className].filter(Boolean).join(" "), style, children: [
    /* @__PURE__ */ jsxs("svg", { className: "aui-kit-robot-scene", viewBox: "0 0 400 300", preserveAspectRatio: "xMidYMid meet", "aria-hidden": true, children: [
      /* @__PURE__ */ jsxs("g", { stroke: "var(--aether-color-border-control)", strokeWidth: 0.7, fill: "none", children: [
        Array.from({ length: 19 }, (_, i) => {
          const t = i / 18;
          const y = 186 + Math.pow(t, 1.65) * 114;
          return /* @__PURE__ */ jsx("line", { x1: 0, x2: 400, y1: y, y2: y, opacity: i % 3 === 0 ? 0.95 : 0.48 }, `h${i}`);
        }),
        Array.from({ length: 29 }, (_, i) => {
          const k = i - 14;
          return /* @__PURE__ */ jsx("line", { x1: 200 + k * 400 / 70, y1: 186, x2: 200 + k * 400 / 13, y2: 300, opacity: k === 0 ? 1 : 0.55, strokeWidth: k === 0 ? 1.2 : 0.7 }, `v${i}`);
        })
      ] }),
      showsStage && /* @__PURE__ */ jsxs("g", { children: [
        /* @__PURE__ */ jsx("rect", { x: 56, y: 36, width: 288, height: 174, rx: 16, fill: "none", stroke: "var(--aether-color-joint, #8b87ff)", strokeOpacity: 0.6, strokeWidth: 2 }),
        /* @__PURE__ */ jsx("line", { x1: 91, y1: 36, x2: 200, y2: 210, stroke: "var(--aether-color-part)", strokeOpacity: 0.18, strokeWidth: 26, strokeLinecap: "round" }),
        /* @__PURE__ */ jsx("line", { x1: 309, y1: 36, x2: 200, y2: 210, stroke: "var(--aether-color-part)", strokeOpacity: 0.18, strokeWidth: 26, strokeLinecap: "round" })
      ] }),
      /* @__PURE__ */ jsxs("g", { transform: "translate(208 141) scale(0.46)", children: [
        [-1, 1].map((side) => /* @__PURE__ */ jsxs("g", { children: [
          /* @__PURE__ */ jsx("line", { x1: side * 118, y1: 13, x2: side * 165, y2: 105, stroke: "var(--aether-viewport-part)", strokeWidth: 32, strokeLinecap: "round" }),
          /* @__PURE__ */ jsx("line", { x1: side * 165, y1: 105, x2: side * 184, y2: 189, stroke: "var(--aether-viewport-part)", strokeWidth: 25, strokeLinecap: "round" }),
          /* @__PURE__ */ jsx("circle", { cx: side * 118, cy: 13, r: 26, fill: "#8b87ff" }),
          /* @__PURE__ */ jsx("circle", { cx: side * 165, cy: 105, r: 18, fill: "var(--aether-color-accent)" })
        ] }, side)),
        /* @__PURE__ */ jsx("rect", { x: -92, y: -15, width: 184, height: 210, rx: 25, fill: "var(--aether-viewport-part)", stroke: "var(--aether-color-text)", strokeOpacity: 0.48, strokeWidth: 1.5 }),
        /* @__PURE__ */ jsx("rect", { x: -66, y: 28, width: 132, height: 68, rx: 15, fill: "var(--aether-viewport-part-shade)" }),
        /* @__PURE__ */ jsx("rect", { x: -65, y: -130, width: 130, height: 104, rx: 24, fill: "var(--aether-color-warn)", fillOpacity: 0.92, stroke: "#fff", strokeOpacity: 0.72, strokeWidth: 2 }),
        /* @__PURE__ */ jsx("rect", { x: -44, y: -105, width: 88, height: 48, rx: 10, fill: "var(--aether-viewport-part-shade)" }),
        /* @__PURE__ */ jsx("circle", { cx: -19, cy: -81, r: 8, fill: "var(--aether-color-part)" }),
        /* @__PURE__ */ jsx("circle", { cx: 19, cy: -81, r: 8, fill: "var(--aether-color-part)" }),
        /* @__PURE__ */ jsxs("g", { strokeWidth: 2.4, strokeLinecap: "round", children: [
          /* @__PURE__ */ jsx("line", { x1: 8, y1: -18, x2: 74, y2: -18, stroke: "#ff453a" }),
          /* @__PURE__ */ jsx("circle", { cx: 74, cy: -18, r: 4, fill: "#ff453a" }),
          /* @__PURE__ */ jsx("line", { x1: 8, y1: -18, x2: -31, y2: -63, stroke: "#30d158" }),
          /* @__PURE__ */ jsx("circle", { cx: -31, cy: -63, r: 4, fill: "#30d158" }),
          /* @__PURE__ */ jsx("line", { x1: 8, y1: -18, x2: 8, y2: -90, stroke: "#0a84ff" }),
          /* @__PURE__ */ jsx("circle", { cx: 8, cy: -90, r: 4, fill: "#0a84ff" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-robot-top", children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-3", children: [
        /* @__PURE__ */ jsx("span", { className: "aui-kit-badge", style: tintStyle(AD.accent, { alignSelf: "flex-start" }), children: mode }),
        /* @__PURE__ */ jsx("strong", { className: "aui-kit-s11", children: selected }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-t2", style: { fontSize: 9 }, children: "Character space \xB7 millimetres" })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-mini-cube", "aria-hidden": true, children: [
        /* @__PURE__ */ jsx("span", { children: "TOP" }),
        /* @__PURE__ */ jsxs("span", { children: [
          /* @__PURE__ */ jsx("b", { children: "FRONT" }),
          /* @__PURE__ */ jsx("i", { children: "RIGHT" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-robot-bottom", children: [
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-camera-chrome", children: [
        ["home", "cube", "split-diagonal", "camera"].map((icon) => /* @__PURE__ */ jsx(Sym, { name: icon, size: 11 }, icon)),
        hud !== void 0 && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain", "aria-pressed": hud, title: hud ? "Hide performance HUD" : "Show performance HUD", style: { color: hud ? AD.accent : "inherit" }, onClick: onToggleHud, children: /* @__PURE__ */ jsx(Sym, { name: "gauge", size: 11 }) }),
        /* @__PURE__ */ jsx(Sym, { name: "help", size: 11 })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-hstack-5 aui-kit-t2", style: { fontSize: 9 }, children: [
        /* @__PURE__ */ jsx(Sym, { name: "cube-transparent", size: 10 }),
        display
      ] })
    ] }),
    children
  ] });
}
export {
  AxisGizmo,
  CenterTray,
  DotGrid,
  EmptyStage,
  MaterialSphere,
  MoveGizmo,
  PerspectiveGrid,
  RadialMenu,
  RobotViewport,
  ViewCube,
  ViewportMock,
  VisualizationIcon,
  checkerStyle,
  cubeBasis,
  cubeDirection,
  cubeFaces
};
