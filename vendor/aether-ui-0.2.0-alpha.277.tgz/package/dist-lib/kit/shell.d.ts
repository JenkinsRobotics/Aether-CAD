/**
 * WorkspaceShell.swift + Sidebars.swift: the three sidebars and the scaffold.
 *
 *   TOP   → ToolSidebar       tools that act on OBJECTS
 *   LEFT  → WorkspaceSidebar  what you are working ON (browser/tree/library)
 *   RIGHT → ViewSidebar       how it is PRESENTED (view, environment, appearance, inspector)
 *
 * Shared state (layout flags, armed tool, ribbon settings, the right sidebar's
 * panel stack and presentation prefs) travels through KitShellContext so the
 * viewport, prompt bar and every ribbon agree on what the pointer is doing.
 */
import { type CSSProperties, type MutableRefObject, type ReactNode } from "react";
import { type ArmedTool, type LayoutFlags, type PanelStack, type PanelStackActions, type RibbonGroup, type RibbonTool, type ToolCategory, type ToolDensity, type ToolGroup, type ToolPopupStyle } from "./state.js";
import { type TrayItem } from "./viewport.js";
export interface RibbonSettings {
    density: ToolDensity;
    popupStyle: ToolPopupStyle;
    activeCategory: string;
    /** "sidebar" = the monochrome ToolSidebar; "ribbon" = the tinted legacy ToolRibbon the July-19 "Rex" build used. */
    toolbar: "sidebar" | "ribbon";
    /** The bottom-centre CenterTray the Rex build put in every workspace. */
    centerTray: boolean;
}
export interface ViewPrefs {
    viewPreset: string;
    displayMode: "wireframe" | "hiddenLine" | "shaded";
    showHiddenEdges: boolean;
    navMode: "select" | "pan" | "orbit" | "measure";
    panSpeed: number;
    invertPan: boolean;
    orbitSensitivity: number;
    turntable: boolean;
    measureUnits: string;
    snapToGeometry: boolean;
    showGrid: boolean;
    showOrigin: boolean;
    showViewCube: boolean;
    groundShadow: boolean;
    keyLight: number;
    themeName: string;
    showEdges: boolean;
    keepImportedColors: boolean;
    opacity: number;
}
export declare const defaultViewPrefs: () => ViewPrefs;
export declare const VIEW_TABS: readonly [{
    readonly id: "View";
    readonly icon: "cube";
}, {
    readonly id: "Environment";
    readonly icon: "appearance-light";
}, {
    readonly id: "Appearance";
    readonly icon: "palette";
}, {
    readonly id: "Inspector";
    readonly icon: "sliders";
}];
/** A workspace the Expanded tool sidebar can switch between, boxed at its left like the glass WorkspaceRibbon's column. */
export interface ShellWorkspace {
    id: string;
    name: string;
    icon?: string;
}
export interface KitShell {
    /** The app's workspaces, for the Expanded sidebar's dropdown; a sidebar may override them with props. */
    workspaces?: readonly ShellWorkspace[];
    workspaceID?: string;
    onWorkspaceSelect?: (id: string) => void;
    layout: LayoutFlags;
    setLayout: (f: LayoutFlags | ((f: LayoutFlags) => LayoutFlags)) => void;
    armed: ArmedTool | null;
    arm: (tool: RibbonTool, group: RibbonGroup) => void;
    disarm: () => void;
    /** Call after a tool commits; honours `repeats`. */
    committed: () => void;
    repeats: boolean;
    /** A workspace claims immediate-action tools here; returning true means "handled, don't arm". */
    actionHandler: MutableRefObject<((tool: RibbonTool) => boolean) | null>;
    ribbon: RibbonSettings;
    setRibbon: (r: RibbonSettings | ((r: RibbonSettings) => RibbonSettings)) => void;
    viewPanels: PanelStack;
    viewPanelActions: PanelStackActions;
    view: ViewPrefs;
    setView: (v: ViewPrefs | ((v: ViewPrefs) => ViewPrefs)) => void;
}
export declare const useKitShell: () => KitShell;
export declare function KitShellProvider({ layout, setLayout, initialRibbon, workspaces, workspaceID, onWorkspaceSelect, children }: {
    layout: LayoutFlags;
    setLayout: KitShell["setLayout"]; /** Starting toolbar settings — a gallery shows the three densities side by side. */
    initialRibbon?: Partial<RibbonSettings>;
    workspaces?: readonly ShellWorkspace[];
    workspaceID?: string;
    onWorkspaceSelect?: (id: string) => void;
    children: ReactNode;
}): import("react").JSX.Element;
/** Floating → a translucent pill; docked → a flat panel meeting its neighbours edge to edge. */
export declare const chromeClass: (docked: boolean) => "aui-kit-chrome aui-kit-chrome-docked" | "aui-kit-chrome aui-kit-chrome-floating";
export interface SidebarTab {
    id: string;
    icon: string;
}
/** The icon rail. Every tab toggles its own panel. */
export declare function StackRail({ tabs, state, actions, docked }: {
    tabs: readonly SidebarTab[];
    state: PanelStack;
    actions: PanelStackActions;
    docked?: boolean;
}): import("react").JSX.Element;
/** One panel card: a header (the drag handle) over caller-supplied content. */
export declare function StackCard({ id, title, icon, onClose, docked, floating, width, lifted, dragProps, style, children }: {
    id: string;
    title: string;
    icon: string;
    onClose: () => void;
    docked?: boolean;
    floating?: boolean;
    width?: number;
    lifted?: boolean;
    dragProps?: React.HTMLAttributes<HTMLDivElement>;
    style?: CSSProperties;
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * A full side sidebar: the rail plus the stack of open panels. Header drag on a
 * stacked panel: mostly vertical → reorder (drop line), pulled sideways → tears
 * off to float where it is dropped. Floating cards are drawn by the scaffold.
 */
export declare function PanelSidebar({ tabs, state, actions, docked, outer, content }: {
    tabs: readonly SidebarTab[];
    state: PanelStack;
    actions: PanelStackActions;
    docked?: boolean;
    outer?: boolean;
    content: (id: string) => ReactNode;
}): import("react").JSX.Element;
/** The top sidebar, driven by a per-workspace catalog. */
export declare function ToolSidebar({ groups, categories, armGroup, docked, workspaces, workspaceID, onWorkspaceSelect, onCommand, renderIcon, activeCategory: controlledCategory, onCategoryChange }: {
    groups?: readonly ToolGroup[];
    categories?: readonly ToolCategory[];
    armGroup: RibbonGroup;
    docked?: boolean;
    /** Products own command behavior and state; omitted preserves the demo's armed-tool behavior. */
    onCommand?: (id: string) => void;
    renderIcon?: (tool: RibbonTool, size: number) => ReactNode;
    activeCategory?: string;
    onCategoryChange?: (category: string) => void;
    /** Expanded density's workspace dropdown; defaults to the shell's. */ workspaces?: readonly ShellWorkspace[];
    workspaceID?: string;
    onWorkspaceSelect?: (id: string) => void;
}): import("react").JSX.Element;
/** ToolRibbon.swift — the modular tool toolbar: floating pill of tinted category icons, or the docked legacy ribbon. */
export declare function ToolRibbon({ groups, docked }: {
    groups: readonly RibbonGroup[];
    docked?: boolean;
}): import("react").JSX.Element;
/** The armed-tool banner, shared by every workspace's scaffold. */
export declare function PromptBar(): import("react").JSX.Element | null;
/** The body of one view-sidebar panel. Inspector is caller-supplied; the rest are presentation settings. */
export declare function ViewTabContent({ tab, inspector }: {
    tab: string;
    inspector: ReactNode;
}): import("react").JSX.Element;
export interface ContentInsets {
    top: number;
    left: number;
    bottom: number;
    right: number;
}
export declare const ContentInsetsContext: import("react").Context<ContentInsets>;
export declare const useContentInsets: () => ContentInsets;
export interface WorkspaceScaffoldProps {
    toolGroups?: readonly ToolGroup[];
    toolCategories?: readonly ToolCategory[];
    toolArmGroup: RibbonGroup;
    leftTabs: readonly SidebarTab[];
    leftPanels: PanelStack;
    leftActions: PanelStackActions;
    /** Optional center-view modes (3D · Gallery · Table …) shown in a bottom pill. */
    centerTabs?: readonly SidebarTab[];
    centerSelection?: string;
    onCenterSelect?: (id: string) => void;
    center: ReactNode;
    left: (id: string) => ReactNode;
    inspector: ReactNode;
    /** The workspace's CenterTray items; shown when `ribbon.centerTray` is on. */
    tray?: readonly TrayItem[];
}
/** The whole workspace frame: tool sidebar on top, workspace sidebar left, view sidebar right, center between. */
export declare function WorkspaceScaffold({ toolGroups, toolCategories, toolArmGroup, leftTabs, leftPanels, leftActions, centerTabs, centerSelection, onCenterSelect, center, left, inspector, tray }: WorkspaceScaffoldProps): import("react").JSX.Element;
export type DockPlacement = "docked" | "floating" | "hidden";
/** The area in-window floating chrome covers (PanelObstructionInsets). Spatial canvases ignore it; structured content opts in via DockSafeArea. */
export interface DockInsets {
    top: number;
    bottom: number;
    left: number;
    right: number;
}
export declare const useDockInsets: () => DockInsets;
/** CodexUI's `.avoidsFloatingWorkspacePanels(edges)`: keeps tables and timelines inside the visible area. */
export declare function DockSafeArea({ edges, children, style }: {
    edges?: readonly ("top" | "bottom" | "left" | "right")[];
    children: ReactNode;
    style?: CSSProperties;
}): import("react").JSX.Element;
/** CodexUI's FloatingPanelSizing: floating panels are capped cards, never full-height columns. */
export declare const floatingPanelHeight: (available: number, preferredFraction?: number, minimum?: number, margins?: number) => number;
/**
 * The canvas-first layout every CodexUI workspace used: one source view per
 * side region with three presentations — docked in the flow, floating over the
 * canvas (right side draggable, clamped to the window), or hidden with a hover
 * strip that reveals it in the Canvas preset.
 */
export declare function DockingWorkspace({ left, center, right, leftPlacement, rightPlacement, leftWidth, rightWidth, centerInset, canvasReveal, leftTitle, rightTitle, overlayTop, overlayBottom, ribbonClearance }: {
    left: ReactNode;
    center: ReactNode;
    right: ReactNode;
    leftPlacement: DockPlacement;
    rightPlacement: DockPlacement;
    leftWidth?: number;
    rightWidth?: number;
    centerInset?: number;
    /** Hidden regions reveal on hover at the edge (only in the Canvas preset, as CodexUI's policy says). */ canvasReveal?: boolean;
    leftTitle?: string;
    rightTitle?: string;
    /** The floating ribbon, placed over the centre at the top or bottom. */ overlayTop?: ReactNode;
    overlayBottom?: ReactNode;
    /** Where a floating ribbon sits (74px of clearance for DockSafeArea), if the app draws it outside this component. */ ribbonClearance?: "top" | "bottom" | null;
}): import("react").JSX.Element;
