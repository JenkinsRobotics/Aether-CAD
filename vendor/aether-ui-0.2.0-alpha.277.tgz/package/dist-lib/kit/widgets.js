import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useId, useState } from "react";
import { Sym, ToolGlyph } from "./icons.js";
import { showsStageLabel } from "./state.js";
const AD = {
  accent: "var(--aether-color-accent)",
  accent2: "var(--aether-color-part)",
  warn: "var(--aether-color-warn)",
  danger: "var(--aether-color-error)",
  ok: "var(--aether-color-ok)",
  text: "var(--aether-color-text)",
  text2: "var(--aether-color-text-dim)",
  text3: "var(--aether-color-text-faint)",
  panel: "var(--aether-color-bg-panel)",
  panelHi: "var(--aether-color-bg-control)",
  purple: "var(--aether-color-joint)",
  pink: "var(--aether-color-error)",
  teal: "var(--aether-color-part)",
  blue: "var(--aether-color-accent)"
};
const tintStyle = (tint, extra) => ({ ...tint ? { "--tint": tint } : {}, ...extra });
const cx = (...names) => names.filter(Boolean).join(" ");
function Pill({ icon, label, active = false, tint = AD.accent, onClick }) {
  return /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-pill", "data-active": active || void 0, style: tintStyle(tint), onClick, children: [
    icon && /* @__PURE__ */ jsx(Sym, { name: icon, size: 11, weight: "semibold" }),
    /* @__PURE__ */ jsx("span", { children: label })
  ] });
}
function Panel({ title, systemImage, accessory, children, className, style }) {
  return /* @__PURE__ */ jsxs("div", { className: cx("aui-kit-panel", className), style, children: [
    title && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-panel-head", children: [
        systemImage && /* @__PURE__ */ jsx(Sym, { name: systemImage, size: 11, weight: "semibold" }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-panel-title", children: title }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
        accessory
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-kit-divider" })
    ] }),
    children
  ] });
}
function Row({ icon, label, detail, indent = 0, tint = AD.text2, selected = false, badge, controls = false, onClick }) {
  const [hidden, setHidden] = useState(false);
  const [locked, setLocked] = useState(false);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "aui-kit-row",
      "data-selected": selected || void 0,
      "data-hidden": hidden || void 0,
      style: tintStyle(tint, { paddingLeft: 10 + indent }),
      onClick,
      role: onClick ? "button" : void 0,
      children: [
        /* @__PURE__ */ jsx(Sym, { name: icon, size: 12, className: "aui-kit-row-icon" }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-row-label", children: label }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
        badge && /* @__PURE__ */ jsx("span", { className: "aui-kit-row-badge", children: badge }),
        detail && /* @__PURE__ */ jsx("span", { className: "aui-kit-row-detail", children: detail }),
        controls && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              className: "aui-kit-plain",
              "aria-label": locked ? "Unlock" : "Lock",
              "aria-pressed": locked,
              onClick: (e) => {
                e.stopPropagation();
                setLocked(!locked);
              },
              style: { color: locked ? AD.accent : AD.text3 },
              children: /* @__PURE__ */ jsx(Sym, { name: locked ? "lock" : "unlock", size: 10.5 })
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              className: "aui-kit-plain",
              "aria-label": hidden ? "Show" : "Hide",
              "aria-pressed": hidden,
              onClick: (e) => {
                e.stopPropagation();
                setHidden(!hidden);
              },
              style: { color: hidden ? AD.text3 : AD.text2 },
              children: /* @__PURE__ */ jsx(Sym, { name: hidden ? "hidden" : "visible", size: 10.5 })
            }
          )
        ] })
      ]
    }
  );
}
function Field({ label, value, unit }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-field", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-field-label", children: label }),
    /* @__PURE__ */ jsxs("span", { className: "aui-kit-field-value", children: [
      /* @__PURE__ */ jsx("span", { children: value }),
      unit && /* @__PURE__ */ jsx("small", { children: unit })
    ] })
  ] });
}
const Badge = ({ text, tint = AD.text3 }) => /* @__PURE__ */ jsx("span", { className: "aui-kit-badge", style: tintStyle(tint), children: text });
const MetricCard = ({ title, value, caption, tint = AD.accent }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-metric", style: tintStyle(tint), children: [
  /* @__PURE__ */ jsx("span", { className: "aui-kit-metric-title", children: title }),
  /* @__PURE__ */ jsx("span", { className: "aui-kit-metric-value", children: value }),
  caption && /* @__PURE__ */ jsx("span", { className: "aui-kit-metric-caption", children: caption })
] });
function Range({ value, onChange, min = 0, max = 1, step = 0.01, ariaLabel, tint, gradient, style }) {
  const pct = (value - min) / (max - min || 1) * 100;
  const vars = { "--pct": `${pct}%`, ...gradient ? { "--gradient": `linear-gradient(to right, ${gradient.join(", ")})` } : {}, ...style };
  return /* @__PURE__ */ jsx(
    "input",
    {
      type: "range",
      className: gradient ? "aui-kit-range aui-kit-range-gradient" : "aui-kit-range",
      "aria-label": ariaLabel,
      min,
      max,
      step,
      value,
      onChange: (e) => onChange(Number(e.target.value)),
      style: tintStyle(tint, vars)
    }
  );
}
function LabeledSlider({ label, value, onChange, min = 0, max = 1, unit = "", tint, readout }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-labeled-slider", children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-between", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-t2 aui-kit-s11", children: label }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-mono aui-kit-t3 aui-kit-s10", children: readout ?? `${value.toFixed(2)}${unit}` })
    ] }),
    /* @__PURE__ */ jsx(Range, { value, onChange, min, max, ariaLabel: label, tint })
  ] });
}
function SegmentedIcons({ items, selection, onChange }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-segmented-icons", role: "radiogroup", children: items.map((item, i) => /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      role: "radio",
      "aria-checked": selection === i,
      "aria-label": item.help,
      title: item.help,
      className: "aui-kit-segmented-icon",
      "data-active": selection === i || void 0,
      onClick: () => onChange(i),
      children: /* @__PURE__ */ jsx(Sym, { name: item.icon, size: 12, weight: "medium" })
    },
    item.help
  )) });
}
function ToolCluster({ tools, axis = "vertical", solid = false }) {
  const [selected, setSelected] = useState(0);
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-tool-cluster", "data-axis": axis, "data-solid": solid || void 0, role: "radiogroup", children: tools.map((t, i) => /* @__PURE__ */ jsxs(
    "button",
    {
      type: "button",
      role: "radio",
      "aria-checked": selected === i,
      title: t.label,
      style: tintStyle(t.tint ?? AD.accent),
      className: "aui-kit-tool-cluster-item",
      "data-active": selected === i || void 0,
      onClick: () => setSelected(i),
      children: [
        /* @__PURE__ */ jsx(ToolGlyph, { name: t.icon, size: 14, weight: "medium" }),
        /* @__PURE__ */ jsx("span", { children: t.label })
      ]
    },
    t.label
  )) });
}
const Toast = ({ icon = "info", message, tint = AD.accent }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-toast", role: "status", style: tintStyle(tint), children: [
  /* @__PURE__ */ jsx(Sym, { name: icon, size: 12 }),
  /* @__PURE__ */ jsx("span", { children: message })
] });
const Callout = ({ icon = "lightbulb", title, message, tint = AD.accent2 }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-callout", style: tintStyle(tint), children: [
  /* @__PURE__ */ jsx(Sym, { name: icon === "lightbulb" ? "lighting" : icon, size: 13 }),
  /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx("strong", { children: title }),
    /* @__PURE__ */ jsx("p", { children: message })
  ] })
] });
function Switch({ checked, onChange, label, size = "small" }) {
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      role: "switch",
      "aria-checked": checked,
      "aria-label": label,
      className: "aui-kit-switch",
      "data-size": size,
      onClick: () => onChange(!checked),
      children: /* @__PURE__ */ jsx("span", {})
    }
  );
}
const ToggleRow = ({ label, isOn, onChange }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-between aui-kit-toggle-row", children: [
  /* @__PURE__ */ jsx("span", { className: "aui-kit-t2 aui-kit-s115", children: label }),
  /* @__PURE__ */ jsx(Switch, { checked: isOn, onChange, label })
] });
const ToggleLine = ({ label, isOn, onChange, size = "mini" }) => /* @__PURE__ */ jsxs("label", { className: "aui-kit-toggle-line", children: [
  /* @__PURE__ */ jsx("span", { children: label }),
  /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
  /* @__PURE__ */ jsx(Switch, { checked: isOn, onChange, label, size })
] });
const ProgressBar = ({ value, tint = AD.accent }) => /* @__PURE__ */ jsx("div", { className: "aui-kit-progress", role: "progressbar", "aria-valuenow": Math.round(value * 100), "aria-valuemin": 0, "aria-valuemax": 100, style: tintStyle(tint), children: /* @__PURE__ */ jsx("span", { style: { width: `${Math.max(0, Math.min(1, value)) * 100}%` } }) });
const PropertyField = ({ label, value, unit }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-property", children: [
  /* @__PURE__ */ jsx("span", { className: "aui-kit-property-label", children: label }),
  /* @__PURE__ */ jsxs("span", { className: "aui-kit-property-box", children: [
    /* @__PURE__ */ jsx("span", { children: value }),
    unit && /* @__PURE__ */ jsx("small", { children: unit })
  ] })
] });
const CommandButton = ({ icon, active = false, onClick, label }) => /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-command", "data-active": active || void 0, "aria-pressed": active, "aria-label": label ?? icon, title: label, onClick, children: /* @__PURE__ */ jsx(Sym, { name: icon, size: 12 }) });
function NotificationCard({ icon = "status-ok", title, message, action, timestamp = "Just now", tint = AD.ok, onDismiss }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-notification", style: tintStyle(tint), children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-notification-head", children: [
      /* @__PURE__ */ jsx(Sym, { name: icon, size: 13, className: "aui-kit-tinted" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: title }),
        /* @__PURE__ */ jsx("p", { children: message })
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t3", "aria-label": "Dismiss", onClick: onDismiss, children: /* @__PURE__ */ jsx(Sym, { name: "close", size: 9, weight: "bold" }) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-divider" }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-between", children: [
      action ? /* @__PURE__ */ jsx("span", { className: "aui-kit-notification-action", children: action }) : /* @__PURE__ */ jsx("span", {}),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-t3", style: { fontSize: 8.5 }, children: timestamp })
    ] })
  ] });
}
function DialogCard({ title, subtitle, icon, confirmLabel = "Create", onCancel, onConfirm, children }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-dialog-card", role: "dialog", "aria-label": title, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-dialog-head", children: [
      icon && /* @__PURE__ */ jsx(Sym, { name: icon, size: 12, weight: "semibold", style: { color: AD.accent } }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: title }),
        subtitle && /* @__PURE__ */ jsx("span", { children: subtitle })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-divider" }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-dialog-body", children }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-divider" }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-dialog-actions", children: [
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-capsule-btn", onClick: onCancel, children: "Cancel" }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-capsule-btn", "data-primary": true, onClick: onConfirm, children: confirmLabel })
    ] })
  ] });
}
function DocumentTabs({ tabs, selection, onChange }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-doc-tabs", role: "tablist", children: tabs.map((t, i) => /* @__PURE__ */ jsxs("button", { type: "button", role: "tab", "aria-selected": selection === i, className: "aui-kit-doc-tab", "data-active": selection === i || void 0, onClick: () => onChange(i), children: [
    /* @__PURE__ */ jsx("span", { children: t }),
    /* @__PURE__ */ jsx(Sym, { name: "close", size: 8, weight: "bold", className: "aui-kit-t3" })
  ] }, t)) });
}
const ChipPicker = ({ options, selection, onChange }) => /* @__PURE__ */ jsx("div", { className: "aui-kit-chips", role: "radiogroup", children: options.map((opt) => /* @__PURE__ */ jsx("button", { type: "button", role: "radio", "aria-checked": selection === opt, className: "aui-kit-chip", "data-active": selection === opt || void 0, onClick: () => onChange(opt), children: opt }, opt)) });
const Spinner = ({ size = 28 }) => /* @__PURE__ */ jsx("span", { className: "aui-kit-spinner", style: { width: size, height: size }, "aria-hidden": true });
function ProgressCard({ title, detail = "", progress, countText }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-progress-card", role: "status", children: [
    /* @__PURE__ */ jsx(Spinner, {}),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("strong", { children: title }),
      detail && /* @__PURE__ */ jsx("span", { children: detail })
    ] }),
    progress != null && /* @__PURE__ */ jsxs("div", { className: "aui-kit-progress-card-bar", children: [
      /* @__PURE__ */ jsx(ProgressBar, { value: progress }),
      countText && /* @__PURE__ */ jsx("span", { className: "aui-kit-mono aui-kit-t3", style: { fontSize: 9.5 }, children: countText })
    ] })
  ] });
}
function PanelCard({ title, subtitle, icon, tint = AD.accent, onMenu, children, className, style, contentOnly = false }) {
  return /* @__PURE__ */ jsxs("div", { className: cx("aui-kit-panel aui-kit-panel-card", className), "data-content-only": contentOnly || void 0, style: tintStyle(tint, style), children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-panel-card-head", "data-subtitle": subtitle ? "" : void 0, children: [
      icon && /* @__PURE__ */ jsx("span", { className: "aui-kit-icon-badge", children: /* @__PURE__ */ jsx(Sym, { name: icon, size: 11, weight: "semibold" }) }),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-panel-card-titles", children: [
        /* @__PURE__ */ jsx("strong", { children: title }),
        subtitle && /* @__PURE__ */ jsx("span", { children: subtitle })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-panel-card-menu", "aria-label": `${title} menu`, onClick: onMenu, children: /* @__PURE__ */ jsx(Sym, { name: "more", size: 11, weight: "semibold" }) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-divider" }),
    children
  ] });
}
function ListRow({ icon, title, detail, level = 0, selected = false, statusColor, onClick }) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "aui-kit-list-row",
      "data-selected": selected || void 0,
      role: onClick ? "button" : void 0,
      tabIndex: onClick ? 0 : void 0,
      onClick,
      onKeyDown: (e) => {
        if (onClick && (e.key === "Enter" || e.key === " ")) {
          e.preventDefault();
          onClick();
        }
      },
      children: [
        level > 0 && /* @__PURE__ */ jsx("span", { style: { width: level * 13, flexShrink: 0 } }),
        /* @__PURE__ */ jsx(Sym, { name: icon, size: 10.5, weight: "medium", className: "aui-kit-list-row-icon" }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-list-row-title", children: title }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
        detail && /* @__PURE__ */ jsx("span", { className: "aui-kit-list-row-detail", children: detail }),
        statusColor && /* @__PURE__ */ jsx("span", { className: "aui-kit-dot", style: { background: statusColor } })
      ]
    }
  );
}
const PanelAction = ({ icon, label, onClick }) => /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-panel-action", "aria-label": label ?? icon, title: label, onClick, children: [
  icon && /* @__PURE__ */ jsx(Sym, { name: icon, size: 10.5, weight: "semibold" }),
  label && /* @__PURE__ */ jsx("span", { children: label })
] });
function TreeRow({
  depth = 0,
  icon,
  title,
  count,
  detail,
  expandable = false,
  expanded = false,
  selected = false,
  muted = false,
  bold = false,
  visible = true,
  onToggleVisible,
  onToggleExpand,
  onTap,
  trailing,
  dragHandleProps
}) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "aui-kit-tree-row",
      role: onTap ? "treeitem" : void 0,
      "aria-selected": onTap ? selected : void 0,
      "aria-expanded": expandable ? expanded : void 0,
      "aria-level": depth + 1,
      tabIndex: onTap ? 0 : void 0,
      "data-selected": selected || void 0,
      "data-muted": muted || void 0,
      "data-bold": bold || void 0,
      "data-visible": visible ? void 0 : "false",
      style: { paddingLeft: depth * 15 + 10 },
      onClick: onTap,
      onKeyDown: (e) => {
        if (onTap && (e.key === "Enter" || e.key === " ")) {
          e.preventDefault();
          onTap();
        }
      },
      ...dragHandleProps,
      children: [
        /* @__PURE__ */ jsx("span", { className: "aui-kit-tree-disclosure", children: expandable && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain", "aria-label": expanded ? "Collapse" : "Expand", onClick: (e) => {
          e.stopPropagation();
          (onToggleExpand ?? onTap)?.();
        }, children: /* @__PURE__ */ jsx(Sym, { name: "chevron-right", size: 9, weight: "semibold", style: { transform: expanded ? "rotate(90deg)" : void 0, transition: "transform .16s" } }) }) }),
        onToggleVisible && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-tree-eye", "aria-label": visible ? "Hide" : "Show", "aria-pressed": !visible, onClick: (e) => {
          e.stopPropagation();
          onToggleVisible();
        }, children: /* @__PURE__ */ jsx(Sym, { name: visible ? "visible" : "hidden", size: 10 }) }),
        /* @__PURE__ */ jsx(Sym, { name: icon, size: 12, className: "aui-kit-tree-icon" }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-tree-title", children: title }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
        count != null ? /* @__PURE__ */ jsx("span", { className: "aui-kit-tree-count", children: count }) : detail ? /* @__PURE__ */ jsx("span", { className: "aui-kit-tree-detail", children: detail }) : null,
        trailing
      ]
    }
  );
}
function SearchField({ placeholder = "Filter items", text, onChange }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-search", children: [
    /* @__PURE__ */ jsx(Sym, { name: "search", size: 11, className: "aui-kit-t3" }),
    /* @__PURE__ */ jsx("input", { type: "search", value: text, placeholder, "aria-label": placeholder, onChange: (e) => onChange(e.target.value) }),
    text && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t3", "aria-label": "Clear", onClick: () => onChange(""), children: /* @__PURE__ */ jsx(Sym, { name: "close-circle", size: 11 }) })
  ] });
}
function StepperField({ label, value, onChange, step = 1, unit = "" }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-stepper", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-property-label", children: label }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-stepper-box", role: "group", "aria-label": label, children: [
      /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Decrease ${label}`, onClick: () => onChange(value - step), children: /* @__PURE__ */ jsx(Sym, { name: "minus", size: 9, weight: "bold" }) }),
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-stepper-value", children: [
        /* @__PURE__ */ jsx("span", { children: value.toFixed(1) }),
        unit && /* @__PURE__ */ jsx("small", { children: unit })
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Increase ${label}`, onClick: () => onChange(value + step), children: /* @__PURE__ */ jsx(Sym, { name: "plus", size: 9, weight: "bold" }) })
    ] })
  ] });
}
const InspectorTabs = ({ tabs, selection, onChange }) => /* @__PURE__ */ jsx("div", { className: "aui-kit-inspector-tabs", role: "tablist", children: tabs.map((t, i) => {
  const tab = typeof t === "string" ? { label: t } : t;
  return /* @__PURE__ */ jsxs("button", { type: "button", role: "tab", "aria-selected": selection === i, "data-active": selection === i || void 0, onClick: () => onChange(i), children: [
    "icon" in tab && tab.icon && /* @__PURE__ */ jsx(Sym, { name: tab.icon, size: 10 }),
    tab.label
  ] }, tab.label);
}) });
function Segmented({ options, value, onChange, ariaLabel, size = "small" }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-segmented", role: "radiogroup", "aria-label": ariaLabel, "data-size": size, children: options.map((o) => /* @__PURE__ */ jsx("button", { type: "button", role: "radio", "aria-checked": value === o.id, "aria-label": o.label ?? o.id, "data-active": value === o.id || void 0, onClick: () => onChange(o.id), children: o.icon ? /* @__PURE__ */ jsx(Sym, { name: o.icon, size: 12 }) : o.label }, o.id)) });
}
const StageChip = ({ stage, active, compact = false, showLabel = !compact, onClick }) => /* @__PURE__ */ jsxs("button", { type: "button", role: "tab", "aria-selected": active, className: "aui-kit-stage-chip", "data-active": active || void 0, "data-compact": !showLabel || void 0, "data-small": compact || void 0, title: stage.name, onClick, children: [
  /* @__PURE__ */ jsx(Sym, { name: stage.icon, size: 12, weight: "medium" }),
  /* @__PURE__ */ jsx("span", { children: stage.name })
] });
function StatusBar({ workspace, model, engine = "RealityKit", themeName = "Studio Blue", kernel = "OCCT 7.8" }) {
  return /* @__PURE__ */ jsxs("footer", { className: "aui-kit-status-bar", "aria-label": "Status", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-status-dot" }),
    /* @__PURE__ */ jsx("strong", { children: "Aether Animation Studio" }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-hair" }),
    /* @__PURE__ */ jsx("span", { children: workspace }),
    model && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-hair" }),
      /* @__PURE__ */ jsx(Sym, { name: "cube", size: 9 }),
      /* @__PURE__ */ jsxs("span", { children: [
        model.name,
        " \xB7 ",
        model.triangles.toLocaleString(),
        " tris"
      ] })
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
    /* @__PURE__ */ jsx(Sym, { name: "cpu", size: 9 }),
    /* @__PURE__ */ jsx("span", { children: engine }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-hair" }),
    /* @__PURE__ */ jsx("span", { children: themeName }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-hair" }),
    /* @__PURE__ */ jsx("span", { children: kernel })
  ] });
}
const SYSTEM_OUTPUTS = [
  { icon: "cpu", name: "Servo bus", detail: "PCA9685 \xB7 6ch", status: "Armed", tint: AD.accent2, statusTint: AD.ok },
  { icon: "audio", name: "Audio", detail: "Built-in \xB7 L/R", status: "Ready", tint: AD.warn, statusTint: AD.ok },
  { icon: "screen-play", name: "Video wall", detail: "HDMI-1", status: "Ready", tint: AD.warn, statusTint: AD.ok },
  { icon: "lighting", name: "DMX lights", detail: "8 fixtures", status: "Offline", tint: AD.text3, statusTint: AD.text3 }
];
function SystemStatusView({ outputs = SYSTEM_OUTPUTS, media = [{ name: "hello.wav", icon: "waveform" }, { name: "eyes.mov", icon: "film-stack" }] }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-system-status", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", children: "OUTPUTS" }),
    outputs.map((o) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-binding-row", children: [
      /* @__PURE__ */ jsx(Sym, { name: o.icon, size: 14, style: { color: o.tint, width: 20 } }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("span", { children: o.name }),
        /* @__PURE__ */ jsx("small", { children: o.detail })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-status-capsule", style: tintStyle(o.statusTint), children: o.status })
    ] }, o.name)),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-divider", style: { margin: "6px 0" } }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", children: "MEDIA" }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-media-chips", children: media.map((m) => /* @__PURE__ */ jsxs("span", { className: "aui-kit-media-chip", children: [
      /* @__PURE__ */ jsx(Sym, { name: m.icon, size: 11, style: { color: AD.warn } }),
      m.name
    ] }, m.name)) })
  ] });
}
const HeaderIcon = ({ icon, label, onClick, active = false, tint }) => /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-header-icon", "aria-label": label, title: label, "data-active": active || void 0, style: tintStyle(tint), onClick, children: /* @__PURE__ */ jsx(Sym, { name: icon, size: 12 }) });
const Caption = ({ children, style }) => /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", style, children });
const Divider = ({ vertical = false, height, style }) => /* @__PURE__ */ jsx("span", { className: vertical ? "aui-kit-vdivider" : "aui-kit-divider", style: { height: vertical ? height : void 0, ...style } });
const Diamond = ({ size = 22, fill = AD.accent, className, style }) => /* @__PURE__ */ jsx("svg", { width: size, height: size, viewBox: "0 0 10 10", className, style, "aria-hidden": true, children: /* @__PURE__ */ jsx("path", { d: "M5 0 10 5 5 10 0 5z", fill }) });
const Triangle = ({ size = 22, fill = AD.accent2 }) => /* @__PURE__ */ jsx("svg", { width: size, height: size, viewBox: "0 0 10 10", "aria-hidden": true, children: /* @__PURE__ */ jsx("path", { d: "M5 0 10 10H0z", fill }) });
const useLabelId = () => useId();
function WorkspaceStageTabs({ stages, activeID, onSelect, compact = false, labelMode = "automatic", utilityStartID }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-stage-tabs", role: "tablist", "aria-label": "Workspaces", "data-compact": compact || void 0, children: stages.map((stage) => /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
    stage.id === utilityStartID && /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 22, margin: "0 3px", alignSelf: "center" } }),
    /* @__PURE__ */ jsx(StageChip, { stage, active: stage.id === activeID, compact, showLabel: showsStageLabel(labelMode, stage.id === activeID, compact), onClick: () => onSelect?.(stage.id) })
  ] }, stage.id)) });
}
function WalkthroughCard({ icon, progress, purpose, onPrevious, onNext, onClose }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-walkthrough", role: "status", children: [
    /* @__PURE__ */ jsx(Sym, { name: icon, size: 17, weight: "semibold", style: { color: AD.accent } }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-1", style: { minWidth: 0 }, children: [
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-walkthrough-kicker", children: [
        "WORKSPACE WALKTHROUGH \xB7 ",
        progress
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-walkthrough-purpose", children: purpose })
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 26 } }),
    /* @__PURE__ */ jsx(CommandButton, { icon: "chevron-left", label: "Previous workspace", onClick: onPrevious }),
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-capsule-btn", "data-primary": true, style: { padding: "5px 12px" }, onClick: onNext, children: "Next" }),
    /* @__PURE__ */ jsx(CommandButton, { icon: "close", label: "Close walkthrough", onClick: onClose })
  ] });
}
function DropZone({ icon = "document-download", title = "Drop model files here", detail = "or click to choose files", footLeft, footRight, onPick }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-8", style: { width: "100%" }, children: [
    /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-dropzone", onClick: onPick, children: [
      /* @__PURE__ */ jsx(Sym, { name: icon, size: 24, style: { color: AD.accent } }),
      /* @__PURE__ */ jsx("strong", { children: title }),
      /* @__PURE__ */ jsx("span", { children: detail })
    ] }),
    (footLeft || footRight) && /* @__PURE__ */ jsxs("div", { className: "aui-kit-between aui-kit-t3", style: { fontSize: 8.5 }, children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-hstack-5", children: footLeft }),
      /* @__PURE__ */ jsx("span", { children: footRight })
    ] })
  ] });
}
const ConnectorField = ({ label, value, onSwap }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-3", style: { width: "100%" }, children: [
  /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", style: { fontSize: 8, letterSpacing: 0.5 }, children: label }),
  /* @__PURE__ */ jsxs("div", { className: "aui-kit-connector", children: [
    /* @__PURE__ */ jsx(Sym, { name: "target", size: 11, style: { color: AD.accent } }),
    /* @__PURE__ */ jsx("span", { children: value }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t2", "aria-label": `Swap ${label}`, onClick: onSwap, children: /* @__PURE__ */ jsx(Sym, { name: "refresh", size: 11 }) })
  ] })
] });
function ContextActionsCard({ icon = "cursor-rays", title, kind, actions, activeID, onSelect, width = 186 }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-context-card", style: { width }, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-context-card-head", children: [
      /* @__PURE__ */ jsx(Sym, { name: icon, size: 13, style: { color: AD.accent2 } }),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-1", children: [
        /* @__PURE__ */ jsx("strong", { children: title }),
        /* @__PURE__ */ jsx("span", { children: kind })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      /* @__PURE__ */ jsx(Sym, { name: "more", size: 11, className: "aui-kit-t3" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-divider" }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-context-card-actions", role: "menu", children: actions.map((a) => /* @__PURE__ */ jsxs("button", { type: "button", role: "menuitem", "data-active": a.id === activeID || void 0, onClick: () => onSelect?.(a.id), children: [
      /* @__PURE__ */ jsx(Sym, { name: a.icon, size: 11, style: { color: a.danger ? AD.warn : AD.accent2, width: 15 } }),
      /* @__PURE__ */ jsx("span", { children: a.label }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
      /* @__PURE__ */ jsx(Sym, { name: "chevron-right", size: 7, className: "aui-kit-t3" })
    ] }, a.id)) })
  ] });
}
const DeviceStatusRow = ({ name, route, ok = true }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-device-row", children: [
  /* @__PURE__ */ jsx(Sym, { name: ok ? "status-ok" : "status-error", size: 11, style: { color: ok ? AD.ok : AD.warn } }),
  /* @__PURE__ */ jsx("span", { children: name }),
  /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
  /* @__PURE__ */ jsx("small", { children: route })
] });
function SafetyStatus({ healthy = true, title = "System healthy", detail = "Heartbeat received 18 ms ago", rows, onStop, stopLabel = "EMERGENCY STOP" }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-8", style: { width: "100%" }, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-hstack-8", style: { gap: 10 }, children: [
      /* @__PURE__ */ jsx(Sym, { name: healthy ? "shield-check" : "status-error", size: 27, style: { color: healthy ? AD.ok : AD.danger } }),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-1", children: [
        /* @__PURE__ */ jsx("strong", { className: "aui-kit-s12", children: title }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-t3", style: { fontSize: 9 }, children: detail })
      ] })
    ] }),
    rows.map((r) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-between", style: { fontSize: 10 }, children: [
      /* @__PURE__ */ jsxs("span", { className: "aui-kit-hstack-6", children: [
        /* @__PURE__ */ jsx("span", { className: "aui-kit-dot", style: { background: r.tint ?? AD.ok, width: 7, height: 7 } }),
        r.label
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-t3", style: { fontSize: 9 }, children: r.value })
    ] }, r.label)),
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-estop", onClick: onStop, children: stopLabel })
  ] });
}
const LiveBar = ({ fraction, tint = AD.accent, width = 52 }) => /* @__PURE__ */ jsx("span", { className: "aui-kit-live-bar", style: tintStyle(tint, { width }), children: /* @__PURE__ */ jsx("span", { style: { width: `${Math.max(0, Math.min(1, fraction)) * 100}%` } }) });
const StatChip = ({ label, value, tint }) => /* @__PURE__ */ jsxs("span", { className: "aui-kit-stat-chip", children: [
  /* @__PURE__ */ jsx("small", { children: label }),
  /* @__PURE__ */ jsx("strong", { style: { color: tint }, children: value })
] });
const ProjectCard = ({ name, kind, meta, tint = AD.accent, icon = "cube-transparent", onClick }) => /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-project-card", onClick, style: tintStyle(tint), children: [
  /* @__PURE__ */ jsx("span", { className: "aui-kit-project-thumb", children: /* @__PURE__ */ jsx(Sym, { name: icon, size: 30 }) }),
  /* @__PURE__ */ jsxs("span", { className: "aui-kit-project-text", children: [
    /* @__PURE__ */ jsx("strong", { children: name }),
    /* @__PURE__ */ jsx("span", { children: kind }),
    /* @__PURE__ */ jsx("small", { children: meta })
  ] })
] });
const DeviceIdentity = ({ icon = "cpu", name, detail, tint = AD.ok }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-device-identity", style: tintStyle(tint), children: [
  /* @__PURE__ */ jsx("span", { className: "aui-kit-device-identity-badge", children: /* @__PURE__ */ jsx(Sym, { name: icon, size: 14 }) }),
  /* @__PURE__ */ jsxs("span", { className: "aui-kit-stack-1", children: [
    /* @__PURE__ */ jsx("strong", { children: name }),
    /* @__PURE__ */ jsx("small", { children: detail })
  ] })
] });
function CalibrationRangeBar({ start = 0.1, end = 0.7, minLabel = "980\xB5s", maxLabel = "2000\xB5s", tint = AD.accent2 }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-calib", style: tintStyle(tint), children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-calib-track", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-calib-span", style: { left: `${start * 100}%`, width: `${(end - start) * 100}%` } }),
      /* @__PURE__ */ jsx("i", { style: { left: `${start * 100}%` } }),
      /* @__PURE__ */ jsx("i", { style: { left: `${end * 100}%` } })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-between aui-kit-t3", style: { fontSize: 9 }, children: [
      /* @__PURE__ */ jsx("span", { children: minLabel }),
      /* @__PURE__ */ jsx("span", { children: maxLabel })
    ] })
  ] });
}
function MouseControlDiagram({ profile, orbit, pan, zoom, special, style }) {
  const rightDetail = /right/i.test(orbit) ? "Orbit" : "Menu";
  const button = (label, detail) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-mouse-button", "data-button": label, "data-orbit": detail === "Orbit", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-mouse-key", children: label }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-mouse-detail", children: detail })
  ] });
  const row = (title, detail, icon) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-mouse-row", children: [
    /* @__PURE__ */ jsx(Sym, { name: icon, size: 12, style: { color: "var(--aether-color-accent)", width: 18 } }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("strong", { children: title }),
      /* @__PURE__ */ jsx("span", { children: detail })
    ] })
  ] });
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-mouse-diagram", role: "img", "aria-label": `Mouse mapping for ${profile}`, style, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-mouse-body", children: [
      button("L", "Select"),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-mouse-button", children: [
        /* @__PURE__ */ jsx("span", { className: "aui-kit-mouse-wheel", children: /* @__PURE__ */ jsx(Sym, { name: "arrows-vertical", size: 8, weight: "bold" }) }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-mouse-detail", children: "Wheel" })
      ] }),
      button("R", rightDetail)
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-mouse-rows", children: [
      row("Orbit", orbit, "rotate-3d"),
      row("Pan", pan, "move"),
      row("Zoom", zoom, "zoom-in"),
      row("Special", special, "sparkles")
    ] })
  ] });
}
export {
  AD,
  Badge,
  CalibrationRangeBar,
  Callout,
  Caption,
  ChipPicker,
  CommandButton,
  ConnectorField,
  ContextActionsCard,
  DeviceIdentity,
  DeviceStatusRow,
  DialogCard,
  Diamond,
  Divider,
  DocumentTabs,
  DropZone,
  Field,
  HeaderIcon,
  InspectorTabs,
  LabeledSlider,
  ListRow,
  LiveBar,
  MetricCard,
  MouseControlDiagram,
  NotificationCard,
  Panel,
  PanelAction,
  PanelCard,
  Pill,
  ProgressBar,
  ProgressCard,
  ProjectCard,
  PropertyField,
  Range,
  Row,
  SafetyStatus,
  SearchField,
  Segmented,
  SegmentedIcons,
  Spinner,
  StageChip,
  StatChip,
  StatusBar,
  StepperField,
  Switch,
  SystemStatusView,
  Toast,
  ToggleLine,
  ToggleRow,
  ToolCluster,
  TreeRow,
  Triangle,
  WalkthroughCard,
  WorkspaceStageTabs,
  tintStyle,
  useLabelId
};
