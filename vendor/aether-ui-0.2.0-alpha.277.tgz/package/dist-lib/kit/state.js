import { useCallback, useState } from "react";
const LAYOUT_PRESETS = [
  { id: "floating", label: "Floating", icon: "windows" },
  { id: "docked", label: "Docked", icon: "columns" },
  { id: "canvas", label: "Canvas", icon: "fit" }
];
const defaultLayout = () => applyPreset({
  showLeft: true,
  showRight: true,
  leftDocked: false,
  rightDocked: false,
  rightPinned: true,
  ribbonDocked: false,
  showStatusBar: true,
  panelsOnOuterEdge: false,
  showZones: false
}, "floating");
function applyPreset(flags, preset) {
  switch (preset) {
    case "floating":
      return { ...flags, showLeft: true, showRight: true, leftDocked: false, rightDocked: false, rightPinned: true, ribbonDocked: false };
    case "docked":
      return { ...flags, showLeft: true, showRight: true, leftDocked: true, rightDocked: true, rightPinned: true, ribbonDocked: true };
    case "canvas":
      return { ...flags, showLeft: false, showRight: false, leftDocked: false, rightDocked: false, rightPinned: false, ribbonDocked: false };
  }
}
function detectPreset(f) {
  if (!f.showLeft && !f.showRight && !f.ribbonDocked) return "canvas";
  if (f.showLeft && f.showRight && f.leftDocked && f.rightDocked && f.ribbonDocked) return "docked";
  if (f.showLeft && f.showRight && !f.leftDocked && !f.rightDocked && !f.ribbonDocked) return "floating";
  return null;
}
const nextPreset = (preset) => preset === "floating" ? "docked" : preset === "docked" ? "canvas" : "floating";
const layoutLabel = (f) => LAYOUT_PRESETS.find((p) => p.id === detectPreset(f))?.label ?? "Custom";
const cyclePreset = (f) => applyPreset(f, nextPreset(detectPreset(f)));
const TOOL_DENSITIES = [
  { id: "compact", label: "Compact", detail: "Icons only", icon: "grid-3" },
  { id: "standard", label: "Standard", detail: "Grouped, with headings", icon: "rows" },
  { id: "expanded", label: "Expanded", detail: "Grouped, with the workspace", icon: "grid-2" }
];
let toolSerial = 0;
const tool = (icon, label, primary = true) => ({ id: `tool-${++toolSerial}`, icon, label, primary });
const group = (name, tools, icon, tint) => ({ id: `group-${++toolSerial}`, name, tools, icon, tint });
const ribbonGroupsOf = (groups, fallbackTint) => groups.map((g) => ({ name: g.name, icon: categoryIcon(g), tint: g.tint ?? fallbackTint, tools: g.tools }));
const ribbonGroup = (name, icon, tint, tools) => ({ name, icon, tint, tools });
const categoryIcon = (g) => g.icon ?? g.tools[0]?.icon ?? "grid-2";
const primaryTools = (g) => g.tools.filter((t) => t.primary);
const overflowTools = (g) => g.tools.filter((t) => !t.primary);
const toolPrompt = (armed) => armed ? `${armed.tool.label} \u2014 click in the viewport. Esc to cancel.` : "";
const panelStack = (order, defaults = [], side = "right", exclusive = true) => ({ order, side, exclusive, enabled: exclusive ? defaults.filter((id) => order.includes(id)).slice(0, 1) : [...defaults], floatingOffset: {} });
const isEnabled = (s, id) => s.enabled.includes(id);
const orderedPanels = (s) => s.order.filter((id) => s.enabled.includes(id));
const isOpen = (s) => s.enabled.length > 0;
const isFloating = (s, id) => id in s.floatingOffset;
const stackedPanels = (s) => orderedPanels(s).filter((id) => !(id in s.floatingOffset));
const floatingPanels = (s) => orderedPanels(s).filter((id) => id in s.floatingOffset);
function togglePanel(s, id) {
  if (s.enabled.includes(id)) {
    const { [id]: _gone, ...rest } = s.floatingOffset;
    return { ...s, enabled: s.enabled.filter((e) => e !== id), floatingOffset: rest };
  }
  return s.exclusive ? { ...s, enabled: [id], floatingOffset: {} } : { ...s, enabled: [...s.enabled, id] };
}
function reorderStacked(s, id, index) {
  const others = stackedPanels(s).filter((p) => p !== id);
  const open = [...others];
  open.splice(Math.min(Math.max(index, 0), others.length), 0, id);
  const closed = s.order.filter((p) => !s.enabled.includes(p));
  return { ...s, order: [...open, ...floatingPanels(s).filter((p) => p !== id), ...closed] };
}
function detachPanel(s, id, offset) {
  const n = Object.keys(s.floatingOffset).length;
  const dx = s.side === "left" ? 230 + n * 18 : -230 - n * 18;
  return { ...s, floatingOffset: { ...s.floatingOffset, [id]: offset ?? { x: dx, y: 40 + n * 28 } } };
}
function restackPanel(s, id) {
  const { [id]: _gone, ...rest } = s.floatingOffset;
  return { ...s, floatingOffset: rest };
}
const setFloatingOffset = (s, id, offset) => ({ ...s, floatingOffset: { ...s.floatingOffset, [id]: offset } });
const nearHomeEdge = (s, offset) => s.side === "left" ? offset.x < 110 : offset.x > -110;
function usePanelStack(initial) {
  const [state, set] = useState(initial);
  const actions = {
    toggle: useCallback((id) => set((s) => togglePanel(s, id)), []),
    reorder: useCallback((id, index) => set((s) => reorderStacked(s, id, index)), []),
    detach: useCallback((id, offset) => set((s) => detachPanel(s, id, offset)), []),
    restack: useCallback((id) => set((s) => restackPanel(s, id)), []),
    setOffset: useCallback((id, offset) => set((s) => setFloatingOffset(s, id, offset)), [])
  };
  return [state, actions];
}
let nodeSerial = 0;
const treeNode = (name, icon, extra = {}) => ({ id: `node-${++nodeSerial}`, name, icon, isFolder: false, children: [], visible: true, ...extra });
const treeState = (nodes = []) => ({ nodes, selection: [], expanded: [], renaming: null });
function findNode(id, nodes) {
  for (const n of nodes) {
    if (n.id === id) return n;
    const hit = findNode(id, n.children);
    if (hit) return hit;
  }
  return null;
}
const removingNodes = (ids, nodes) => nodes.filter((n) => !ids.includes(n.id)).map((n) => ({ ...n, children: removingNodes(ids, n.children) }));
function collectNodes(ids, nodes) {
  const out = [];
  for (const n of nodes) {
    if (ids.includes(n.id)) out.push(n);
    else out.push(...collectNodes(ids, n.children));
  }
  return out;
}
function insertBefore(node, target, nodes) {
  const result = [];
  for (const n of nodes) {
    if (n.id === target) result.push(node);
    result.push({ ...n, children: insertBefore(node, target, n.children) });
  }
  return result;
}
const containsNode = (id, nodes) => nodes.some((n) => n.id === id || containsNode(id, n.children));
function isDescendant(id, ancestor, nodes) {
  const a = findNode(ancestor, nodes);
  return a ? containsNode(id, a.children) : false;
}
const mutateNode = (id, nodes, change) => nodes.map((n) => n.id === id ? change(n) : { ...n, children: mutateNode(id, n.children, change) });
function addFolder(s, name = "New Folder") {
  const folder = treeNode(name, "folder", { isFolder: true });
  return { ...s, nodes: [...s.nodes, folder], expanded: [...s.expanded, folder.id], selection: [folder.id], renaming: folder.id };
}
function groupSelection(s, name = "New Group") {
  const picked = collectNodes(s.selection, s.nodes);
  if (picked.length < 1) return s;
  const folder = treeNode(name, "folder", { isFolder: true, children: picked });
  return { ...s, nodes: [...removingNodes(s.selection, s.nodes), folder], expanded: [...s.expanded, folder.id], selection: [folder.id], renaming: folder.id };
}
const deleteNodes = (s, ids) => ({
  ...s,
  nodes: removingNodes(ids, s.nodes),
  selection: s.selection.filter((id) => !ids.includes(id)),
  expanded: s.expanded.filter((id) => !ids.includes(id))
});
const renameNode = (s, id, name) => ({ ...s, nodes: mutateNode(id, s.nodes, (n) => ({ ...n, name: name || n.name })), renaming: null });
const toggleExpanded = (s, id) => ({ ...s, expanded: s.expanded.includes(id) ? s.expanded.filter((e) => e !== id) : [...s.expanded, id] });
const toggleVisible = (s, id) => ({ ...s, nodes: mutateNode(id, s.nodes, (n) => ({ ...n, visible: !n.visible })) });
function moveNode(s, dragged, target, into) {
  if (dragged === target || isDescendant(target, dragged, s.nodes)) return s;
  const node = findNode(dragged, s.nodes);
  if (!node) return s;
  let tree = removingNodes([dragged], s.nodes);
  const t = findNode(target, tree);
  let expanded = s.expanded;
  if (into && t?.isFolder) {
    tree = mutateNode(target, tree, (n) => ({ ...n, children: [...n.children, node] }));
    if (!expanded.includes(target)) expanded = [...expanded, target];
  } else {
    tree = insertBefore(node, target, tree);
    if (!containsNode(node.id, tree)) tree = [...tree, node];
  }
  return { ...s, nodes: tree, expanded };
}
function moveIntoFolder(s, dragged, folderID) {
  const node = findNode(dragged, s.nodes);
  if (!node) return s;
  let tree = removingNodes([dragged], s.nodes);
  let expanded = s.expanded;
  if (folderID && folderID !== dragged && !isDescendant(folderID, dragged, s.nodes)) {
    tree = mutateNode(folderID, tree, (n) => ({ ...n, children: [...n.children, node] }));
    if (!expanded.includes(folderID)) expanded = [...expanded, folderID];
  } else {
    tree = [...tree, node];
  }
  return { ...s, nodes: tree, expanded };
}
const countLeaves = (nodes) => nodes.reduce((n, node) => n + (node.isFolder ? countLeaves(node.children) : 1), 0);
const STAGE_LABEL_MODES = [
  { id: "automatic", label: "Automatic" },
  { id: "all", label: "All Labels" },
  { id: "selectedOnly", label: "Selected Only" },
  { id: "iconsOnly", label: "Icons Only" }
];
function showsStageLabel(mode, isSelected, compact) {
  switch (mode) {
    case "automatic":
      return compact ? isSelected : true;
    case "all":
      return true;
    case "selectedOnly":
      return isSelected;
    case "iconsOnly":
      return false;
  }
}
export {
  LAYOUT_PRESETS,
  STAGE_LABEL_MODES,
  TOOL_DENSITIES,
  addFolder,
  applyPreset,
  categoryIcon,
  collectNodes,
  containsNode,
  countLeaves,
  cyclePreset,
  defaultLayout,
  deleteNodes,
  detachPanel,
  detectPreset,
  findNode,
  floatingPanels,
  group,
  groupSelection,
  insertBefore,
  isDescendant,
  isEnabled,
  isFloating,
  isOpen,
  layoutLabel,
  moveIntoFolder,
  moveNode,
  mutateNode,
  nearHomeEdge,
  nextPreset,
  orderedPanels,
  overflowTools,
  panelStack,
  primaryTools,
  removingNodes,
  renameNode,
  reorderStacked,
  restackPanel,
  ribbonGroup,
  ribbonGroupsOf,
  setFloatingOffset,
  showsStageLabel,
  stackedPanels,
  toggleExpanded,
  togglePanel,
  toggleVisible,
  tool,
  toolPrompt,
  treeNode,
  treeState,
  usePanelStack
};
