export type LayoutPreset = "floating" | "docked" | "canvas";
export interface LayoutFlags {
    showLeft: boolean;
    showRight: boolean;
    leftDocked: boolean;
    rightDocked: boolean;
    rightPinned: boolean;
    ribbonDocked: boolean;
    showStatusBar: boolean;
    panelsOnOuterEdge: boolean;
    showZones: boolean;
}
export declare const LAYOUT_PRESETS: readonly {
    id: LayoutPreset;
    label: string;
    icon: string;
}[];
export declare const defaultLayout: () => LayoutFlags;
/** Floating → sidebars shown, undocked; docked → everything docked; canvas → hidden. */
export declare function applyPreset(flags: LayoutFlags, preset: LayoutPreset): LayoutFlags;
export declare function detectPreset(f: LayoutFlags): LayoutPreset | null;
export declare const nextPreset: (preset: LayoutPreset | null) => LayoutPreset;
export declare const layoutLabel: (f: LayoutFlags) => string;
export declare const cyclePreset: (f: LayoutFlags) => LayoutFlags;
export type ToolDensity = "compact" | "standard" | "expanded";
export declare const TOOL_DENSITIES: readonly {
    id: ToolDensity;
    label: string;
    detail: string;
    icon: string;
}[];
export type ToolPopupStyle = "list" | "grid";
export interface RibbonTool {
    id: string;
    icon: string;
    label: string;
    /** Shown inline in the group; a non-primary tool is one of the group's "more" tools, listed under MORE in the
     *  group's heading dropdown (Jonathan, 2026-09-24: more tools live in their section, not in the settings dots). */
    primary: boolean;
    /** Optional product-controlled command state; demos may continue to arm tools. */
    active?: boolean;
    /** Remembered choice in a tool family, independent of the currently armed tool. */
    selected?: boolean;
    disabled?: boolean;
    title?: string;
    variants?: readonly RibbonTool[];
}
export interface ToolGroup {
    id: string;
    name: string;
    tools: RibbonTool[];
    /** The category glyph at Compact density; defaults to the first tool's. */
    icon?: string;
    /** The group's colour on the tinted legacy ribbon (the July-19 "Rex" build). */
    tint?: string;
}
export interface ToolCategory {
    name: string;
    groups: ToolGroup[];
}
/** The group a tool arms into — carries the tint shown in the prompt bar. */
export interface RibbonGroup {
    name: string;
    icon: string;
    tint: string;
    tools: RibbonTool[];
}
/** `RibbonTool("cube", "3D Model")` — ids are minted so two "Measure" tools stay distinct. */
export declare const tool: (icon: string, label: string, primary?: boolean) => RibbonTool;
export declare const group: (name: string, tools: RibbonTool[], icon?: string, tint?: string) => ToolGroup;
/** The tinted legacy ribbon takes RibbonGroups; a workspace catalog is ToolGroups. */
export declare const ribbonGroupsOf: (groups: readonly ToolGroup[], fallbackTint: string) => RibbonGroup[];
export declare const ribbonGroup: (name: string, icon: string, tint: string, tools: RibbonTool[]) => RibbonGroup;
export declare const categoryIcon: (g: ToolGroup) => string;
export declare const primaryTools: (g: ToolGroup) => RibbonTool[];
export declare const overflowTools: (g: ToolGroup) => RibbonTool[];
export interface ArmedTool {
    tool: RibbonTool;
    groupName: string;
    tint: string;
}
export declare const toolPrompt: (armed: ArmedTool | null) => string;
export type SidebarSide = "left" | "right";
export interface Offset {
    x: number;
    y: number;
}
export interface PanelStack {
    order: string[];
    side: SidebarSide;
    /** Exclusive = opening one panel closes the others (browser idiom). */
    exclusive: boolean;
    enabled: string[];
    floatingOffset: Record<string, Offset>;
}
export declare const panelStack: (order: string[], defaults?: string[], side?: SidebarSide, exclusive?: boolean) => PanelStack;
export declare const isEnabled: (s: PanelStack, id: string) => boolean;
export declare const orderedPanels: (s: PanelStack) => string[];
export declare const isOpen: (s: PanelStack) => boolean;
export declare const isFloating: (s: PanelStack, id: string) => boolean;
export declare const stackedPanels: (s: PanelStack) => string[];
export declare const floatingPanels: (s: PanelStack) => string[];
export declare function togglePanel(s: PanelStack, id: string): PanelStack;
/** Move a stacked panel to a new index among the stacked panels. */
export declare function reorderStacked(s: PanelStack, id: string, index: number): PanelStack;
/** Tear off: float the panel at a slot beside the stack, cascading per floating count. */
export declare function detachPanel(s: PanelStack, id: string, offset?: Offset): PanelStack;
export declare function restackPanel(s: PanelStack, id: string): PanelStack;
export declare const setFloatingOffset: (s: PanelStack, id: string, offset: Offset) => PanelStack;
/** True when a floating panel has been dragged back over its home edge. */
export declare const nearHomeEdge: (s: PanelStack, offset: Offset) => boolean;
export interface PanelStackActions {
    toggle: (id: string) => void;
    reorder: (id: string, index: number) => void;
    detach: (id: string, offset?: Offset) => void;
    restack: (id: string) => void;
    setOffset: (id: string, offset: Offset) => void;
}
export declare function usePanelStack(initial: () => PanelStack): [PanelStack, PanelStackActions];
export interface TreeNode {
    id: string;
    name: string;
    icon: string;
    detail?: string;
    isFolder: boolean;
    children: TreeNode[];
    visible: boolean;
    /** Links a leaf back to a real asset (a part id, mate id, …). */
    payload?: string;
}
export declare const treeNode: (name: string, icon: string, extra?: Partial<Omit<TreeNode, "name" | "icon">>) => TreeNode;
export interface TreeState {
    nodes: TreeNode[];
    selection: string[];
    expanded: string[];
    renaming: string | null;
}
export declare const treeState: (nodes?: TreeNode[]) => TreeState;
export declare function findNode(id: string, nodes: TreeNode[]): TreeNode | null;
export declare const removingNodes: (ids: readonly string[], nodes: TreeNode[]) => TreeNode[];
/** Nodes matching `ids`, taken from wherever they sit (grouping). */
export declare function collectNodes(ids: readonly string[], nodes: TreeNode[]): TreeNode[];
export declare function insertBefore(node: TreeNode, target: string, nodes: TreeNode[]): TreeNode[];
export declare const containsNode: (id: string, nodes: TreeNode[]) => boolean;
export declare function isDescendant(id: string, ancestor: string, nodes: TreeNode[]): boolean;
export declare const mutateNode: (id: string, nodes: TreeNode[], change: (n: TreeNode) => TreeNode) => TreeNode[];
export declare function addFolder(s: TreeState, name?: string): TreeState;
/** Wrap the current selection in a new folder. */
export declare function groupSelection(s: TreeState, name?: string): TreeState;
export declare const deleteNodes: (s: TreeState, ids: readonly string[]) => TreeState;
export declare const renameNode: (s: TreeState, id: string, name: string) => TreeState;
export declare const toggleExpanded: (s: TreeState, id: string) => TreeState;
export declare const toggleVisible: (s: TreeState, id: string) => TreeState;
/**
 * Drag-and-drop: move `dragged` before `target` or, if `target` is a folder and
 * `into` is set, inside it. Refuses to drop a folder into its own descendant.
 */
export declare function moveNode(s: TreeState, dragged: string, target: string, into: boolean): TreeState;
/** Drop onto empty space / a folder header → append to that container. */
export declare function moveIntoFolder(s: TreeState, dragged: string, folderID: string | null): TreeState;
export declare const countLeaves: (nodes: TreeNode[]) => number;
export type StageLabelMode = "automatic" | "all" | "selectedOnly" | "iconsOnly";
export declare const STAGE_LABEL_MODES: readonly {
    id: StageLabelMode;
    label: string;
}[];
/** Automatic shows every label when there is room and only the selected one in compact windows. */
export declare function showsStageLabel(mode: StageLabelMode, isSelected: boolean, compact: boolean): boolean;
