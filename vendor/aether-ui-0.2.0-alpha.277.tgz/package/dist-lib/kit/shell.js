import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from "react";
import { MenuButton } from "../Menu.js";
import { Popover } from "../Popover.js";
import { Sym, ToolGlyph } from "./icons.js";
import {
  categoryIcon,
  detectPreset,
  floatingPanels,
  isEnabled,
  isOpen,
  nearHomeEdge,
  overflowTools,
  primaryTools,
  ribbonGroupsOf,
  stackedPanels,
  toolPrompt,
  TOOL_DENSITIES,
  usePanelStack,
  panelStack
} from "./state.js";
import { AD, Caption, Divider, Range, Segmented, ToggleLine, tintStyle } from "./widgets.js";
import { CenterTray } from "./viewport.js";
import { setWorkspaceChrome, useWorkspaceChrome } from "../WorkspaceChromePreferences.js";
const defaultViewPrefs = () => ({
  viewPreset: "Standard",
  displayMode: "shaded",
  showHiddenEdges: true,
  navMode: "select",
  panSpeed: 1,
  invertPan: false,
  orbitSensitivity: 1,
  turntable: true,
  measureUnits: "mm",
  snapToGeometry: true,
  showGrid: true,
  showOrigin: true,
  showViewCube: true,
  groundShadow: true,
  keyLight: 1,
  themeName: "Studio Blue",
  showEdges: true,
  keepImportedColors: true,
  opacity: 1
});
const VIEW_TABS = [
  { id: "View", icon: "cube" },
  { id: "Environment", icon: "appearance-light" },
  { id: "Appearance", icon: "palette" },
  { id: "Inspector", icon: "sliders" }
];
const ShellContext = createContext(null);
const useKitShell = () => {
  const shell = useContext(ShellContext);
  if (!shell) throw new Error("useKitShell needs an <KitShellProvider>");
  return shell;
};
function KitShellProvider({ layout, setLayout, initialRibbon, workspaces, workspaceID, onWorkspaceSelect, children }) {
  const [armed, setArmed] = useState(null);
  const actionHandler = useRef(null);
  const [localRibbon, setLocalRibbon] = useState({ density: "standard", popupStyle: "list", activeCategory: "", toolbar: "sidebar", centerTray: false, ...initialRibbon });
  const chrome = useWorkspaceChrome();
  const ribbon = {
    ...localRibbon,
    density: chrome.toolbarDensity === "app" ? localRibbon.density : chrome.toolbarDensity,
    popupStyle: chrome.toolPopup === "app" ? localRibbon.popupStyle : chrome.toolPopup
  };
  const ribbonRef = useRef(ribbon);
  ribbonRef.current = ribbon;
  const setRibbon = (update) => {
    const previous = ribbonRef.current;
    const next = typeof update === "function" ? update(previous) : update;
    if (chrome.toolbarDensity !== "app" && next.density !== previous.density) setWorkspaceChrome({ toolbarDensity: next.density });
    if (chrome.toolPopup !== "app" && next.popupStyle !== previous.popupStyle) setWorkspaceChrome({ toolPopup: next.popupStyle });
    ribbonRef.current = next;
    setLocalRibbon(next);
  };
  const [viewPanels, viewPanelActions] = usePanelStack(() => panelStack(VIEW_TABS.map((t) => t.id), [], "right"));
  const [view, setView] = useState(defaultViewPrefs);
  const repeats = true;
  const shell = {
    layout,
    setLayout,
    armed,
    repeats,
    actionHandler,
    ribbon,
    setRibbon,
    viewPanels,
    viewPanelActions,
    view,
    setView,
    workspaces,
    workspaceID,
    onWorkspaceSelect,
    arm: (tool, group) => {
      if (actionHandler.current?.(tool)) return;
      setArmed({ tool, groupName: group.name, tint: group.tint });
    },
    disarm: () => setArmed(null),
    committed: () => {
      if (!repeats) setArmed(null);
    }
  };
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") setArmed(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  return /* @__PURE__ */ jsx(ShellContext.Provider, { value: shell, children });
}
const chromeClass = (docked) => docked ? "aui-kit-chrome aui-kit-chrome-docked" : "aui-kit-chrome aui-kit-chrome-floating";
function StackRail({ tabs, state, actions, docked = false }) {
  return /* @__PURE__ */ jsx("nav", { className: `aui-kit-rail ${chromeClass(docked)}`, "data-docked": docked || void 0, "aria-label": `${state.side === "left" ? "Workspace" : "View"} sidebar`, children: tabs.map((tab) => /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-rail-btn", "data-active": isEnabled(state, tab.id) || void 0, "aria-pressed": isEnabled(state, tab.id), "aria-label": tab.id, title: tab.id, onClick: () => actions.toggle(tab.id), children: /* @__PURE__ */ jsx(Sym, { name: tab.icon, size: 15, weight: "medium" }) }, tab.id)) });
}
function StackCard({ id, title, icon, onClose, docked = false, floating = false, width = 200, lifted = false, dragProps, style, children }) {
  return /* @__PURE__ */ jsxs(
    "section",
    {
      className: `aui-kit-card ${chromeClass(docked && !floating)}`,
      "data-lifted": lifted || void 0,
      "data-floating": floating || void 0,
      "aria-label": title,
      "data-panel": id,
      style: { width: docked && !floating ? void 0 : width, ...style },
      children: [
        /* @__PURE__ */ jsxs("header", { className: "aui-kit-card-head", ...dragProps, children: [
          /* @__PURE__ */ jsx(Sym, { name: icon, size: 11, className: "aui-kit-t3" }),
          /* @__PURE__ */ jsx("span", { children: title }),
          /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
          /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t3", "aria-label": `Hide ${title}`, title: `Hide ${title}`, onClick: onClose, children: /* @__PURE__ */ jsx(Sym, { name: "close", size: 9, weight: "bold" }) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "aui-kit-divider" }),
        /* @__PURE__ */ jsx("div", { className: "aui-kit-card-body", "data-scroll": !(docked && !floating) || void 0, children })
      ]
    }
  );
}
function PanelSidebar({ tabs, state, actions, docked = false, outer = false, content }) {
  const cardWidth = state.side === "left" ? 232 : 200;
  const stackRef = useRef(null);
  const [drag, setDrag] = useState(null);
  const startDrag = (id) => (e) => {
    if (docked || e.button !== 0) return;
    const startX = e.clientX, startY = e.clientY;
    const move = (ev) => {
      const dx = ev.clientX - startX, dy = ev.clientY - startY;
      const sideways = Math.abs(dx);
      const willFloat = sideways > cardWidth * 0.5 || sideways > 6 && sideways > Math.abs(dy) * 1.5;
      let dropIndex = null;
      if (!willFloat && stackRef.current) {
        const others = Array.from(stackRef.current.querySelectorAll("[data-panel]")).filter((el) => el.dataset.panel !== id);
        dropIndex = others.reduce((acc, el) => {
          const box = el.getBoundingClientRect();
          return acc + (ev.clientY > box.top + box.height / 2 ? 1 : 0);
        }, 0);
      }
      setDrag({ id, dx, dy, dropIndex, willFloat });
    };
    const up = (ev) => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      setDrag((d) => {
        if (d && Math.hypot(d.dx, d.dy) > 4) {
          if (d.willFloat) actions.detach(id, { x: ev.clientX - startX, y: ev.clientY - startY });
          else if (d.dropIndex !== null) actions.reorder(id, d.dropIndex);
        }
        return null;
      });
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };
  const stacked = stackedPanels(state);
  const dropLine = /* @__PURE__ */ jsx("span", { className: "aui-kit-drop-line", style: { width: cardWidth - 16 } });
  const stack = /* @__PURE__ */ jsxs("div", { ref: stackRef, className: "aui-kit-stack", "data-docked": docked || void 0, style: { width: cardWidth }, children: [
    stacked.map((id, index) => {
      const tab = tabs.find((t) => t.id === id);
      const lifted = drag?.id === id;
      return /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
        !docked && drag && !drag.willFloat && drag.dropIndex === index && dropLine,
        docked && index > 0 && /* @__PURE__ */ jsx("span", { className: "aui-kit-divider" }),
        /* @__PURE__ */ jsx(
          StackCard,
          {
            id,
            title: id,
            icon: tab?.icon ?? "square-dashed",
            docked,
            width: cardWidth,
            lifted,
            onClose: () => actions.toggle(id),
            dragProps: docked ? void 0 : { onPointerDown: startDrag(id), style: { cursor: "grab" } },
            style: lifted ? { transform: `translate(${drag.dx}px, ${drag.dy}px)`, zIndex: 1, opacity: drag.willFloat ? 0.9 : 1 } : void 0,
            children: content(id)
          }
        )
      ] }, id);
    }),
    !docked && drag && !drag.willFloat && drag.dropIndex === stacked.length && dropLine
  ] });
  if (docked) {
    const rail = /* @__PURE__ */ jsx(StackRail, { tabs, state, actions, docked: true });
    const railFirst = state.side === "left" !== outer;
    return /* @__PURE__ */ jsxs("div", { className: "aui-kit-sidebar-docked", children: [
      railFirst && rail,
      isOpen(state) && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: "auto" } }),
        /* @__PURE__ */ jsx("div", { className: "aui-kit-stack-scroll", children: stack })
      ] }),
      !railFirst && /* @__PURE__ */ jsxs(Fragment, { children: [
        isOpen(state) && /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: "auto" } }),
        rail
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-sidebar-floating", "data-side": state.side, "data-outer": outer || void 0, children: [
    /* @__PURE__ */ jsx(StackRail, { tabs, state, actions }),
    isOpen(state) && stack
  ] });
}
const ToolListRow = ({ tool, active, tint, onPick, glyph }) => /* @__PURE__ */ jsxs("button", { type: "button", role: tool.selected === void 0 ? "menuitem" : "menuitemradio", "aria-checked": tool.selected, disabled: tool.disabled, title: tool.title, className: "aui-kit-tool-list-row", "data-active": active || void 0, style: tintStyle(tint), onClick: onPick, children: [
  glyph ?? /* @__PURE__ */ jsx(ToolGlyph, { name: tool.icon, size: 13, className: active ? "aui-kit-tinted" : "aui-kit-t2" }),
  /* @__PURE__ */ jsx("span", { children: tool.label }),
  /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
  (tool.selected ?? active) && /* @__PURE__ */ jsx(Sym, { name: "check", size: 10, weight: "bold", className: "aui-kit-tinted" })
] });
function toolMenuKey(event) {
  const items = Array.from(event.currentTarget.querySelectorAll('[role^="menuitem"]:not(:disabled)'));
  if (!items.length) return;
  const index = items.indexOf(document.activeElement);
  const next = event.key === "Home" ? 0 : event.key === "End" ? items.length - 1 : event.key === "ArrowDown" || event.key === "ArrowRight" ? (index + 1) % items.length : event.key === "ArrowUp" || event.key === "ArrowLeft" ? (index - 1 + items.length) % items.length : -1;
  if (next < 0) return;
  event.preventDefault();
  event.stopPropagation();
  items[next].focus();
}
function ToolSidebar({ groups = [], categories = [], armGroup, docked = false, workspaces, workspaceID, onWorkspaceSelect, onCommand, renderIcon, activeCategory: controlledCategory, onCategoryChange }) {
  const shell = useKitShell();
  const { ribbon, setRibbon, armed } = shell;
  const density = ribbon.density;
  const hasCategories = categories.length > 0;
  const activeCategory = categories.find((c) => c.name === (controlledCategory ?? ribbon.activeCategory)) ?? categories[0];
  const activeGroups = activeCategory?.groups ?? groups;
  const [openGroup, setOpenGroup] = useState(null);
  const [showOverflow, setShowOverflow] = useState(false);
  const closeGroup = useCallback(() => setOpenGroup(null), []);
  const closeSettings = useCallback(() => setShowOverflow(false), []);
  const anchors = useRef({});
  const settingsAnchor = useRef(null);
  const arm = (tool) => {
    if (tool.disabled) return;
    if (onCommand) onCommand(tool.id);
    else shell.arm(tool, armGroup);
    setOpenGroup(null);
    setShowOverflow(false);
  };
  const isActive = (tool) => tool.active ?? (!onCommand && armed?.tool.id === tool.id);
  const glyph = (tool, size) => renderIcon?.(tool, size) ?? /* @__PURE__ */ jsx(ToolGlyph, { name: tool.icon, size });
  const withVariants = (tools) => tools.flatMap((t) => t.variants?.length ? [...t.variants] : [t]);
  const scrollTools = (event) => {
    if (event.ctrlKey || event.metaKey || Math.abs(event.deltaX) >= Math.abs(event.deltaY)) return;
    const el = event.currentTarget, before = el.scrollLeft;
    el.scrollLeft += event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? el.clientWidth : 1);
    if (before !== el.scrollLeft) event.preventDefault();
  };
  const popover = (g) => /* @__PURE__ */ jsx(Popover, { open: openGroup === g.id, anchor: anchors.current[g.id], onClose: closeGroup, focus: "first", ariaLabel: g.name, placement: "bottom-start", className: "aui-kit-popover", children: /* @__PURE__ */ jsxs("div", { className: "aui-kit-tool-popover", role: "menu", onKeyDown: toolMenuKey, children: [
    /* @__PURE__ */ jsx(Caption, { style: { padding: "8px 10px 2px" }, children: g.name.toUpperCase() }),
    popoverTools(g)
  ] }) });
  const popoverTools = (g) => /* @__PURE__ */ jsxs(Fragment, { children: [
    popoverList(withVariants(primaryTools(g))),
    overflowTools(g).length > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Divider, { style: { margin: "4px 0" } }),
      /* @__PURE__ */ jsx(Caption, { style: { padding: "2px 10px 2px" }, children: "MORE" }),
      popoverList(withVariants(overflowTools(g)))
    ] })
  ] });
  const popoverList = (tools) => /* @__PURE__ */ jsx(Fragment, { children: ribbon.popupStyle === "grid" ? /* @__PURE__ */ jsx("div", { className: "aui-kit-tool-grid", children: tools.map((t) => /* @__PURE__ */ jsx("button", { type: "button", role: t.selected === void 0 ? "menuitem" : "menuitemradio", "aria-checked": t.selected, disabled: t.disabled, "aria-label": t.label, className: "aui-kit-tool-grid-btn", "data-active": (t.selected ?? isActive(t)) || void 0, title: t.label, style: tintStyle(armGroup.tint), onClick: () => arm(t), children: glyph(t, 16) }, t.id)) }) : tools.map((t) => /* @__PURE__ */ jsx(ToolListRow, { tool: t, active: isActive(t), tint: AD.accent, glyph: glyph(t, 13), onPick: () => arm(t) }, t.id)) });
  const button = (t) => {
    const compact = density === "compact";
    const primary = /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-tool-btn", disabled: t.disabled, "data-compact": compact || void 0, "data-active": isActive(t) || void 0, "aria-label": t.label, "aria-pressed": isActive(t), title: t.title ?? t.label, onClick: () => arm(t), children: [
      glyph(t, compact ? 15 : 17),
      !compact && /* @__PURE__ */ jsx("span", { children: t.label })
    ] });
    if (!t.variants?.length) return /* @__PURE__ */ jsx("span", { className: "aui-kit-tool-slot", children: primary }, t.id);
    const key = `variants:${t.id}`, label2 = `${t.variants.map((v) => v.label).join("/")} variants`;
    return /* @__PURE__ */ jsxs("span", { className: "aui-kit-tool-variants", children: [
      primary,
      /* @__PURE__ */ jsx("button", { type: "button", ref: (el) => {
        anchors.current[key] = el;
      }, className: "aui-kit-tool-variant-toggle", "aria-label": label2, "aria-haspopup": "menu", "aria-expanded": openGroup === key, onClick: () => setOpenGroup(openGroup === key ? null : key), children: /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 8 }) }),
      /* @__PURE__ */ jsx(Popover, { open: openGroup === key, anchor: anchors.current[key]?.parentElement ?? anchors.current[key], onClose: closeGroup, focus: "first", ariaLabel: label2, placement: "bottom-start", className: "aui-kit-popover", children: /* @__PURE__ */ jsx("div", { className: "aui-kit-tool-popover", role: "menu", onKeyDown: toolMenuKey, children: popoverList([...t.variants]) }) })
    ] }, t.id);
  };
  const settingsMenu = /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("button", { ref: settingsAnchor, type: "button", className: "aui-kit-tool-more", "data-compact": density === "compact" || void 0, "aria-label": "More tools and toolbar settings", title: "More", "aria-haspopup": "menu", "aria-expanded": showOverflow, onClick: () => setShowOverflow((v) => !v), children: /* @__PURE__ */ jsx(Sym, { name: "more", size: 14, weight: "medium" }) }),
    /* @__PURE__ */ jsx(Popover, { open: showOverflow, anchor: settingsAnchor.current, onClose: closeSettings, focus: "first", ariaLabel: "Toolbar settings", placement: "bottom-end", className: "aui-kit-popover", children: /* @__PURE__ */ jsxs("div", { className: "aui-kit-tool-popover", style: { width: 232 }, role: "menu", onKeyDown: toolMenuKey, children: [
      /* @__PURE__ */ jsx(Caption, { style: { padding: "5px 10px 0" }, children: "DENSITY" }),
      TOOL_DENSITIES.map((d) => /* @__PURE__ */ jsxs("button", { type: "button", role: "menuitemradio", "aria-checked": ribbon.density === d.id, className: "aui-kit-tool-list-row aui-kit-density-row", "data-active": ribbon.density === d.id || void 0, onClick: () => {
        setRibbon({ ...ribbon, density: d.id });
        setShowOverflow(false);
      }, children: [
        /* @__PURE__ */ jsx(Sym, { name: d.icon, size: 12, className: ribbon.density === d.id ? "aui-kit-tinted" : "aui-kit-t3", style: { width: 20 } }),
        /* @__PURE__ */ jsxs("span", { className: "aui-kit-stack-1", children: [
          /* @__PURE__ */ jsx("span", { children: d.label }),
          /* @__PURE__ */ jsx("small", { children: d.detail })
        ] }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
        ribbon.density === d.id && /* @__PURE__ */ jsx(Sym, { name: "check", size: 10, weight: "bold", className: "aui-kit-tinted" })
      ] }, d.id))
    ] }) })
  ] });
  const expandedGroup = (g) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-tool-group-expanded", children: [
    /* @__PURE__ */ jsx("div", { className: "aui-kit-hstack-2", children: primaryTools(g).map(button) }),
    /* @__PURE__ */ jsxs("button", { ref: (el) => {
      anchors.current[g.id] = el;
    }, type: "button", className: "aui-kit-tool-group-caption", "aria-label": `${g.name} tools`, title: `${g.name} tools`, "aria-haspopup": "menu", "aria-expanded": openGroup === g.id, onClick: () => setOpenGroup(openGroup === g.id ? null : g.id), children: [
      g.name,
      /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 8, weight: "semibold" })
    ] }),
    popover(g)
  ] }, g.id);
  const workspaceList = workspaces ?? shell.workspaces;
  const currentWorkspace = workspaceList?.find((w) => w.id === (workspaceID ?? shell.workspaceID)) ?? workspaceList?.[0];
  const selectWorkspace = onWorkspaceSelect ?? shell.onWorkspaceSelect;
  const workspaceBox = density === "expanded" && workspaceList?.length && currentWorkspace ? /* @__PURE__ */ jsxs(
    MenuButton,
    {
      className: "aui-kit-tool-workspace",
      label: `Workspace: ${currentWorkspace.name}`,
      placement: "bottom-start",
      items: workspaceList.map((w) => ({ id: w.id, label: w.name, icon: w.icon ? /* @__PURE__ */ jsx(Sym, { name: w.icon, size: 14 }) : void 0, kind: "radio", checked: w.id === currentWorkspace.id })),
      onSelect: (id) => selectWorkspace?.(id),
      children: [
        /* @__PURE__ */ jsx(Sym, { name: currentWorkspace.icon ?? "cube-transparent", size: 20, weight: "medium" }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-tool-workspace-name", children: currentWorkspace.name }),
        /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 9, weight: "semibold" })
      ]
    }
  ) : null;
  const chrome = `aui-kit-tool-sidebar ${chromeClass(docked)}`;
  const label = "Tools";
  const selectCategory = (name) => {
    if (onCategoryChange) onCategoryChange(name);
    else setRibbon({ ...ribbon, activeCategory: name });
  };
  const categoryKey = (event, index) => {
    const next = event.key === "Home" ? 0 : event.key === "End" ? categories.length - 1 : event.key === "ArrowRight" ? (index + 1) % categories.length : event.key === "ArrowLeft" ? (index - 1 + categories.length) % categories.length : -1;
    if (next < 0) return;
    event.preventDefault();
    selectCategory(categories[next].name);
    event.currentTarget.parentElement?.querySelectorAll('[role="tab"]')[next]?.focus();
  };
  const categoryTabs = /* @__PURE__ */ jsxs("div", { className: "aui-kit-category-tabs", role: "tablist", children: [
    categories.map((c, index) => /* @__PURE__ */ jsx("button", { type: "button", role: "tab", tabIndex: activeCategory?.name === c.name ? 0 : -1, onKeyDown: (event) => categoryKey(event, index), "aria-selected": activeCategory?.name === c.name, className: "aui-kit-category-tab", "data-active": activeCategory?.name === c.name || void 0, onClick: () => selectCategory(c.name), children: c.name }, c.name)),
    docked && /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" })
  ] });
  if (density === "compact") {
    const icons = /* @__PURE__ */ jsxs(Fragment, { children: [
      activeGroups.map((g) => {
        const open = openGroup === g.id, active = g.tools.some(isActive);
        return /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
          /* @__PURE__ */ jsx("button", { ref: (el) => {
            anchors.current[g.id] = el;
          }, type: "button", className: "aui-kit-tool-category", "data-active": open || active || void 0, "aria-label": g.name, title: g.name, "aria-haspopup": "menu", "aria-expanded": open, onClick: () => setOpenGroup(open ? null : g.id), children: renderIcon && g.tools[0] ? glyph(g.tools[0], 16) : /* @__PURE__ */ jsx(Sym, { name: categoryIcon(g), size: 16, weight: "medium" }) }),
          popover(g)
        ] }, g.id);
      }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 30 } }),
      settingsMenu
    ] });
    if (hasCategories) {
      return /* @__PURE__ */ jsxs("div", { className: `${chrome} aui-kit-category-ribbon`, "data-density": "compact", "data-docked": docked || void 0, role: "toolbar", "data-toolbar-menu-boundary": "", "aria-label": label, children: [
        categoryTabs,
        /* @__PURE__ */ jsxs("div", { className: "aui-kit-category-tools", role: "tabpanel", "aria-label": `${activeCategory?.name} tools`, onWheel: scrollTools, "data-compact": "", children: [
          icons,
          docked && /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" })
        ] })
      ] });
    }
    return /* @__PURE__ */ jsx("div", { className: chrome, "data-density": "compact", "data-docked": docked || void 0, role: "toolbar", "data-toolbar-menu-boundary": "", "aria-label": label, children: icons });
  }
  if (hasCategories) {
    return /* @__PURE__ */ jsxs("div", { className: `${chrome} aui-kit-category-ribbon`, "data-density": density, "data-docked": docked || void 0, "data-workspace": workspaceBox ? "" : void 0, role: "toolbar", "data-toolbar-menu-boundary": "", "aria-label": label, children: [
      workspaceBox,
      categoryTabs,
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-category-tools", role: "tabpanel", "aria-label": `${activeCategory?.name} tools`, onWheel: scrollTools, children: [
        activeGroups.map((g, i) => /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
          expandedGroup(g),
          i < activeGroups.length - 1 && /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 46 } })
        ] }, g.id)),
        docked && /* @__PURE__ */ jsx("span", { className: "aui-kit-spacer" }),
        settingsMenu
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: chrome, "data-density": density, "data-docked": docked || void 0, "data-workspace": workspaceBox ? "" : void 0, role: "toolbar", "data-toolbar-menu-boundary": "", "aria-label": label, children: [
    workspaceBox,
    workspaceBox && /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 46 } }),
    activeGroups.map((g, i) => /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
      expandedGroup(g),
      i < activeGroups.length - 1 && /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 46 } })
    ] }, g.id)),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 46 } }),
    settingsMenu
  ] });
}
function ToolRibbon({ groups, docked }) {
  const shell = useKitShell();
  const isDocked = docked ?? shell.layout.ribbonDocked;
  const [openName, setOpenName] = useState(null);
  const anchors = useRef({});
  const activeID = shell.armed?.tool.id;
  if (isDocked) {
    return /* @__PURE__ */ jsx("div", { className: "aui-kit-tool-ribbon-docked", role: "toolbar", "aria-label": "Tools", children: groups.map((g, i) => /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-tool-ribbon-group", children: [
        /* @__PURE__ */ jsx("div", { className: "aui-kit-hstack-4", children: g.tools.map((t) => /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-kit-tool-btn aui-kit-tool-btn-docked", "data-active": activeID === t.id || void 0, style: tintStyle(g.tint), onClick: () => shell.arm(t, g), children: [
          /* @__PURE__ */ jsx(ToolGlyph, { name: t.icon, size: 19, className: "aui-kit-tinted" }),
          /* @__PURE__ */ jsx("span", { children: t.label })
        ] }, t.id)) }),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", style: { paddingLeft: 6 }, children: g.name.toUpperCase() })
      ] }),
      i < groups.length - 1 && /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: 58 } })
    ] }, g.name)) });
  }
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-tool-ribbon", role: "toolbar", "aria-label": "Tools", children: groups.map((g) => /* @__PURE__ */ jsxs("span", { style: { display: "contents" }, children: [
    /* @__PURE__ */ jsx("button", { ref: (el) => {
      anchors.current[g.name] = el;
    }, type: "button", className: "aui-kit-tool-category aui-kit-tool-category-tinted", "data-active": openName === g.name || void 0, style: tintStyle(g.tint), "aria-label": g.name, title: g.name, "aria-haspopup": "menu", "aria-expanded": openName === g.name, onClick: () => setOpenName(openName === g.name ? null : g.name), children: /* @__PURE__ */ jsx(ToolGlyph, { name: g.icon, size: 16, weight: "medium" }) }),
    /* @__PURE__ */ jsx(Popover, { open: openName === g.name, anchor: anchors.current[g.name], onClose: () => setOpenName(null), ariaLabel: g.name, placement: "bottom-start", className: "aui-kit-popover", children: /* @__PURE__ */ jsxs("div", { className: "aui-kit-tool-popover", role: "menu", children: [
      /* @__PURE__ */ jsx(Caption, { style: { padding: "9px 10px 0" }, children: g.name.toUpperCase() }),
      shell.ribbon.popupStyle === "grid" ? /* @__PURE__ */ jsx("div", { className: "aui-kit-tool-grid", children: g.tools.map((t) => /* @__PURE__ */ jsx("button", { type: "button", role: "menuitem", className: "aui-kit-tool-grid-btn", "data-active": activeID === t.id || void 0, style: tintStyle(g.tint), title: t.label, onClick: () => {
        shell.arm(t, g);
        setOpenName(null);
      }, children: /* @__PURE__ */ jsx(ToolGlyph, { name: t.icon, size: 16, weight: "medium" }) }, t.id)) }) : g.tools.map((t) => /* @__PURE__ */ jsx(ToolListRow, { tool: t, active: activeID === t.id, tint: g.tint, onPick: () => {
        shell.arm(t, g);
        setOpenName(null);
      } }, t.id))
    ] }) })
  ] }, g.name)) });
}
function PromptBar() {
  const shell = useKitShell();
  if (!shell.armed) return null;
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-prompt-bar", role: "status", style: tintStyle(shell.armed.tint), children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-prompt-icon", children: /* @__PURE__ */ jsx(Sym, { name: shell.armed.tool.icon, size: 12, weight: "semibold" }) }),
    /* @__PURE__ */ jsx("span", { children: toolPrompt(shell.armed) }),
    /* @__PURE__ */ jsx("button", { type: "button", className: "aui-kit-plain aui-kit-t3", "aria-label": "Cancel tool", onClick: shell.disarm, children: /* @__PURE__ */ jsx(Sym, { name: "close", size: 9, weight: "bold" }) })
  ] });
}
const VIEW_PRESETS = ["Standard", "Isometric", "Front", "Top", "Right"];
const DISPLAY_MODES = [{ id: "wireframe", label: "Wireframe", icon: "cube-transparent" }, { id: "hiddenLine", label: "Hidden line", icon: "cube" }, { id: "shaded", label: "Shaded", icon: "cube-filled" }];
const NAV_MODES = [{ id: "select", label: "Select", icon: "cursor" }, { id: "pan", label: "Pan", icon: "hand" }, { id: "orbit", label: "Orbit", icon: "refresh" }, { id: "measure", label: "Measure", icon: "ruler" }];
const PrefSlider = ({ label, value, onChange, min, max }) => /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-3", children: [
  /* @__PURE__ */ jsxs("div", { className: "aui-kit-between", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-pref-label", children: label }),
    /* @__PURE__ */ jsxs("span", { className: "aui-kit-t3 aui-kit-s10", children: [
      value.toFixed(2),
      "\xD7"
    ] })
  ] }),
  /* @__PURE__ */ jsx(Range, { value, min, max, onChange, ariaLabel: label })
] });
function ViewTabContent({ tab, inspector }) {
  const { view, setView, disarm } = useKitShell();
  const set = (patch) => setView((v) => ({ ...v, ...patch }));
  if (tab === "Inspector") return /* @__PURE__ */ jsx("div", { className: "aui-kit-stack-10", children: inspector });
  if (tab === "Environment") {
    return /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-10", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-pref-label", children: "Scene" }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "Grid", isOn: view.showGrid, onChange: (showGrid) => set({ showGrid }) }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "Origin", isOn: view.showOrigin, onChange: (showOrigin) => set({ showOrigin }) }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "View cube", isOn: view.showViewCube, onChange: (showViewCube) => set({ showViewCube }) }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "Ground shadow", isOn: view.groundShadow, onChange: (groundShadow) => set({ groundShadow }) }),
      /* @__PURE__ */ jsx(PrefSlider, { label: "Key light", value: view.keyLight, min: 0, max: 2, onChange: (keyLight) => set({ keyLight }) })
    ] });
  }
  if (tab === "Appearance") {
    return /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-10", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-pref-label", children: "Theme" }),
      /* @__PURE__ */ jsxs(MenuButton, { className: "aui-kit-menu-btn", label: "Theme", items: ["Studio Blue", "Graphite", "Blueprint", "High Contrast"].map((t) => ({ id: t, label: t, kind: "radio", checked: view.themeName === t })), onSelect: (themeName) => set({ themeName }), children: [
        view.themeName,
        /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 8 })
      ] }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "Show edges", isOn: view.showEdges, onChange: (showEdges) => set({ showEdges }) }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "Keep imported colors", isOn: view.keepImportedColors, onChange: (keepImportedColors) => set({ keepImportedColors }) }),
      /* @__PURE__ */ jsx(PrefSlider, { label: "Opacity", value: view.opacity, min: 0.2, max: 1, onChange: (opacity) => set({ opacity }) })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-stack-10", children: [
    /* @__PURE__ */ jsxs(MenuButton, { className: "aui-kit-menu-btn", label: "View preset", items: VIEW_PRESETS.map((p) => ({ id: p, label: p, kind: "radio", checked: view.viewPreset === p })), onSelect: (viewPreset) => set({ viewPreset }), children: [
      view.viewPreset,
      /* @__PURE__ */ jsx(Sym, { name: "chevron-down", size: 8 })
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-pref-label", children: "Display" }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-mode-group", role: "radiogroup", "aria-label": "Display mode", children: DISPLAY_MODES.map((m) => /* @__PURE__ */ jsx("button", { type: "button", role: "radio", "aria-checked": view.displayMode === m.id, title: m.label, className: "aui-kit-mode-btn", style: { width: 38, height: 32 }, "data-active": view.displayMode === m.id || void 0, onClick: () => set({ displayMode: m.id }), children: /* @__PURE__ */ jsx(Sym, { name: m.icon, size: 15, weight: "light" }) }, m.id)) }),
    /* @__PURE__ */ jsx(ToggleLine, { label: "Show hidden edges", isOn: view.showHiddenEdges, onChange: (showHiddenEdges) => set({ showHiddenEdges }) }),
    /* @__PURE__ */ jsx(Divider, {}),
    /* @__PURE__ */ jsx("span", { className: "aui-kit-pref-label", children: "Navigation" }),
    /* @__PURE__ */ jsx("div", { className: "aui-kit-mode-group", role: "radiogroup", "aria-label": "Camera navigation", children: NAV_MODES.map((m) => /* @__PURE__ */ jsx("button", { type: "button", role: "radio", "aria-checked": view.navMode === m.id, title: `${m.label} (camera)`, className: "aui-kit-mode-btn", style: { width: 34, height: 28 }, "data-active": view.navMode === m.id || void 0, onClick: () => {
      set({ navMode: m.id });
      disarm();
    }, children: /* @__PURE__ */ jsx(Sym, { name: m.icon, size: 13, weight: "medium" }) }, m.id)) }),
    view.navMode === "pan" && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(PrefSlider, { label: "Speed", value: view.panSpeed, min: 0.25, max: 3, onChange: (panSpeed) => set({ panSpeed }) }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "Invert direction", isOn: view.invertPan, onChange: (invertPan) => set({ invertPan }) })
    ] }),
    view.navMode === "orbit" && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(PrefSlider, { label: "Sensitivity", value: view.orbitSensitivity, min: 0.25, max: 3, onChange: (orbitSensitivity) => set({ orbitSensitivity }) }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "Turntable", isOn: view.turntable, onChange: (turntable) => set({ turntable }) })
    ] }),
    view.navMode === "measure" && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Segmented, { options: ["mm", "cm", "in"].map((u) => ({ id: u, label: u })), value: view.measureUnits, onChange: (measureUnits) => set({ measureUnits }), ariaLabel: "Units" }),
      /* @__PURE__ */ jsx(ToggleLine, { label: "Snap to geometry", isOn: view.snapToGeometry, onChange: (snapToGeometry) => set({ snapToGeometry }) })
    ] })
  ] });
}
const ContentInsetsContext = createContext({ top: 16, left: 16, bottom: 16, right: 16 });
const useContentInsets = () => useContext(ContentInsetsContext);
function EdgeReveal({ edge, canvas, children }) {
  const [shown, setShown] = useState(false);
  if (!canvas) return /* @__PURE__ */ jsx(Fragment, { children });
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-edge-reveal", "data-edge": edge, "data-shown": shown || void 0, onMouseEnter: () => setShown(true), onMouseLeave: () => setShown(false), children: shown ? children : /* @__PURE__ */ jsx("span", { className: "aui-kit-edge-handle", "aria-hidden": true }) });
}
const FLOAT = { left: 72, right: 72, top: 56, bottom: 24, minH: 140 };
function WorkspaceScaffold({ toolGroups = [], toolCategories = [], toolArmGroup, leftTabs, leftPanels, leftActions, centerTabs = [], centerSelection, onCenterSelect, center, left, inspector, tray }) {
  const shell = useKitShell();
  const { layout, viewPanels, viewPanelActions } = shell;
  const isCanvas = detectPreset(layout) === "canvas";
  const hasCenterTabs = centerTabs.length > 0;
  const hostRef = useRef(null);
  const [size, setSize] = useState({ width: 1200, height: 800 });
  useLayoutEffect(() => {
    const el = hostRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => setSize({ width: entry.contentRect.width, height: entry.contentRect.height }));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const bottom = hasCenterTabs ? 74 : 16;
  const insets = layout.ribbonDocked ? { top: 10, left: 10, bottom, right: 10 } : { top: 74, left: 72 + (isOpen(leftPanels) ? 242 : 0), bottom: 12 + bottom, right: 72 + (isOpen(viewPanels) ? 210 : 0) };
  const floatBase = (side, cardW) => side === "left" ? { x: 64, y: 60 } : { x: size.width - 64 - cardW, y: 60 };
  const clamp = (off, side, cardW) => {
    const base = floatBase(side, cardW);
    const minX = FLOAT.left - base.x, maxX = size.width - FLOAT.right - cardW - base.x;
    const minY = FLOAT.top - base.y, maxY = size.height - FLOAT.bottom - FLOAT.minH - base.y;
    return { x: Math.min(Math.max(off.x, minX), Math.max(minX, maxX)), y: Math.min(Math.max(off.y, minY), Math.max(minY, maxY)) };
  };
  const floatingCards = (state, actions, tabs, content) => {
    const cardW = state.side === "left" ? 232 : 200;
    return floatingPanels(state).map((id) => {
      const tab = tabs.find((t) => t.id === id);
      const base = floatBase(state.side, cardW);
      const off = clamp(state.floatingOffset[id] ?? { x: 0, y: 0 }, state.side, cardW);
      const startDrag = (e) => {
        if (e.button !== 0) return;
        const origin = state.floatingOffset[id] ?? { x: 0, y: 0 };
        const sx = e.clientX, sy = e.clientY;
        let last = origin;
        const move = (ev) => {
          last = clamp({ x: origin.x + ev.clientX - sx, y: origin.y + ev.clientY - sy }, state.side, cardW);
          actions.setOffset(id, last);
        };
        const up = () => {
          window.removeEventListener("pointermove", move);
          window.removeEventListener("pointerup", up);
          if (nearHomeEdge(state, last)) actions.restack(id);
        };
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up);
      };
      return /* @__PURE__ */ jsx("div", { className: "aui-kit-floating-card", style: { transform: `translate(${base.x + off.x}px, ${base.y + off.y}px)` }, children: /* @__PURE__ */ jsx(StackCard, { id, title: id, icon: tab?.icon ?? "square-dashed", floating: true, width: cardW, onClose: () => actions.toggle(id), dragProps: { onPointerDown: startDrag, style: { cursor: "grab" } }, children: content(id) }) }, id);
    });
  };
  const toolSidebar = (docked) => shell.ribbon.toolbar === "ribbon" ? /* @__PURE__ */ jsx(ToolRibbon, { groups: ribbonGroupsOf(toolCategories.length ? (toolCategories.find((c) => c.name === shell.ribbon.activeCategory) ?? toolCategories[0]).groups : toolGroups, toolArmGroup.tint), docked }) : /* @__PURE__ */ jsx(ToolSidebar, { groups: toolGroups, categories: toolCategories, armGroup: toolArmGroup, docked });
  const centerTray = shell.ribbon.centerTray && tray && tray.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-kit-tray-slot", style: { bottom: hasCenterTabs ? 76 : 18 }, children: /* @__PURE__ */ jsx(CenterTray, { items: tray }) });
  const workspaceSidebar = (docked) => /* @__PURE__ */ jsx(PanelSidebar, { tabs: leftTabs, state: leftPanels, actions: leftActions, docked, outer: layout.panelsOnOuterEdge, content: left });
  const viewSidebar = (docked) => /* @__PURE__ */ jsx(PanelSidebar, { tabs: VIEW_TABS, state: viewPanels, actions: viewPanelActions, docked, outer: layout.panelsOnOuterEdge, content: (id) => /* @__PURE__ */ jsx(ViewTabContent, { tab: id, inspector }) });
  const centerSwitcher = hasCenterTabs && /* @__PURE__ */ jsxs("div", { className: "aui-kit-center-switcher", role: "tablist", "aria-label": "Center view", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-kit-caption", style: { padding: "0 10px 0 8px" }, children: "CENTER VIEW" }),
    centerTabs.map((tab) => /* @__PURE__ */ jsxs("button", { type: "button", role: "tab", "aria-selected": centerSelection === tab.id, className: "aui-kit-center-tab", "data-active": centerSelection === tab.id || void 0, onClick: () => onCenterSelect?.(tab.id), children: [
      /* @__PURE__ */ jsx(Sym, { name: tab.icon, size: 13, weight: "medium" }),
      /* @__PURE__ */ jsx("span", { children: tab.id })
    ] }, tab.id))
  ] });
  const zoneOverlay = layout.showZones && /* @__PURE__ */ jsx("div", { className: "aui-kit-zone-overlay", "aria-hidden": true, style: { inset: `${insets.top}px ${insets.right}px ${insets.bottom}px ${insets.left}px` }, children: /* @__PURE__ */ jsx("span", { children: "VISIBLE ZONE" }) });
  return /* @__PURE__ */ jsx(ContentInsetsContext.Provider, { value: insets, children: /* @__PURE__ */ jsxs("div", { ref: hostRef, className: "aui-kit-scaffold", "data-mode": layout.ribbonDocked ? "docked" : isCanvas ? "canvas" : "floating", children: [
    layout.ribbonDocked ? /* @__PURE__ */ jsxs("div", { className: "aui-kit-scaffold-docked", children: [
      workspaceSidebar(true),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: "auto" } }),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-scaffold-column", children: [
        toolSidebar(true),
        /* @__PURE__ */ jsx("span", { className: "aui-kit-divider" }),
        /* @__PURE__ */ jsxs("div", { className: "aui-kit-scaffold-center", children: [
          center,
          /* @__PURE__ */ jsx(PromptBar, {})
        ] })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: "auto" } }),
      viewSidebar(true)
    ] }) : /* @__PURE__ */ jsxs("div", { className: "aui-kit-scaffold-floating", children: [
      /* @__PURE__ */ jsx("div", { className: "aui-kit-scaffold-center", children: center }),
      /* @__PURE__ */ jsxs("div", { className: "aui-kit-overlay-top", children: [
        /* @__PURE__ */ jsx(EdgeReveal, { edge: "top", canvas: isCanvas, children: toolSidebar(false) }),
        /* @__PURE__ */ jsx(PromptBar, {})
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-kit-overlay-left", children: /* @__PURE__ */ jsx(EdgeReveal, { edge: "left", canvas: isCanvas, children: workspaceSidebar(false) }) }),
      /* @__PURE__ */ jsx("div", { className: "aui-kit-overlay-right", children: /* @__PURE__ */ jsx(EdgeReveal, { edge: "right", canvas: isCanvas, children: viewSidebar(false) }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-kit-floating-layer", children: [
      floatingCards(leftPanels, leftActions, leftTabs, left),
      floatingCards(viewPanels, viewPanelActions, VIEW_TABS, (id) => /* @__PURE__ */ jsx(ViewTabContent, { tab: id, inspector }))
    ] }),
    centerTray,
    centerSwitcher,
    zoneOverlay
  ] }) });
}
const DockInsetsContext = createContext({ top: 0, bottom: 0, left: 0, right: 0 });
const useDockInsets = () => useContext(DockInsetsContext);
function DockSafeArea({ edges = ["top", "bottom", "left", "right"], children, style }) {
  const i = useDockInsets();
  return /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-safe", style: { paddingTop: edges.includes("top") ? i.top : 0, paddingBottom: edges.includes("bottom") ? i.bottom : 0, paddingLeft: edges.includes("left") ? i.left : 0, paddingRight: edges.includes("right") ? i.right : 0, ...style }, children });
}
const floatingPanelHeight = (available, preferredFraction = 0.72, minimum = 380, margins = 24) => Math.min(Math.max(0, available - margins), Math.max(minimum, available * preferredFraction));
function DockingWorkspace({ left, center, right, leftPlacement, rightPlacement, leftWidth = 246, rightWidth = 286, centerInset = 10, canvasReveal = false, leftTitle = "Browser", rightTitle = "Inspector", overlayTop, overlayBottom, ribbonClearance }) {
  const host = useRef(null);
  const [size, setSize] = useState({ width: 1200, height: 800 });
  const [revealed, setRevealed] = useState(null);
  const [rightOffset, setRightOffset] = useState({ x: 0, y: 0 });
  useLayoutEffect(() => {
    const el = host.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => setSize({ width: entry.contentRect.width, height: entry.contentRect.height }));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  useEffect(() => {
    if (rightPlacement !== "floating") setRightOffset({ x: 0, y: 0 });
  }, [rightPlacement]);
  const cardHeight = floatingPanelHeight(size.height);
  const dragRight = (e) => {
    if (e.button !== 0) return;
    const sx = e.clientX, sy = e.clientY, origin = rightOffset;
    const move = (ev) => {
      const maxLeft = size.width - 12 - rightWidth - 8, maxDown = size.height - 12 - cardHeight - 8;
      setRightOffset({ x: Math.min(0, Math.max(-maxLeft, origin.x + ev.clientX - sx)), y: Math.max(0, Math.min(maxDown, origin.y + ev.clientY - sy)) });
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };
  const floating = (side, content, width, title, peek = false) => /* @__PURE__ */ jsxs(
    "div",
    {
      className: "aui-kit-dock-floating",
      "data-side": side,
      "data-peek": peek || void 0,
      "aria-label": title,
      style: { width, height: cardHeight, transform: side === "right" ? `translate(${rightOffset.x}px, ${rightOffset.y}px)` : void 0 },
      onMouseLeave: () => {
        if (peek) setRevealed(null);
      },
      children: [
        side === "right" && !peek && /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-grip", title: "Drag to reposition", onPointerDown: dragRight, children: /* @__PURE__ */ jsx(Sym, { name: "menu", size: 10, weight: "semibold" }) }),
        /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-floating-body", children: content })
      ]
    }
  );
  const reveal = (side, content, width, title) => /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-reveal", "data-side": side, onMouseEnter: () => setRevealed(side), children: revealed === side ? floating(side, content, width, title, true) : /* @__PURE__ */ jsx("span", { className: "aui-kit-dock-reveal-handle", "aria-hidden": true }) });
  const insets = {
    top: overlayTop || ribbonClearance === "top" ? 74 : 0,
    bottom: overlayBottom || ribbonClearance === "bottom" ? 74 : 0,
    left: leftPlacement === "floating" ? leftWidth + 18 : 0,
    right: rightPlacement === "floating" ? rightWidth + 18 : 0
  };
  return /* @__PURE__ */ jsxs("div", { className: "aui-kit-dock-workspace", children: [
    leftPlacement === "docked" && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-column", style: { width: leftWidth }, "aria-label": leftTitle, children: left }),
      /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: "auto" } })
    ] }),
    /* @__PURE__ */ jsxs("div", { ref: host, className: "aui-kit-dock-center", children: [
      /* @__PURE__ */ jsx(DockInsetsContext.Provider, { value: insets, children: /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-center-body", style: { padding: centerInset }, children: center }) }),
      leftPlacement === "floating" && floating("left", left, leftWidth, leftTitle),
      rightPlacement === "floating" && floating("right", right, rightWidth, rightTitle),
      canvasReveal && leftPlacement === "hidden" && reveal("left", left, leftWidth, leftTitle),
      canvasReveal && rightPlacement === "hidden" && reveal("right", right, rightWidth, rightTitle),
      overlayTop && /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-overlay", "data-edge": "top", children: overlayTop }),
      overlayBottom && /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-overlay", "data-edge": "bottom", children: overlayBottom })
    ] }),
    rightPlacement === "docked" && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("span", { className: "aui-kit-vdivider", style: { height: "auto" } }),
      /* @__PURE__ */ jsx("div", { className: "aui-kit-dock-column", style: { width: rightWidth }, "aria-label": rightTitle, children: right })
    ] })
  ] });
}
export {
  ContentInsetsContext,
  DockSafeArea,
  DockingWorkspace,
  KitShellProvider,
  PanelSidebar,
  PromptBar,
  StackCard,
  StackRail,
  ToolRibbon,
  ToolSidebar,
  VIEW_TABS,
  ViewTabContent,
  WorkspaceScaffold,
  chromeClass,
  defaultViewPrefs,
  floatingPanelHeight,
  useContentInsets,
  useDockInsets,
  useKitShell
};
