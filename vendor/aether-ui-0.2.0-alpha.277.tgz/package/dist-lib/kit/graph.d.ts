/**
 * Timeline, graph, inspector and settings widgets: Timeline.swift, Graph.swift,
 * NodeWidgets.swift (nodes + timelines), RigAnimate.swift (CurveInspector,
 * CurveCard), MateInspector.swift, PerformanceHUD.swift, EnvironmentPanel.swift,
 * Visualization.swift (panel), DesignWorkspace.swift (PartPropertiesPanel,
 * PropSection), NewCharacterDialog.swift and SettingsKit.swift.
 */
import { type CSSProperties, type ReactNode } from "react";
/** A graph node card with connector dots and a selection state. */
export declare function GraphNode({ title, icon, sub, tint, width, big, selected, badge, onTap }: {
    title: string;
    icon: string;
    sub: string;
    tint: string;
    width?: number;
    big?: boolean;
    selected?: boolean;
    badge?: {
        text: string;
        on: boolean;
    };
    onTap?: () => void;
}): import("react").JSX.Element;
/** A live servo channel row (channel, name, position bar, angle readout, armed dot). */
export declare function ServoTrack({ name, channel, degrees, fraction, selected, armed, onTap }: {
    name: string;
    channel: number;
    degrees: number;
    fraction: number;
    selected?: boolean;
    armed?: boolean;
    onTap?: () => void;
}): import("react").JSX.Element;
export interface TimelineTrack {
    id: string;
    name: string;
    color: string;
    keys: number[];
}
/** The dope-sheet timeline — transport, ruler, and keyframe tracks. */
export declare function DopeSheetTimeline({ tracks, progress, duration, isPlaying, onScrub, onTogglePlay, onRewind, onAddKey, style, audio, badge }: {
    tracks: readonly TimelineTrack[];
    progress: number;
    duration?: number;
    isPlaying?: boolean;
    onScrub?: (p: number) => void;
    onTogglePlay?: () => void;
    onRewind?: () => void;
    onAddKey?: () => void;
    style?: CSSProperties;
    /** An audio lane under the key tracks (CodexUI TimelinePrototype / Live Follow). */ audio?: {
        name: string;
        color?: string;
    };
    /** A pill after the clock, e.g. "LIVE FOLLOW". */ badge?: {
        text: string;
        tint?: string;
    };
}): import("react").JSX.Element;
/** Typed logic node — category subtitle, colored accent, named ports, selection + warning. */
export declare function LogicNode({ title, subtitle, icon, color, inputs, outputs, selected, warning }: {
    title: string;
    subtitle: string;
    icon: string;
    color: string;
    inputs?: readonly string[];
    outputs?: readonly string[];
    selected?: boolean;
    warning?: boolean;
}): import("react").JSX.Element;
/** A row in the node library palette — the node types you can add to a graph. */
export declare const NodeLibraryRow: ({ title, category, icon, color, onAdd }: {
    title: string;
    category: string;
    icon: string;
    color: string;
    onAdd?: () => void;
}) => import("react").JSX.Element;
export interface FeatureTimelineItem {
    id: string;
    icon: string;
    title: string;
}
/** A horizontal timeline of feature nodes (Onshape/Fusion history-bar idiom). */
export declare function FeatureTimeline({ items, selectedID, onSelect, onPlay, onAdd }: {
    items: readonly FeatureTimelineItem[];
    selectedID?: string;
    onSelect?: (id: string) => void;
    onPlay?: () => void;
    onAdd?: () => void;
}): import("react").JSX.Element;
export interface DocumentTab {
    id: string;
    name: string;
}
/** A floating pill of document tabs with a trailing add button. Onshape bottom-bar idiom. */
export declare function DocumentTabBar({ tabs, selectedID, onSelect, onAdd }: {
    tabs: readonly DocumentTab[];
    selectedID?: string;
    onSelect?: (id: string) => void;
    onAdd?: () => void;
}): import("react").JSX.Element;
/** CurveCard's body without the card chrome, for the Inspector tab. */
export declare function CurveInspector(): import("react").JSX.Element;
/** Floating curve editor card — the Animate "Curve · Knee" widget. */
export declare const CurveCard: ({ onClose }: {
    onClose?: () => void;
}) => import("react").JSX.Element;
export type MateType = "fastened" | "revolute" | "slider" | "cylindrical" | "planar" | "ball";
export type MateAxis = "X" | "Y" | "Z";
export interface Mate {
    id: string;
    name: string;
    type: MateType;
    parent: string;
    child: string;
    axis: MateAxis;
    value: number;
    minValue: number;
    maxValue: number;
}
export declare const MATE_TYPES: readonly {
    id: MateType;
    label: string;
    icon: string;
    driven: boolean;
    unit: string;
}[];
export declare const mateType: (id: MateType) => {
    id: MateType;
    label: string;
    icon: string;
    driven: boolean;
    unit: string;
};
/** Live inspector for an authored mate. */
export declare function MateInspector({ mate, onChange, parentName, childName, onDelete }: {
    mate: Mate;
    onChange: (m: Mate) => void;
    parentName: string;
    childName: string;
    onDelete?: () => void;
}): import("react").JSX.Element;
/** Pinned live-stats HUD in the viewport corner. */
export declare function PerformanceHUD({ engine, fps, cpuPercent, memoryMB, loadMs, triangles, kernel, onClose }: {
    engine: string;
    fps: number;
    cpuPercent: number;
    memoryMB: number;
    loadMs?: number;
    triangles?: number;
    kernel?: string;
    onClose?: () => void;
}): import("react").JSX.Element;
export interface RenderPrefs {
    themeName: string;
    engine: string;
    background: string;
    keyLight: number;
    showOrigin: boolean;
    showViewCube: boolean;
    keepColors: boolean;
    showGrid: boolean;
    groundShadow: boolean;
    deflection: number;
    pinPerformance: boolean;
}
export declare const RENDER_ENGINES: readonly ["RealityKit", "Metal", "Ray Traced", "WebGPU", "Three.js"];
export declare const BENCH_THEMES: readonly ["Studio Blue", "Graphite", "Blueprint", "High Contrast"];
export declare const defaultRenderPrefs: () => RenderPrefs;
/** Quick scene/environment controls for the viewport tray. */
export declare function EnvironmentPanel({ prefs, onChange }: {
    prefs: RenderPrefs;
    onChange: (p: RenderPrefs) => void;
}): import("react").JSX.Element;
export interface StudioMaterial {
    name: string;
    category: string;
    finish: "Glossy" | "Matte";
    color: [number, number, number];
}
export declare const MATERIALS: readonly StudioMaterial[];
export declare const ENVIRONMENTS: readonly {
    name: string;
    background: [number, number, number];
    checkered?: boolean;
}[];
/** Material / Environment tabs with sphere previews. */
export declare function VisualizationPanel({ onMaterial, onEnvironment }: {
    onMaterial?: (m: StudioMaterial) => void;
    onEnvironment?: (name: string) => void;
}): import("react").JSX.Element;
/** A collapsible titled section with a disclosure chevron. */
export declare function PropSection({ title, defaultOpen, children }: {
    title: string;
    defaultOpen?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
export interface DesignShape {
    id: string;
    kind: string;
    icon: string;
    tint: string;
    x: number;
    y: number;
    size: number;
    material: string;
    appearance: string;
    opacity: number;
    visible: boolean;
    rotation: [number, number, number];
}
/** Context-aware Inspector content for a selected part: General, Transform, Information. */
export declare function PartPropertiesPanel({ shape, onChange, onDelete }: {
    shape: DesignShape;
    onChange: (s: DesignShape) => void;
    onDelete?: (id: string) => void;
}): import("react").JSX.Element;
/** New Character sheet — a project-local Character you can later publish. */
export declare function NewCharacterDialog({ onCreate, onCancel }: {
    onCreate: (name: string) => void;
    onCancel: () => void;
}): import("react").JSX.Element;
export declare const SettingsPage: ({ title, subtitle, children }: {
    title: string;
    subtitle?: string;
    children: ReactNode;
}) => import("react").JSX.Element;
export declare const SettingsSection: ({ title, icon, footnote, children }: {
    title: string;
    icon: string;
    footnote?: string;
    children: ReactNode;
}) => import("react").JSX.Element;
export declare const SettingsSlider: ({ label, value, onChange, min, max, format, step }: {
    label: string;
    value: number;
    onChange: (v: number) => void;
    min?: number;
    max?: number;
    format?: (v: number) => string;
    step?: number;
}) => import("react").JSX.Element;
export declare const SettingsColorRow: ({ label, color, onChange }: {
    label: string;
    color: string;
    onChange: (v: string) => void;
}) => import("react").JSX.Element;
export declare const SettingsLabeledRow: ({ label, children }: {
    label: string;
    children: ReactNode;
}) => import("react").JSX.Element;
export declare const SettingsCheck: ({ label, checked, onChange }: {
    label: string;
    checked: boolean;
    onChange: (v: boolean) => void;
}) => import("react").JSX.Element;
/** The theme's palette at a glance. */
export declare const ThemeSwatchStrip: ({ colors }: {
    colors: readonly string[];
}) => import("react").JSX.Element;
/** Approximate preview of the shared roughness/metallic surface values. */
export declare const MaterialPreviewSphere: ({ roughness, metallic, size }: {
    roughness: number;
    metallic: number;
    size?: number;
}) => import("react").JSX.Element;
/** A synthetic waveform, drawn the way CodexUI's Canvas drew its dialogue track. */
export declare function WaveformLane({ color, samples }: {
    color?: string;
    samples?: number;
}): import("react").JSX.Element;
export interface CueBlock {
    start: number;
    length: number;
    label: string;
}
export interface CueTrack {
    name: string;
    color: string;
    blocks: readonly CueBlock[];
}
/** The Show sequence: transport, timecode, a state pill, and block tracks per medium (ShowPrototype.swift). */
export declare function CueTimeline({ tracks, timecode, badge, onPlay, onStop, onRewind, style }: {
    tracks: readonly CueTrack[];
    timecode?: string;
    badge?: {
        text: string;
        tint?: string;
    } | null;
    onPlay?: () => void;
    onStop?: () => void;
    onRewind?: () => void;
    style?: CSSProperties;
}): import("react").JSX.Element;
/** A typed port line in the node inspector (PrototypeNodePortRow). */
export declare const NodePortRow: ({ direction, name, type, color }: {
    direction: "IN" | "OUT";
    name: string;
    type: string;
    color: string;
}) => import("react").JSX.Element;
export interface CanvasNode {
    id: string;
    x: number;
    y: number;
    width?: number;
    title: string;
    subtitle: string;
    icon: string;
    color: string;
    inputs?: readonly string[];
    outputs?: readonly string[];
    selected?: boolean;
    warning?: boolean;
}
/** A link between unit-space anchor points; the S-curve is drawn like CodexUI's `drawConnection`. */
export interface CanvasLink {
    from: [number, number];
    to: [number, number];
    color: string;
}
export declare const connectionPath: (x1: number, y1: number, x2: number, y2: number) => string;
/** The behaviour graph: dotted grid, S-curve links, positioned `LogicNode`s, and the canvas status chrome (PrototypeNodeCanvas). */
export declare function NodeCanvas({ nodes, links, title, status, zoom, height, style }: {
    nodes: readonly CanvasNode[];
    links: readonly CanvasLink[];
    title?: string;
    status?: {
        text: string;
        tint?: string;
    } | null;
    zoom?: string;
    height?: number;
    style?: CSSProperties;
}): import("react").JSX.Element;
export interface ChannelMapRow {
    motion: string;
    channel: string;
    range: string;
    color: string;
    live: number;
}
/** Semantic motion → device / channel → range → live value (HardwarePrototype channel map). */
export declare function ChannelMapTable({ rows, style }: {
    rows: readonly ChannelMapRow[];
    style?: CSSProperties;
}): import("react").JSX.Element;
export interface ThemeTile {
    id: string;
    label: string;
    panel: string;
    accent: string;
    line?: string;
}
/** The theme picker grid from CodexUI's Appearance settings: a panel swatch with the accent dot. */
export declare function ThemeTileGrid({ themes, activeID, onSelect }: {
    themes: readonly ThemeTile[];
    activeID: string;
    onSelect?: (id: string) => void;
}): import("react").JSX.Element;
