/** Instructions shown only when the user opens Help. */
export interface FeatureWindowHelp {
    summary: string;
    steps?: readonly string[];
}
/** Shared icon-control row. Help opens beside the editor without resizing it. */
export declare function createFeatureWindowAccessories(options: {
    title: string;
    help?: FeatureWindowHelp;
    helpActive?: boolean;
    onHelpToggle?: (active: boolean) => void;
}): {
    element: HTMLDivElement;
    /** Synchronize app-owned state without firing the user-toggle callback. */
    setHelpActive: (active: boolean) => void;
    addHelp: (contentNode: HTMLElement | string) => void;
    dispose: () => void;
    actionIcon(iconSvg: string, title: string, onToggle: (active: boolean) => void, active?: boolean): HTMLButtonElement;
};
