import { AetherIcon, aetherIconNames } from "./AetherIcon.js";
import { createElement, useEffect, useRef } from "react";
const scopes = /* @__PURE__ */ new Set();
let pointer = null;
function rememberContextTarget(target, x, y) {
  pointer = { target, x, y };
}
function contextTargetAt(anchor) {
  if (!pointer || !anchor || typeof anchor !== "object" || !("x" in anchor) || !("y" in anchor)) return null;
  return anchor.x === pointer.x && anchor.y === pointer.y ? pointer.target : null;
}
function useContextCommands(commands, element) {
  const current = useRef(commands);
  current.current = commands;
  useEffect(() => {
    const scope = { element, commands: () => current.current };
    scopes.add(scope);
    return () => {
      scopes.delete(scope);
    };
  }, [element]);
}
function contextCommandsFor(target, scopedOnly = false) {
  const matches = [...scopes].filter((s) => s.element ? s.element.current?.contains(target) : !scopedOnly);
  const depth = (s) => {
    let n = 0, e = s.element?.current;
    while (e) {
      n++;
      e = e.parentElement;
    }
    return n;
  };
  matches.sort((a, b) => depth(a) - depth(b));
  const commands = /* @__PURE__ */ new Map();
  matches.forEach((s) => s.commands().forEach((c) => commands.set(c.id, c)));
  return [...commands.values()].sort((a, b) => (a.order ?? 100) - (b.order ?? 100));
}
function runContextCommand(command) {
  if (command.disabled) return;
  try {
    Promise.resolve(command.run()).catch(report);
  } catch (error) {
    report(error);
  }
}
function report(error) {
  document.dispatchEvent(new CustomEvent("aether-context-error", { detail: error instanceof Error ? error.message : String(error) }));
}
function shortcutLabel(shortcut) {
  if (!shortcut?.includes("Mod+")) return shortcut;
  const mac = typeof navigator !== "undefined" && /Mac|iPhone|iPad/.test(navigator.platform);
  return mac ? shortcut.replace("Mod+Shift+", "\u21E7\u2318").replace("Mod+", "\u2318") : shortcut.replace("Mod+", "Ctrl+");
}
function contextCommandItems(commands) {
  return commands.map(({ run: _run, heading, ...item }, index) => {
    const aliases = { "zoom-fit": "fit", "surface-fit": "fit", "zoom": "zoom-in", "application-settings": "settings" };
    const icon = aliases[item.id] ?? (aetherIconNames.includes(item.id) ? item.id : "document");
    return {
      ...item,
      icon: item.icon ?? createElement(AetherIcon, { name: icon }),
      id: `aether:${item.id}`,
      shortcut: shortcutLabel(item.shortcut),
      separatorBefore: index > 0 && (!!item.separatorBefore || !!heading && heading !== commands[index - 1].heading)
    };
  });
}
export {
  contextCommandItems,
  contextCommandsFor,
  contextTargetAt,
  rememberContextTarget,
  runContextCommand,
  useContextCommands
};
