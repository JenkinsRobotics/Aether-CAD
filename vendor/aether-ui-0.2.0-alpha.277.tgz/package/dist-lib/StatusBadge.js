import { jsx } from "react/jsx-runtime";
import "./AnalyticsElements.css";
function StatusBadge({ children, tone = "neutral" }) {
  return /* @__PURE__ */ jsx("span", { className: "aui-status-badge", "data-tone": tone, children });
}
export {
  StatusBadge
};
