import { jsx, jsxs } from "react/jsx-runtime";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import "./DocumentSaveGuard.css";
function DocumentSaveGuard({ state, recoveries, onRecover, onKeepSaved, onSignIn, onRetry, onCopy, onDownload, onOpenSaved, recoveryOpensTab = false }) {
  if (recoveries.length) return /* @__PURE__ */ jsxs(Dialog, { open: true, title: "Unsaved changes found", onClose: onKeepSaved, children: [
    /* @__PURE__ */ jsx("p", { children: "Unsaved changes from another tab were found on this browser. Choose a draft to recover." }),
    recoveries.map((draft) => /* @__PURE__ */ jsxs("div", { className: "aui-document-save-guard-actions", children: [
      /* @__PURE__ */ jsxs("span", { children: [
        new Date(draft.updated).toLocaleString(),
        " \xB7 based on revision ",
        draft.revision ?? "new document"
      ] }),
      /* @__PURE__ */ jsx(Button, { onClick: () => onRecover(draft.id), children: recoveryOpensTab ? "Open recovery in new tab" : "Recover changes" })
    ] }, draft.id)),
    /* @__PURE__ */ jsx(Button, { onClick: onKeepSaved, children: "Keep saved version" })
  ] });
  const problem = state.phase === "conflict" || state.phase === "offline" || state.phase !== "saved" && state.backedUp === false;
  if (!problem) return null;
  const signIn = state.status === 401;
  const message = signIn ? "Your sign-in expired. Changes have not been saved to Studio." : state.status === 409 ? "Another tab saved a newer version. This tab cannot overwrite it." : state.message ?? "Your latest changes do not have a recovery backup. Keep this tab open until saving finishes.";
  return /* @__PURE__ */ jsxs("section", { className: "aui-document-save-guard", "aria-label": "Save needs attention", children: [
    /* @__PURE__ */ jsxs("p", { role: "alert", children: [
      message,
      " ",
      state.backedUp ? "A recovery copy is kept on this browser." : "Keep this tab open or download your changes."
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-document-save-guard-actions", children: [
      signIn && /* @__PURE__ */ jsx(Button, { primary: true, onClick: onSignIn, children: "Sign in to save" }),
      /* @__PURE__ */ jsx(Button, { onClick: onRetry, children: "Check and retry save" }),
      !signIn && /* @__PURE__ */ jsx(Button, { onClick: onCopy, children: "Save a copy" }),
      onOpenSaved && /* @__PURE__ */ jsx(Button, { onClick: onOpenSaved, children: "Open saved version" }),
      /* @__PURE__ */ jsx(Button, { onClick: onDownload, children: "Download unsaved copy" })
    ] })
  ] });
}
export {
  DocumentSaveGuard
};
