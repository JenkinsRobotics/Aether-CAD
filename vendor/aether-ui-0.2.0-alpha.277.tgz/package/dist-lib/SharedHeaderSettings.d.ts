/** The Settings Header pane lists only controls provided by a mounted app header. */
export declare function SharedHeaderSettings({ appID }: {
    appID?: string;
}): import("react").JSX.Element;
