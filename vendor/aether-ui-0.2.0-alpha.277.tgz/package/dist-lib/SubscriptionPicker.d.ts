import "./WorkflowWidgets.css";
export interface SubscriptionPlan {
    id: string;
    label: string;
    description: string;
    price: string;
    detail: string;
}
export interface SubscriptionPickerProps {
    plans: readonly SubscriptionPlan[];
    selected: string;
    onSelect: (id: string) => void;
    period: string;
    onPeriodChange: (id: string) => void;
    allowance: string;
    allowances: readonly {
        value: string;
        label: string;
    }[];
    onAllowanceChange: (value: string) => void;
    onSubscribe: () => void;
}
export declare function SubscriptionPicker({ plans, selected, onSelect, period, onPeriodChange, allowance, allowances, onAllowanceChange, onSubscribe }: SubscriptionPickerProps): import("react").JSX.Element;
