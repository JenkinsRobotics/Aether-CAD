import { type CollectionControl } from "./CollectionView.js";
import { type CollectionFilterOption } from "./CollectionFilter.js";
import type { CSSProperties, ReactNode } from "react";
export interface ListBoxItem {
    id: string;
    category?: string;
    label: string;
    description?: string;
    icon?: ReactNode;
    badge?: string;
    /** Non-interactive metadata, such as version and revision badges. */
    accessory?: ReactNode;
    group?: string;
    disabled?: boolean;
    dimmed?: boolean;
    actions?: readonly {
        id: string;
        label: string;
        icon: ReactNode;
        pinned?: boolean;
        disabled?: boolean;
        shortcut?: 'Delete' | 'F2';
    }[];
}
export interface ListBoxProps {
    items: readonly ListBoxItem[];
    selectedIDs: ReadonlySet<string>;
    onSelect?: (ids: readonly string[], mode: "single" | "toggle" | "range") => void;
    ariaLabel: string;
    title?: string;
    controls?: readonly CollectionControl[];
    /** Hide the search/category row for compact secondary lists. */
    showFilter?: boolean;
    filter?: string;
    onFilterChange?: (query: string) => void;
    filterOptions?: readonly CollectionFilterOption[];
    selectionMode?: "none" | "single" | "multiple";
    onActivate?: (id: string) => void;
    onContextMenu?: (id: string, x: number, y: number) => void;
    onAction?: (itemID: string, actionID: string) => void;
    emptyState?: ReactNode;
    loading?: boolean;
    loadingState?: ReactNode;
    error?: ReactNode;
    /** Lists at or above this item count use fixed-row windowing. */
    virtualizeThreshold?: number;
    /** Scroll viewport height used when windowing. */
    height?: number;
    rowHeight?: number;
    overscan?: number;
    className?: string;
    style?: CSSProperties;
}
/**
 * THE flat collection for Aether products. Product code supplies data and
 * commands; ListBox owns consistent selection, keyboard, action, and scalable
 * rendering behavior.
 */
export declare function ListBoxRows({ items, selectedIDs, onSelect, ariaLabel, selectionMode, onActivate, onContextMenu, onFocusItem, onAction, emptyState, loading, loadingState, error, virtualizeThreshold, height, rowHeight, overscan, className, style, }: ListBoxProps & {
    onFocusItem?: (id: string) => void;
}): import("react").JSX.Element;
/** Every flat collection uses the same searchable frame as hierarchical lists. */
export declare function ListBox(props: ListBoxProps): import("react").JSX.Element;
