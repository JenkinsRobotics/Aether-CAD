import "./ConceptInspectors.css";
export interface AppearanceValue {
    color: string;
    opacity: number;
    tessellation: "auto" | "high";
}
export interface AppearanceInspectorProps {
    value?: AppearanceValue;
    onChange?: (value: AppearanceValue) => void;
    showTessellation?: boolean;
}
export declare function AppearanceInspector({ value, onChange, showTessellation }: AppearanceInspectorProps): import("react").JSX.Element;
