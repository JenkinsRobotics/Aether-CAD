import { jsx, jsxs } from "react/jsx-runtime";
function Ribbon({ children }) {
  const onKeyDown = (event) => {
    if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
    const tools = Array.from(
      event.currentTarget.querySelectorAll(
        ".aui-ribbon-tool:not(:disabled)"
      )
    );
    const index = tools.indexOf(document.activeElement);
    if (index < 0) return;
    event.preventDefault();
    const step = event.key === "ArrowRight" ? 1 : -1;
    tools[(index + step + tools.length) % tools.length]?.focus();
  };
  return /* @__PURE__ */ jsx("div", { className: "aui-ribbon", role: "toolbar", onKeyDown, children });
}
function RibbonGroup({ label, children }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-ribbon-group", children: [
    /* @__PURE__ */ jsx("div", { className: "aui-ribbon-group-buttons", children }),
    /* @__PURE__ */ jsx("div", { className: "aui-ribbon-group-label", children: label })
  ] });
}
function RibbonTool({ icon, label, active, disabled, onClick, ...buttonProps }) {
  const classes = ["aui-ribbon-tool"];
  if (active) classes.push("aui-ribbon-tool--active");
  return /* @__PURE__ */ jsxs(
    "button",
    {
      ...buttonProps,
      type: "button",
      className: classes.join(" "),
      disabled,
      onClick,
      children: [
        /* @__PURE__ */ jsx("span", { className: "aui-ribbon-tool-icon", "aria-hidden": true, children: icon }),
        /* @__PURE__ */ jsx("span", { className: "aui-ribbon-tool-label", children: label })
      ]
    }
  );
}
export {
  Ribbon,
  RibbonGroup,
  RibbonTool
};
