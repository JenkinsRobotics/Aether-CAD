import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
import "./EnvironmentControl.css";
function EnvironmentControl({ actions, onSelect }) {
  const [open, setOpen] = useState(false);
  const button = useRef(null);
  const id = useId();
  useEffect(() => {
    if (!open) return;
    const close = (event) => {
      if (event.key !== "Escape" || event.defaultPrevented) return;
      const focused = event.target instanceof Element ? event.target : document.activeElement;
      if (focused?.closest(".aui-studio-camera-control")) return;
      setOpen(false);
      button.current?.focus();
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [open]);
  return /* @__PURE__ */ jsxs("div", { className: "aui-environment-control", "data-expanded": open, style: { "--environment-actions": actions.length }, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-environment-surface", children: [
      /* @__PURE__ */ jsx("button", { ref: button, className: "aui-environment-toggle", type: "button", "aria-label": "Environment", title: open ? "Collapse environment" : "Expand environment", "aria-expanded": open, "aria-controls": id, onClick: () => setOpen(!open), children: /* @__PURE__ */ jsx(AetherIcon, { name: "lighting" }) }),
      /* @__PURE__ */ jsx("div", { id, className: "aui-environment-content", role: "group", "aria-label": "Environment and snapping controls", "aria-hidden": !open, inert: !open, children: actions.map((action) => action.items ? /* @__PURE__ */ jsxs(MenuButton, { className: "aui-environment-action", menuClassName: "aui-collection-popup", label: action.label, placement: "bottom-end", items: action.items, onSelect, disabled: action.disabled, children: [
        action.icon,
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down", className: "aui-environment-action-caret" })
      ] }, action.id) : /* @__PURE__ */ jsx("button", { className: "aui-environment-action", type: "button", "aria-label": action.label, title: action.disabledReason ?? action.label, "aria-pressed": action.pressed, disabled: action.disabled, onClick: () => onSelect(action.id), children: action.icon }, action.id)) })
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-environment-caption", children: "Environment" })
  ] });
}
export {
  EnvironmentControl
};
