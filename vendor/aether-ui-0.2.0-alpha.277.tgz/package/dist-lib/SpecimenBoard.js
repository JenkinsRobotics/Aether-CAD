import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import "./ConceptWidgets.css";
function SpecimenBoard({ title, detail, icon = "hammer", eyebrow, stats = [], status, sections }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-specimen-board", children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-specimen-board__intro", children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: icon }),
      /* @__PURE__ */ jsxs("div", { children: [
        eyebrow ? /* @__PURE__ */ jsx("small", { children: eyebrow }) : null,
        /* @__PURE__ */ jsx("strong", { children: title }),
        /* @__PURE__ */ jsx("span", { children: detail })
      ] }),
      stats.length || status ? /* @__PURE__ */ jsxs("aside", { children: [
        stats.map((stat) => /* @__PURE__ */ jsx("b", { children: stat }, stat)),
        status ? /* @__PURE__ */ jsx("em", { children: status }) : null
      ] }) : null
    ] }),
    sections.map((section) => /* @__PURE__ */ jsxs("section", { className: "aui-specimen-board__section", children: [
      /* @__PURE__ */ jsxs("header", { children: [
        /* @__PURE__ */ jsx("strong", { children: section.title }),
        /* @__PURE__ */ jsx("span", { children: section.detail }),
        /* @__PURE__ */ jsx("small", { children: section.specimens.length })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-specimen-board__grid", style: { "--aui-specimen-min": `${section.minimumWidth ?? 290}px`, "--aui-specimen-max": `${section.maximumWidth ?? 410}px` }, children: section.specimens.map((specimen) => {
        return /* @__PURE__ */ jsxs("article", { className: "aui-specimen-card", children: [
          /* @__PURE__ */ jsxs("header", { children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: specimen.icon }),
            /* @__PURE__ */ jsx("strong", { children: specimen.title }),
            /* @__PURE__ */ jsx("span", { children: specimen.detail }),
            specimen.idealSize ? /* @__PURE__ */ jsxs("small", { children: [
              "IDEAL ",
              specimen.idealSize
            ] }) : null
          ] }),
          /* @__PURE__ */ jsx("div", { className: "aui-specimen-card__content", style: { "--aui-specimen-height": `${specimen.previewHeight ?? 120}px` }, children: specimen.designSize ? /* @__PURE__ */ jsx(ScaledSpecimen, { size: specimen.designSize, height: specimen.previewHeight ?? 370, children: specimen.content }) : specimen.content })
        ] }, specimen.id);
      }) })
    ] }, section.id))
  ] });
}
function ScaledSpecimen({ size, height, children }) {
  const host = useRef(null);
  const [scale, setScale] = useState(1);
  const [width, designHeight] = size;
  useEffect(() => {
    const element = host.current;
    if (!element || typeof ResizeObserver === "undefined") return;
    const measure = () => setScale(Math.min(element.clientWidth / width, height / designHeight, 1));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, [width, designHeight, height]);
  return /* @__PURE__ */ jsx("div", { ref: host, className: "aui-scaled-specimen", style: { height }, children: /* @__PURE__ */ jsx("div", { style: { width, height: designHeight, transform: `scale(${scale})`, transformOrigin: "top left" }, children }) });
}
export {
  SpecimenBoard
};
