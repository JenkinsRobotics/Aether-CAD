import { jsx, jsxs } from "react/jsx-runtime";
import { NotificationContent } from "./Toast.js";
function NotificationCenter({ items, onAction, onDismiss, onMarkRead, onClear, emptyMessage = "No notifications", ariaLabel = "Notification history" }) {
  return /* @__PURE__ */ jsxs("section", { className: "aui-notification-center", "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsx("strong", { children: ariaLabel }),
      items.length && onClear ? /* @__PURE__ */ jsx("button", { type: "button", onClick: onClear, children: "Clear all" }) : null
    ] }),
    items.length === 0 ? /* @__PURE__ */ jsx("div", { className: "aui-notification-empty", children: emptyMessage }) : /* @__PURE__ */ jsx("ul", { children: items.map((item) => /* @__PURE__ */ jsxs("li", { className: item.read ? "" : "aui-notification--unread", children: [
      /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-notification-main", "aria-label": item.read ? `Open ${item.title}` : `Mark ${item.title} read`, onClick: () => onMarkRead?.(item.id), children: [
        /* @__PURE__ */ jsx(NotificationContent, { item }),
        item.timestamp ? /* @__PURE__ */ jsx("time", { children: item.timestamp }) : null
      ] }),
      /* @__PURE__ */ jsxs("span", { className: "aui-notification-actions", children: [
        item.actionLabel ? /* @__PURE__ */ jsx("button", { type: "button", onClick: () => onAction?.(item.id), children: item.actionLabel }) : null,
        /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Remove ${item.title}`, onClick: () => onDismiss?.(item.id), children: "\xD7" })
      ] })
    ] }, item.id)) })
  ] });
}
export {
  NotificationCenter
};
