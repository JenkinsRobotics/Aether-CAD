import type { ReactNode } from "react";
export type NotificationKind = "success" | "warning" | "error" | "progress";
export interface NotificationItem {
    id: string;
    kind: NotificationKind;
    title: string;
    message?: string;
    timestamp?: string;
    read?: boolean;
    progress?: number;
    actionLabel?: string;
    persistent?: boolean;
}
export interface ToastStackProps {
    items: readonly NotificationItem[];
    onAction?: (id: string) => void;
    onDismiss?: (id: string) => void;
    className?: string;
}
export declare function NotificationContent({ item, actions }: {
    item: NotificationItem;
    actions?: ReactNode;
}): import("react").JSX.Element;
export declare function ToastStack({ items, onAction, onDismiss, className }: ToastStackProps): import("react").JSX.Element;
