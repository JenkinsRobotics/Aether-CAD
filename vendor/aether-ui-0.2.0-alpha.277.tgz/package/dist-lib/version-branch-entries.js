function versionBranchIDs(entries, branch) {
  const byID = new Map(entries.map((entry) => [entry.id, entry]));
  const found = /* @__PURE__ */ new Set();
  const queue = entries.filter((entry) => entry.branch === branch).map((entry) => entry.id);
  while (queue.length) {
    const id = queue.pop();
    if (found.has(id)) continue;
    const entry = byID.get(id);
    if (!entry) continue;
    found.add(id);
    queue.push(...entry.primaryParents);
  }
  return found;
}
export {
  versionBranchIDs
};
