import { jsx, jsxs } from "react/jsx-runtime";
import { useId, useRef, useState } from "react";
import { Button } from "./Button.js";
function FileField({ files, defaultFiles = [], onFilesChange, label, accept, multiple = false, disabled = false, help, error, className }) {
  const [internal, setInternal] = useState(defaultFiles);
  const [dragging, setDragging] = useState(false);
  const current = files ?? internal;
  const inputRef = useRef(null);
  const inputID = useId();
  const update = (next) => {
    const bounded = multiple ? next : next.slice(0, 1);
    if (files === void 0) setInternal(bounded);
    onFilesChange?.(bounded);
  };
  const drop = (event) => {
    event.preventDefault();
    setDragging(false);
    if (!disabled) update([...event.dataTransfer.files]);
  };
  return /* @__PURE__ */ jsxs("div", { className: ["aui-file-field", dragging ? "aui-file-field--dragging" : "", className].filter(Boolean).join(" "), "aria-invalid": Boolean(error) || void 0, children: [
    /* @__PURE__ */ jsx("label", { htmlFor: inputID, children: label }),
    /* @__PURE__ */ jsxs("div", { className: "aui-file-drop", onDragEnter: (event) => {
      event.preventDefault();
      if (!disabled) setDragging(true);
    }, onDragOver: (event) => event.preventDefault(), onDragLeave: () => setDragging(false), onDrop: drop, children: [
      /* @__PURE__ */ jsx("input", { id: inputID, ref: inputRef, type: "file", accept, multiple, disabled, onChange: (event) => update([...event.target.files ?? []]) }),
      /* @__PURE__ */ jsx(Button, { disabled, onClick: () => inputRef.current?.click(), children: "Browse\u2026" }),
      /* @__PURE__ */ jsx("span", { children: current.length > 0 ? `${current.length} ${current.length === 1 ? "file" : "files"} selected` : "Drop files here" })
    ] }),
    current.length > 0 ? /* @__PURE__ */ jsx("ul", { children: current.map((file, index) => /* @__PURE__ */ jsxs("li", { children: [
      /* @__PURE__ */ jsx("span", { children: file.name }),
      /* @__PURE__ */ jsxs("small", { children: [
        file.size.toLocaleString(),
        " B"
      ] })
    ] }, `${file.name}-${file.size}-${index}`)) }) : null,
    current.length > 0 ? /* @__PURE__ */ jsx("button", { type: "button", className: "aui-file-clear", disabled, onClick: () => update([]), children: "Clear files" }) : null,
    help && !error ? /* @__PURE__ */ jsx("div", { className: "aui-field-help", children: help }) : null,
    error ? /* @__PURE__ */ jsx("div", { className: "aui-field-error", role: "alert", children: error }) : null
  ] });
}
export {
  FileField
};
