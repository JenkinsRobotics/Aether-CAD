import { jsx } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { ApplicationUpdates } from "./ApplicationUpdates.js";
function ApplicationWelcome({ name, description, artwork, wideArtwork, badge, updates }) {
  const planned = badge?.toLowerCase().includes("coming soon");
  return /* @__PURE__ */ jsx(ApplicationUpdates, { name, description, artwork: wideArtwork ?? artwork, updates: updates ?? [
    { id: "workspace", title: planned ? "Your future workspace" : "Your workspace", description: planned ? "Creation tools and the document library are in development." : "Open existing work or use the app\u2019s starting actions to begin a new document.", status: planned ? "Planned" : "Available", artwork: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }), color: "#a8cdb9" },
    { id: "appearance", title: "Make it your own", description: "Choose a light or dark interface in Settings to suit your workspace.", status: "Available", artwork: /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }), color: "#ecd094" }
  ] });
}
export {
  ApplicationWelcome
};
