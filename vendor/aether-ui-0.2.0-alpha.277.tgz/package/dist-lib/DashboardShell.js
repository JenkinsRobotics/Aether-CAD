import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { CollapsibleSidebar, SidebarLabel, SidebarToggle } from "./CollapsibleSidebar.js";
import "./DashboardShell.css";
import { SidebarRow } from "./ApplicationSidebar.js";
function DashboardShell({ id, brand, subtitle, mark, navigation, activeID, onNavigate, search, profile, breadcrumb, title, actions, children }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-dashboard-stage", children: /* @__PURE__ */ jsxs("div", { className: "aui-dashboard-shell", children: [
    /* @__PURE__ */ jsxs(CollapsibleSidebar, { id, ariaLabel: "Dashboard navigation", className: "aui-dashboard-sidebar aui-application-sidebar", toggle: "custom", footer: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(SidebarLabel, { children: profile }),
      /* @__PURE__ */ jsx(SidebarToggle, {})
    ] }), children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-dashboard-brand", children: [
        /* @__PURE__ */ jsx("span", { className: "aui-dashboard-brand__mark", children: mark }),
        /* @__PURE__ */ jsxs(SidebarLabel, { children: [
          /* @__PURE__ */ jsx("strong", { children: brand }),
          /* @__PURE__ */ jsx("small", { children: subtitle })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-dashboard-sidebar__search", children: /* @__PURE__ */ jsx(SidebarLabel, { children: search }) }),
      /* @__PURE__ */ jsx("nav", { children: navigation.map((group) => /* @__PURE__ */ jsxs("div", { className: "aui-dashboard-nav-group", children: [
        /* @__PURE__ */ jsx(SidebarLabel, { children: /* @__PURE__ */ jsx("h2", { children: group.label }) }),
        group.items.map((item) => /* @__PURE__ */ jsx(SidebarRow, { item: { ...item, current: item.id === activeID, onSelect: () => onNavigate(item.id) } }, item.id))
      ] }, group.label)) })
    ] }),
    /* @__PURE__ */ jsxs("main", { className: "aui-dashboard-main", children: [
      /* @__PURE__ */ jsxs("header", { className: "aui-dashboard-page-header", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "aui-dashboard-breadcrumb", children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "dashboard" }),
            breadcrumb
          ] }),
          /* @__PURE__ */ jsx("h1", { children: title })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "aui-dashboard-page-actions", children: actions })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-dashboard-content", children })
    ] })
  ] }) });
}
export {
  DashboardShell
};
