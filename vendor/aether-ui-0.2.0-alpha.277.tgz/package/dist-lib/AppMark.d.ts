import type { ImgHTMLAttributes } from "react";
import { type AppMarkName } from "@aether/assets/branding/marks/sources";
export type { AppMarkName } from "@aether/assets/branding/marks/sources";
export type AppMarkProps = Omit<ImgHTMLAttributes<HTMLImageElement>, "src"> & {
    app?: AppMarkName;
    size?: number;
};
/** The application's standalone transparent A, without an icon tile or clipping. */
export declare function AppMark({ app, size, alt, style, ...props }: AppMarkProps): import("react").JSX.Element;
