import { type FileTypeDefinition } from "./file-types.js";
import "./FileTypeFilters.css";
/** The same file identities used by library rows, presented as quick filters. */
export declare function FileTypeFilters({ value, onChange, types, quickIDs }: {
    value: string;
    onChange: (id: string) => void;
    types?: readonly FileTypeDefinition[];
    quickIDs?: readonly string[];
}): import("react").JSX.Element;
