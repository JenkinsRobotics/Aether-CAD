import { jsx, jsxs } from "react/jsx-runtime";
function ErrorState({
  title,
  description,
  detail,
  retryAction,
  secondaryAction,
  compact,
  className
}) {
  const classes = ["aui-state", "aui-error-state"];
  if (compact) classes.push("aui-state--compact");
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs("section", { className: classes.join(" "), role: "alert", children: [
    /* @__PURE__ */ jsx("div", { className: "aui-state-icon", "aria-hidden": true, children: "!" }),
    /* @__PURE__ */ jsx("strong", { children: title }),
    description ? /* @__PURE__ */ jsx("p", { children: description }) : null,
    detail ? /* @__PURE__ */ jsx("pre", { children: detail }) : null,
    retryAction || secondaryAction ? /* @__PURE__ */ jsxs("div", { className: "aui-state-actions", children: [
      retryAction,
      secondaryAction
    ] }) : null
  ] });
}
export {
  ErrorState
};
