import { Fragment, jsx, jsxs } from "react/jsx-runtime";
function NotificationContent({ item, actions }) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("span", { className: "aui-notification-icon", "aria-hidden": true, children: item.kind === "success" ? "\u2713" : item.kind === "warning" ? "!" : item.kind === "error" ? "\xD7" : "\u21BB" }),
    /* @__PURE__ */ jsxs("span", { className: "aui-notification-copy", children: [
      /* @__PURE__ */ jsx("strong", { children: item.title }),
      item.message ? /* @__PURE__ */ jsx("span", { children: item.message }) : null,
      item.kind === "progress" && item.progress !== void 0 ? /* @__PURE__ */ jsx("progress", { max: 100, value: item.progress, "aria-label": `${item.title} progress` }) : null
    ] }),
    actions
  ] });
}
function ToastStack({ items, onAction, onDismiss, className }) {
  return /* @__PURE__ */ jsx("div", { className: ["aui-toast-stack", className].filter(Boolean).join(" "), "aria-label": "Notifications", children: items.map((item) => /* @__PURE__ */ jsx("div", { className: `aui-toast aui-toast--${item.kind}`, role: item.kind === "error" ? "alert" : "status", "aria-label": item.title, children: /* @__PURE__ */ jsx(NotificationContent, { item, actions: /* @__PURE__ */ jsxs("span", { className: "aui-notification-actions", children: [
    item.actionLabel ? /* @__PURE__ */ jsx("button", { type: "button", onClick: () => onAction?.(item.id), children: item.actionLabel }) : null,
    !item.persistent ? /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Dismiss ${item.title}`, onClick: () => onDismiss?.(item.id), children: "\xD7" }) : null
  ] }) }) }, item.id)) });
}
export {
  NotificationContent,
  ToastStack
};
