const DOCUMENT_HISTORY_CHANGED = "aether:document-history-changed";
const historyBranchKey = (branch) => branch.id ?? branch.name;
const historyReferenceKey = (reference) => reference.branch_id ?? reference.branch ?? "Main";
export {
  DOCUMENT_HISTORY_CHANGED,
  historyBranchKey,
  historyReferenceKey
};
