import { jsx, jsxs } from "react/jsx-runtime";
import { useId } from "react";
import { Button } from "./Button.js";
import "./ThumbnailPicker.css";
function ThumbnailPicker({ label, items, value, onChange }) {
  const id = useId();
  return /* @__PURE__ */ jsxs("section", { className: "aui-thumbnail-picker", "aria-labelledby": id, children: [
    /* @__PURE__ */ jsx("h3", { id, children: label }),
    /* @__PURE__ */ jsx("div", { className: "aui-thumbnail-picker__grid", children: items.map((item) => /* @__PURE__ */ jsxs(Button, { appearance: "flat", active: value === item.id, "aria-label": item.label, "aria-pressed": value === item.id, disabled: item.disabled, onClick: () => onChange(item.id), children: [
      /* @__PURE__ */ jsx("span", { className: "aui-thumbnail-picker__preview", "aria-hidden": "true", children: item.preview }),
      /* @__PURE__ */ jsx("span", { className: "aui-thumbnail-picker__label", children: item.label }),
      item.detail && /* @__PURE__ */ jsx("small", { children: item.detail })
    ] }, item.id)) })
  ] });
}
export {
  ThumbnailPicker
};
