import { type ReactNode } from "react";
import "./StudioAppFrame.css";
import "./StudioCameraControl.css";
/** One expanding camera surface; products supply their real navigation. */
export declare function StudioCameraControl({ projection, children, expanded, onExpandedChange }: {
    projection?: string;
    children: ReactNode;
    expanded?: boolean;
    onExpandedChange?: (open: boolean) => void;
}): import("react").JSX.Element;
