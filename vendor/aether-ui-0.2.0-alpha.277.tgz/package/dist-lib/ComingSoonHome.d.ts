import type { ReactNode } from "react";
import "./ComingSoonHome.css";
/** Presentation-only product home; identity and navigation belong to the caller. */
export declare function ComingSoonHome({ id, name, description, icon, artwork, wideArtwork, homeUrl, suiteUrl, suiteName, navigation }: {
    /** Sidebar puts all application chrome in one full-height collapsible rail. */
    navigation?: "header" | "sidebar";
    id: string;
    name: string;
    description: string;
    icon: ReactNode;
    artwork: ReactNode;
    wideArtwork?: ReactNode;
    homeUrl: string;
    suiteUrl: string;
    suiteName: string;
}): import("react").JSX.Element;
