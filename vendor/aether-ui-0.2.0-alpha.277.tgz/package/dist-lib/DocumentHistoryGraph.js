import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useMemo, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { Menu } from "./Menu.js";
import { historyBranchKey } from "./DocumentServices.js";
import { milestoneChanges, visibleHistory, visibleParents } from "./document-history-view.js";
const HISTORY_LEGEND = [["workspace", "Workspace"], ["tag", "Version"], ["change", "Change"], ["triangle", "Release candidate"], ["triangle-filled", "Release"], ["obsoletion", "Contains obsoletion"], ["auto-version", "Automatic version"]];
const stamp = (time) => time ? new Date(time * 1e3).toLocaleString(void 0, { dateStyle: "short", timeStyle: "short" }) : "";
const marker = (row) => row.kind === "workspace" ? "workspace" : row.kind === "start" ? "change" : row.status === "candidate" ? "triangle" : row.status === "released" ? "triangle-filled" : row.status === "obsolete" ? "obsoletion" : row.origin === "automatic" ? "auto-version" : "tag";
const filters = [
  { id: "all", label: "Show all branches", icon: "branch" },
  { id: "workspaces", label: "Show all branches with workspaces", icon: "workspace" },
  { id: "current", label: "Show current branch", icon: "branch-from" },
  { id: "parents", label: "Show current branch with parent branches", icon: "version-control" }
];
function DocumentHistoryGraph({ history, graph, branch, query, selectedID, selectedSave, onSelect, onSelectSave, onOpenWorkspace, onContextMenu }) {
  const [filter, setFilter] = useState("all"), [filterOpen, setFilterOpen] = useState(false);
  const [automatic, setAutomatic] = useState(true), [merges, setMerges] = useState(true);
  const [expanded, setExpanded] = useState(/* @__PURE__ */ new Set());
  const anchor = useRef(null);
  const shown = useMemo(() => history ? visibleHistory(graph, history, branch, filter, automatic, query) : [], [graph, history, branch, filter, automatic, query]);
  const changes = useMemo(() => new Map(shown.map((row) => [row.id, history ? milestoneChanges(row, history) : []])), [shown, history]);
  const offsets = /* @__PURE__ */ new Map();
  let height = 0;
  for (const row of shown) {
    offsets.set(row.id, height);
    height += 52 + (expanded.has(row.id) ? (changes.get(row.id)?.length ?? 0) * 40 : 0);
  }
  const graphWidth = 16 + Math.max(1, ...shown.map((row) => row.lane + 1)) * 14;
  const items = filters.map((item) => ({ ...item, icon: /* @__PURE__ */ jsx(AetherIcon, { name: item.icon }), kind: "radio", checked: filter === item.id }));
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-version-tools", role: "toolbar", "aria-label": "History display", children: [
      /* @__PURE__ */ jsx("div", { ref: anchor, children: /* @__PURE__ */ jsx(IconButton, { label: "Filter branches", "aria-haspopup": "menu", "aria-expanded": filterOpen, onClick: () => setFilterOpen(!filterOpen), children: /* @__PURE__ */ jsx(AetherIcon, { name: "branch-filter" }) }) }),
      /* @__PURE__ */ jsx(IconButton, { label: automatic ? "Hide automatic versions" : "Show automatic versions", "aria-pressed": automatic, onClick: () => setAutomatic(!automatic), children: /* @__PURE__ */ jsx(AetherIcon, { name: "auto-version" }) }),
      /* @__PURE__ */ jsx(IconButton, { label: merges ? "Hide merge lines" : "Show merge lines", "aria-pressed": merges, onClick: () => setMerges(!merges), children: /* @__PURE__ */ jsx(AetherIcon, { name: "merge" }) }),
      /* @__PURE__ */ jsxs("span", { title: filters.find((f) => f.id === filter)?.label, children: [
        history?.branches.find((b) => historyBranchKey(b) === branch)?.name ?? branch,
        history?.writable === false ? " \xB7 Read only" : ""
      ] })
    ] }),
    /* @__PURE__ */ jsx(Menu, { open: filterOpen, anchor: anchor.current, items, onSelect: (id) => {
      setFilter(id);
      setFilterOpen(false);
    }, onClose: () => setFilterOpen(false), ariaLabel: "Branch visibility" }),
    /* @__PURE__ */ jsxs("div", { className: "aui-version-columns", style: { paddingLeft: graphWidth }, children: [
      /* @__PURE__ */ jsx("span", { children: "Name" }),
      /* @__PURE__ */ jsx("span", { children: "Modified" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-version-graph-scroll", children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-version-graph-content", children: [
        /* @__PURE__ */ jsx("svg", { className: "aui-version-links", width: graphWidth, height, "aria-hidden": "true", children: shown.flatMap((row) => visibleParents(row, graph, shown, merges).map((parent) => {
          const to = shown.find((item) => item.id === parent);
          const x = 14 + row.lane * 14, y = offsets.get(row.id) + 17, px = 14 + to.lane * 14, py = offsets.get(parent) + 17;
          return /* @__PURE__ */ jsx("path", { d: `M ${x} ${y} C ${x} ${(y + py) / 2}, ${px} ${(y + py) / 2}, ${px} ${py}` }, `${row.id}-${parent}`);
        })) }),
        /* @__PURE__ */ jsx("ol", { "aria-label": "Version graph", children: shown.map((row) => {
          const entries = changes.get(row.id);
          return /* @__PURE__ */ jsxs("li", { "data-kind": row.kind, "data-status": row.status, "data-origin": row.origin, children: [
            /* @__PURE__ */ jsxs("div", { className: "aui-version-entry", children: [
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  className: "aui-version-row",
                  style: { paddingLeft: graphWidth },
                  "aria-pressed": selectedSave == null && selectedID === row.id,
                  "aria-label": `${row.kind === "workspace" ? "Workspace" : row.kind === "version" ? "Version" : "Document"} ${row.name}`,
                  title: [row.message, row.statusNote].filter(Boolean).join(" \u2014 "),
                  onClick: () => onSelect(row),
                  onDoubleClick: () => {
                    if (row.kind === "workspace" && (row.branchID ?? row.name) !== branch) onOpenWorkspace(row.branchID ?? row.name);
                  },
                  onContextMenu: (e) => {
                    e.preventDefault();
                    onSelect(row);
                    onContextMenu({ x: e.clientX, y: e.clientY });
                  },
                  children: [
                    /* @__PURE__ */ jsx("span", { className: "aui-version-marker", style: { left: row.lane * 14 + 6 }, children: /* @__PURE__ */ jsx(AetherIcon, { name: marker(row) }) }),
                    /* @__PURE__ */ jsx("span", { className: "aui-version-name", children: /* @__PURE__ */ jsx("strong", { children: row.name }) }),
                    /* @__PURE__ */ jsxs("span", { className: "aui-version-modified", children: [
                      /* @__PURE__ */ jsx("span", { children: row.author }),
                      /* @__PURE__ */ jsx("small", { children: stamp(row.saved) })
                    ] })
                  ]
                }
              ),
              row.kind !== "start" && (entries.length ? /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-version-expand", style: { left: graphWidth }, "aria-expanded": expanded.has(row.id), "aria-label": `Show changes for ${row.name}`, onClick: () => setExpanded((prev) => {
                const next = new Set(prev);
                next.has(row.id) ? next.delete(row.id) : next.add(row.id);
                return next;
              }), children: [
                /* @__PURE__ */ jsx(AetherIcon, { name: expanded.has(row.id) ? "chevron-down" : "chevron-right" }),
                expanded.has(row.id) ? "Hide changes" : "Show changes\u2026"
              ] }) : /* @__PURE__ */ jsx("small", { className: "aui-version-no-changes", style: { left: graphWidth }, children: "0 changes" }))
            ] }),
            expanded.has(row.id) && /* @__PURE__ */ jsx("ol", { "aria-label": `Changes for ${row.name}`, className: "aui-version-changes", children: entries.map((save) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                "aria-pressed": selectedSave === save.revision,
                onClick: () => onSelectSave(save.revision),
                onContextMenu: (e) => {
                  e.preventDefault();
                  onSelectSave(save.revision);
                  onContextMenu({ x: e.clientX, y: e.clientY });
                },
                style: { paddingLeft: graphWidth },
                children: [
                  /* @__PURE__ */ jsx(AetherIcon, { name: "change" }),
                  /* @__PURE__ */ jsxs("span", { children: [
                    /* @__PURE__ */ jsx("strong", { children: save.note || (save.event === "save" ? "Saved changes" : save.event) }),
                    /* @__PURE__ */ jsxs("small", { children: [
                      save.author,
                      " \xB7 ",
                      stamp(save.saved)
                    ] })
                  ] })
                ]
              }
            ) }, save.revision)) })
          ] }, row.id);
        }) })
      ] }),
      !history && /* @__PURE__ */ jsx("p", { role: "status", children: "Loading history\u2026" }),
      history && !shown.length && /* @__PURE__ */ jsx("p", { children: "No matching versions or workspaces." })
    ] }),
    /* @__PURE__ */ jsx("dl", { className: "aui-version-legend", children: HISTORY_LEGEND.map(([icon, label]) => /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("dt", { children: /* @__PURE__ */ jsx(AetherIcon, { name: icon }) }),
      /* @__PURE__ */ jsx("dd", { children: label })
    ] }, label)) }),
    /* @__PURE__ */ jsx("footer", { className: "aui-version-foot", children: "Right-click an entry for actions" })
  ] });
}
export {
  DocumentHistoryGraph,
  HISTORY_LEGEND
};
