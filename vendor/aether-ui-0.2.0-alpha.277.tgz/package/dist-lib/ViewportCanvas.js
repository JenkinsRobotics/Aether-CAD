import { jsx } from "react/jsx-runtime";
import { useEffect, useRef } from "react";
function ViewportCanvas({ onMount, style, className }) {
  const canvasRef = useRef(null);
  const mountRef = useRef(onMount);
  mountRef.current = onMount;
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    return mountRef.current(canvas);
  }, []);
  const classes = ["aui-viewport-canvas"];
  if (className) classes.push(className);
  return /* @__PURE__ */ jsx("div", { className: classes.join(" "), style, children: /* @__PURE__ */ jsx("canvas", { ref: canvasRef }) });
}
export {
  ViewportCanvas
};
