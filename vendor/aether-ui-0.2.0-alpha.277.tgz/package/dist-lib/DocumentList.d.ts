import { type ReactNode } from "react";
import { type ListBoxProps } from "./ListBox.js";
import "./DocumentList.css";
/** Display metadata supplied by the host; this does not define PDM semantics. */
export interface DocumentListItem {
    id: string;
    name: string;
    reference?: string;
    thumbnail?: ReactNode;
    version?: string;
    revision?: string;
    revisionStyle?: "solid" | "outline";
    status?: {
        label: string;
        kind: "draft" | "branch";
    };
    disabled?: boolean;
}
export interface DocumentListProps {
    items: readonly DocumentListItem[];
    selectedIDs: ReadonlySet<string>;
    onSelect: NonNullable<ListBoxProps["onSelect"]>;
    onOpen?: (id: string) => void;
    onContextMenu?: ListBoxProps["onContextMenu"];
    query: string;
    onQueryChange: (query: string) => void;
    ariaLabel?: string;
    selectionMode?: "single" | "multiple";
    height?: number;
    loading?: boolean;
    error?: ReactNode;
    /** Optional controls above the search field, supplied by the host. */
    toolbar?: ReactNode;
}
export declare function filterDocumentListItems(items: readonly DocumentListItem[], query: string): DocumentListItem[];
/** Thumbnail list using the common list selection, keyboard and windowing behavior. */
export declare function DocumentList({ items, selectedIDs, onSelect, onOpen, onContextMenu, query, onQueryChange, ariaLabel, selectionMode, height, loading, error, toolbar }: DocumentListProps): import("react").JSX.Element;
