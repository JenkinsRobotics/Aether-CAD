import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useContext, useState } from "react";
import { StudioDesignContext } from "./StudioDesignContext.js";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { DocumentTabs } from "./DocumentTabs.js";
import { DocumentFileManager } from "./DocumentFileManager.js";
import { FileManagerPanel } from "./FileManagerPanel.js";
import "./DocumentTabBar.css";
import "./WorkspaceFileBar.css";
function WorkspaceFileBar({ manager, onAdd, addLabel = "Create new document", trailing, fileActions, ...tabs }) {
  const studio = useContext(StudioDesignContext);
  const [open, setOpen] = useState(false), [library, setLibrary] = useState(false);
  const [error, setError] = useState("");
  const groups = manager.documentGroups?.length ? manager.documentGroups : [{ id: "open", label: "Open files", items: tabs.tabs.map((tab) => ({ id: tab.id, name: tab.label, kind: "file", icon: tab.icon })) }];
  const manage = () => {
    setLibrary(false);
    setError("");
    setOpen(true);
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: `aui-document-tabbar aui-document-tray${studio ? " aui-document-tabbar--studio" : ""}`, "data-placement": "bottom", children: [
      /* @__PURE__ */ jsx("div", { className: "aui-document-tray-heading", children: "Open files" }),
      /* @__PURE__ */ jsxs("div", { className: "aui-tab-add-group", children: [
        /* @__PURE__ */ jsx("button", { type: "button", className: "aui-document-tabbar-add aui-menu-trigger", "aria-label": addLabel, title: addLabel, onClick: onAdd, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }),
        /* @__PURE__ */ jsx(MenuButton, { className: "aui-tab-add-menu", label: "Add options", placement: "top-start", anchorTo: "group", items: [{ id: "add", label: addLabel, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }, { id: "manage", label: "Manage files\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }) }], onSelect: (id) => id === "add" ? onAdd() : manage(), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: "rotate(90deg)" } }) })
      ] }),
      /* @__PURE__ */ jsx(DocumentTabs, { ...tabs, onClose: void 0, renderTabActions: tabs.renderTabActions ?? ((tab) => /* @__PURE__ */ jsx(
        MenuButton,
        {
          className: "aui-tab-menu",
          label: `Options for ${tab.label}`,
          placement: "top-end",
          items: [...tabs.onReorder ? [{ id: "left", label: "Move left", disabled: tabs.tabs.indexOf(tab) === 0 }, { id: "right", label: "Move right", disabled: tabs.tabs.indexOf(tab) === tabs.tabs.length - 1 }] : [], { id: "manage", label: "Manage files\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }) }, ...tabs.onClose ? [{ id: "close", label: "Close tab", disabled: tab.pinned && !tabs.allowClosePinned, separatorBefore: true }] : []],
          onSelect: (id) => {
            const index = tabs.tabs.indexOf(tab);
            if (id === "close") tabs.onClose?.(tab.id);
            else if (id === "manage") manage();
            else {
              const target = tabs.tabs[index + (id === "left" ? -1 : 1)];
              if (target) tabs.onReorder?.(tab.id, target.id);
            }
          },
          children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: "rotate(90deg)" } })
        }
      )) }),
      trailing,
      /* @__PURE__ */ jsxs("div", { className: "aui-document-tray-actions", children: [
        fileActions,
        /* @__PURE__ */ jsx("button", { type: "button", className: "aui-document-tabbar-add aui-menu-trigger", "aria-label": "Manage folders and files", title: "Folders and files", onClick: () => {
          setError("");
          setLibrary(true);
          setOpen(true);
        }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }) }),
        /* @__PURE__ */ jsx("button", { type: "button", className: "aui-document-tabbar-add aui-menu-trigger", "aria-label": "Part manager", title: "Document contents", onClick: manage, children: /* @__PURE__ */ jsx(AetherIcon, { name: "part-manager" }) })
      ] })
    ] }),
    /* @__PURE__ */ jsx(Dialog, { open, title: "File manager", onClose: () => setOpen(false), actions: /* @__PURE__ */ jsx(Button, { onClick: () => setLibrary(!library), children: library ? "Document contents" : "Open from library\u2026" }), children: /* @__PURE__ */ jsxs("div", { className: "aui-workspace-files", children: [
      error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
      open && (library ? /* @__PURE__ */ jsx(DocumentFileManager, { ...manager }) : /* @__PURE__ */ jsx(FileManagerPanel, { showLibrary: false, ariaLabel: "Document contents", documentName: manager.connection.name, documentGroups: groups, activeID: manager.activeID ?? tabs.activeID, onOpen: async (item) => {
        try {
          if (manager.documentGroups?.length) await manager.onOpenItem?.(item);
          else tabs.onSelect(item.id);
          setOpen(false);
        } catch (e) {
          setError(e instanceof Error ? e.message : String(e));
        }
      } }))
    ] }) })
  ] });
}
export {
  WorkspaceFileBar
};
