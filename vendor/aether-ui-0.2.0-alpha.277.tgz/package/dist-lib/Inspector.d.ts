import { type ReactNode } from 'react';
import './Inspector.css';
export interface InspectorProps {
    children: ReactNode;
    className?: string;
}
/** Compact property sheet. Nested FieldRows inherit inline labels; other forms keep their layout. */
export declare function Inspector({ children, className }: InspectorProps): import("react").JSX.Element;
export interface InspectorSectionProps {
    title: string;
    children: ReactNode;
    actions?: ReactNode;
    /** Omit for a static section; supply to make it a disclosure. */
    defaultOpen?: boolean;
}
export declare function InspectorSection({ title, children, actions, defaultOpen }: InspectorSectionProps): import("react").JSX.Element;
/** Related actions share a row and wrap instead of stretching into separate large buttons. */
export declare function InspectorActions({ children, label }: {
    children: ReactNode;
    label?: string;
}): import("react").JSX.Element;
