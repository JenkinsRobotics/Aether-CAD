import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { cloneElement, useEffect, useId, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useOverlayPosition } from "./overlay-position.js";
function Tooltip({
  children,
  content,
  shortcut,
  disabledReason,
  delayMilliseconds = 500,
  placement = "top-start"
}) {
  const id = useId();
  const anchorRef = useRef(null);
  const tooltipRef = useRef(null);
  const timerRef = useRef(null);
  const [open, setOpen] = useState(false);
  const position = useOverlayPosition({
    open,
    overlayRef: tooltipRef,
    anchor: anchorRef.current,
    placement,
    gap: 7
  });
  const clearTimer = () => {
    if (timerRef.current !== null) clearTimeout(timerRef.current);
    timerRef.current = null;
  };
  const hide = () => {
    clearTimer();
    setOpen(false);
  };
  const show = () => {
    document.dispatchEvent(new CustomEvent("aether-tooltip-open", { detail: id }));
    setOpen(true);
  };
  useEffect(() => {
    const otherOpened = (event) => {
      if (event.detail !== id) hide();
    };
    document.addEventListener("aether-tooltip-open", otherOpened);
    return () => document.removeEventListener("aether-tooltip-open", otherOpened);
  }, [id]);
  const showAfterDelay = () => {
    clearTimer();
    timerRef.current = setTimeout(show, delayMilliseconds);
  };
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event) => {
      if (event.key === "Escape") hide();
    };
    document.addEventListener("keydown", onKeyDown, true);
    return () => document.removeEventListener("keydown", onKeyDown, true);
  });
  useEffect(() => () => clearTimer(), []);
  const describedBy = [children.props["aria-describedby"], open ? id : null].filter(Boolean).join(" ") || void 0;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "span",
      {
        ref: anchorRef,
        className: "aui-tooltip-anchor",
        onPointerEnter: showAfterDelay,
        onPointerLeave: hide,
        onFocusCapture: () => {
          clearTimer();
          show();
        },
        onBlurCapture: (event) => {
          if (!event.currentTarget.contains(event.relatedTarget)) hide();
        },
        children: cloneElement(children, { "aria-describedby": describedBy })
      }
    ),
    open && anchorRef.current && typeof document !== "undefined" ? createPortal(
      /* @__PURE__ */ jsxs(
        "div",
        {
          ref: tooltipRef,
          id,
          className: "aui-tooltip",
          role: "tooltip",
          style: position,
          children: [
            /* @__PURE__ */ jsx("span", { children: content }),
            shortcut ? /* @__PURE__ */ jsx("kbd", { children: shortcut }) : null,
            disabledReason ? /* @__PURE__ */ jsx("small", { children: disabledReason }) : null
          ]
        }
      ),
      document.body
    ) : null
  ] });
}
export {
  Tooltip
};
