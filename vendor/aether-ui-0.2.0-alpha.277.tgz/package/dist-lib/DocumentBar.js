import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ApplicationIdentity, ApplicationSettings } from "./ApplicationChrome.js";
import { WorkspaceQuickControls } from "./WorkspaceQuickControls.js";
function DocumentBar({ leading, center, trailing, className, variant = "standard", windowChrome = true, application, viewControls, account, defaultHeaderPins, compactControls }) {
  const classes = ["aui-document-bar"];
  if (variant === "transparent") classes.push("aui-document-bar--transparent");
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("header", { "data-application": application?.id, className: classes.join(" "), "data-aether-window-drag-region": windowChrome ? "true" : void 0, children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-document-bar-cluster", children: [
        windowChrome && /* @__PURE__ */ jsx("span", { className: "aui-native-titlebar-space", "aria-hidden": "true" }),
        application && /* @__PURE__ */ jsx(ApplicationIdentity, { ...application, launcher: false }),
        leading
      ] }),
      center ? /* @__PURE__ */ jsx("div", { className: "aui-document-bar-center", children: center }) : null,
      /* @__PURE__ */ jsxs("div", { className: "aui-document-bar-cluster aui-document-bar-cluster--trailing", children: [
        trailing,
        application ? /* @__PURE__ */ jsx(WorkspaceQuickControls, { appID: application.id, appName: application.name, defaultPinnedIDs: defaultHeaderPins, onSettings: application.onSettings, apps: application.apps ?? [], viewControls, onShare: application.onShare, account, compact: compactControls }) : viewControls
      ] })
    ] }),
    application && /* @__PURE__ */ jsx(ApplicationSettings, { appID: application.id, name: application.name, onSettings: application.onSettings, enabled: windowChrome })
  ] });
}
export {
  DocumentBar
};
