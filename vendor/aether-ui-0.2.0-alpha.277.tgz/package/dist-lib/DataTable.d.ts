import type { CSSProperties, ReactNode } from "react";
export interface DataTableColumn<Row> {
    id: string;
    header: string;
    cell: (row: Row) => ReactNode;
    sortValue?: (row: Row) => string | number | null | undefined;
    editValue?: (row: Row) => string;
    editable?: boolean;
    sortable?: boolean;
    resizable?: boolean;
    reorderable?: boolean;
    pinned?: boolean;
    width?: number;
    minWidth?: number;
    maxWidth?: number;
    align?: "start" | "center" | "end";
}
export interface DataTableSort {
    columnID: string;
    direction: "ascending" | "descending";
}
export interface DataTableRowAction {
    id: string;
    label: string;
    icon: ReactNode;
    disabled?: boolean;
}
export interface DataTableProps<Row> {
    rows: readonly Row[];
    rowID: (row: Row) => string;
    columns: readonly DataTableColumn<Row>[];
    selectedIDs: ReadonlySet<string>;
    onSelect: (ids: readonly string[], mode: "single" | "toggle" | "range") => void;
    ariaLabel: string;
    selectionMode?: "single" | "multiple";
    sort?: DataTableSort | null;
    onSortChange?: (sort: DataTableSort | null) => void;
    filter?: string;
    filterText?: (row: Row) => string;
    onEdit?: (rowID: string, columnID: string, value: string) => void;
    onColumnResize?: (columnID: string, width: number) => void;
    onColumnReorder?: (sourceID: string, targetID: string) => void;
    rowActions?: (row: Row) => readonly DataTableRowAction[];
    onRowAction?: (rowID: string, actionID: string) => void;
    onActivate?: (rowID: string) => void;
    emptyState?: ReactNode;
    loading?: boolean;
    loadingState?: ReactNode;
    error?: ReactNode;
    virtualizeThreshold?: number;
    height?: number;
    rowHeight?: number;
    overscan?: number;
    className?: string;
    style?: CSSProperties;
}
/** Product-free table for BOMs, parameters, problems, and task surfaces. */
export declare function DataTable<Row>({ rows, rowID, columns, selectedIDs, onSelect, ariaLabel, selectionMode, sort, onSortChange, filter, filterText, onEdit, onColumnResize, onColumnReorder, rowActions, onRowAction, onActivate, emptyState, loading, loadingState, error, virtualizeThreshold, height, rowHeight, overscan, className, style, }: DataTableProps<Row>): import("react").JSX.Element;
