import { jsx, jsxs } from "react/jsx-runtime";
import { useId, useState } from "react";
import { Inspector } from "./Inspector.js";
import { FieldRow } from "./FieldRow.js";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { NumberField } from "./NumberField.js";
import { ColorField } from "./ColorField.js";
import { SelectField } from "./SelectField.js";
import { Slider } from "./Slider.js";
import { Checkbox } from "./Checkbox.js";
import "./StylePropertiesPanel.css";
function Section({ title, children, enabled, onEnabled, action }) {
  const [open, setOpen] = useState(true);
  const id = useId();
  return /* @__PURE__ */ jsxs("section", { className: "aui-style-section", children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-style-section-toggle", "aria-expanded": open, "aria-controls": id, onClick: () => setOpen(!open), children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: open ? "chevron-down" : "chevron-right" }),
        title
      ] }),
      action,
      onEnabled && /* @__PURE__ */ jsx(Checkbox, { label: "", "aria-label": `Enable ${title.toLowerCase()}`, checked: enabled, onChange: (e) => onEnabled(e.target.checked) })
    ] }),
    /* @__PURE__ */ jsx("div", { id, hidden: !open, children: /* @__PURE__ */ jsx("fieldset", { disabled: enabled === false, children }) })
  ] });
}
function Numeric({ label, value, onChange, min, max, unit = "px" }) {
  return /* @__PURE__ */ jsx(FieldRow, { label, children: /* @__PURE__ */ jsx(NumberField, { "aria-label": label, value, min, max, unit, onCommit: onChange }) });
}
function StylePropertiesPanel({ value: v, onChange, selectionLabel = "Rectangle", onReset, className = "" }) {
  const [linked, setLinked] = useState(true);
  const update = (patch) => onChange({ ...v, ...patch });
  const radius = (index, next) => update({ corners: linked ? [next, next, next, next] : v.corners.map((n, i) => i === index ? next : n) });
  return /* @__PURE__ */ jsx(Inspector, { children: /* @__PURE__ */ jsxs("aside", { className: `aui-style-properties ${className}`, "aria-label": "Style properties", children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-style-heading", children: [
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("strong", { children: selectionLabel }) }),
      onReset && /* @__PURE__ */ jsx(IconButton, { label: "Reset properties", onClick: onReset, children: /* @__PURE__ */ jsx(AetherIcon, { name: "refresh" }) })
    ] }),
    /* @__PURE__ */ jsxs(Section, { title: "Layout", children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-style-pair", children: [
        /* @__PURE__ */ jsx(Numeric, { label: "Width", value: v.width, min: 1, max: 2e3, onChange: (width) => update({ width }) }),
        /* @__PURE__ */ jsx(Numeric, { label: "Height", value: v.height, min: 1, max: 2e3, onChange: (height) => update({ height }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-style-pair", children: [
        /* @__PURE__ */ jsx(Numeric, { label: "Rotation", value: v.rotation, min: -360, max: 360, unit: "\xB0", onChange: (rotation) => update({ rotation }) }),
        /* @__PURE__ */ jsx(Numeric, { label: "Layer opacity", value: v.opacity, min: 0, max: 100, unit: "%", onChange: (opacity) => update({ opacity }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Section, { title: "Corners", action: /* @__PURE__ */ jsx(IconButton, { label: "Link corner radii", "aria-pressed": linked, onClick: () => setLinked(!linked), children: /* @__PURE__ */ jsx(AetherIcon, { name: "link" }) }), children: [
      /* @__PURE__ */ jsx("div", { className: "aui-style-corners", children: ["Top left", "Top right", "Bottom left", "Bottom right"].map((label, position) => {
        const index = [0, 1, 3, 2][position];
        return /* @__PURE__ */ jsxs("label", { children: [
          /* @__PURE__ */ jsx("span", { className: `aui-style-corner-glyph corner-${index}`, "aria-hidden": true }),
          /* @__PURE__ */ jsx(NumberField, { "aria-label": `${label} radius`, value: v.corners[index], min: 0, max: 1e3, unit: "px", onCommit: (n) => radius(index, n) })
        ] }, label);
      }) }),
      /* @__PURE__ */ jsx("small", { children: linked ? "All corners change together" : "Adjust each corner independently" })
    ] }),
    /* @__PURE__ */ jsxs(Section, { title: "Fill", enabled: v.fill.enabled, onEnabled: (enabled) => update({ fill: { ...v.fill, enabled } }), children: [
      /* @__PURE__ */ jsx(FieldRow, { label: "Color", children: /* @__PURE__ */ jsx(ColorField, { ariaLabel: "Fill color", value: v.fill.color, onChange: (color) => update({ fill: { ...v.fill, color } }) }) }),
      /* @__PURE__ */ jsx(FieldRow, { label: "Opacity", children: /* @__PURE__ */ jsx(Slider, { ariaLabel: "Fill opacity", value: v.fill.opacity, unit: "%", onChange: (opacity) => update({ fill: { ...v.fill, opacity } }) }) })
    ] }),
    /* @__PURE__ */ jsxs(Section, { title: "Border", enabled: v.border.enabled, onEnabled: (enabled) => update({ border: { ...v.border, enabled } }), children: [
      /* @__PURE__ */ jsx(FieldRow, { label: "Color", children: /* @__PURE__ */ jsx(ColorField, { ariaLabel: "Border color", value: v.border.color, onChange: (color) => update({ border: { ...v.border, color } }) }) }),
      /* @__PURE__ */ jsxs("div", { className: "aui-style-pair", children: [
        /* @__PURE__ */ jsx(Numeric, { label: "Thickness", value: v.border.width, min: 0, max: 100, onChange: (width) => update({ border: { ...v.border, width } }) }),
        /* @__PURE__ */ jsx(FieldRow, { label: "Style", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Border style", value: v.border.style, options: [{ value: "solid", label: "Solid" }, { value: "dashed", label: "Dashed" }, { value: "dotted", label: "Dotted" }], onChange: (e) => update({ border: { ...v.border, style: e.target.value } }) }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Section, { title: "Shadow", enabled: v.shadow.enabled, onEnabled: (enabled) => update({ shadow: { ...v.shadow, enabled } }), children: [
      /* @__PURE__ */ jsx(FieldRow, { label: "Color", children: /* @__PURE__ */ jsx(ColorField, { ariaLabel: "Shadow color", value: v.shadow.color, onChange: (color) => update({ shadow: { ...v.shadow, color } }) }) }),
      /* @__PURE__ */ jsx(FieldRow, { label: "Opacity", children: /* @__PURE__ */ jsx(Slider, { ariaLabel: "Shadow opacity", value: v.shadow.opacity, unit: "%", onChange: (opacity) => update({ shadow: { ...v.shadow, opacity } }) }) }),
      /* @__PURE__ */ jsxs("div", { className: "aui-style-pair", children: [
        /* @__PURE__ */ jsx(Numeric, { label: "Offset X", value: v.shadow.x, min: -200, max: 200, onChange: (x) => update({ shadow: { ...v.shadow, x } }) }),
        /* @__PURE__ */ jsx(Numeric, { label: "Offset Y", value: v.shadow.y, min: -200, max: 200, onChange: (y) => update({ shadow: { ...v.shadow, y } }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-style-pair", children: [
        /* @__PURE__ */ jsx(Numeric, { label: "Blur", value: v.shadow.blur, min: 0, max: 200, onChange: (blur) => update({ shadow: { ...v.shadow, blur } }) }),
        /* @__PURE__ */ jsx(Numeric, { label: "Spread", value: v.shadow.spread, min: -100, max: 100, onChange: (spread) => update({ shadow: { ...v.shadow, spread } }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("footer", { children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "check" }),
      /* @__PURE__ */ jsx("span", { children: "Changes apply to the selection" })
    ] })
  ] }) });
}
export {
  StylePropertiesPanel
};
