import "./LayoutStyleControls.css";
export interface LayoutStyleValue {
    direction: "row" | "column";
    alignment: "stretch" | "center" | "start" | "end";
    gap: number;
    padding: number;
    radius: number;
    strokeWidth: number;
    stroke: string;
    fill: string;
    clip: boolean;
}
export declare const defaultLayoutStyle: LayoutStyleValue;
export declare function LayoutStyleControls({ value, onChange }: {
    value?: LayoutStyleValue;
    onChange?: (value: LayoutStyleValue) => void;
}): import("react").JSX.Element;
