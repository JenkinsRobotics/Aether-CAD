import { type ReactNode } from 'react';
import './ParameterRow.css';
export interface ParameterRowProps {
    label: string;
    ariaLabel?: string;
    icon?: ReactNode;
    value: number;
    onChange: (value: number) => void;
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
    /** Suggested slider interval; numeric entry may extend beyond it within min/max. */
    sliderRange?: {
        min: number;
        max: number;
    };
    help?: string;
    disabled?: boolean;
    modulation?: {
        label: string;
        onEdit: () => void;
        range?: {
            min: number;
            max: number;
        };
    };
}
/** A shared inspector row. Products supply meaning, limits and assignment actions. */
export declare function ParameterRow({ label, ariaLabel, icon, value, onChange, min, max, step, unit, sliderRange, help, disabled, modulation }: ParameterRowProps): import("react").JSX.Element;
