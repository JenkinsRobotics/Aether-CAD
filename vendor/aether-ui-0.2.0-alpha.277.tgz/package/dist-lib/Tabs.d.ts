import type { ReactNode } from "react";
export interface TabDefinition {
    id: string;
    label: string;
    icon?: ReactNode;
    disabled?: boolean;
    title?: string;
}
export interface TabsProps {
    tabs: readonly TabDefinition[];
    activeID: string;
    onSelect: (id: string) => void;
}
/** Underlined tab strip (workspaces, documents). Keyboard: ←/→ move and
 *  select (selection follows focus), Home/End jump; roving tabindex. */
export declare function Tabs({ tabs, activeID, onSelect }: TabsProps): import("react").JSX.Element;
