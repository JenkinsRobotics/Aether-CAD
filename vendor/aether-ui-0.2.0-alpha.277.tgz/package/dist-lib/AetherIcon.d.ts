import type { SVGProps } from "react";
declare const icons: Record<string, string>;
export type AetherIconName = keyof typeof icons;
export declare const aetherIconNames: AetherIconName[];
export interface AetherIconProps extends Omit<SVGProps<SVGSVGElement>, "children" | "dangerouslySetInnerHTML" | "ref"> {
    name: AetherIconName;
}
export declare function registerIconPack(pack: Partial<Record<AetherIconName, string>> | null): void;
export declare function AetherIcon({ name, ...props }: AetherIconProps): import("react").JSX.Element;
export {};
