import type { ReactNode } from "react";
import type { MenuItem } from "./Menu.js";
import type { TreeMovePosition } from "./Tree.js";
export type FeatureTreeKind = "reference" | "feature" | "part" | "folder";
/** Presentation of the owning application's entities, never a CAD document/evaluator. */
export interface FeatureTreeItem {
    id: string;
    label: string;
    kind: FeatureTreeKind;
    type: string;
    icon?: ReactNode;
    hidden?: boolean;
    suppressed?: boolean;
    error?: string;
    dimensionsShown?: boolean;
    dynamicSuppression?: boolean;
    children?: readonly FeatureTreeItem[];
}
export type FeatureTreeCommand = "rename" | "edit" | "copy-sketch" | "dimensions" | "add-to-folder" | "new-folder" | "visibility" | "hide-other-sketches" | "hide-all-sketches" | "suppress" | "dynamic-suppression" | "comment" | "view-normal" | "dependencies" | "rollback" | "move" | "appearance" | "delete";
export interface FeatureTreeRequest {
    command: FeatureTreeCommand;
    ids: readonly string[];
    name?: string;
    value?: boolean;
    /** Number of active history entries, independent of folders or reference rows. */
    index?: number;
    targetID?: string;
    position?: TreeMovePosition;
}
export interface FeatureTreeAction {
    item: MenuItem;
    request: FeatureTreeRequest;
}
export declare const DEFAULT_FEATURE_GEOMETRY: readonly FeatureTreeItem[];
export declare function FeatureTypeIcon({ type }: {
    type: string;
}): import("react").JSX.Element;
export declare const flattenFeatureItems: (items: readonly FeatureTreeItem[]) => FeatureTreeItem[];
export declare const isSketchFeature: (item: FeatureTreeItem) => boolean;
/** Shared ordering/labels/state for every feature menu. Apps only provide capability and dispatch. */
export declare function featureTreeActions(item: FeatureTreeItem, options: {
    selected: readonly FeatureTreeItem[];
    features: readonly FeatureTreeItem[];
    rollbackIndex?: number;
    available: readonly FeatureTreeCommand[];
    canCommand?: (request: FeatureTreeRequest) => boolean | string;
}): FeatureTreeAction[];
/** Folder choices share one submenu regardless of the application or folder count. */
export declare function featureTreeMenuItems(actions: readonly FeatureTreeAction[]): MenuItem[];
