import type { ButtonHTMLAttributes, HTMLAttributes, ReactNode } from "react";
/** The vertical icon rail beside a sidebar. */
export interface RailProps extends HTMLAttributes<HTMLDivElement> {
    children: ReactNode;
}
export declare function Rail({ children, className, ...props }: RailProps): import("react").JSX.Element;
export interface RailButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
    label: string;
    active?: boolean;
    children: ReactNode;
}
export declare function RailButton({ label, active, className, children, ...props }: RailButtonProps): import("react").JSX.Element;
