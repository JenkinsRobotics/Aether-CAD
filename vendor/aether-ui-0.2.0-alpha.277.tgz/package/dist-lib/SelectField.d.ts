import type { ReactNode, SelectHTMLAttributes } from "react";
export interface SelectFieldOption {
    value: string;
    label: string;
    disabled?: boolean;
}
export interface SelectFieldProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, "children"> {
    options: readonly SelectFieldOption[];
    placeholder?: string;
    invalid?: boolean;
    /**
     * A glyph naming what the select filters, drawn in the field's leading edge.
     *
     * It lives here so no panel has to position one itself. The comments filters
     * did, with an absolutely placed icon and a hand-counted left padding, and at
     * sidebar width the field shrank until the icon sat on top of the text
     * (Jonathan, 2026-10-04: "the icon is behind the text"). The field now
     * reserves the space in its own layout, so it cannot be squeezed away.
     */
    icon?: ReactNode;
}
/** Native select semantics with the shared Aether field presentation. */
export declare function SelectField({ options, placeholder, invalid, icon, className, ...selectProps }: SelectFieldProps): import("react").JSX.Element;
