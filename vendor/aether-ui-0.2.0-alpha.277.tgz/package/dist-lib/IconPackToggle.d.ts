import type { ToolIconPack } from "./ToolIconTheme.js";
/** The illustrated tool packs a `ToolIconTheme` can scope. */
export declare const TOOL_ICON_PACKS: readonly {
    id: ToolIconPack;
    label: string;
}[];
/** Header control: which illustrated tool pack every `ToolIcon` under the app's `ToolIconTheme` draws from. State is the caller's, like `LayoutPresetButton`. */
export declare function IconPackToggle({ pack, onChange }: {
    pack: ToolIconPack;
    onChange: (pack: ToolIconPack) => void;
}): import("react").JSX.Element;
