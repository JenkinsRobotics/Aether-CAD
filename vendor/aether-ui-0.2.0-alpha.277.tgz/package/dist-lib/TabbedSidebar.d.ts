import { type CSSProperties, type ReactNode } from "react";
import "./TabbedSidebar.css";
import { type SidebarAttachment } from "./WorkspaceChromePreferences.js";
export interface SidebarTab {
    id: string;
    label: string;
    icon: ReactNode;
    separatorBefore?: boolean;
    command?: boolean;
    pressed?: boolean;
}
export interface TabbedSidebarProps {
    tabs: readonly SidebarTab[];
    /** Null collapses the panel while leaving the tab strip accessible. */
    activeTab: string | null;
    /** Optional independent panel toggles; the parent composes their contents. */
    activeTabs?: readonly string[];
    onTabToggle?: (id: string) => void;
    onTabChange: (id: string | null) => void;
    tabPosition?: "top" | "bottom" | "left" | "right";
    /** Workspace edge retained while opening and collapsing, independent of tray order. */
    anchor?: "top" | "bottom" | "left" | "right";
    /** Combined card by default at every viewport. Detached is an explicit secondary variant. */
    attachment?: SidebarAttachment;
    /** Slim is an icon-only, equal-cell tray restricted to top/bottom edges. */
    variant?: "standard" | "slim";
    animate?: boolean;
    /** Floating trays collapse to intrinsic icon size; docked trays keep their span. */
    floating?: boolean;
    /** Expanded floating height policy. Content is capped by the available space. */
    heightPolicy?: "fill" | "content" | number;
    ariaLabel: string;
    resize?: {
        side: "left" | "right";
        width: number;
        minWidth?: number;
        maxWidth: number;
        onWidthChange: (width: number) => void;
        onHeightChange?: (height: number) => void;
        onResetWidth: () => void;
        onResetHeight: () => void;
    };
    /** Keep true during the shell's closing animation. */
    expanded?: boolean;
    style?: CSSProperties;
    children?: ReactNode;
}
/** Docked or floating sidebar; parent owns selection and retained editors.
 * The tab strip uses toggle-button semantics because the active tab can close
 * its panel. Arrow keys move focus; Enter/Space activate or close a panel. */
export declare function TabbedSidebar({ tabs, activeTab, activeTabs, onTabToggle, onTabChange, tabPosition, anchor, attachment, variant, animate, floating, heightPolicy, resize, ariaLabel, expanded, style, children }: TabbedSidebarProps): import("react").JSX.Element;
