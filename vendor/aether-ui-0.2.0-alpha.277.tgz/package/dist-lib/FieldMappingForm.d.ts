import "./WorkflowWidgets.css";
export interface MappingField {
    id: string;
    label: string;
    required?: boolean;
}
export interface FieldMappingFormProps {
    mode: string;
    onModeChange: (value: string) => void;
    fileName: string;
    itemCount: string;
    onUpdateFile: () => void;
    fields: readonly MappingField[];
    columns: readonly string[];
    value: Readonly<Record<string, string>>;
    onChange: (value: Record<string, string>) => void;
    onContinue: () => void;
}
export declare function FieldMappingForm({ mode, onModeChange, fileName, itemCount, onUpdateFile, fields, columns, value, onChange, onContinue }: FieldMappingFormProps): import("react").JSX.Element;
