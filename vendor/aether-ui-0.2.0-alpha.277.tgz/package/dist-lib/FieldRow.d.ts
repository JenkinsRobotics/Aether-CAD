import { type ReactNode } from "react";
import './Inspector.css';
export interface FieldRowProps {
    label: ReactNode;
    htmlFor?: string;
    children: ReactNode;
    help?: ReactNode;
    error?: ReactNode;
    modified?: boolean;
    required?: boolean;
    onReset?: () => void;
    className?: string;
    /** Inspector inherits inline; standalone forms retain stacked labels. */
    layout?: 'inline' | 'stacked';
}
/** Standard property-editor row. The application supplies the editor and owns
 * transactions; FieldRow owns consistent labeling, help, error, and reset UI. */
export declare function FieldRow({ label, htmlFor, children, help, error, modified, required, onReset, className, layout, }: FieldRowProps): import("react").JSX.Element;
