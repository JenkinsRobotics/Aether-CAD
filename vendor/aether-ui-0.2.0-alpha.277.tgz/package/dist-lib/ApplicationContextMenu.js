import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { Menu } from "./Menu.js";
import { ToastStack } from "./Toast.js";
import { contextCommandsFor, contextCommandItems, rememberContextTarget, runContextCommand } from "./context-commands.js";
function usesNativeTextMenu(target) {
  if (target.closest("input, textarea") || target instanceof HTMLElement && target.isContentEditable || target.closest('[contenteditable="true"], [contenteditable=""]')) return true;
  const selection = target.ownerDocument.getSelection();
  if (!selection || selection.isCollapsed || !selection.toString().trim()) return false;
  for (let i = 0; i < selection.rangeCount; i++) {
    if (selection.getRangeAt(i).intersectsNode(target)) return true;
  }
  return false;
}
function ApplicationContextMenu({ name, enabled = true }) {
  const [menu, setMenu] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    if (!enabled) return;
    let pending;
    const capture = (event) => {
      if (!(event.target instanceof Element)) return;
      clearTimeout(pending);
      if (usesNativeTextMenu(event.target)) {
        clearTimeout(pending);
        setMenu(null);
        event.stopImmediatePropagation();
        return;
      }
      event.preventDefault();
      clearTimeout(pending);
      if (event.target.closest('[role="menu"]')) return;
      rememberContextTarget(event.target, event.clientX, event.clientY);
      const commands = contextCommandsFor(event.target, true);
      pending = setTimeout(() => {
        if (document.querySelector('[role="menu"]')) return;
        setMenu(commands.length ? { x: event.clientX, y: event.clientY, commands } : null);
      }, 0);
    };
    const keyboard = (event) => {
      if (event.key !== "ContextMenu" && !(event.shiftKey && event.key === "F10")) return;
      if (!(event.target instanceof Element) || usesNativeTextMenu(event.target)) return;
      event.preventDefault();
      const box = event.target.getBoundingClientRect();
      event.target.dispatchEvent(new MouseEvent("contextmenu", { bubbles: true, cancelable: true, clientX: box.left + Math.min(20, box.width / 2), clientY: box.top + Math.min(20, box.height / 2) }));
    };
    const problem = (event) => setError(event.detail);
    document.addEventListener("contextmenu", capture, true);
    document.addEventListener("keydown", keyboard);
    document.addEventListener("aether-context-error", problem);
    return () => {
      document.removeEventListener("contextmenu", capture, true);
      clearTimeout(pending);
      document.removeEventListener("keydown", keyboard);
      document.removeEventListener("aether-context-error", problem);
    };
  }, [enabled, name]);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Menu, { open: !!menu, anchor: menu, items: contextCommandItems(menu?.commands ?? []), applicationCommands: false, ariaLabel: "Aether commands", onClose: () => setMenu(null), onSelect: (id) => {
      const command = menu?.commands.find((c) => `aether:${c.id}` === id);
      if (command) runContextCommand(command);
    } }),
    error && /* @__PURE__ */ jsx(ToastStack, { items: [{ id: "context-error", kind: "error", title: "Command unavailable", message: error }], onDismiss: () => setError("") })
  ] });
}
export {
  ApplicationContextMenu
};
