import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import "./RankedList.css";
function RankedList({ label, items, onSelect, selectedID }) {
  return /* @__PURE__ */ jsx("ol", { className: "aui-ranked-list", "aria-label": label, children: items.map((item, index) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("button", { type: "button", disabled: !onSelect, "aria-pressed": onSelect ? selectedID === item.id : void 0, onClick: () => onSelect?.(item.id), children: [
    /* @__PURE__ */ jsx("span", { className: "aui-ranked-list__rank", children: index + 1 }),
    /* @__PURE__ */ jsx("span", { className: "aui-ranked-list__icon", children: item.icon }),
    /* @__PURE__ */ jsx("span", { className: "aui-ranked-list__label", children: item.label }),
    /* @__PURE__ */ jsx("strong", { children: item.value }),
    onSelect && /* @__PURE__ */ jsx(AetherIcon, { name: "open-external" })
  ] }) }, item.id)) });
}
export {
  RankedList
};
