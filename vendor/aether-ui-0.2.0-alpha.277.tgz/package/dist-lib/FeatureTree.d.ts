import type { TreeProps } from "./Tree.js";
import { type FeatureTreeCommand, type FeatureTreeItem, type FeatureTreeRequest } from "./feature-tree.js";
import "./FeatureTree.css";
export interface FeatureTreeProps {
    features: readonly FeatureTreeItem[];
    parts: readonly FeatureTreeItem[];
    defaultGeometry?: readonly FeatureTreeItem[];
    selectedIDs: ReadonlySet<string>;
    onSelect: TreeProps["onSelect"];
    availableCommands?: readonly FeatureTreeCommand[];
    onCommand?: (request: FeatureTreeRequest) => void;
    /** Owning application validates dependencies, locks, transactions and folder cycles. */
    canCommand?: (request: FeatureTreeRequest) => boolean | string;
    rollbackIndex?: number;
    filter?: string;
    onFilterChange?: (query: string) => void;
    ariaLabel?: string;
    partsLabel?: string;
    className?: string;
    storageKey?: string;
}
/** Content-only authoring widget. Containers and model evaluation belong to its host. */
export declare function FeatureTree({ features, parts, defaultGeometry, selectedIDs, onSelect, availableCommands, onCommand, canCommand, rollbackIndex, filter, onFilterChange, ariaLabel, partsLabel, className, storageKey }: FeatureTreeProps): import("react").JSX.Element;
