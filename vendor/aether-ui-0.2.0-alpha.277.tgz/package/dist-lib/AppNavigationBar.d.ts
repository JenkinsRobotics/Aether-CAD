import type { ReactNode } from "react";
import { type AppWordmarkName } from "./AppWordmark.js";
import "./AppNavigationBar.css";
export interface AppNavigationItem {
    id: string;
    label: string;
    disabled?: boolean;
}
export interface AppNavigationBarProps {
    brand: string;
    /** Registered app identity; canonical Aether brand names are recognized automatically. */
    app?: AppWordmarkName;
    mark?: ReactNode;
    items: readonly AppNavigationItem[];
    activeID: string;
    onNavigate: (id: string) => void;
    onHome: () => void;
    /** Right-aligned pinned utilities, Share, menus and account controls supplied by the application. */
    actions?: ReactNode;
    className?: string;
}
/** Left-aligned grouped page navigation composed in the standard DocumentBar container.
 * Narrow containers move the page row below the identity and actions. */
export declare function AppNavigationBar({ brand, app, mark, items, activeID, onNavigate, onHome, actions, className }: AppNavigationBarProps): import("react").JSX.Element;
