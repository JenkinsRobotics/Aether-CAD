const stacks = /* @__PURE__ */ new WeakMap();
function registerFeatureWindow(panel, viewport) {
  const stack = stacks.get(viewport) ?? [];
  for (let index = stack.length - 1; index >= 0; index--) if (!stack[index].isConnected) stack.splice(index, 1);
  stacks.set(viewport, stack);
  const bounds = panel.getBoundingClientRect(), area = viewport.getBoundingClientRect();
  if (stack.length && bounds.width > 0 && area.width > 0) {
    const occupied = stack.map((item) => item.getBoundingClientRect());
    let left = bounds.left;
    for (const other of occupied.sort((a, b) => a.left - b.left)) {
      if (left < other.right + 12 && left + bounds.width > other.left - 12) left = other.right + 12;
    }
    if (left + bounds.width > area.right - 8) {
      left = Math.max(area.left + 8, Math.min(bounds.left + stack.length * 24, area.right - bounds.width - 8));
      const top = Math.min(bounds.top + stack.length * 24, area.bottom - 80) - area.top;
      panel.style.top = `${Math.max(0, top)}px`;
      panel.style.maxHeight = `calc(100% - ${Math.max(0, top) + 16}px)`;
    }
    panel.style.left = `${left - area.left}px`;
    panel.style.right = "auto";
  }
  const publish = () => {
    stack.forEach((item, index) => {
      item.style.zIndex = String(14 + index);
      item.dataset.frontmost = String(index === stack.length - 1);
    });
    const front = stack.at(-1);
    if (front) front.dispatchEvent(new CustomEvent("aether-feature-window-focus", { bubbles: true, detail: { panel: front } }));
  };
  const focus = () => {
    const index = stack.indexOf(panel);
    if (index >= 0) stack.splice(index, 1);
    stack.push(panel);
    publish();
  };
  panel.addEventListener("pointerdown", focus, true);
  panel.addEventListener("focusin", focus);
  focus();
  return {
    focus,
    isFrontmost: () => stack.at(-1) === panel,
    dispose() {
      panel.removeEventListener("pointerdown", focus, true);
      panel.removeEventListener("focusin", focus);
      const index = stack.indexOf(panel), front = stack.at(-1) === panel;
      if (index >= 0) stack.splice(index, 1);
      if (front) publish();
    }
  };
}
export {
  registerFeatureWindow
};
