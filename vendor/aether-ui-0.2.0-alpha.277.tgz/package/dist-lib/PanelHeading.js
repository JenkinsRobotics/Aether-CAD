import { jsx, jsxs } from "react/jsx-runtime";
function PanelHeading({
  children,
  actions
}) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-panel-heading", children: [
    /* @__PURE__ */ jsx("span", { children }),
    actions ? /* @__PURE__ */ jsx("span", { children: actions }) : null
  ] });
}
export {
  PanelHeading
};
