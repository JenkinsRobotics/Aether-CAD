import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { Timeline } from "./Timeline.js";
import { Button } from "./Button.js";
import { SegmentedControl } from "./SegmentedControl.js";
import "./ConceptInspectors.css";
function SequenceEditor({ initialTracks, durationS = 8, initialMode = "dope-sheet" }) {
  const [tracks, setTracks] = useState([...initialTracks]);
  const [mode, setMode] = useState(initialMode);
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [loop, setLoop] = useState(true);
  const [selection, setSelection] = useState(null);
  const [filter, setFilter] = useState("");
  const [markers, setMarkers] = useState([]);
  useEffect(() => {
    if (!playing) return;
    const timer = window.setInterval(() => setTime((current) => Math.min(durationS, current + 1 / 30) === durationS && loop ? 0 : Math.min(durationS, current + 1 / 30)), 1e3 / 30);
    return () => window.clearInterval(timer);
  }, [playing, loop, durationS]);
  useEffect(() => {
    if (!loop && time >= durationS) setPlaying(false);
  }, [time, loop, durationS]);
  const visible = tracks.filter((track) => track.label.toLowerCase().includes(filter.toLowerCase()));
  return /* @__PURE__ */ jsxs("section", { className: "aui-sequence-editor", "aria-label": "Sequence editor", children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsx("input", { "aria-label": "Filter tracks", placeholder: "Filter tracks", value: filter, onChange: (e) => setFilter(e.target.value) }),
      /* @__PURE__ */ jsx(Button, { onClick: () => setMarkers((list) => [...list, time]), children: "Marker" }),
      /* @__PURE__ */ jsx(Button, { onClick: () => setTracks((list) => [...list, { id: `track-${list.length}`, label: `Motion ${list.length + 1}`, keyframes: [] }]), children: "Add Row" }),
      /* @__PURE__ */ jsx(Button, { onClick: () => {
        const id = selection?.trackID ?? tracks[0]?.id;
        if (id) setTracks((list) => list.map((t) => t.id === id ? { ...t, keyframes: [...t.keyframes, { timeS: time, value: 0 }].sort((a, b) => a.timeS - b.timeS) } : t));
      }, disabled: !tracks.length, children: "Add Key" }),
      /* @__PURE__ */ jsx(Button, { disabled: !selection, onClick: () => {
        setTracks((list) => list.map((t) => t.id === selection?.trackID ? { ...t, keyframes: t.keyframes.filter((_, i) => i !== selection.index) } : t));
        setSelection(null);
      }, children: "Delete Key" })
    ] }),
    /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Timeline design mode", value: mode, onChange: (id) => setMode(id), options: [{ id: "dope-sheet", label: "Dopesheet" }, { id: "curves", label: "Motion Curves" }, { id: "waypoints", label: "Waypoint Lanes" }] }),
    mode === "waypoints" ? /* @__PURE__ */ jsxs("div", { className: "aui-waypoint-lanes", "aria-label": "Waypoint lanes", children: [
      /* @__PURE__ */ jsx(Button, { onClick: () => setPlaying(!playing), children: playing ? "Pause" : "Play" }),
      /* @__PURE__ */ jsx("input", { "aria-label": "Waypoint time", type: "range", min: 0, max: durationS, step: 0.01, value: time, onChange: (e) => setTime(Number(e.target.value)) }),
      visible.map((track) => /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: track.label }),
        /* @__PURE__ */ jsx("div", { children: track.keyframes.map((key, index) => /* @__PURE__ */ jsxs("button", { "aria-pressed": selection?.trackID === track.id && selection.index === index, onClick: () => {
          setSelection({ trackID: track.id, index });
          setTime(key.timeS);
        }, children: [
          key.timeS.toFixed(2),
          "s \xB7 ",
          key.value?.toFixed(2) ?? "\u2014"
        ] }, index)) })
      ] }, track.id))
    ] }) : /* @__PURE__ */ jsx(Timeline, { variant: "editor", mode, tracks: visible, timeS: time, durationS, onSeek: setTime, playing, onTogglePlay: () => setPlaying(!playing), looping: loop, onToggleLoop: () => setLoop(!loop), onStop: () => {
      setPlaying(false);
      setTime(0);
    }, onStepFrame: (direction) => setTime(Math.max(0, Math.min(durationS, time + direction / 30))), onSeekAdjacentKeyframe: (direction) => {
      const times = [...new Set(tracks.flatMap((track) => track.keyframes.map((key) => key.timeS)))].sort((a, b) => a - b);
      setTime(direction < 0 ? [...times].reverse().find((t) => t < time - 1e-6) ?? 0 : times.find((t) => t > time + 1e-6) ?? durationS);
    }, selected: selection, onSelectKeyframe: (trackID, index) => setSelection({ trackID, index }), emptyState: /* @__PURE__ */ jsx(Button, { onClick: () => setTracks([{ id: "first", label: "Motion 1", keyframes: [] }]), children: "Add first track" }) }),
    /* @__PURE__ */ jsxs("footer", { children: [
      tracks.length,
      " tracks \xB7 ",
      time.toFixed(2),
      "s ",
      /* @__PURE__ */ jsxs("span", { children: [
        "Markers: ",
        markers.length ? markers.map((m) => `${m.toFixed(2)}s`).join(", ") : "None"
      ] })
    ] })
  ] });
}
export {
  SequenceEditor
};
