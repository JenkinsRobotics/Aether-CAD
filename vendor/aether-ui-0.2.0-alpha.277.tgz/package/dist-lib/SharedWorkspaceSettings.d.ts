export declare function SharedWorkspaceSettings(): import("react").JSX.Element;
