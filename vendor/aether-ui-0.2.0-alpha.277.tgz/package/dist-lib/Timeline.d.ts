import type { ReactNode } from "react";
/**
 * Dope-sheet timeline: labeled tracks, keyframe diamonds, adaptive time
 * ruler, draggable playhead. Purely presentational — the app owns time,
 * playback, and keyframe mutation through its engine.
 * Behavior reference: Swift `TimelineEditorView` + `UIDevTimelineDesignB`.
 */
export interface TimelineKeyframe {
    timeS: number;
    value?: number;
}
export interface TimelineTrack {
    id: string;
    label: string;
    detail?: string;
    color?: string;
    kind?: "motion" | "audio" | "event";
    keyframes: readonly TimelineKeyframe[];
}
export type TimelineEditorMode = "dope-sheet" | "curves";
export interface TimelineProps {
    tracks: readonly TimelineTrack[];
    durationS: number;
    timeS: number;
    onSeek: (timeS: number) => void;
    playing?: boolean;
    onTogglePlay?: () => void;
    selected?: {
        trackID: string;
        index: number;
    } | null;
    onSelectKeyframe?: (trackID: string, index: number) => void;
    emptyState?: ReactNode;
    variant?: "compact" | "editor";
    clipName?: string;
    framesPerSecond?: number;
    onFramesPerSecondChange?: (framesPerSecond: number) => void;
    looping?: boolean;
    onToggleLoop?: () => void;
    onStop?: () => void;
    onStepFrame?: (direction: -1 | 1) => void;
    onSeekAdjacentKeyframe?: (direction: -1 | 1) => void;
    mode?: TimelineEditorMode;
    outputStatus?: string;
}
export declare function Timeline(props: TimelineProps): import("react").JSX.Element;
