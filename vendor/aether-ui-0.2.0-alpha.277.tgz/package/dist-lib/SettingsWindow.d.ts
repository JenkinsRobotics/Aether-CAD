import type { ReactNode } from "react";
export interface SettingsPane {
    id: string;
    label: string;
    icon?: ReactNode;
    disabled?: boolean;
}
export interface SettingsSection {
    title: string;
    panes: SettingsPane[];
}
export interface SettingsWindowProps {
    open: boolean;
    title: string;
    sections: SettingsSection[];
    activePaneID: string;
    onSelectPane: (id: string) => void;
    onClose: () => void;
    /** Native settings open as a modeless utility window. Modal remains
     * available for flows that intentionally block their workspace. */
    presentation?: "floating" | "modal";
    /** The archived Aether settings window is compact; CAD keeps the larger
     * editing surface. */
    size?: "standard" | "large";
    /** Select the mounted app whose header icons are configured. */
    headerAppID?: string;
    /** Content of the active pane. */
    children: ReactNode;
}
/** The suite-standard per-app settings window: macOS anatomy — traffic-light
 *  close, grouped sidebar (General / Viewport / Advanced …), card-based
 *  content pane. Products supply sections and pane content; disabled panes
 *  render greyed out as placeholders. */
export declare function SettingsWindow(props: SettingsWindowProps): import("react").JSX.Element | null;
/** Rounded settings card with the Aether Animation Studio section header: accent icon,
 *  bold title, muted caption. `tone="notice"` renders the accent info card. */
export declare function SettingsCard(props: {
    title?: ReactNode;
    caption?: ReactNode;
    icon?: ReactNode;
    tone?: "notice";
    children?: ReactNode;
}): import("react").JSX.Element;
/** Settings row. Default: label left, control right. `stacked` puts the
 *  control full-width under the label line with `value` right-aligned —
 *  the Aether Animation Studio slider row. */
export declare function SettingsRow(props: {
    label: ReactNode;
    icon?: ReactNode;
    value?: ReactNode;
    caption?: ReactNode;
    disabled?: boolean;
    stacked?: boolean;
    children?: ReactNode;
}): import("react").JSX.Element;
