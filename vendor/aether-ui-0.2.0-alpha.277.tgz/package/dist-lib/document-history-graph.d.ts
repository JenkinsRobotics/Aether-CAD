import { type DocumentHistory, type DocumentVersionStatus } from "./DocumentServices.js";
export interface HistoryMilestone {
    id: string;
    kind: "workspace" | "version" | "start";
    name: string;
    revision: number;
    branch: string;
    branchID?: string;
    author: string;
    saved: number;
    message: string;
    lane: number;
    parents: string[];
    primaryParents: string[];
    status?: DocumentVersionStatus;
    origin?: "user" | "automatic";
    statusUpdated?: number;
    statusNote?: string;
}
/** Saved snapshot IDs are transport/concurrency tokens, never version numbers.
 * Project only explicit versions, each workspace head, and document creation.
 * Follow real parents through omitted saves so parallel branches aren't joined
 * by their timestamps. Distinct labels at the same snapshot remain distinct. */
export declare function documentHistoryGraph(history: DocumentHistory, 
/** Commit-list view (version control): only versions, plus one "Uncommitted
 *  changes" row for this branch when it has saves after its last version. No
 *  permanent workspace rows or creation marker (Jonathan, 2026-10-19). */
commitsFor?: string): HistoryMilestone[];
