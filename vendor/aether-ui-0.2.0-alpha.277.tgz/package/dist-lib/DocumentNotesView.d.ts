import { type ReactNode } from "react";
import "./DocumentNotesView.css";
interface DocumentNotesViewProps {
    loaded: boolean;
    canEdit: boolean;
    editing: boolean;
    busy: boolean;
    conflicted: boolean;
    text: string;
    savedText: string;
    error: string;
    conflict: ReactNode;
    onRefresh: () => void;
    onEdit: () => void;
    onChange: (text: string) => void;
    onSave: () => void;
    onCancel: () => void;
}
/** Read-first document notes, shared by the suite and its editors. */
export declare function DocumentNotesView(props: DocumentNotesViewProps): import("react").JSX.Element;
export {};
