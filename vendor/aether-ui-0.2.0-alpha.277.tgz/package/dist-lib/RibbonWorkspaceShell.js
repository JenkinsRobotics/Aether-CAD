import { jsx, jsxs } from "react/jsx-runtime";
import { DocumentBar } from "./DocumentBar.js";
import { WorkspaceShell } from "./WorkspaceShell.js";
import { WorkspaceRibbon } from "./WorkspaceRibbon.js";
import "./RibbonWorkspaceShell.css";
function RibbonWorkspaceShell({
  documentBar,
  ribbon,
  className,
  style,
  preservePanelContent = true,
  ...workspace
}) {
  return /* @__PURE__ */ jsxs("div", { className: ["aui-ribbon-workspace-shell", className].filter(Boolean).join(" "), style, children: [
    /* @__PURE__ */ jsx(DocumentBar, { ...documentBar }),
    /* @__PURE__ */ jsx(
      WorkspaceShell,
      {
        ...workspace,
        preservePanelContent,
        style: { flex: "1 1 0", minHeight: 0 },
        toolbar: /* @__PURE__ */ jsx(WorkspaceRibbon, { ...ribbon })
      }
    )
  ] });
}
export {
  RibbonWorkspaceShell
};
