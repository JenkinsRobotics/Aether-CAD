import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { SidePanelHeader } from "./SidePanelHeader.js";
import { PanelNotice, PanelNotifications, PanelNotificationButton } from "./PanelNotifications.js";
import { StudioDesignContext } from "./StudioDesignContext.js";
import { VersionControl } from "./VersionControl.js";
import { useDocumentMutation } from "./useDocumentMutation.js";
import { DocumentCreateDialog } from "./DocumentCreateDialog.js";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { Button } from "./Button.js";
import { useConfirm } from "./useConfirm.js";
import { Menu } from "./Menu.js";
import { DOCUMENT_HISTORY_CHANGED, historyBranchKey } from "./DocumentServices.js";
import { DocumentHistoryGraph } from "./DocumentHistoryGraph.js";
import { documentHistoryGraph } from "./document-history-graph.js";
import "./DocumentVersionPanel.css";
const stamp = (seconds) => seconds ? new Date(seconds * 1e3).toLocaleString(void 0, {
  dateStyle: "short",
  timeStyle: "short"
}) : "";
function DocumentVersionPanel({
  connection,
  embedded = false,
  createOnly = false,
  onCreated,
  onCancel,
  branchSource,
  branchOnly = false
}) {
  const studio = (useContext(StudioDesignContext) || embedded) && !createOnly;
  const [disconnected, setDisconnected] = useState(false);
  const [liveWritable, setLiveWritable] = useState();
  const liveAccess = useRef(true), historyRead = useRef(0);
  const [history, setHistory] = useState(null);
  const [confirm, confirmDialog, ask] = useConfirm();
  const [busy, setBusy] = useState(false), [error, setError] = useState("");
  const [selectedChange, setSelectedChange] = useState(null);
  const [notice, setNotice] = useState("");
  const [query, setQuery] = useState(""), [selection, setSelection] = useState(void 0);
  const [operation, setOperation] = useState(
    createOnly ? "version" : null
  );
  const [name, setName] = useState(""), [message, setMessage] = useState("");
  const [compare, setCompare] = useState(""), [report, setReport] = useState("");
  const [source, setSource] = useState(""), [conflict, setConflict] = useState(null);
  const [recovery, setRecovery] = useState(false), [recoverySelection, setRecoverySelection] = useState(null);
  const [menu, setMenu] = useState(
    null
  );
  const menuAnchor = useRef(null);
  const branch = connection.branch ?? "Main";
  const branchLabel = history?.branches.find((b) => historyBranchKey(b) === branch)?.name ?? connection.branchLabel ?? branch;
  const stable = history?.branch_identity === "stable";
  const mutation = useDocumentMutation(connection, async (action) => {
    if (action === "restore" || action === "merge") await connection.reload();
    await load();
    setError("");
    setNotice("Change confirmed.");
    setOperation(null);
    if (action === "version" || action === "branch_create") onCreated?.();
  }, stable);
  const writable = !disconnected && liveWritable !== false && !mutation.uncertain && connection.writable !== false && history?.writable !== false;
  const graph = useMemo(
    // Studio's version control is a commit list (branches switch from its selector);
    // the standard graph keeps branch heads, which double as navigation there.
    () => history ? documentHistoryGraph(history, studio ? branch : void 0) : [],
    [history, branch, studio]
  );
  const defaultSelection = graph.find((row) => row.id === `workspace:${branch}`)?.id ?? graph[0]?.id;
  const selected = selectedChange == null ? graph.find(
    (row) => row.id === (selection === void 0 ? defaultSelection : selection)
  ) : void 0;
  const [snapshots, setSnapshots] = useState(/* @__PURE__ */ new Map());
  const rendered = useRef(/* @__PURE__ */ new Map());
  useEffect(() => {
    rendered.current = /* @__PURE__ */ new Map();
    setSnapshots(/* @__PURE__ */ new Map());
  }, [connection.key]);
  const historyKey = useRef(null);
  useEffect(() => {
    const preview = connection.previewRevision?.bind(connection);
    if (!preview || !history || historyKey.current !== connection.key) return;
    let live = true;
    const parents = new Map(history.revisions.map((save) => [save.revision, save.parent_revision]));
    const render = (revision) => {
      let task = rendered.current.get(revision);
      if (!task) {
        task = preview(revision).catch(() => null);
        rendered.current.set(revision, task);
      }
      return task;
    };
    void (async () => {
      for (const revision of [...new Set(graph.map((row) => row.revision))]) {
        let candidate = revision, image = null;
        for (let step = 0; candidate != null && !image && step < 64; step++) {
          image = await render(candidate);
          candidate = parents.get(candidate);
        }
        if (!live) return;
        setSnapshots((current) => current.get(revision) === image ? current : new Map(current).set(revision, image));
      }
    })();
    return () => {
      live = false;
    };
  }, [connection, graph, history]);
  const snapshot = recovery ? recoverySelection : selectedChange ?? selected?.revision ?? null;
  const selectedName = recovery ? "automatic save" : selectedChange != null ? "change" : selected?.name ?? "entry";
  const sameAsHead = (revision) => {
    if (revision == null || !history) return false;
    const content = (at) => history.revisions.find((row) => row.revision === at)?.blob_hash;
    return !!content(revision) && content(revision) === content(head(history));
  };
  const head = (h, workspace = branch) => h.branches.find((b) => historyBranchKey(b) === workspace)?.head_revision;
  const load = async () => {
    const request = ++historyRead.current;
    const next = await connection.call("history");
    if (request === historyRead.current && liveAccess.current) {
      historyKey.current = connection.key;
      setHistory(next);
    }
    return next;
  };
  useEffect(() => {
    let live = true;
    liveAccess.current = true;
    setDisconnected(false);
    setLiveWritable(void 0);
    setHistory(null);
    setError("");
    setNotice("");
    setSelection(void 0);
    setSelectedChange(null);
    setRecovery(false);
    setRecoverySelection(null);
    setOperation(createOnly ? "version" : null);
    setReport("");
    setConflict(null);
    setName("");
    setMessage("");
    setMenu(null);
    const refresh = async () => {
      if (!liveAccess.current) return;
      const request = ++historyRead.current;
      try {
        const h = await connection.call("history");
        if (live && request === historyRead.current && liveAccess.current) {
          historyKey.current = connection.key;
          setHistory(h);
        }
      } catch (e) {
        if (live && request === historyRead.current) setError(e.message);
      }
    };
    const unsubscribe = connection.subscribeChanges?.((event) => {
      if (!live) return;
      const available = event.kind !== "unavailable";
      liveAccess.current = available;
      setDisconnected(!available);
      setLiveWritable(event.kind === "state" ? event.writable : void 0);
      if (available) void refresh();
      else {
        historyRead.current++;
        setHistory(null);
      }
    });
    const changed = (event) => {
      if (event.detail === connection.key) refresh();
    };
    window.addEventListener(DOCUMENT_HISTORY_CHANGED, changed);
    refresh();
    const timer = setInterval(refresh, 1e4);
    window.addEventListener("focus", refresh);
    return () => {
      live = false;
      historyRead.current++;
      unsubscribe?.();
      clearInterval(timer);
      window.removeEventListener("focus", refresh);
      window.removeEventListener(DOCUMENT_HISTORY_CHANGED, changed);
    };
  }, [connection.key, createOnly]);
  const run = async (work) => {
    if (busy || mutation.uncertain || !liveAccess.current) return;
    setBusy(true);
    setError("");
    try {
      await work();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const prepare = async () => {
    await connection.flush();
    return load();
  };
  const openOperation = (next) => {
    setOperation(next);
    setName("");
    setMessage("");
    setReport("");
    setConflict(null);
    setCompare("");
  };
  const version = () => run(async () => {
    const h = await prepare();
    await mutation.send("version", {
      name: name.trim(),
      message,
      branch,
      expected_revision: head(h)
    });
    setSelection(`version:${name.trim()}`);
    setNotice(`Version \u201C${name.trim()}\u201D created.`);
    setName("");
    setMessage("");
    if (!createOnly) setOperation(null);
    await load();
    onCreated?.();
  });
  const createBranchFromCurrent = () => run(async () => {
    const h = await prepare();
    const created = await mutation.send("branch_create", {
      name: name.trim(),
      message,
      ...h.branch_identity === "stable" ? {} : { branch },
      from_revision: branchSource ?? head(h),
      expected_revision: head(h, h.branch_identity === "stable" ? "Main" : branch)
    });
    setSelection(`workspace:${created?.branch_id ?? name.trim()}`);
    setNotice(`Branch \u201C${name.trim()}\u201D created.`);
    setName("");
    setMessage("");
    if (!createOnly) setOperation(null);
    await load();
    onCreated?.();
  });
  const closeCreation = useCallback(() => setOperation(null), []);
  const restore = async (entryID) => {
    const entry = entryID ? graph.find((row) => row.id === entryID) : void 0;
    const targetSnapshot = entryID ? entry?.revision : snapshot;
    if (!writable || busy || targetSnapshot == null || !await confirm({
      title: "Restore version",
      action: "Restore",
      message: `Restore ${entry?.name ?? selectedName} in ${branchLabel}? Current work will be saved for recovery first.`
    }))
      return;
    void run(async () => {
      const h = await prepare();
      await mutation.send("restore", {
        revision: targetSnapshot,
        branch,
        expected_revision: head(h)
      });
      await connection.reload();
      await load();
    });
  };
  const download = () => void run(async () => {
    if (snapshot == null) return;
    if (connection.downloadSnapshot) {
      await connection.downloadSnapshot(snapshot);
      return;
    }
    const file = await connection.call(
      "read_revision",
      { revision: snapshot }
    );
    const url = URL.createObjectURL(
      new Blob([
        Uint8Array.from(atob(file.data_base64), (c) => c.charCodeAt(0))
      ])
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = file.name;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  });
  const merge = (resolution) => run(async () => {
    const h = await prepare();
    try {
      await mutation.send("merge", {
        source,
        target: branch,
        resolution,
        expected_revision: resolution ? conflict?.target_head : head(h),
        expected_source_revision: resolution ? conflict?.source_head : head(h, source)
      });
      setConflict(null);
      setOperation(null);
      await connection.reload();
      await load();
    } catch (e) {
      const detail = e.detail;
      if (detail?.conflict) setConflict(detail);
      throw e;
    }
  });
  const rename = async () => {
    if (!selected || selected.kind === "start") return;
    const kind = selected.kind === "version" ? "version" : "branch";
    const next = await ask({ title: `Rename ${kind}`, message: `New ${kind} name`, action: "Rename", value: selected.name });
    if (!next || next === selected.name) return;
    void run(async () => {
      const h = await prepare();
      await mutation.send(
        selected.kind === "version" ? "version_update" : "branch_rename",
        {
          ...selected.kind === "workspace" && stable ? { branch: selected.branchID ?? selected.name, expected_revision: head(h, selected.branchID ?? selected.name) } : { name: selected.name, branch, expected_revision: head(h) },
          new_name: next.trim()
        }
      );
      setSelection(selected.kind === "workspace" && stable ? selected.id : `${selected.kind}:${next.trim()}`);
      await load();
    });
  };
  const remove = async () => {
    if (!selected || selected.kind === "start" || !await confirm({
      title: selected.kind === "version" ? "Remove version" : "Delete branch",
      action: selected.kind === "version" ? "Remove" : "Delete",
      message: selected.kind === "version" ? `Remove version label ${selected.name}? Its saved content remains available for recovery.` : `Delete merged workspace ${selected.name}? Unmerged work is protected.`
    }))
      return;
    void run(async () => {
      const h = await prepare();
      await mutation.send(
        selected.kind === "version" ? "version_delete" : "branch_delete",
        selected.kind === "workspace" && stable ? { branch: selected.branchID ?? selected.name, expected_revision: head(h, selected.branchID ?? selected.name), expected_main_revision: head(h, "Main") } : { name: selected.name, branch, expected_revision: head(h) }
      );
      setSelection(null);
      await load();
    });
  };
  const actionIcons = { open: "workspace", branch: "branch-from", compare: "compare", restore: "restore", download: "document-download", rename: "pencil", remove: "delete", merge: "merge", share: "people", recovery: "history", candidate: "triangle", released: "triangle-filled", obsolete: "obsoletion", withdraw: "close-circle" };
  const actionsFor = (selected2, snapshot2) => [
    { id: "compare", label: "Compare entries", disabled: busy || snapshot2 == null },
    ...!recovery && selected2?.kind === "workspace" ? [
      {
        id: "open",
        label: `Open workspace ${selected2.name}`,
        disabled: busy || !connection.openBranch || (selected2.branchID ?? selected2.name) === branch
      }
    ] : [],
    {
      id: "branch",
      label: "Branch from here",
      disabled: busy || !writable || snapshot2 == null
    },
    {
      id: "restore",
      label: "Restore selected entry",
      disabled: busy || !writable || snapshot2 == null || snapshot2 === (history && head(history))
    },
    {
      id: "download",
      label: "Download",
      disabled: busy || snapshot2 == null
    },
    ...!recovery && selected2 && selected2.kind !== "start" ? [
      {
        id: "rename",
        label: selected2.kind === "version" ? "Rename version" : "Rename workspace",
        disabled: busy || !writable || selected2.kind === "version" && !!selected2.status && selected2.status !== "version" || selected2.kind === "workspace" && (selected2.name === "Main" || (selected2.branchID ?? selected2.name) === branch)
      },
      {
        id: "remove",
        label: selected2.kind === "version" ? "Remove version label" : "Delete merged workspace",
        disabled: busy || !writable || selected2.kind === "version" && !!selected2.status && selected2.status !== "version" || selected2.kind === "workspace" && (selected2.name === "Main" || (selected2.branchID ?? selected2.name) === branch)
      }
    ] : [],
    {
      id: "merge",
      label: `Merge into ${branchLabel}`,
      separatorBefore: true,
      disabled: busy || !writable || (history?.branches.length ?? 0) < 2
    },
    ...history?.scope ? [
      {
        id: "share",
        label: history.scope === "workspace" ? "Make document private" : "Share with workspace",
        disabled: busy || !writable
      }
    ] : [],
    ...!recovery && selected2?.kind === "version" ? [
      ...selected2.status === "version" || !selected2.status ? [{ id: "candidate", label: "Create release candidate" }] : [],
      ...selected2.status === "candidate" ? [{ id: "released", label: "Approve release" }, { id: "withdraw", label: "Withdraw release candidate" }] : [],
      ...selected2.status === "released" ? [{ id: "obsolete", label: "Obsolete release" }] : []
    ].map((item) => ({ ...item, disabled: busy || !writable, separatorBefore: true })) : [],
    {
      id: "recovery",
      label: recovery ? "Back to versions" : "Automatic saves (recovery)",
      separatorBefore: true
    }
  ].filter((item) => menu !== "toolbar" || item.id !== "branch").map((item) => ({ ...item, icon: /* @__PURE__ */ jsx(AetherIcon, { name: actionIcons[item.id] }) }));
  const items = actionsFor(selected, snapshot);
  const entryActions = (id) => {
    const row = graph.find((item) => item.id === id);
    return row ? actionsFor(row, row.revision) : [];
  };
  const [pendingAction, setPendingAction] = useState(null);
  const command = async (id) => {
    setMenu(null);
    if (id === "branch" || id === "merge" || id === "compare") openOperation(id);
    if (["candidate", "released", "obsolete", "withdraw"].includes(id) && selected?.kind === "version") {
      const note = id === "obsolete" ? await ask({ title: "Obsolete release", message: "Reason for obsoleting this document release", action: "Mark obsolete", value: "" }) : "";
      if (note == null) return;
      void run(async () => {
        const h = await prepare();
        await mutation.send("version_status", {
          name: selected.name,
          branch,
          expected_revision: head(h),
          expected_status: selected.status ?? "version",
          expected_status_updated: selected.statusUpdated ?? 0,
          status: id === "withdraw" ? "version" : id,
          note
        });
        await load();
      });
    }
    if (id === "restore") void restore();
    if (id === "download") download();
    if (id === "rename") void rename();
    if (id === "remove") void remove();
    if (id === "recovery") {
      setRecovery(!recovery);
      setOperation(null);
      setRecoverySelection(null);
    }
    if (id === "open" && selected)
      void run(async () => {
        await connection.openBranch?.(selected.branchID ?? selected.name);
      });
    if (id === "share" && await confirm({
      title: history?.scope === "workspace" ? "Make private" : "Share with workspace",
      action: history?.scope === "workspace" ? "Make private" : "Share",
      message: history?.scope === "workspace" ? "Make this document and discussions private?" : "Share this document and discussions with your workspace?"
    }))
      void run(async () => {
        const h = await prepare();
        await mutation.send("share", {
          scope: h.scope === "workspace" ? "personal" : "workspace",
          expected_revision: head(h, "Main")
        });
        await connection.reload();
        await load();
      });
  };
  useEffect(() => {
    if (pendingAction && selected?.id === pendingAction.entry) {
      setPendingAction(null);
      void command(pendingAction.id);
    }
  });
  const pendingNotice = mutation.uncertain && /* @__PURE__ */ jsxs("div", { role: "group", "aria-label": "Confirm pending change", children: [
    /* @__PURE__ */ jsx("p", { children: "The reply was lost. Confirm the original change before making another." }),
    mutation.canRetry ? /* @__PURE__ */ jsx(Button, { disabled: mutation.retrying, onClick: () => void mutation.retry().catch((e) => setError(e.message)), children: "Retry original change" }) : /* @__PURE__ */ jsx("p", { children: "This server cannot safely replay this change. Check its history before submitting again." })
  ] });
  return /* @__PURE__ */ jsx(PanelNotifications, { children: /* @__PURE__ */ jsxs(
    "section",
    {
      className: `aui-version-panel${studio ? " aui-version-panel--studio" : ""}`,
      "aria-label": createOnly ? branchOnly ? "Create branch" : "Create version" : "Versions and history",
      children: [
        confirmDialog,
        disconnected && /* @__PURE__ */ jsx(PanelNotice, { message: "Live updates are disconnected. Your draft is kept. Reconnecting\u2026" }),
        !createOnly && !studio && /* @__PURE__ */ jsxs("header", { className: "aui-version-head", children: [
          /* @__PURE__ */ jsx("h3", { children: createOnly ? "Create version" : "Versions and history" }),
          !createOnly && /* @__PURE__ */ jsxs("div", { className: "aui-version-head-actions", ref: menuAnchor, children: [
            /* @__PURE__ */ jsx(PanelNotificationButton, {}),
            /* @__PURE__ */ jsx(
              IconButton,
              {
                label: "Create version",
                disabled: busy || !writable,
                onClick: () => openOperation("version"),
                children: /* @__PURE__ */ jsx(AetherIcon, { name: "version-create" })
              }
            ),
            /* @__PURE__ */ jsx(IconButton, { label: "Create branch", disabled: busy || !writable || snapshot == null, onClick: () => openOperation("branch"), children: /* @__PURE__ */ jsx(AetherIcon, { name: "branch-from" }) }),
            /* @__PURE__ */ jsx(
              IconButton,
              {
                label: "More history actions",
                "aria-haspopup": "menu",
                "aria-expanded": !!menu,
                onClick: () => setMenu(menu ? null : "toolbar"),
                children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" })
              }
            )
          ] })
        ] }),
        studio && recovery && !embedded && /* @__PURE__ */ jsx(SidePanelHeader, { title: "Version control", icon: "version-control" }),
        !createOnly && (!studio || recovery) && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "aui-version-search", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "search",
              "aria-label": "Search history",
              placeholder: "Search history",
              value: query,
              onChange: (e) => setQuery(e.target.value)
            }
          ),
          /* @__PURE__ */ jsx(AetherIcon, { name: "search" })
        ] }) }),
        studio ? /* @__PURE__ */ jsx(PanelNotice, { message: error }) : error && /* @__PURE__ */ jsx("p", { role: "alert", className: "aui-version-error", children: error }),
        studio ? /* @__PURE__ */ jsx(PanelNotice, { children: pendingNotice }) : pendingNotice,
        !createOnly && (operation === "version" || operation === "branch") && /* @__PURE__ */ jsx(DocumentCreateDialog, { connection, onClose: closeCreation, mode: operation, sourceRevision: operation === "branch" && !(selected?.kind === "workspace" && (selected.branchID ?? selected.name) === branch) && !sameAsHead(snapshot) ? snapshot ?? void 0 : void 0, sourceName: operation === "branch" ? selectedName : void 0 }),
        operation && (createOnly || operation !== "version" && operation !== "branch") && /* @__PURE__ */ jsxs(
          "div",
          {
            className: "aui-version-operation",
            role: "group",
            "aria-label": `${operation} action`,
            children: [
              !createOnly && /* @__PURE__ */ jsx(
                IconButton,
                {
                  className: "aui-version-dismiss",
                  label: "Close action",
                  onClick: () => setOperation(null),
                  children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
                }
              ),
              operation === "version" && /* @__PURE__ */ jsxs(
                "form",
                {
                  onSubmit: (e) => {
                    e.preventDefault();
                    if (branchOnly) void createBranchFromCurrent();
                    else void version();
                  },
                  children: [
                    /* @__PURE__ */ jsxs("label", { children: [
                      "Name",
                      /* @__PURE__ */ jsx(
                        "input",
                        {
                          autoFocus: true,
                          "aria-label": "Name",
                          value: name,
                          maxLength: 80,
                          onChange: (e) => setName(e.target.value)
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxs("label", { children: [
                      "Description",
                      /* @__PURE__ */ jsx(
                        "textarea",
                        {
                          "aria-label": "Description",
                          rows: 2,
                          value: message,
                          maxLength: 500,
                          onChange: (e) => setMessage(e.target.value)
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "aui-version-create-actions", children: [
                      !branchOnly && /* @__PURE__ */ jsxs(
                        Button,
                        {
                          primary: true,
                          type: "submit",
                          disabled: busy || !writable || !name.trim(),
                          children: [
                            /* @__PURE__ */ jsx(AetherIcon, { name: "version-create" }),
                            " Create version"
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxs(
                        Button,
                        {
                          primary: branchOnly,
                          type: "button",
                          disabled: busy || !writable || !name.trim(),
                          onClick: () => void createBranchFromCurrent(),
                          children: [
                            /* @__PURE__ */ jsx(AetherIcon, { name: "branch-from" }),
                            " Create branch"
                          ]
                        }
                      ),
                      onCancel && /* @__PURE__ */ jsxs(Button, { type: "button", onClick: onCancel, children: [
                        /* @__PURE__ */ jsx(AetherIcon, { name: "close" }),
                        " Cancel"
                      ] })
                    ] }),
                    notice && /* @__PURE__ */ jsx("p", { role: "status", children: notice })
                  ]
                }
              ),
              operation === "compare" && /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsxs("label", { children: [
                  "Compare ",
                  selectedName,
                  " with",
                  /* @__PURE__ */ jsxs(
                    "select",
                    {
                      "aria-label": "Compare with",
                      value: compare,
                      onChange: (e) => setCompare(e.target.value),
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Choose entry" }),
                        graph.filter((row) => row.revision !== snapshot).map((row) => /* @__PURE__ */ jsxs("option", { value: row.id, children: [
                          row.name,
                          row.kind === "workspace" ? " (workspace)" : ""
                        ] }, row.id))
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs(
                  Button,
                  {
                    disabled: busy || !compare || snapshot == null,
                    onClick: () => void run(async () => {
                      const target = graph.find((row) => row.id === compare);
                      if (!target) return;
                      const result = await connection.call("compare", { from: snapshot, to: target.revision });
                      setReport(
                        result.same_content ? "Identical file content." : result.content_diff?.text?.replace(
                          /^--- revision .*$/m,
                          "--- Selected entry"
                        ).replace(
                          /^\+\+\+ revision .*$/m,
                          "+++ Compared entry"
                        ) ?? "The files differ."
                      );
                    }),
                    children: [
                      /* @__PURE__ */ jsx(AetherIcon, { name: "compare" }),
                      " Compare entries"
                    ]
                  }
                ),
                report && /* @__PURE__ */ jsx("pre", { "aria-label": "Entry comparison", children: report })
              ] }),
              operation === "merge" && /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsxs("label", { children: [
                  "Merge from",
                  /* @__PURE__ */ jsxs(
                    "select",
                    {
                      "aria-label": "Merge source",
                      value: source,
                      onChange: (e) => {
                        setSource(e.target.value);
                        setConflict(null);
                      },
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Choose workspace" }),
                        history?.branches.filter((b) => historyBranchKey(b) !== branch).map((b) => /* @__PURE__ */ jsx("option", { value: historyBranchKey(b), children: b.name }, historyBranchKey(b)))
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs(
                  Button,
                  {
                    disabled: busy || !writable || !history?.branches.some(
                      (b) => historyBranchKey(b) === source && source !== branch
                    ),
                    onClick: () => void merge(),
                    children: [
                      /* @__PURE__ */ jsx(AetherIcon, { name: "merge" }),
                      " Merge into ",
                      branchLabel
                    ]
                  }
                ),
                conflict && /* @__PURE__ */ jsxs("div", { role: "group", "aria-label": "Resolve merge conflict", children: [
                  /* @__PURE__ */ jsx("p", { children: "Both workspaces changed. Choose the complete file to keep; both save histories remain available." }),
                  /* @__PURE__ */ jsxs(Button, { disabled: busy, onClick: () => void merge("source"), children: [
                    /* @__PURE__ */ jsx(AetherIcon, { name: "document" }),
                    " Use source file"
                  ] }),
                  /* @__PURE__ */ jsxs(Button, { disabled: busy, onClick: () => void merge("target"), children: [
                    /* @__PURE__ */ jsx(AetherIcon, { name: "workspace" }),
                    " Keep current file"
                  ] }),
                  /* @__PURE__ */ jsxs(Button, { onClick: () => setConflict(null), children: [
                    /* @__PURE__ */ jsx(AetherIcon, { name: "close" }),
                    " Cancel merge"
                  ] })
                ] })
              ] })
            ]
          }
        ),
        !createOnly && (recovery ? /* @__PURE__ */ jsxs("div", { className: "aui-version-recovery", children: [
          /* @__PURE__ */ jsxs(
            Button,
            {
              onClick: () => {
                setRecovery(false);
                setOperation(null);
              },
              children: [
                /* @__PURE__ */ jsx(AetherIcon, { name: "version-control" }),
                " Back to versions"
              ]
            }
          ),
          /* @__PURE__ */ jsx("h4", { children: "Automatic saves" }),
          /* @__PURE__ */ jsx("p", { children: "Recovery snapshots, not versions or commits." }),
          /* @__PURE__ */ jsx("ol", { "aria-label": "Automatic saves", children: history?.revisions.filter(
            (save) => `${save.author} ${save.branch}`.toLowerCase().includes(query.toLowerCase())
          ).map((save) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              "aria-pressed": recoverySelection === save.revision,
              onClick: () => setRecoverySelection(save.revision),
              onContextMenu: (e) => {
                e.preventDefault();
                setRecoverySelection(save.revision);
                setMenu({ x: e.clientX, y: e.clientY });
              },
              children: [
                /* @__PURE__ */ jsx("span", { children: stamp(save.saved) }),
                /* @__PURE__ */ jsxs("small", { children: [
                  save.author,
                  " \xB7 ",
                  save.branch
                ] })
              ]
            }
          ) }, save.revision)) })
        ] }) : studio ? /* @__PURE__ */ jsx(
          VersionControl,
          {
            embedded,
            entries: graph.map((row) => ({
              id: row.id,
              name: row.name,
              description: row.message || "",
              kind: row.kind === "workspace" ? row.branch === "Main" ? "workspace" : "branch" : row.kind === "start" ? "start" : row.status === "released" ? "release" : row.status === "candidate" ? "review" : row.status === "obsolete" ? "deprecated" : row.parents.some((id) => !row.primaryParents.includes(id)) ? "merge" : "version",
              branch: history?.branches.find((item) => historyBranchKey(item) === (row.branchID ?? row.branch))?.name ?? row.branch,
              lane: row.lane,
              parents: row.parents,
              primaryParents: row.primaryParents,
              author: row.author,
              saved: row.saved,
              current: row.id === `workspace:${branch}`,
              snapshot: snapshots.get(row.revision) ?? void 0,
              changes: row.message ? [row.message] : []
            })),
            activeBranch: branchLabel,
            selected: selected?.id ?? null,
            notice: history && graph.every((row) => row.kind === "start") ? "No versions yet. Your edits save automatically; create a version to mark a point in history." : void 0,
            branchOptions: history?.branches.map((item) => ({ id: historyBranchKey(item), name: item.name })),
            onOpenBranch: connection.openBranch ? (id) => {
              if (id !== branch) void run(async () => {
                await connection.openBranch(id);
              });
            } : void 0,
            onSelect: (id) => {
              setSelection(id);
              setSelectedChange(null);
              setReport("");
            },
            createKinds: ["version", "branch"],
            onCreate: busy || !writable ? void 0 : (kind, id) => {
              if (id) setSelection(id);
              setSelectedChange(null);
              openOperation(kind === "branch" ? "branch" : "version");
            },
            onCompare: (id) => {
              setSelection(id);
              setSelectedChange(null);
              openOperation("compare");
            },
            onRestore: busy || !writable ? void 0 : (id) => void restore(id),
            onMerge: busy || !writable ? void 0 : () => openOperation("merge"),
            entryActions,
            onEntryAction: (entry, id) => setPendingAction({ entry, id })
          }
        ) : /* @__PURE__ */ jsx(
          DocumentHistoryGraph,
          {
            history,
            graph,
            branch,
            query,
            selectedID: selected?.id,
            selectedSave: selectedChange,
            onSelect: (row) => {
              setSelection(row.id);
              setSelectedChange(null);
              setReport("");
            },
            onSelectSave: setSelectedChange,
            onOpenWorkspace: (name2) => void run(async () => {
              await connection.openBranch?.(name2);
            }),
            onContextMenu: setMenu
          }
        )),
        menu && /* @__PURE__ */ jsx(
          Menu,
          {
            open: true,
            className: "aui-collection-popup",
            anchor: menu === "toolbar" ? menuAnchor.current : menu,
            placement: "bottom-end",
            ariaLabel: "History actions",
            items,
            onSelect: command,
            onClose: () => setMenu(null)
          }
        )
      ]
    }
  ) });
}
export {
  DocumentVersionPanel
};
