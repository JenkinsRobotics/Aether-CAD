function createFeatureWindowHelp(title, trigger, onDismiss) {
  const card = document.createElement("aside");
  card.className = "aui-feature-help-popover";
  card.setAttribute("role", "dialog");
  card.setAttribute("aria-label", `${title} help`);
  const header = document.createElement("header");
  const heading = document.createElement("strong");
  heading.textContent = `${title} help`;
  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "\xD7";
  close.setAttribute("aria-label", "Close help");
  close.onclick = () => {
    onDismiss();
    trigger.focus();
  };
  header.append(heading, close);
  const content = document.createElement("div");
  content.className = "aui-feature-help-content";
  card.append(header, content);
  let lifetime = null;
  let observer = null;
  const position = () => {
    const anchor = trigger.getBoundingClientRect(), bounds = card.getBoundingClientRect();
    const left = anchor.right + 8 + bounds.width <= window.innerWidth - 8 ? anchor.right + 8 : anchor.left - bounds.width - 8;
    card.style.left = `${Math.max(8, Math.min(left, window.innerWidth - bounds.width - 8))}px`;
    card.style.top = `${Math.max(8, Math.min(anchor.top, window.innerHeight - bounds.height - 8))}px`;
  };
  const hide = () => {
    lifetime?.abort();
    lifetime = null;
    observer?.disconnect();
    observer = null;
    card.remove();
  };
  return {
    add(contentNode) {
      if (typeof contentNode === "string") {
        const paragraph = document.createElement("p");
        paragraph.textContent = contentNode;
        content.append(paragraph);
      } else content.append(contentNode);
      if (card.isConnected) position();
    },
    show() {
      if (!content.childElementCount || card.isConnected) return;
      document.body.append(card);
      position();
      lifetime = new (document.defaultView?.AbortController ?? AbortController)();
      const signal = lifetime.signal;
      document.addEventListener("keydown", (event) => {
        if (event.key !== "Escape") return;
        event.preventDefault();
        event.stopPropagation();
        onDismiss();
        trigger.focus();
      }, { capture: true, signal });
      document.addEventListener("pointerdown", (event) => {
        if (!card.contains(event.target) && !trigger.contains(event.target)) onDismiss();
      }, { capture: true, signal });
      window.addEventListener("resize", position, { signal });
      document.addEventListener("scroll", position, { capture: true, signal });
      observer = new window.MutationObserver(() => {
        if (!trigger.isConnected) hide();
        else position();
      });
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    },
    hide,
    dispose: hide
  };
}
export {
  createFeatureWindowHelp
};
