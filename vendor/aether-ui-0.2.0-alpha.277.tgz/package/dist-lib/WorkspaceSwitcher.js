import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Menu } from "./Menu.js";
import "./WorkspaceSwitcher.css";
function ToolMenuButton({
  label,
  items,
  onSelect,
  children,
  placement = "bottom-end",
  anchorTo = "trigger",
  className,
  menuClassName,
  ...buttonProps
}) {
  const anchorRef = useRef(null);
  const [open, setOpen] = useState(false);
  const classes = ["aui-menu-trigger"];
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        ...buttonProps,
        ref: anchorRef,
        type: "button",
        className: classes.join(" "),
        "aria-label": label,
        title: label,
        "aria-haspopup": "menu",
        "aria-expanded": open,
        onClick: () => setOpen((current) => !current),
        children
      }
    ),
    /* @__PURE__ */ jsx(
      Menu,
      {
        open,
        anchor: anchorTo === "group" ? anchorRef.current?.parentElement ?? anchorRef.current : anchorRef.current,
        items,
        onSelect,
        onClose: () => setOpen(false),
        ariaLabel: label,
        placement,
        className: menuClassName
      }
    )
  ] });
}
function WorkspaceSwitcher({
  workspaces,
  workspaceID,
  onSelect,
  label,
  className,
  menuClassName
}) {
  const current = workspaces.find((workspace) => workspace.id === workspaceID);
  const classes = ["aui-workspace-switcher"];
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs(
    ToolMenuButton,
    {
      className: classes.join(" "),
      menuClassName,
      label: label ?? `Workspace: ${current?.label ?? ""}`,
      placement: "bottom-start",
      items: workspaces.map((workspace, index) => ({
        id: workspace.id,
        label: workspace.label,
        icon: workspace.icon,
        disabled: workspace.disabled,
        disabledReason: workspace.disabledReason,
        kind: "radio",
        checked: workspace.id === workspaceID,
        heading: index === 0 ? "Workspace" : void 0
      })),
      onSelect,
      children: [
        current?.icon ? /* @__PURE__ */ jsx("span", { className: "aui-workspace-switcher-icon", "aria-hidden": "true", children: current.icon }) : null,
        /* @__PURE__ */ jsx("span", { className: "aui-workspace-switcher-name", children: current?.label ?? "Workspace" }),
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron" })
      ]
    }
  );
}
export {
  ToolMenuButton,
  WorkspaceSwitcher
};
