import url from "@aether/assets/models/scifirobot/scifirobot.glb?url";
const modelStudioSample = { id: "scifirobot", name: "Scifirobot", url, filename: "scifirobot.glb", format: "glb", units: "meters", kind: "mesh-study" };
import cadURL from "@aether/assets/models/scifirobot/parametric/Scifirobot.acpart?url";
import stepURL from "@aether/assets/models/scifirobot/parametric/Scifirobot.step?url";
const modelStudioFeatureSample = { id: "scifirobot-parametric", name: "Scifirobot", url: cadURL, stepURL, filename: "Scifirobot.acpart", format: "acpart", units: "millimeters", kind: "feature-model" };
export {
  modelStudioFeatureSample,
  modelStudioSample
};
