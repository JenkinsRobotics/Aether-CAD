import { type ChartSeries } from "./ChartLegend.js";
import "./ComparisonChart.css";
export interface ComparisonPoint {
    id: string;
    label: string;
    values: Readonly<Record<string, number>>;
}
export interface ComparisonChartProps {
    label: string;
    data: readonly ComparisonPoint[];
    series: readonly ChartSeries[];
    kind?: "line" | "bar";
    selectedID?: string;
    onSelect?: (id: string) => void;
    formatValue?: (value: number) => string;
}
/** Nonnegative multi-series comparisons, with keyboard inspection and legend toggles. */
export declare function ComparisonChart({ label, data, series, kind, selectedID, onSelect, formatValue }: ComparisonChartProps): import("react").JSX.Element;
