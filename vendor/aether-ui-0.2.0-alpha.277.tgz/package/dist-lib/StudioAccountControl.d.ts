import "./StudioAppFrame.css";
/** Account-card presentation shared with the approved transparent header. */
export declare function StudioAccountControl({ name, detail, onViewAccount, onSettings, onSignOut }: {
    name?: string;
    detail?: string;
    onViewAccount?: () => void;
    onSettings?: () => void;
    onSignOut?: () => void;
}): import("react").JSX.Element;
