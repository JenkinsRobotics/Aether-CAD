import { jsx, jsxs } from "react/jsx-runtime";
import { useMemo, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
function compareValues(left, right) {
  if (left == null && right == null) return 0;
  if (left == null) return 1;
  if (right == null) return -1;
  return typeof left === "number" && typeof right === "number" ? left - right : String(left).localeCompare(String(right), void 0, {
    numeric: true,
    sensitivity: "base"
  });
}
function DataTable({
  rows,
  rowID,
  columns,
  selectedIDs,
  onSelect,
  ariaLabel,
  selectionMode = "multiple",
  sort,
  onSortChange,
  filter,
  filterText,
  onEdit,
  onColumnResize,
  onColumnReorder,
  rowActions,
  onRowAction,
  onActivate,
  emptyState,
  loading = false,
  loadingState,
  error,
  virtualizeThreshold = 100,
  height = 280,
  rowHeight = 32,
  overscan = 4,
  className,
  style
}) {
  const [widths, setWidths] = useState(
    () => Object.fromEntries(columns.map((column) => [column.id, column.width ?? 140]))
  );
  const [focusedID, setFocusedID] = useState(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [editing, setEditing] = useState(null);
  const [editDraft, setEditDraft] = useState("");
  const anchorRef = useRef(null);
  const dragColumnRef = useRef(null);
  const rowRefs = useRef(/* @__PURE__ */ new Map());
  const displayedRows = useMemo(() => {
    const query = (filter ?? "").trim().toLocaleLowerCase();
    let result = query ? rows.filter((row) => {
      const value = filterText ? filterText(row) : columns.map((column) => column.sortValue?.(row) ?? "").join(" ");
      return value.toLocaleLowerCase().includes(query);
    }) : [...rows];
    if (sort) {
      const column = columns.find((entry) => entry.id === sort.columnID);
      if (column?.sortValue) {
        result = [...result].sort((left, right) => {
          const order = compareValues(column.sortValue(left), column.sortValue(right));
          return sort.direction === "ascending" ? order : -order;
        });
      }
    }
    return result;
  }, [columns, filter, filterText, rows, sort]);
  const hasActions = Boolean(rowActions);
  const template = [
    ...columns.map((column) => `${widths[column.id] ?? column.width ?? 140}px`),
    ...hasActions ? ["36px"] : []
  ].join(" ");
  const pinnedOffsets = useMemo(() => {
    const offsets = {};
    let left = 0;
    for (const column of columns) {
      if (!column.pinned) continue;
      offsets[column.id] = left;
      left += widths[column.id] ?? column.width ?? 140;
    }
    return offsets;
  }, [columns, widths]);
  const virtualized = displayedRows.length >= virtualizeThreshold;
  const start = virtualized ? Math.max(0, Math.floor(scrollTop / rowHeight) - overscan) : 0;
  const end = virtualized ? Math.min(
    displayedRows.length,
    Math.ceil((scrollTop + height) / rowHeight) + overscan
  ) : displayedRows.length;
  const visibleRows = displayedRows.slice(start, end);
  const selectRow = (row, event) => {
    const id = rowID(row);
    if (selectionMode === "multiple" && event.shiftKey && anchorRef.current) {
      const from = displayedRows.findIndex((entry) => rowID(entry) === anchorRef.current);
      const to = displayedRows.findIndex((entry) => rowID(entry) === id);
      if (from >= 0 && to >= 0) {
        const [rangeStart, rangeEnd] = from < to ? [from, to] : [to, from];
        onSelect(
          displayedRows.slice(rangeStart, rangeEnd + 1).map(rowID),
          "range"
        );
        return;
      }
    }
    anchorRef.current = id;
    onSelect(
      [id],
      selectionMode === "multiple" && (event.metaKey || event.ctrlKey) ? "toggle" : "single"
    );
  };
  const focusRow = (index) => {
    const row = displayedRows[index];
    if (!row) return;
    const id = rowID(row);
    setFocusedID(id);
    rowRefs.current.get(id)?.focus();
  };
  const handleRowKey = (event, row, index) => {
    switch (event.key) {
      case "ArrowDown":
        focusRow(Math.min(displayedRows.length - 1, index + 1));
        break;
      case "ArrowUp":
        focusRow(Math.max(0, index - 1));
        break;
      case "Home":
        focusRow(0);
        break;
      case "End":
        focusRow(displayedRows.length - 1);
        break;
      case "Enter":
        if (selectedIDs.has(rowID(row))) onActivate?.(rowID(row));
        else selectRow(row, event);
        break;
      case " ":
        selectRow(row, event);
        break;
      default:
        return;
    }
    event.preventDefault();
  };
  const startResize = (event, column) => {
    event.preventDefault();
    event.stopPropagation();
    const initialX = event.clientX;
    const initialWidth = widths[column.id] ?? column.width ?? 140;
    const move = (moveEvent) => {
      const next = Math.min(
        column.maxWidth ?? 600,
        Math.max(column.minWidth ?? 60, initialWidth + moveEvent.clientX - initialX)
      );
      setWidths((current) => ({ ...current, [column.id]: next }));
      onColumnResize?.(column.id, next);
    };
    const finish = () => {
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerup", finish);
    };
    document.addEventListener("pointermove", move);
    document.addEventListener("pointerup", finish);
  };
  const beginEdit = (row, column) => {
    if (!column.editable || !onEdit) return;
    setEditing({ rowID: rowID(row), columnID: column.id });
    setEditDraft(
      column.editValue?.(row) ?? String(column.sortValue?.(row) ?? "")
    );
  };
  const commitEdit = () => {
    if (!editing) return;
    onEdit?.(editing.rowID, editing.columnID, editDraft);
    setEditing(null);
  };
  const classes = ["aui-data-table", className].filter(Boolean).join(" ");
  if (loading || error || displayedRows.length === 0) {
    return /* @__PURE__ */ jsx("div", { className: classes, role: "grid", "aria-label": ariaLabel, "aria-busy": loading || void 0, style, children: /* @__PURE__ */ jsx("div", { className: "aui-data-table-state", role: error ? "alert" : "status", children: error ?? (loading ? loadingState ?? "Loading\u2026" : emptyState ?? "No rows") }) });
  }
  return /* @__PURE__ */ jsx("div", { className: classes, role: "grid", "aria-label": ariaLabel, "aria-rowcount": displayedRows.length + 1, style, children: /* @__PURE__ */ jsxs("div", { className: "aui-data-table-scroll", style: virtualized ? { height } : void 0, onScroll: (event) => setScrollTop(event.currentTarget.scrollTop), children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-data-table-header", role: "row", style: { gridTemplateColumns: template }, children: [
      columns.map((column) => {
        const activeSort = sort?.columnID === column.id ? sort.direction : void 0;
        const pinnedStyle = column.pinned ? { position: "sticky", left: pinnedOffsets[column.id], zIndex: 3 } : void 0;
        return /* @__PURE__ */ jsxs(
          "div",
          {
            className: "aui-data-table-heading",
            role: "columnheader",
            "aria-sort": activeSort ?? "none",
            draggable: Boolean(column.reorderable && onColumnReorder),
            style: { ...pinnedStyle, justifyContent: column.align ?? "start" },
            onDragStart: (event) => {
              dragColumnRef.current = column.id;
              event.dataTransfer.setData("text/plain", column.id);
            },
            onDragOver: (event) => {
              if (dragColumnRef.current && dragColumnRef.current !== column.id) event.preventDefault();
            },
            onDrop: (event) => {
              event.preventDefault();
              if (dragColumnRef.current && dragColumnRef.current !== column.id) {
                onColumnReorder?.(dragColumnRef.current, column.id);
              }
              dragColumnRef.current = null;
            },
            children: [
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  disabled: !column.sortable,
                  onClick: () => {
                    if (!column.sortable) return;
                    onSortChange?.(
                      !activeSort ? { columnID: column.id, direction: "ascending" } : activeSort === "ascending" ? { columnID: column.id, direction: "descending" } : null
                    );
                  },
                  children: [
                    column.header,
                    activeSort ? /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: /* @__PURE__ */ jsx(AetherIcon, { name: activeSort === "ascending" ? "chevron-up" : "chevron-down" }) }) : null
                  ]
                }
              ),
              column.resizable ? /* @__PURE__ */ jsx("span", { className: "aui-data-table-resizer", role: "separator", "aria-label": `Resize ${column.header}`, onPointerDown: (event) => startResize(event, column) }) : null
            ]
          },
          column.id
        );
      }),
      hasActions ? /* @__PURE__ */ jsx("div", { role: "columnheader", "aria-label": "Row actions" }) : null
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-data-table-body", style: virtualized ? { height: displayedRows.length * rowHeight } : void 0, children: visibleRows.map((row, offset) => {
      const id = rowID(row);
      const index = start + offset;
      const selected = selectedIDs.has(id);
      const rowStyle = {
        gridTemplateColumns: template,
        ...virtualized ? { position: "absolute", top: index * rowHeight, left: 0, height: rowHeight } : null
      };
      return /* @__PURE__ */ jsxs(
        "div",
        {
          ref: (element) => {
            if (element) rowRefs.current.set(id, element);
            else rowRefs.current.delete(id);
          },
          className: `aui-data-table-row${selected ? " aui-data-table-row--selected" : ""}`,
          role: "row",
          "aria-selected": selected,
          tabIndex: focusedID === id || focusedID === null && index === 0 ? 0 : -1,
          style: rowStyle,
          onFocus: () => setFocusedID(id),
          onClick: (event) => selectRow(row, event),
          onDoubleClick: () => onActivate?.(id),
          onKeyDown: (event) => handleRowKey(event, row, index),
          children: [
            columns.map((column) => {
              const isEditing = editing?.rowID === id && editing.columnID === column.id;
              const pinnedStyle = column.pinned ? { position: "sticky", left: pinnedOffsets[column.id], zIndex: 2 } : void 0;
              return /* @__PURE__ */ jsx(
                "div",
                {
                  className: "aui-data-table-cell",
                  role: "gridcell",
                  style: { ...pinnedStyle, justifyContent: column.align ?? "start" },
                  onDoubleClick: (event) => {
                    event.stopPropagation();
                    beginEdit(row, column);
                  },
                  children: isEditing ? /* @__PURE__ */ jsx(
                    "input",
                    {
                      autoFocus: true,
                      "aria-label": `Edit ${column.header}`,
                      value: editDraft,
                      onChange: (event) => setEditDraft(event.target.value),
                      onClick: (event) => event.stopPropagation(),
                      onBlur: commitEdit,
                      onKeyDown: (event) => {
                        event.stopPropagation();
                        if (event.key === "Enter") commitEdit();
                        if (event.key === "Escape") setEditing(null);
                      }
                    }
                  ) : column.cell(row)
                },
                column.id
              );
            }),
            hasActions ? /* @__PURE__ */ jsx("div", { className: "aui-data-table-actions", role: "gridcell", children: rowActions?.(row).map((action) => /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                "aria-label": action.label,
                title: action.label,
                disabled: action.disabled,
                onClick: (event) => {
                  event.stopPropagation();
                  onRowAction?.(id, action.id);
                },
                children: action.icon
              },
              action.id
            )) }) : null
          ]
        },
        id
      );
    }) })
  ] }) });
}
export {
  DataTable
};
