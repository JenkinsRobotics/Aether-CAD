const agentModes = [
  { id: "agent", label: "Agent", description: "Inspect and edit with enabled tools." },
  { id: "ask", label: "Ask", description: "Answer questions without changing the workspace." },
  { id: "plan", label: "Plan", description: "Inspect and propose steps without making changes." }
];
function agentModeContext(context, mode) {
  if (mode === "agent") return context;
  return `${context}
Chat mode: ${mode}. Only read-only tools are available. ${mode === "plan" ? "Inspect the workspace and propose a plan. Do not claim to have applied changes." : "Answer the question without modifying the workspace."}`;
}
function agentModeInteraction(interaction, mode, disabled) {
  if (!interaction) return;
  const tools = interaction.tools.filter((tool) => !disabled.includes(tool.name) && (mode === "agent" || interaction.readOnlyTools?.includes(tool.name)));
  return { ...interaction, tools, execute: (call, signal) => {
    if (!tools.some((tool) => tool.name === call.name)) return Promise.reject(Error("This editor tool is not available in the current mode."));
    return interaction.execute(call, signal);
  } };
}
export {
  agentModeContext,
  agentModeInteraction,
  agentModes
};
