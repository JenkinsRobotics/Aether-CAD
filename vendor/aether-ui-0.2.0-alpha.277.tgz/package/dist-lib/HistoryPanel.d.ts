import { type ReactNode } from 'react';
import { type MenuItem } from './Menu.js';
import './HistoryPanel.css';
export interface HistoryEntry {
    id: string;
    label: string;
    icon?: ReactNode;
    description?: string;
    details?: ReactNode;
    category?: string;
    /** Product-owned state: a rolled-back feature or an undone editing step. */
    inactive?: boolean;
    current?: boolean;
    actions?: readonly MenuItem[];
}
export interface HistoryPanelProps {
    entries: readonly HistoryEntry[];
    onCommand?: (entryID: string, commandID: string) => void;
    emptyMessage?: string;
    /** The combined History / Version control panel supplies the header. */
    embedded?: boolean;
    /** Applied step count in the full, unfiltered operation order. */
    rollbackIndex?: number;
    /** Optional subset of entries participating in rollback, in display order. */
    rollbackEntryIDs?: readonly string[];
    onRollback?: (index: number) => void;
    rollbackDisabled?: boolean;
}
/** Editing history presentation only. Each editor owns ordering, operations and undo. */
export declare function HistoryPanel({ entries, onCommand, emptyMessage, embedded, rollbackIndex, rollbackEntryIDs, onRollback, rollbackDisabled }: HistoryPanelProps): import("react").JSX.Element;
