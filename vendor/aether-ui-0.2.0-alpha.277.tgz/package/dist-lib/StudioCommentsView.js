import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { PanelNotice } from "./PanelNotifications.js";
import { useEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Avatar } from "./Avatar.js";
import { ReviewFilterBar } from "./ReviewFilterBar.js";
import { MenuButton } from "./Menu.js";
import { ReviewComposer } from "./ReviewComposer.js";
import { commentScreenshot } from "./comment-images.js";
import "./StudioReview.css";
function StudioCommentsView(props) {
  const { state, connection, busy } = props;
  const [filter, setFilter] = useState("all"), [localTag, setLocalTag] = useState(""), [query, setQuery] = useState("");
  const tag = props.reviewTag ?? localTag, setTag = props.onReviewTag ?? setLocalTag;
  const [scope, setScope] = useState("*"), [history, setHistory] = useState(null);
  const stream = useRef(null), count = useRef(0);
  useEffect(() => {
    let live = true;
    setHistory(null);
    setQuery("");
    setScope("*");
    setFilter("all");
    void connection.call("history").then((next) => {
      if (live) setHistory(next);
    }).catch(() => {
    });
    return () => {
      live = false;
    };
  }, [connection.key]);
  useEffect(() => {
    if (stream.current && (state?.comments.length ?? 0) > count.current) stream.current.scrollTop = stream.current.scrollHeight;
    count.current = state?.comments.length ?? 0;
  }, [state?.comments.length]);
  const person = (id) => state?.members.find((member) => member.id === id);
  const tagsFor = (item) => item.tags ?? [];
  const tagFor = (item) => tagsFor(item).join(" ");
  const tags = [...new Set([...state?.comments ?? [], ...state?.tasks ?? []].flatMap(tagsFor).filter(Boolean))];
  const branches = history?.branches.map((branch) => ({ value: branch.id ?? "Main", label: branch.name })) ?? [{ value: connection.branch ?? "Main", label: connection.branchLabel ?? "Main" }];
  const allowed = (item) => state?.can_manage || state?.actor === state?.owner || item.author === state?.actor;
  const rootMatches = new Set((state?.comments ?? []).filter((item) => !item.deleted && (!tag || tagsFor(item).includes(tag)) && `${item.text} ${tagFor(item)}`.toLowerCase().includes(query.toLowerCase())).map((item) => item.parent ?? item.id));
  const roots = new Set((state?.comments ?? []).filter((item) => !item.parent && rootMatches.has(item.id) && (scope === "*" || (item.branch_id ?? "Main") === scope) && (filter === "all" || (filter === "resolved" ? item.resolved : !item.resolved))).map((item) => item.id));
  const items = (state?.comments ?? []).filter((item) => roots.has(item.parent ?? item.id) && (!item.deleted || !item.parent));
  const edited = state?.comments.find((item) => item.id === props.editing);
  const versions = [...history?.branches.map((branch) => ({ id: branch.head_revision, label: `${branch.name} \xB7 current saved state` })) ?? [], ...history?.versions.map((version) => ({ id: version.revision, label: version.name })) ?? []];
  return /* @__PURE__ */ jsxs("section", { className: "aui-studio-review-view", "aria-label": "Comments", children: [
    /* @__PURE__ */ jsx(
      ReviewFilterBar,
      {
        subject: "comments",
        query,
        onQueryChange: setQuery,
        groups: [
          { id: "status", label: "Status", value: filter, defaultValue: "all", onChange: setFilter, options: [{ value: "all", label: "All" }, { value: "open", label: "Open" }, { value: "resolved", label: "Resolved" }] },
          { id: "tag", label: "Tags", value: tag, defaultValue: "", onChange: setTag, options: [{ value: "", label: "All tags" }, ...tags.map((value) => ({ value, label: value }))] },
          { id: "workspace", label: "Workspace", value: scope, defaultValue: "*", onChange: setScope, options: [{ value: "*", label: "All workspaces" }, ...branches] }
        ],
        actions: [{ id: "follow", label: "Follow live comment updates", kind: "checkbox", checked: props.following, separatorBefore: true }],
        onAction: () => props.onFollowing(!props.following),
        onReset: () => {
          setFilter("all");
          setTag("");
          setScope("*");
        }
      }
    ),
    /* @__PURE__ */ jsx(PanelNotice, { message: props.error, children: props.conflict }),
    /* @__PURE__ */ jsxs("div", { className: "ps-review-stream", ref: stream, role: "log", "aria-label": "Design comments", children: [
      !state && /* @__PURE__ */ jsx("p", { role: "status", children: "Loading comments\u2026" }),
      state && !items.length && /* @__PURE__ */ jsx("p", { className: "ps-review-empty", children: "No comments in this view." }),
      items.map((item) => /* @__PURE__ */ jsxs("article", { className: `ps-review-message${item.parent ? " ps-review-message-reply" : ""}`, "aria-label": `Comment by ${person(item.author)?.name ?? "Former member"}`, children: [
        /* @__PURE__ */ jsx("span", { className: "ps-review-avatar", children: /* @__PURE__ */ jsx(Avatar, { name: person(item.author)?.name ?? "Former member", src: person(item.author)?.avatar }) }),
        /* @__PURE__ */ jsxs("div", { className: "ps-review-message-content", children: [
          /* @__PURE__ */ jsxs("div", { className: "ps-review-message-meta", children: [
            /* @__PURE__ */ jsxs("strong", { children: [
              item.source === "ai" ? "AI \xB7 " : "",
              item.author === state?.actor ? "You" : person(item.author)?.name ?? "Former member"
            ] }),
            /* @__PURE__ */ jsx("time", { dateTime: new Date(item.created * 1e3).toISOString(), title: new Date(item.created * 1e3).toLocaleString(), children: new Date(item.created * 1e3).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) }),
            !item.deleted && /* @__PURE__ */ jsx(MenuButton, { className: "ps-review-more", label: `Comment actions: ${item.text}`, disabled: busy, items: [
              { id: "reply", label: "Reply", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "comment" }) },
              ...!item.parent && allowed(item) ? [{ id: "resolve", label: item.resolved ? "Reopen discussion" : "Resolve discussion", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "check" }) }] : [],
              ...allowed(item) ? [{ id: "edit", label: "Edit comment", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "pencil" }) }, { id: "remove", label: "Remove comment", danger: true, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "delete" }) }] : []
            ], onSelect: (id) => {
              if (id === "reply") props.onReply(state.comments.find((root) => root.id === (item.parent ?? item.id)) ?? item);
              else if (id === "resolve") props.onResolve(item);
              else if (id === "edit") props.onEdit(item);
              else props.onRemove(item);
            }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
          ] }),
          item.resolved && /* @__PURE__ */ jsxs("span", { className: "ps-review-resolved", children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "check" }),
            "Resolved"
          ] }),
          /* @__PURE__ */ jsx("p", { children: item.deleted ? "Comment removed" : item.text }),
          !item.deleted && /* @__PURE__ */ jsxs(Fragment, { children: [
            !!tagsFor(item).length && /* @__PURE__ */ jsx("div", { className: "ps-review-item-tags", children: tagsFor(item).map((tag2) => /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => setTag(tag2), children: [
              /* @__PURE__ */ jsx(AetherIcon, { name: "tag" }),
              tag2
            ] }, tag2)) }),
            item.reference_name && /* @__PURE__ */ jsxs("small", { className: "ps-review-reference", children: [
              /* @__PURE__ */ jsx(AetherIcon, { name: "cube" }),
              item.reference_name
            ] }),
            item.attachments?.map((image, index) => /* @__PURE__ */ jsx("a", { className: "ps-review-image", href: image.data_url, download: image.name, children: /* @__PURE__ */ jsx("img", { src: image.data_url, alt: image.name }) }, index)),
            item.revision != null && /* @__PURE__ */ jsxs("div", { className: "ps-review-version", children: [
              /* @__PURE__ */ jsx("span", { children: /* @__PURE__ */ jsx(AetherIcon, { name: "cube" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs("strong", { children: [
                  connection.name,
                  " \xB7 ",
                  history?.versions.find((version) => version.revision === item.revision)?.name ?? `Saved state ${item.revision}`
                ] }),
                /* @__PURE__ */ jsxs("small", { children: [
                  item.branch ?? "Main",
                  " workspace"
                ] })
              ] })
            ] })
          ] })
        ] })
      ] }, item.id))
    ] }),
    /* @__PURE__ */ jsx(
      ReviewComposer,
      {
        task: false,
        value: props.text,
        onChange: props.onText,
        busy: busy || props.conflicted || !state,
        members: state?.members,
        versions,
        initialImages: edited?.attachments,
        initialRevision: edited?.revision,
        initialTags: edited?.tags ?? (tag ? [tag] : []),
        initialMentions: edited?.mentions,
        initialReference: !!edited?.reference_name,
        resetKey: `${connection.key}:${props.editing}:${props.reply}:${props.draftReset}`,
        context: tag ? /* @__PURE__ */ jsxs("button", { className: "ps-review-context-chip", type: "button", "aria-label": `Clear tag filter: ${tag}`, onClick: () => setTag(""), children: [
          /* @__PURE__ */ jsx(AetherIcon, { name: "tag" }),
          tag,
          /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
        ] }) : void 0,
        referenceLabel: "Reference document",
        selectedName: connection.name,
        reply: props.editing ? "Editing comment" : props.reply ? person(state?.comments.find((item) => item.id === props.reply)?.author ?? "")?.name ?? "discussion" : void 0,
        onCancelReply: props.onCancel,
        onCapture: commentScreenshot,
        onSubmit: (attachments, reference, revision, metadata) => props.onSubmit({ ...!props.editing ? { branch: props.reply ? state?.comments.find((item) => item.id === props.reply)?.branch_id ?? "Main" : connection.branch ?? "Main" } : {}, attachments, revision: revision ?? null, reference_name: reference ? edited?.reference_name ?? connection.name : "", ...metadata, tags: metadata.tags.length ? metadata.tags : tag ? [tag] : [] })
      }
    )
  ] });
}
export {
  StudioCommentsView
};
