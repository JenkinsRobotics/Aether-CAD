import { type FileManagerGroup, type FileManagerItem } from "./FileManagerPanel.js";
import type { DocumentConnection } from "./DocumentServices.js";
export interface DocumentFileManagerProps {
    connection: DocumentConnection;
    documentGroups?: readonly FileManagerGroup[];
    activeID?: string | null;
    onOpenItem?: (item: FileManagerItem) => void | Promise<void>;
    fileType?: (name: string) => string;
}
/** Shared library controller. The session owns transport/navigation; products
 * supply document contents and their selection behavior, never a second UI. */
export declare function DocumentFileManager({ connection, documentGroups, activeID, onOpenItem, fileType }: DocumentFileManagerProps): import("react").JSX.Element;
