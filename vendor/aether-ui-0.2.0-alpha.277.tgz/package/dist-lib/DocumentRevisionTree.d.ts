import { type DocumentHistory } from "./DocumentServices.js";
import { type HistoryMilestone } from "./document-history-graph.js";
import "./DocumentRevisionTree.css";
export type RevisionTreeAction = "save" | "version" | "branch" | "restore" | "release";
export interface RevisionTreeDraft {
    dirty: boolean;
    changed: boolean;
    sinceVersion?: string;
}
export interface DocumentRevisionTreeProps {
    history: DocumentHistory;
    /** Permanent branch key, never the mutable display label. */
    branch: string;
    selection: string;
    drafts?: Readonly<Record<string, RevisionTreeDraft>>;
    onBranchChange: (key: string) => void;
    onSelect: (row: HistoryMilestone) => void;
    /** Host owns authorization, flushing, concurrency, mutations and errors. */
    actions?: Partial<Record<RevisionTreeAction, {
        onInvoke: () => void;
        disabled?: boolean;
        reason?: string;
    }>>;
    busy?: boolean;
}
/** Compact, controlled PDM presentation of the existing history contract. */
export declare function DocumentRevisionTree({ history, branch, selection, drafts, onBranchChange, onSelect, actions, busy }: DocumentRevisionTreeProps): import("react").JSX.Element;
