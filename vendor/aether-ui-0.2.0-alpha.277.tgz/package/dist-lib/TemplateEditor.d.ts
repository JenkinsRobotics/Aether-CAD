import "./WorkflowWidgets.css";
export interface TemplateStep {
    id: string;
    title: string;
    description: string;
}
export interface TemplateEditorProps {
    stage: "import" | "structure";
    name: string;
    example: string;
    steps: readonly TemplateStep[];
    onNameChange: (value: string) => void;
    onExampleChange: (value: string) => void;
    onImport: () => void;
    onSave: () => void;
    onCancel: () => void;
}
export declare function TemplateEditor({ stage, name, example, steps, onNameChange, onExampleChange, onImport, onSave, onCancel }: TemplateEditorProps): import("react").JSX.Element;
