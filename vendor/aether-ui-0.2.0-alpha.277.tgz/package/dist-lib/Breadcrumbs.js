import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { MenuButton } from "./Menu.js";
function Breadcrumbs({
  items,
  onNavigate,
  ariaLabel = "Breadcrumbs",
  maxVisible = 5,
  className
}) {
  if (items.length === 0) return null;
  const visibleLimit = Math.max(3, maxVisible);
  const overflowCount = Math.max(0, items.length - visibleLimit);
  const first = items[0];
  const hidden = overflowCount > 0 ? items.slice(1, overflowCount + 1) : [];
  const visible = overflowCount > 0 ? [first, ...items.slice(overflowCount + 1)] : items;
  const overflowItems = hidden.map((item) => ({
    id: item.id,
    label: item.label,
    disabled: item.disabled,
    disabledReason: item.disabled ? "This location is unavailable." : void 0
  }));
  const classes = ["aui-breadcrumbs", className].filter(Boolean).join(" ");
  return /* @__PURE__ */ jsx("nav", { className: classes, "aria-label": ariaLabel, children: /* @__PURE__ */ jsx("ol", { children: visible.map((item, visibleIndex) => {
    const originalIndex = items.findIndex((candidate) => candidate.id === item.id);
    const current = originalIndex === items.length - 1;
    const insertOverflow = visibleIndex === 1 && hidden.length > 0;
    return /* @__PURE__ */ jsxs("li", { children: [
      insertOverflow ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("span", { className: "aui-breadcrumbs-separator", "aria-hidden": true, children: "/" }),
        /* @__PURE__ */ jsx(MenuButton, { label: "More locations", items: overflowItems, onSelect: onNavigate, placement: "bottom-start", children: "\u2026" })
      ] }) : null,
      visibleIndex > 0 ? /* @__PURE__ */ jsx("span", { className: "aui-breadcrumbs-separator", "aria-hidden": true, children: "/" }) : null,
      current ? /* @__PURE__ */ jsx("span", { className: "aui-breadcrumb-current", "aria-current": "page", children: item.label }) : /* @__PURE__ */ jsx("button", { type: "button", disabled: item.disabled, onClick: () => onNavigate(item.id), children: item.label })
    ] }, item.id);
  }) }) });
}
export {
  Breadcrumbs
};
