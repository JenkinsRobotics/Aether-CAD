export declare function InterfaceColorSettings(): import("react").JSX.Element;
