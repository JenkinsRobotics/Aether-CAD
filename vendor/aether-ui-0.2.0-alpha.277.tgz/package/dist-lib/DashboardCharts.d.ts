import "./DashboardCharts.css";
export interface DashboardChartPoint {
    id: string;
    label: string;
    value: number;
}
interface ChartProps {
    label: string;
    data: readonly DashboardChartPoint[];
    formatValue?: (n: number) => string;
    selectedID?: string;
    onSelect?: (id: string) => void;
}
export declare function DashboardLineChart({ label, data, formatValue, selectedID, onSelect, maximum, axisFormat }: ChartProps & {
    maximum?: number;
    axisFormat?: (n: number) => string;
}): import("react").JSX.Element;
export declare function DashboardBarChart({ label, data, formatValue, selectedID, onSelect, axisFormat }: ChartProps & {
    axisFormat?: (n: number) => string;
}): import("react").JSX.Element;
export {};
