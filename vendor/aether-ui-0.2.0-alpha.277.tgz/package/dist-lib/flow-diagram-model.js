const FLOW_TONES = ["green", "violet", "red", "neutral", "teal", "blue", "amber"];
const FLOW_SIDES = ["left", "right", "top", "bottom"];
const flowClamp = (value, min, max) => Math.max(min, Math.min(max, value));
function flowPortPoint(node, port) {
  const { x, y, width, height } = node;
  switch (port.side) {
    case "left":
      return { x, y: y + height * port.offset };
    case "right":
      return { x: x + width, y: y + height * port.offset };
    case "top":
      return { x: x + width * port.offset, y };
    case "bottom":
      return { x: x + width * port.offset, y: y + height };
  }
}
function flowEndpoint(document, endpoint) {
  const node = document.nodes.find((item) => item.id === endpoint.nodeId);
  const port = node?.ports.find((item) => item.id === endpoint.portId);
  return node && port ? { node, port, point: flowPortPoint(node, port) } : void 0;
}
function flowConnectionError(document, source, target, ignoreId) {
  const from = flowEndpoint(document, source), to = flowEndpoint(document, target);
  if (!from || !to) return "Choose existing connection points.";
  if (from.port.direction !== "output" || to.port.direction !== "input") return "Connect an output to an input.";
  if (source.nodeId === target.nodeId) return "Choose an input on another node.";
  if (document.connections.some((edge) => edge.id !== ignoreId && edge.source.nodeId === source.nodeId && edge.source.portId === source.portId && edge.target.nodeId === target.nodeId && edge.target.portId === target.portId)) return "These points are already connected.";
  return null;
}
function flowRoundedPath(points, radius = 18) {
  const distinct = points.filter((point, index) => index === 0 || point.x !== points[index - 1].x || point.y !== points[index - 1].y);
  if (distinct.length === 0) return "";
  let path = `M${distinct[0].x} ${distinct[0].y}`;
  for (let i = 1; i < distinct.length - 1; i++) {
    const a = distinct[i - 1], b = distinct[i], c = distinct[i + 1];
    const incoming = Math.hypot(b.x - a.x, b.y - a.y), outgoing = Math.hypot(c.x - b.x, c.y - b.y);
    const corner = Math.min(radius, incoming / 2, outgoing / 2);
    const p = { x: b.x + (a.x - b.x) * corner / incoming, y: b.y + (a.y - b.y) * corner / incoming };
    const q = { x: b.x + (c.x - b.x) * corner / outgoing, y: b.y + (c.y - b.y) * corner / outgoing };
    path += `L${p.x} ${p.y}Q${b.x} ${b.y} ${q.x} ${q.y}`;
  }
  const last = distinct[distinct.length - 1];
  return distinct.length > 1 ? `${path}L${last.x} ${last.y}` : path;
}
const normals = { left: { x: -1, y: 0 }, right: { x: 1, y: 0 }, top: { x: 0, y: -1 }, bottom: { x: 0, y: 1 } };
function flowConnectionPath(document, edge) {
  const from = flowEndpoint(document, edge.source), to = flowEndpoint(document, edge.target);
  if (!from || !to) return "";
  const a = from.point, b = to.point;
  if (edge.waypoints.length) return flowRoundedPath([a, ...edge.waypoints, b]);
  const n1 = from.node.kind === "source" && from.port.side === "left" ? normals.right : normals[from.port.side], n2 = normals[to.port.side];
  if (n1.x === 1 && n2.x === -1 && b.x - a.x > 60) {
    const diagonal = Math.min(Math.abs(b.y - a.y), (b.x - a.x) / 2);
    const bend = a.x + (b.x - a.x - diagonal) * 0.7;
    return flowRoundedPath([a, { x: bend, y: a.y }, { x: bend + diagonal, y: b.y }, b]);
  }
  const p = { x: a.x + n1.x * 24, y: a.y + n1.y * 24 }, q = { x: b.x + n2.x * 24, y: b.y + n2.y * 24 };
  const mid = n1.x ? [{ x: (p.x + q.x) / 2, y: p.y }, { x: (p.x + q.x) / 2, y: q.y }] : [{ x: p.x, y: (p.y + q.y) / 2 }, { x: q.x, y: (p.y + q.y) / 2 }];
  return flowRoundedPath([a, p, ...mid, q, b]);
}
function flowRoutes(document) {
  return document.connections.map((edge) => ({ id: edge.id, path: flowConnectionPath(document, edge), tone: edge.tone, dashed: edge.dashed, label: edge.label }));
}
function flowNodeBounds(document, node) {
  const roomX = document.width - node.width, roomY = document.height - node.height;
  const minX = Math.min(12, roomX / 2), minY = Math.min(28, roomY / 2);
  return { minX, maxX: Math.max(minX, roomX - 12), minY, maxY: Math.max(minY, roomY - 12) };
}
function flowMoveNode(document, id, point) {
  return { ...document, nodes: document.nodes.map((node) => {
    if (node.id !== id) return node;
    const bounds = flowNodeBounds(document, node);
    return { ...node, x: flowClamp(point.x, bounds.minX, bounds.maxX), y: flowClamp(point.y, bounds.minY, bounds.maxY) };
  }) };
}
function flowMovePort(document, nodeId, id, point) {
  return { ...document, nodes: document.nodes.map((node) => {
    if (node.id !== nodeId) return node;
    const distances = [Math.abs(point.x - node.x), Math.abs(point.x - node.x - node.width), Math.abs(point.y - node.y), Math.abs(point.y - node.y - node.height)];
    const side = FLOW_SIDES[distances.indexOf(Math.min(...distances))];
    const offset = flowClamp(side === "left" || side === "right" ? (point.y - node.y) / node.height : (point.x - node.x) / node.width, 0, 1);
    return { ...node, ports: node.ports.map((port) => port.id === id ? { ...port, side, offset } : port) };
  }) };
}
function flowDelete(document, selection) {
  if (selection.kind === "connection") return { ...document, connections: document.connections.filter((edge) => edge.id !== selection.id) };
  const nodeId = selection.kind === "node" ? selection.id : selection.nodeId;
  const removed = (end) => end.nodeId === nodeId && (selection.kind === "node" || end.portId === selection.id);
  return {
    ...document,
    nodes: selection.kind === "node" ? document.nodes.filter((node) => node.id !== nodeId) : document.nodes.map((node) => node.id === nodeId ? { ...node, ports: node.ports.filter((port) => port.id !== selection.id) } : node),
    connections: document.connections.filter((edge) => !removed(edge.source) && !removed(edge.target))
  };
}
function parseFlowDocument(text) {
  if (text.length > 1e6) throw new Error("Diagram files must be smaller than 1 MB.");
  const value = JSON.parse(text);
  const record = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
  const str = (v, max = 160) => typeof v === "string" && v.length <= max;
  const num = (v, min, max) => typeof v === "number" && Number.isFinite(v) && v >= min && v <= max;
  const fail = () => {
    throw new Error("Invalid flow diagram. Check nodes, ports and connection references.");
  };
  if (!record(value) || value.version !== 1 || !num(value.width, 400, 5e3) || !num(value.height, 300, 5e3) || !Array.isArray(value.nodes) || value.nodes.length > 100 || !Array.isArray(value.connections) || value.connections.length > 400) return fail();
  const ids = /* @__PURE__ */ new Set();
  for (const node of value.nodes) {
    if (!record(node) || !str(node.id) || !node.id || ids.has(node.id) || !str(node.label) || !str(node.detail) || !str(node.notes, 4e3) || !["source", "module", "gate", "processor"].includes(node.kind) || !FLOW_TONES.includes(node.tone) || !num(node.width, 16, value.width) || !num(node.height, 20, value.height) || !num(node.x, 0, value.width - node.width) || !num(node.y, 0, value.height - node.height) || !Array.isArray(node.ports) || node.ports.length > 40) return fail();
    ids.add(node.id);
    if (node.kind === "processor" && (node.width < 120 || node.height < 96)) return fail();
    const ports = /* @__PURE__ */ new Set();
    for (const port of node.ports) {
      if (!record(port) || !str(port.id) || !port.id || ports.has(port.id) || !str(port.label) || !FLOW_SIDES.includes(port.side) || !num(port.offset, 0, 1) || !["input", "output"].includes(port.direction)) return fail();
      ports.add(port.id);
    }
  }
  ids.clear();
  const document = value;
  for (const edge of value.connections) {
    if (!record(edge) || !str(edge.id) || !edge.id || ids.has(edge.id) || !str(edge.label) || !str(edge.notes, 4e3) || !FLOW_TONES.includes(edge.tone) || typeof edge.dashed !== "boolean" || !record(edge.source) || !record(edge.target) || !str(edge.source.nodeId) || !str(edge.source.portId) || !str(edge.target.nodeId) || !str(edge.target.portId) || !Array.isArray(edge.waypoints) || edge.waypoints.length > 20) return fail();
    if (edge.waypoints.some((p) => !record(p) || !num(p.x, 0, value.width) || !num(p.y, 0, value.height))) return fail();
    ids.add(edge.id);
  }
  for (const edge of document.connections) if (flowConnectionError(document, edge.source, edge.target, edge.id)) return fail();
  return document;
}
export {
  FLOW_SIDES,
  FLOW_TONES,
  flowClamp,
  flowConnectionError,
  flowConnectionPath,
  flowDelete,
  flowEndpoint,
  flowMoveNode,
  flowMovePort,
  flowNodeBounds,
  flowPortPoint,
  flowRoundedPath,
  flowRoutes,
  parseFlowDocument
};
