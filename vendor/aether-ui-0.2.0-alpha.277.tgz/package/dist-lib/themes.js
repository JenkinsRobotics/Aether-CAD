import packagedAssets0 from "@aether/assets/catalogs/28b1cf0e1f9aba";
import packagedAssets1 from "@aether/assets/catalogs/fc43ab973bc0db";
const DEFAULT_THEME_ID = "aether-default";
const themeFiles = packagedAssets0;
const viewportFiles = packagedAssets1;
const byID = (files) => Object.fromEntries(Object.values(files).map((m) => [m.id, m]));
const manifests = byID(themeFiles);
const merge = (a, b) => ({ ...a ?? {}, ...b ?? {} });
function resolveTheme(manifest, registry = manifests, seen = []) {
  if (seen.includes(manifest.id)) throw new Error(`theme ${manifest.id} extends itself`);
  const baseID = manifest.id === DEFAULT_THEME_ID ? null : manifest.extends ?? DEFAULT_THEME_ID;
  const base = baseID ? resolveTheme(registry[baseID] ?? manifests[baseID], registry, [...seen, manifest.id]) : null;
  return {
    id: manifest.id,
    name: manifest.name,
    description: manifest.description ?? "",
    aliases: manifest.aliases ?? [],
    modes: { dark: merge(base?.modes.dark, manifest.modes?.dark), light: merge(base?.modes.light, manifest.modes?.light) },
    geometry: merge(base?.geometry, manifest.geometry),
    font: merge(base?.font, manifest.font),
    effects: merge(base?.effects, manifest.effects),
    touch: merge(base?.touch, manifest.touch)
  };
}
const aetherThemes = [manifests[DEFAULT_THEME_ID], ...Object.values(manifests).filter((m) => m.id !== DEFAULT_THEME_ID).sort((a, b) => a.name.localeCompare(b.name))].map((m) => resolveTheme(m));
const aetherViewportThemes = Object.values(byID(viewportFiles)).sort((a, b) => a.name.localeCompare(b.name)).map((m) => ({ id: m.id, name: m.name, description: m.description ?? "", aliases: [], modes: { dark: m.modes?.dark ?? {}, light: m.modes?.light ?? {} }, geometry: {}, font: {}, effects: {}, touch: {} }));
const aetherTheme = (id) => aetherThemes.find((t) => t.id === id);
function themeCSS(theme, className = `.aether-theme-${theme.id}`) {
  const vars = (tokens) => Object.entries(tokens).map(([name, value]) => `  --aether-${name}: ${value};`).join("\n");
  const classes = [className, ...theme.aliases];
  const dark = `  color-scheme: dark;
${vars(theme.modes.dark)}`;
  return `${classes.join(",\n")} {
${dark}

${vars(theme.geometry)}

${vars(theme.font)}

${vars(theme.effects)}
}
${classes.flatMap((c) => [`${c}.aether-light-theme`, `.aether-light-theme ${c}`]).join(",\n")} {
  color-scheme: light;
${vars(theme.modes.light)}
}
${classes.flatMap((c) => [`${c}.aether-dark-theme`, `.aether-dark-theme ${c}`]).join(",\n")} {
${dark}
}
`;
}
export {
  DEFAULT_THEME_ID,
  aetherTheme,
  aetherThemes,
  aetherViewportThemes,
  resolveTheme,
  themeCSS
};
