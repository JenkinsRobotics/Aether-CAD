import { jsx, jsxs } from "react/jsx-runtime";
import { useLayoutEffect, useRef, useState } from "react";
import { PanelResizeHandle } from "./PanelResizeHandle.js";
import { AetherIcon } from "./AetherIcon.js";
import "./TreePanelSplit.css";
const bounded = (ratio) => Math.max(0.2, Math.min(0.8, ratio));
function TreePanelSplit({ primary, secondary, primaryLabel, secondaryLabel, defaultRatio = 0.65, storageKey, collapsible = [], defaultCollapsed = [] }) {
  const root = useRef(null);
  const [height, setHeight] = useState(600);
  useLayoutEffect(() => {
    const element = root.current;
    if (!element) return;
    const measure = () => {
      const size = element.getBoundingClientRect().height - 6;
      if (size > 0) setHeight(size);
    };
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  const initial = Number.isFinite(defaultRatio) ? bounded(defaultRatio) : 0.65;
  const [ratio, setRatio] = useState(() => {
    try {
      const saved = storageKey && localStorage.getItem(storageKey);
      return saved && Number.isFinite(Number(saved)) ? bounded(Number(saved)) : initial;
    } catch {
      return initial;
    }
  });
  const update = (value) => {
    const next = bounded(value);
    setRatio(next);
    try {
      if (storageKey) localStorage.setItem(storageKey, String(next));
    } catch {
    }
  };
  const [collapsed, setCollapsed] = useState(() => {
    try {
      const saved = storageKey && localStorage.getItem(`${storageKey}.collapsed`);
      return saved ? JSON.parse(saved) : defaultCollapsed;
    } catch {
      return defaultCollapsed;
    }
  });
  const toggle = (part) => {
    const next = collapsed.includes(part) ? collapsed.filter((p) => p !== part) : [...collapsed, part];
    setCollapsed(next);
    try {
      if (storageKey) localStorage.setItem(`${storageKey}.collapsed`, JSON.stringify(next));
    } catch {
    }
  };
  const closedPrimary = collapsible.includes("primary") && collapsed.includes("primary");
  const closedSecondary = collapsible.includes("secondary") && collapsed.includes("secondary");
  const rows = closedPrimary && closedSecondary ? "auto 0 auto" : closedPrimary ? "auto 0 minmax(0, 1fr)" : closedSecondary ? "minmax(0, 1fr) 0 auto" : `minmax(0, ${ratio}fr) 6px minmax(0, ${1 - ratio}fr)`;
  const section = (part, label, content, closed) => /* @__PURE__ */ jsxs("section", { className: `aui-tree-panel-split-section${closed ? " is-collapsed" : ""}`, "aria-label": label, "data-collapsible": collapsible.includes(part) || void 0, children: [
    collapsible.includes(part) && /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        className: "aui-tree-panel-split-toggle",
        "aria-expanded": !closed,
        "aria-label": `${closed ? "Expand" : "Collapse"} ${label}`,
        title: `${closed ? "Expand" : "Collapse"} ${label}`,
        onClick: () => toggle(part),
        children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: closed ? void 0 : "rotate(90deg)" } })
      }
    ),
    content
  ] });
  return /* @__PURE__ */ jsxs("div", { ref: root, className: `aui-tree-panel-split${closedPrimary && closedSecondary ? " is-all-collapsed" : ""}`, style: { gridTemplateRows: rows }, children: [
    section("primary", primaryLabel, primary, closedPrimary),
    /* @__PURE__ */ jsx("div", { className: "aui-tree-panel-split-divider", hidden: closedPrimary || closedSecondary, children: /* @__PURE__ */ jsx(
      PanelResizeHandle,
      {
        edge: "bottom",
        label: `Resize ${primaryLabel} and ${secondaryLabel}`,
        value: height * ratio,
        min: height * 0.2,
        max: height * 0.8,
        onChange: (size) => update(size / height),
        onReset: () => update(initial)
      }
    ) }),
    section("secondary", secondaryLabel, secondary, closedSecondary)
  ] });
}
export {
  TreePanelSplit
};
