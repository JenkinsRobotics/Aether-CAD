import { jsx, jsxs } from "react/jsx-runtime";
import { useRef } from "react";
import { AetherIcon } from "./AetherIcon.js";
function BottomPanel({
  tabs,
  activeID,
  onSelect,
  collapsed = false,
  onCollapsedChange,
  actions,
  ariaLabel = "Bottom panel"
}) {
  const refs = useRef(/* @__PURE__ */ new Map());
  const active = tabs.find((tab) => tab.id === activeID) ?? tabs[0];
  const move = (event, index) => {
    let next;
    if (event.key === "ArrowRight") next = (index + 1) % tabs.length;
    else if (event.key === "ArrowLeft") next = (index - 1 + tabs.length) % tabs.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = tabs.length - 1;
    else return;
    event.preventDefault();
    onSelect(tabs[next].id);
    refs.current.get(tabs[next].id)?.focus();
  };
  if (!active) return null;
  return /* @__PURE__ */ jsxs("section", { className: `aui-bottom-panel${collapsed ? " aui-bottom-panel--collapsed" : ""}`, "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-bottom-panel-header", onDoubleClick: () => onCollapsedChange?.(!collapsed), children: [
      /* @__PURE__ */ jsx("div", { className: "aui-bottom-panel-tabs", role: "tablist", "aria-label": `${ariaLabel} tabs`, children: tabs.map((tab, index) => /* @__PURE__ */ jsxs(
        "button",
        {
          ref: (element) => {
            if (element) refs.current.set(tab.id, element);
            else refs.current.delete(tab.id);
          },
          id: `aui-bottom-tab-${tab.id}`,
          type: "button",
          role: "tab",
          "aria-selected": tab.id === active.id,
          "aria-controls": `aui-bottom-panel-${tab.id}`,
          tabIndex: tab.id === active.id ? 0 : -1,
          onClick: () => {
            onSelect(tab.id);
            if (collapsed) onCollapsedChange?.(false);
          },
          onKeyDown: (event) => move(event, index),
          children: [
            tab.icon ? /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: tab.icon }) : null,
            tab.label,
            tab.badge !== void 0 ? /* @__PURE__ */ jsx("small", { children: tab.badge }) : null
          ]
        },
        tab.id
      )) }),
      /* @__PURE__ */ jsxs("div", { className: "aui-bottom-panel-actions", children: [
        actions,
        /* @__PURE__ */ jsx("button", { type: "button", "aria-label": collapsed ? "Expand bottom panel" : "Collapse bottom panel", onClick: () => onCollapsedChange?.(!collapsed), children: /* @__PURE__ */ jsx(AetherIcon, { name: collapsed ? "chevron-up" : "chevron-down" }) })
      ] })
    ] }),
    !collapsed ? /* @__PURE__ */ jsx("div", { className: "aui-bottom-panel-content", id: `aui-bottom-panel-${active.id}`, role: "tabpanel", "aria-labelledby": `aui-bottom-tab-${active.id}`, children: active.content }) : null
  ] });
}
export {
  BottomPanel
};
