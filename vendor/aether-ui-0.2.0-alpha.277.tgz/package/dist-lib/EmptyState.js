import { jsx, jsxs } from "react/jsx-runtime";
function EmptyState({
  title,
  description,
  icon,
  primaryAction,
  secondaryAction,
  compact,
  className
}) {
  const classes = ["aui-state", "aui-empty-state"];
  if (compact) classes.push("aui-state--compact");
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs("section", { className: classes.join(" "), "aria-label": typeof title === "string" ? title : void 0, children: [
    icon ? /* @__PURE__ */ jsx("div", { className: "aui-state-icon", "aria-hidden": true, children: icon }) : null,
    /* @__PURE__ */ jsx("strong", { children: title }),
    description ? /* @__PURE__ */ jsx("p", { children: description }) : null,
    primaryAction || secondaryAction ? /* @__PURE__ */ jsxs("div", { className: "aui-state-actions", children: [
      primaryAction,
      secondaryAction
    ] }) : null
  ] });
}
export {
  EmptyState
};
