import { jsx } from "react/jsx-runtime";
import { createPortal } from "react-dom";
import { Button } from "./Button.js";
import { EmptyState } from "./EmptyState.js";
import { Dialog } from "./Dialog.js";
import { useOverlayHost } from "./OverlayScope.js";
import { DocumentVersionPanel } from "./DocumentVersionPanel.js";
import { DOCUMENT_HISTORY_CHANGED } from "./DocumentServices.js";
function DocumentCreateDialog({ connection, onClose, mode = "version", sourceRevision, sourceName }) {
  const host = useOverlayHost();
  return createPortal(/* @__PURE__ */ jsx("div", { className: "aui-version-dialog", children: /* @__PURE__ */ jsx(Dialog, { open: true, title: `Create ${mode} from ${sourceName ?? connection?.branchLabel ?? (connection?.branch?.startsWith("branch-") ? "current workspace" : connection?.branch) ?? "Main"}`, onClose, actions: !connection && /* @__PURE__ */ jsx(Button, { onClick: onClose, children: "Cancel" }), children: connection ? /* @__PURE__ */ jsx(DocumentVersionPanel, { connection, createOnly: true, branchOnly: mode === "branch", branchSource: sourceRevision, onCancel: onClose, onCreated: () => {
    window.dispatchEvent(new CustomEvent(DOCUMENT_HISTORY_CHANGED, { detail: connection.key }));
    onClose();
  } }) : /* @__PURE__ */ jsx(EmptyState, { compact: true, title: "No document connected", description: "Open a saved document to create a version or branch." }) }) }), host ?? document.body);
}
export {
  DocumentCreateDialog
};
