import { type ReactNode } from 'react';
import './ApplicationSplash.css';
export type SplashPhase = 'pending' | 'running' | 'done' | 'failed';
export interface SplashStage {
    id: string;
    title: string;
    detail?: string;
    phase: SplashPhase;
}
export interface ApplicationSplashProps {
    appName: string;
    tagline?: string;
    version?: string;
    artworkUrl?: string;
    headline: string;
    detail?: string;
    /** Actual startup fraction 0–1. Omit when progress cannot be measured. */
    progress?: number;
    state?: 'loading' | 'ready' | 'offline' | 'error';
    stages?: readonly SplashStage[];
    footnote?: string;
    /** Product-owned actions, such as retry or continue offline. */
    actions?: ReactNode;
}
/** Presentation only: the owning application reports real startup state and decides when to dismiss. */
export declare function ApplicationSplash({ appName, tagline, version, artworkUrl, headline, detail, progress, state, stages, footnote, actions }: ApplicationSplashProps): import("react").JSX.Element;
