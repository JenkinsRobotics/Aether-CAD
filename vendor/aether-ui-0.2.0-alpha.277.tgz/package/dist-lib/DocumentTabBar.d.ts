import { type ReactNode, type HTMLAttributes } from "react";
import { type DocumentTab, type DocumentTabsProps } from "./DocumentTabs.js";
import { type MenuItem } from "./Menu.js";
import "./DocumentTabBar.css";
export interface DocumentElementTab extends DocumentTab {
    id: string;
    label: string;
    icon?: ReactNode;
    /** Kind of element, displayed as a second line in the studio variant. */
    detail?: string;
    disabled?: boolean;
    current?: boolean;
    onSelect?: () => void;
    /** Makes the tab closable (open-file tabs). */
    onClose?: () => void;
}
/**
 * A document's tab row with an add control: the shared DocumentTabs strip plus
 * "+". Along the bottom (Onshape) or in the top bar (Fusion). Presentational —
 * the app supplies the tabs and decides what adding and opening mean.
 */
export declare function DocumentTabBar({ tabs, addItems, onAdd, onAddClick, addLabel, addDisabledReason, ariaLabel, placement, variant, onOverview, overviewLabel, trailing, className, containerProps, renderTabActions, renderTabs }: {
    tabs: readonly DocumentElementTab[];
    /** Choices for the "+" menu; omit to hide it. */
    addItems?: readonly MenuItem[];
    onAdd?: (id: string) => void;
    /** A plain "+" button instead of a menu, e.g. to open a creation dialog. */
    onAddClick?: () => void;
    addLabel?: string;
    /** When set, "+" is shown disabled with this explanation. */
    addDisabledReason?: string;
    ariaLabel?: string;
    /** "header": tabs along the top bar (Fusion), "+" after the tabs. */
    placement?: "bottom" | "header";
    /** Opt-in dark, full-width thumbnail row; always uses the bottom layout. */
    variant?: "standard" | "studio";
    /** Studio variant's trailing document browser action. */
    onOverview?: () => void;
    overviewLabel?: string;
    /** App-owned document/folder actions, fixed at the right while tabs overflow. */
    trailing?: ReactNode;
    className?: string;
    /** Events for product-owned drag, detach and context actions. */
    containerProps?: Omit<HTMLAttributes<HTMLDivElement>, "children" | "className">;
    renderTabActions?: DocumentTabsProps["renderTabActions"];
    /** Optional grouped presentation; receives the same adaptive tab budget. */
    renderTabs?: (props: DocumentTabsProps) => ReactNode;
}): import("react").JSX.Element;
