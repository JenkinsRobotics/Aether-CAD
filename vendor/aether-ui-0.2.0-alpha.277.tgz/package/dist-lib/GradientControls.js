import { jsx, jsxs } from "react/jsx-runtime";
import { Button } from "./Button.js";
import { ColorField } from "./ColorField.js";
import { FieldRow } from "./FieldRow.js";
import { NumberField } from "./NumberField.js";
import "./GradientControls.css";
function GradientControls({ value, onChange, disabled }) {
  const stops = (next) => onChange({ ...value, stops: next });
  return /* @__PURE__ */ jsxs("fieldset", { className: "aui-gradient-controls", disabled, children: [
    /* @__PURE__ */ jsx("legend", { children: "Gradient" }),
    value.kind === "linear" && /* @__PURE__ */ jsx(FieldRow, { label: "Angle", children: /* @__PURE__ */ jsx(NumberField, { disabled, "aria-label": "Gradient angle", value: value.angleDeg, min: -360, max: 360, unit: "\xB0", onCommit: (angleDeg) => onChange({ ...value, angleDeg }) }) }),
    value.stops.map((stop, index) => /* @__PURE__ */ jsxs("fieldset", { className: "aui-gradient-stop", children: [
      /* @__PURE__ */ jsxs("legend", { children: [
        "Stop ",
        index + 1
      ] }),
      /* @__PURE__ */ jsx(ColorField, { disabled, ariaLabel: `Stop ${index + 1} color`, value: stop.color, onChange: (color) => stops(value.stops.map((s, i) => i === index ? { ...s, color } : s)) }),
      /* @__PURE__ */ jsx(FieldRow, { label: "Position", children: /* @__PURE__ */ jsx(NumberField, { disabled, "aria-label": `Stop ${index + 1} position`, value: stop.offset * 100, min: 0, max: 100, unit: "%", onCommit: (offset) => stops(value.stops.map((s, i) => i === index ? { ...s, offset: offset / 100 } : s).sort((a, b) => a.offset - b.offset)) }) }),
      /* @__PURE__ */ jsx(FieldRow, { label: "Opacity", children: /* @__PURE__ */ jsx(NumberField, { disabled, "aria-label": `Stop ${index + 1} opacity`, value: stop.opacity * 100, min: 0, max: 100, unit: "%", onCommit: (opacity) => stops(value.stops.map((s, i) => i === index ? { ...s, opacity: opacity / 100 } : s)) }) }),
      /* @__PURE__ */ jsxs(Button, { disabled: disabled || value.stops.length <= 2, onClick: () => stops(value.stops.filter((_, i) => i !== index)), children: [
        "Remove stop ",
        index + 1
      ] })
    ] }, index)),
    /* @__PURE__ */ jsx(Button, { disabled: disabled || value.stops.length >= 16, onClick: () => stops([...value.stops, { offset: 0.5, color: value.stops[0].color, opacity: 1 }].sort((a, b) => a.offset - b.offset)), children: "Add gradient stop" })
  ] });
}
export {
  GradientControls
};
