import { jsx, jsxs } from "react/jsx-runtime";
import { useLayoutEffect, useRef, useState } from "react";
import { visibleParents } from "./document-history-view.js";
const laneX = (lane) => 10 + lane * 16;
const laneColor = (lane) => ["var(--aether-color-accent-icon)", "var(--aether-color-text)", "var(--aether-color-ok)", "var(--aether-color-warn)"][Math.abs(lane) % 4];
function VersionControlGraph({ entries, visible, selected, children, linear = false }) {
  const content = useRef(null);
  const [positions, setPositions] = useState({});
  const lanes = [...new Set(visible.map((entry) => entry.lane))].sort((a, b) => a - b);
  const xFor = (lane) => laneX(linear ? 0 : Math.max(0, lanes.indexOf(lane)));
  const width = linear ? 20 : 22 + Math.max(0, lanes.length - 1) * 16;
  useLayoutEffect(() => {
    const root = content.current;
    if (!root) return;
    const rows = [...root.querySelectorAll("[data-entry-id]")];
    const measure = () => {
      const top = root.getBoundingClientRect().top;
      const next = {};
      for (const row of rows) {
        const head = row.querySelector(".aui-vc-entry-head");
        const rect = head.getBoundingClientRect();
        next[row.dataset.entryId] = rect.top + rect.height / 2 - top;
      }
      setPositions((previous) => JSON.stringify(previous) === JSON.stringify(next) ? previous : next);
    };
    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(root);
    rows.forEach((row) => observer?.observe(row));
    window.addEventListener("resize", measure);
    return () => {
      observer?.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [visible, selected]);
  const byID = new Map(visible.map((entry) => [entry.id, entry]));
  return /* @__PURE__ */ jsxs("div", { ref: content, className: "aui-vc-graph", "data-linear": linear, role: "list", "aria-label": "Versions", style: { paddingLeft: width }, children: [
    /* @__PURE__ */ jsxs("svg", { className: "aui-vc-graph-links", width, height: "100%", role: "img", "aria-label": linear ? "Branch version timeline" : "Branch and merge graph", children: [
      /* @__PURE__ */ jsx("title", { children: "Version ancestry \u2014 separate branch lanes, solid parent links and dashed merge links" }),
      visible.flatMap((entry) => {
        const primary = new Set(visibleParents(entry, entries, visible, false));
        return visibleParents(entry, entries, visible, !linear).map((id) => {
          const parent = byID.get(id);
          const y = positions[entry.id], py = positions[id];
          if (y == null || py == null) return null;
          const x = xFor(entry.lane), px = xFor(parent.lane);
          const direction = Math.sign(py - y), bend = Math.min(12, Math.abs(py - y) / 2);
          const path = x === px ? `M ${x} ${y} L ${px} ${py}` : `M ${x} ${y} L ${x} ${py - direction * bend} Q ${x} ${py} ${(x + px) / 2} ${py} L ${px} ${py}`;
          const merge = !primary.has(id);
          return /* @__PURE__ */ jsx(
            "path",
            {
              "data-from": entry.id,
              "data-to": id,
              "data-merge": merge,
              stroke: laneColor(merge ? parent.lane : entry.lane),
              d: path,
              children: /* @__PURE__ */ jsxs("title", { children: [
                entry.name,
                " \u2192 ",
                parent.name,
                merge ? " (merge)" : ""
              ] })
            },
            `${entry.id}:${id}`
          );
        });
      }),
      visible.map((entry) => positions[entry.id] == null ? null : /* @__PURE__ */ jsx(
        "circle",
        {
          "data-node": entry.id,
          "data-lane": entry.lane,
          "data-selected": selected === entry.id,
          cx: xFor(entry.lane),
          cy: positions[entry.id],
          r: selected === entry.id ? 5 : 4,
          stroke: laneColor(entry.lane),
          style: { color: laneColor(entry.lane) },
          children: /* @__PURE__ */ jsxs("title", { children: [
            entry.name,
            " \xB7 ",
            entry.branch
          ] })
        },
        entry.id
      ))
    ] }),
    children
  ] });
}
export {
  VersionControlGraph
};
