import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import "./LinkCard.css";
function LinkCard({ icon, title, description, action, href, external = false, onSelect, className }) {
  const body = /* @__PURE__ */ jsxs(Fragment, { children: [
    icon && /* @__PURE__ */ jsx("span", { className: "aui-link-card-icon", "aria-hidden": "true", children: icon }),
    /* @__PURE__ */ jsx("strong", { className: "aui-link-card-title", children: title }),
    description && /* @__PURE__ */ jsx("span", { className: "aui-link-card-description", children: description }),
    action && /* @__PURE__ */ jsxs("small", { className: "aui-link-card-action", children: [
      action,
      external && /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: " \u2197" })
    ] })
  ] });
  const classes = `aui-link-card${icon ? "" : " aui-link-card--no-icon"}${className ? ` ${className}` : ""}`;
  return href ? /* @__PURE__ */ jsx("a", { className: classes, href, onClick: onSelect, ...external ? { target: "_blank", rel: "noopener noreferrer" } : {}, children: body }) : /* @__PURE__ */ jsx("button", { type: "button", className: classes, onClick: onSelect, children: body });
}
function LinkCardGrid({ children, ariaLabel }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-link-card-grid", "aria-label": ariaLabel, children });
}
export {
  LinkCard,
  LinkCardGrid
};
