import { jsx, jsxs } from "react/jsx-runtime";
import { createPortal } from "react-dom";
import { useEffect, useId, useMemo, useRef, useState } from "react";
import { fuzzyScore } from "./command-matching.js";
import { AetherIcon } from "./AetherIcon.js";
import { useOverlayHost } from "./OverlayScope.js";
import { useOverlayPosition } from "./overlay-position.js";
import "./CommandSearch.css";
function CommandSearch({
  commands,
  onSelect,
  ariaLabel = "Search commands, tools, or help",
  placeholder = "Search commands, tools, or help\u2026",
  className = "",
  registerShortcut = false
}) {
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [activeID, setActiveID] = useState(null);
  const field = useRef(null);
  const input = useRef(null);
  const list = useRef(null);
  const listID = useId();
  const overlayHost = useOverlayHost();
  const results = useMemo(() => commands.map((command, index) => ({ command, index, score: fuzzyScore(command, query) })).filter((item) => item.score !== null).sort((a, b) => b.score - a.score || a.index - b.index).slice(0, 12).map((item) => item.command), [commands, query]);
  const enabled = results.filter((command) => !command.disabled);
  const active = enabled.find((command) => command.id === activeID) ?? enabled[0];
  const open = expanded && !!query.trim();
  const position = useOverlayPosition({ open, overlayRef: list, anchor: field.current, respectToolbarBoundary: false });
  useEffect(() => {
    if (!registerShortcut) return;
    const focus = (event) => {
      if (event.defaultPrevented || !(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== "k") return;
      if (event.target instanceof Element && event.target.closest('[role="dialog"], [role="menu"]')) return;
      event.preventDefault();
      input.current?.focus();
      input.current?.select();
    };
    document.addEventListener("keydown", focus);
    return () => document.removeEventListener("keydown", focus);
  }, [registerShortcut]);
  useEffect(() => {
    if (!open) return;
    const dismiss = (event) => {
      if (!field.current?.contains(event.target) && !list.current?.contains(event.target)) setExpanded(false);
    };
    document.addEventListener("pointerdown", dismiss, true);
    return () => document.removeEventListener("pointerdown", dismiss, true);
  }, [open]);
  useEffect(() => {
    if (open && active) document.getElementById(`${listID}-${active.id}`)?.scrollIntoView?.({ block: "nearest" });
  }, [open, active?.id, listID]);
  const choose = (command) => {
    const current = commands.find((item) => item.id === command.id);
    if (!current || current.disabled) return;
    setExpanded(false);
    setQuery("");
    setActiveID(null);
    input.current?.blur();
    onSelect(current.id);
  };
  return /* @__PURE__ */ jsxs("div", { ref: field, className: `aui-command-search ${className}`, children: [
    /* @__PURE__ */ jsx(AetherIcon, { name: "search", "aria-hidden": "true" }),
    /* @__PURE__ */ jsx(
      "input",
      {
        ref: input,
        type: "search",
        role: "combobox",
        "aria-label": ariaLabel,
        placeholder,
        autoComplete: "off",
        spellCheck: false,
        "aria-autocomplete": "list",
        "aria-expanded": open,
        "aria-controls": open ? listID : void 0,
        "aria-activedescendant": open && active ? `${listID}-${active.id}` : void 0,
        value: query,
        onFocus: () => setExpanded(true),
        onBlur: () => setExpanded(false),
        onChange: (event) => {
          setQuery(event.target.value);
          setActiveID(null);
          setExpanded(true);
        },
        onKeyDown: (event) => {
          if (event.nativeEvent.isComposing) return;
          if (event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            setExpanded(false);
            return;
          }
          if ((event.key === "ArrowDown" || event.key === "ArrowUp") && query.trim()) {
            event.preventDefault();
            event.stopPropagation();
            setExpanded(true);
            if (enabled.length) {
              const index = enabled.findIndex((command) => command.id === active?.id);
              setActiveID(enabled[(index + (event.key === "ArrowDown" ? 1 : -1) + enabled.length) % enabled.length].id);
            }
          } else if (event.key === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            if (open && active) choose(active);
          } else if (event.key === "Tab") setExpanded(false);
        }
      }
    ),
    query ? /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Clear command search", onClick: () => {
      setQuery("");
      setActiveID(null);
      input.current?.focus();
    }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) }) : /* @__PURE__ */ jsx("kbd", { children: "\u2318 K" }),
    open && createPortal(/* @__PURE__ */ jsx(
      "div",
      {
        ref: list,
        id: listID,
        className: "aui-command-search-results",
        role: "listbox",
        "aria-label": "Matching commands",
        style: { ...position, width: field.current?.getBoundingClientRect().width },
        children: results.length ? results.map((command) => /* @__PURE__ */ jsxs(
          "button",
          {
            id: `${listID}-${command.id}`,
            type: "button",
            role: "option",
            tabIndex: -1,
            "aria-selected": active?.id === command.id,
            "aria-disabled": command.disabled || void 0,
            title: command.disabled ? command.disabledReason : command.description,
            onPointerDown: (event) => event.preventDefault(),
            onPointerMove: () => {
              if (!command.disabled) setActiveID(command.id);
            },
            onClick: () => choose(command),
            children: [
              /* @__PURE__ */ jsx("span", { className: "aui-command-search-icon", "aria-hidden": "true", children: command.icon }),
              /* @__PURE__ */ jsxs("span", { className: "aui-command-search-copy", children: [
                /* @__PURE__ */ jsx("strong", { children: command.label }),
                /* @__PURE__ */ jsx("small", { children: command.disabled ? command.disabledReason : command.category })
              ] }),
              command.shortcut && /* @__PURE__ */ jsx("kbd", { children: command.shortcut })
            ]
          },
          command.id
        )) : /* @__PURE__ */ jsx("div", { className: "aui-command-search-empty", role: "status", children: "No matching commands" })
      }
    ), overlayHost ?? document.body)
  ] });
}
export {
  CommandSearch
};
