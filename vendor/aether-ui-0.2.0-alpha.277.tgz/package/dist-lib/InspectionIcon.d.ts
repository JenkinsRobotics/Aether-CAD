declare const icons: {
    measure: string;
    section: string;
    interference: string;
};
/** Original Aether inspection artwork, stored in the shared asset package. */
export declare function InspectionIcon({ kind }: {
    kind: keyof typeof icons;
}): import("react").JSX.Element;
export {};
