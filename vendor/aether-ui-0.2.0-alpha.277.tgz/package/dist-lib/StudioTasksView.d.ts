import type { ActionItemsViewProps } from "./ActionItemsView.js";
import "./StudioReview.css";
/** Shared task cards use the same authenticated, revision-guarded store as comments. */
export declare function StudioTasksView(props: ActionItemsViewProps): import("react").JSX.Element;
