import { jsx, jsxs } from "react/jsx-runtime";
import connectorArt from "@aether/assets/electronics/connector-housing.svg";
import "./HarnessWidgets.css";
function HarnessConnectorCard({
  title,
  pins,
  selected,
  activePin,
  onPin,
  onSelect,
  portSide = "right"
}) {
  return /* @__PURE__ */ jsxs("g", { className: "aui-harness-card", "data-selected": selected || void 0, children: [
    /* @__PURE__ */ jsx(
      "rect",
      {
        width: "180",
        height: 32 + pins.length * 32,
        rx: "9",
        className: "aui-harness-card-body"
      }
    ),
    /* @__PURE__ */ jsx(
      "path",
      {
        d: "M9 0H171Q180 0 180 9V32H0V9Q0 0 9 0",
        className: "aui-harness-card-head"
      }
    ),
    /* @__PURE__ */ jsxs(
      "g",
      {
        role: "button",
        tabIndex: 0,
        "aria-label": `Select ${title}`,
        onClick: onSelect,
        onKeyDown: (e) => {
          if (e.key === "Enter") onSelect?.();
        },
        children: [
          /* @__PURE__ */ jsx("rect", { width: "180", height: "32", fill: "transparent" }),
          /* @__PURE__ */ jsx("text", { x: "13", y: "21", className: "aui-harness-title", children: title }),
          /* @__PURE__ */ jsx("text", { x: "154", y: "22", children: "\u21E5" })
        ]
      }
    ),
    pins.map((pin, i) => /* @__PURE__ */ jsxs(
      "g",
      {
        className: "aui-harness-pin",
        role: "button",
        tabIndex: 0,
        "aria-label": `${title} pin ${pin.id} ${pin.label}`,
        "aria-pressed": activePin === pin.id,
        onPointerDown: (e) => e.stopPropagation(),
        onClick: (e) => {
          e.stopPropagation();
          onPin?.(pin.id);
        },
        onKeyDown: (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onPin?.(pin.id);
          }
        },
        children: [
          /* @__PURE__ */ jsx(
            "rect",
            {
              x: "1",
              y: 32 + i * 32,
              width: "178",
              height: "32",
              fill: "transparent"
            }
          ),
          /* @__PURE__ */ jsx("path", { d: `M0 ${32 + i * 32}H180`, className: "aui-harness-divider" }),
          /* @__PURE__ */ jsx("text", { x: "13", y: 53 + i * 32, className: "aui-harness-muted", children: pin.id }),
          /* @__PURE__ */ jsx("text", { x: "39", y: 53 + i * 32, children: pin.label }),
          /* @__PURE__ */ jsx(
            "circle",
            {
              cx: (pin.side ?? portSide) === "right" ? 171 : 9,
              cy: 48 + i * 32,
              r: "3",
              className: "aui-harness-port"
            }
          )
        ]
      },
      pin.id
    ))
  ] });
}
function ConnectorFace({
  pins,
  title,
  triangular = false
}) {
  const points = pins.length === 3 ? [
    [21, 21],
    [59, 21],
    [40, 52]
  ] : pins.length === 2 ? [
    [27, 38],
    [53, 38]
  ] : pins.map((_, i) => [
    25 + i % 2 * 30,
    (pins.length > 6 ? 16 : 23) + Math.floor(i / 2) * Math.min(18, 48 / Math.max(1, Math.ceil(pins.length / 2) - 1))
  ]);
  return /* @__PURE__ */ jsxs(
    "g",
    {
      className: "aui-connector-face",
      "aria-label": `${title} connector face`,
      role: "img",
      children: [
        /* @__PURE__ */ jsx("rect", { x: "20", y: "-5", width: "40", height: "8", rx: "3" }),
        /* @__PURE__ */ jsx(
          "path",
          {
            d: triangular ? "M13 0H67Q80 4 76 20L52 70Q40 86 28 70L4 20Q0 4 13 0Z" : "M10 0H70Q80 0 80 10V70Q80 80 70 80H10Q0 80 0 70V10Q0 0 10 0Z"
          }
        ),
        pins.map((pin, i) => /* @__PURE__ */ jsxs("g", { children: [
          /* @__PURE__ */ jsx(
            "circle",
            {
              cx: points[i]?.[0] ?? 40,
              cy: points[i]?.[1] ?? 40,
              r: pins.length > 8 ? 5 : 9
            }
          ),
          /* @__PURE__ */ jsx(
            "text",
            {
              x: points[i]?.[0] ?? 40,
              y: (points[i]?.[1] ?? 40) + 3.5,
              textAnchor: "middle",
              children: pin
            }
          )
        ] }, pin))
      ]
    }
  );
}
function ConnectorPreview({
  title,
  tone = "neutral"
}) {
  return /* @__PURE__ */ jsxs(
    "g",
    {
      className: "aui-connector-preview",
      "data-tone": tone,
      role: "img",
      "aria-label": `${title} housing illustration`,
      children: [
        /* @__PURE__ */ jsx("rect", { width: "82", height: "82", rx: "7" }),
        /* @__PURE__ */ jsx("image", { href: connectorArt, x: "4", y: "4", width: "74", height: "74" })
      ]
    }
  );
}
function HarnessConnectionTable({
  rows,
  width = 330,
  contacts = false,
  onSelect
}) {
  const partX = width * (contacts ? 0.42 : 0.58), lengthX = width * (contacts ? 0.65 : 0.89);
  return /* @__PURE__ */ jsxs("g", { className: "aui-harness-table", children: [
    /* @__PURE__ */ jsx(
      "rect",
      {
        width,
        height: 28 + rows.length * 26,
        rx: "7",
        className: "aui-harness-card-body"
      }
    ),
    /* @__PURE__ */ jsx(
      "path",
      {
        d: `M7 0H${width - 7}Q${width} 0 ${width} 7V28H0V7Q0 0 7 0`,
        className: "aui-harness-card-head"
      }
    ),
    /* @__PURE__ */ jsx("text", { x: "32", y: "18", className: "aui-harness-muted", children: "Destination" }),
    /* @__PURE__ */ jsx("text", { x: partX, y: "18", className: "aui-harness-muted", children: "Part" }),
    /* @__PURE__ */ jsx(
      "text",
      {
        x: lengthX,
        y: "18",
        textAnchor: "middle",
        className: "aui-harness-muted",
        children: "Length"
      }
    ),
    contacts && /* @__PURE__ */ jsx("text", { x: width * 0.78, y: "18", className: "aui-harness-muted", children: "Contact" }),
    rows.map((row, i) => /* @__PURE__ */ jsxs(
      "g",
      {
        role: "button",
        tabIndex: 0,
        "aria-label": `Connection ${row.pin} to ${row.destination}`,
        onClick: () => onSelect?.(row.id),
        onKeyDown: (e) => {
          if (e.key === "Enter") onSelect?.(row.id);
        },
        children: [
          /* @__PURE__ */ jsx("rect", { y: 28 + i * 26, width, height: "26", fill: "transparent" }),
          /* @__PURE__ */ jsx(
            "path",
            {
              d: `M0 ${28 + i * 26}H${width}`,
              className: "aui-harness-divider"
            }
          ),
          /* @__PURE__ */ jsx("text", { x: "10", y: 46 + i * 26, className: "aui-harness-muted", children: row.pin }),
          /* @__PURE__ */ jsx("text", { x: "32", y: 46 + i * 26, children: row.destination }),
          /* @__PURE__ */ jsx(
            "rect",
            {
              x: partX - 5,
              y: 33 + i * 26,
              width: "74",
              height: "16",
              rx: "8",
              className: "aui-harness-gauge"
            }
          ),
          /* @__PURE__ */ jsx(
            "path",
            {
              d: `M${partX} ${41 + i * 26}h12`,
              stroke: row.color,
              strokeWidth: "3",
              strokeLinecap: "round"
            }
          ),
          /* @__PURE__ */ jsx("text", { x: partX + 18, y: 45 + i * 26, children: row.part }),
          /* @__PURE__ */ jsx("text", { x: lengthX, y: 46 + i * 26, textAnchor: "middle", children: row.length }),
          contacts && /* @__PURE__ */ jsx("text", { x: width * 0.78, y: 46 + i * 26, children: row.contact ?? "\u2014" })
        ]
      },
      `${row.id}:${row.pin}`
    ))
  ] });
}
function HarnessDrawingScope({ children }) {
  return /* @__PURE__ */ jsx("g", { className: "aui-harness-drawing", children });
}
export {
  ConnectorFace,
  ConnectorPreview,
  HarnessConnectionTable,
  HarnessConnectorCard,
  HarnessDrawingScope
};
