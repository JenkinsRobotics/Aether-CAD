export declare function AdvisorWelcome({ hasContext }: {
    hasContext?: boolean;
}): import("react").JSX.Element;
/** Presentation examples only; product behavior remains in the owning app. */
export declare function advisorQuestions(app: string): string[];
