import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { DashboardCard } from "./DashboardCards.js";
import { Avatar } from "./Avatar.js";
import { TextField } from "./TextField.js";
import { Button } from "./Button.js";
import { Popover } from "./Popover.js";
import "./WorkflowWidgets.css";
function TeamMembersPanel({ members, onInvite, onCreditChange, onRemove, totalCredits }) {
  const [email, setEmail] = useState("");
  const [editor, setEditor] = useState(null);
  const member = members.find((item) => item.id === editor?.id);
  const allocated = members.filter((item) => item.id !== editor?.id).reduce((sum, item) => sum + item.credits, 0);
  const maximum = Math.max(0, totalCredits - allocated);
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title: "Team members", className: "aui-workflow", children: /* @__PURE__ */ jsxs("div", { className: "aui-workflow-stack", children: [
    /* @__PURE__ */ jsxs("form", { className: "aui-workflow-actions", onSubmit: (e) => {
      e.preventDefault();
      onInvite(email.trim());
      setEmail("");
    }, children: [
      /* @__PURE__ */ jsx(TextField, { type: "email", "aria-label": "Team member email", value: email, required: true, onChange: (e) => setEmail(e.target.value), placeholder: "Enter team member\u2019s email" }),
      /* @__PURE__ */ jsx(Button, { type: "submit", children: "Invite" })
    ] }),
    /* @__PURE__ */ jsx("ul", { className: "aui-workflow-members", children: members.map((person) => /* @__PURE__ */ jsxs("li", { children: [
      /* @__PURE__ */ jsx(Avatar, { name: person.name, src: person.avatar }),
      /* @__PURE__ */ jsxs("span", { children: [
        /* @__PURE__ */ jsx("strong", { children: person.name }),
        /* @__PURE__ */ jsx("small", { children: person.email })
      ] }),
      /* @__PURE__ */ jsx(Button, { "aria-label": `Edit credits for ${person.name}`, onClick: (e) => setEditor({ id: person.id, anchor: e.currentTarget, credits: person.credits }), children: person.credits.toLocaleString() })
    ] }, person.id)) }),
    /* @__PURE__ */ jsx(Popover, { open: Boolean(editor && member), anchor: editor?.anchor ?? null, onClose: () => setEditor(null), ariaLabel: "Member credit limit", focus: "first", children: editor && member && /* @__PURE__ */ jsxs("form", { className: "aui-workflow aui-workflow-stack aui-workflow-credit", onSubmit: (e) => {
      e.preventDefault();
      if (Number.isInteger(editor.credits) && editor.credits >= 0 && editor.credits <= maximum) {
        onCreditChange(editor.id, editor.credits);
        setEditor(null);
      }
    }, children: [
      /* @__PURE__ */ jsx("strong", { children: member.name }),
      /* @__PURE__ */ jsxs("label", { className: "aui-workflow-field", children: [
        "Monthly credit limit",
        /* @__PURE__ */ jsx(TextField, { type: "number", required: true, min: 0, max: maximum, value: editor.credits, onChange: (e) => setEditor({ ...editor, credits: Number(e.target.value) }) })
      ] }),
      /* @__PURE__ */ jsxs("p", { className: "aui-workflow-hint", children: [
        allocated.toLocaleString(),
        " of ",
        totalCredits.toLocaleString(),
        " credits are assigned to other members."
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-workflow-actions", children: [
        /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", children: "Update" }),
        /* @__PURE__ */ jsx(Button, { onClick: () => setEditor(null), children: "Cancel" })
      ] }),
      /* @__PURE__ */ jsx(Button, { appearance: "flat", onClick: () => {
        onRemove(editor.id);
        setEditor(null);
      }, children: "Remove member" })
    ] }) })
  ] }) });
}
export {
  TeamMembersPanel
};
