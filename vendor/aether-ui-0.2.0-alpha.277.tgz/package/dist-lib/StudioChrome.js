import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { applyInterfaceColors, INTERFACE_COLORS_KEY } from "./InterfaceColors.js";
import { useEffect, useLayoutEffect, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Menu, MenuButton } from "./Menu.js";
import { nextLayoutPreset } from "./WorkspaceShell.js";
import { DEFAULT_THEME_ID, resolveTheme, themeCSS } from "./themes.js";
const PRESET_TITLE = { floating: "Floating", docked: "Docked", canvas: "Canvas" };
function StudioModeButton({ preset, onChange, extraItems = [], onExtraSelect }) {
  const [menu, setMenu] = useState(null);
  const title = PRESET_TITLE[preset];
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        className: `aui-studio-mode aui-studio-mode--${preset}`,
        "aria-label": `Studio mode: ${title}`,
        title: "Mode",
        "aria-haspopup": "menu",
        onClick: () => onChange(nextLayoutPreset(preset)),
        onContextMenu: (event) => {
          event.preventDefault();
          setMenu({ x: event.clientX, y: event.clientY });
        },
        onKeyDown: (event) => {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            const rect = event.currentTarget.getBoundingClientRect();
            setMenu({ x: rect.left, y: rect.bottom });
          }
        },
        children: /* @__PURE__ */ jsx(AetherIcon, { name: `mode-${preset}` })
      }
    ),
    menu ? /* @__PURE__ */ jsx(
      Menu,
      {
        open: true,
        anchor: menu,
        placement: "bottom-start",
        ariaLabel: "Studio modes",
        items: [
          ...["floating", "docked", "canvas"].map((entry) => ({
            id: entry,
            label: PRESET_TITLE[entry],
            icon: /* @__PURE__ */ jsx(AetherIcon, { name: `mode-${entry}` }),
            kind: "radio",
            checked: entry === preset
          })),
          { id: "reset", label: "Reset Studio Layout", separatorBefore: true },
          ...extraItems
        ],
        onSelect: (id) => {
          setMenu(null);
          if (extraItems.some((item) => item.id === id)) onExtraSelect?.(id);
          else onChange(id === "reset" ? "floating" : id);
        },
        onClose: () => setMenu(null)
      }
    ) : null
  ] });
}
function WorkspaceWindowMenu() {
  const browserManaged = "The browser manages windows and tabs.";
  return /* @__PURE__ */ jsx(
    MenuButton,
    {
      label: "Windows",
      className: "aui-workspace-windows",
      placement: "bottom-end",
      items: [
        { id: "new-tab", label: "New Workspace Tab" },
        { id: "new-window", label: "New Workspace Window" },
        { id: "detach", label: "Detach Current Tab", disabled: true, disabledReason: browserManaged, separatorBefore: true },
        { id: "merge", label: "Merge All Windows", disabled: true, disabledReason: browserManaged },
        { id: "tab-bar", label: "Show or Hide Tab Bar", disabled: true, disabledReason: browserManaged },
        { id: "previous-tab", label: "Previous Workspace Tab", shortcut: "\u21E7\u2318[", disabled: true, disabledReason: browserManaged, separatorBefore: true },
        { id: "next-tab", label: "Next Workspace Tab", shortcut: "\u21E7\u2318]", disabled: true, disabledReason: browserManaged }
      ],
      onSelect: (id) => {
        if (id === "new-tab") window.open(location.href, "_blank");
        if (id === "new-window") window.open(location.href, "_blank", "popup=yes,width=1280,height=800");
      },
      children: /* @__PURE__ */ jsx(AetherIcon, { name: "windows" })
    }
  );
}
const APPEARANCE_ORDER = ["system", "light", "dark"];
const APPEARANCE_TITLE = { system: "System", light: "Light", dark: "Dark" };
const APPEARANCE_KEY = "aether-appearance";
function storedAppearance() {
  try {
    const saved = localStorage.getItem(APPEARANCE_KEY);
    return saved && APPEARANCE_ORDER.includes(saved) ? saved : "system";
  } catch {
    return "system";
  }
}
function applyAppearance(mode) {
  if (typeof document === "undefined") return;
  const prefersLight = typeof matchMedia === "function" && matchMedia("(prefers-color-scheme: light)").matches;
  const light = mode === "light" || mode === "system" && prefersLight;
  document.documentElement.classList.toggle("aether-light-theme", light);
  document.documentElement.dataset.aetherTheme = light ? "light" : "dark";
  document.documentElement.dataset.appearance = mode;
  applyInterfaceColors();
}
const THEME_KEY = "aether-theme";
const VIEWPORT_KEY = "aether-viewport-theme";
function installAetherTheme(manifest) {
  if (typeof document === "undefined") return;
  const existing = document.head.querySelector(`style[data-aether-theme="${manifest.id}"]`);
  const style = existing ?? document.createElement("style");
  style.setAttribute("data-aether-theme", manifest.id);
  style.textContent = themeCSS(resolveTheme(manifest));
  if (!existing) document.head.append(style);
}
function setAetherTheme(themeID) {
  try {
    localStorage.setItem(THEME_KEY, themeID);
  } catch {
  }
  applyAetherTheme();
  announceTheme(themeID);
}
function activeAetherTheme() {
  const fallback = typeof document === "undefined" ? DEFAULT_THEME_ID : document.documentElement.dataset.aetherHostTheme || DEFAULT_THEME_ID;
  try {
    return localStorage.getItem(THEME_KEY) || fallback;
  } catch {
    return fallback;
  }
}
const announceTheme = (id) => {
  if (typeof document === "undefined") return;
  const EventClass = document.defaultView?.CustomEvent ?? CustomEvent;
  document.dispatchEvent(new EventClass("aether-theme", { detail: id }));
};
const swapRootClass = (prefix, id) => {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  for (const name of [...root.classList]) if (name.startsWith(prefix)) root.classList.remove(name);
  if (id) root.classList.add(`${prefix}${id}`);
};
function applyAetherTheme() {
  if (typeof document === "undefined") return;
  const active = activeAetherTheme();
  swapRootClass("aether-theme-", active === DEFAULT_THEME_ID ? null : active);
}
function setAetherViewportTheme(viewportID) {
  try {
    if (viewportID) localStorage.setItem(VIEWPORT_KEY, viewportID);
    else localStorage.removeItem(VIEWPORT_KEY);
  } catch {
  }
  applyAetherViewportTheme();
  announceTheme(viewportID);
}
function activeAetherViewportTheme() {
  const fallback = typeof document === "undefined" ? null : document.documentElement.dataset.aetherHostViewportTheme ?? null;
  try {
    return localStorage.getItem(VIEWPORT_KEY) ?? fallback;
  } catch {
    return fallback;
  }
}
function applyAetherViewportTheme() {
  if (typeof document === "undefined") return;
  swapRootClass("aether-viewport-", activeAetherViewportTheme());
}
function setAetherAppearance(mode) {
  try {
    localStorage.setItem(APPEARANCE_KEY, mode);
  } catch {
  }
  applyAppearance(mode);
  document.dispatchEvent(new CustomEvent("aether-appearance", { detail: mode }));
}
function useStudioDesignDefaults() {
  useLayoutEffect(() => {
    const root = document.documentElement;
    root.dataset.aetherHostTheme = "model-studio";
    root.dataset.aetherHostViewportTheme = "model-studio";
    try {
      if (localStorage.getItem("aether.studio-design") !== "model-studio-1") {
        const keys = [THEME_KEY, VIEWPORT_KEY, APPEARANCE_KEY, INTERFACE_COLORS_KEY];
        localStorage.setItem("aether.studio-design.previous", JSON.stringify(Object.fromEntries(keys.map((key) => [key, localStorage.getItem(key)]))));
        localStorage.removeItem(INTERFACE_COLORS_KEY);
        setAetherTheme("model-studio");
        setAetherViewportTheme("model-studio");
        setAetherAppearance("dark");
        localStorage.setItem("aether.studio-design", "model-studio-1");
      }
    } catch {
    }
    applyAetherTheme();
    applyAetherViewportTheme();
    announceTheme(activeAetherTheme());
  }, []);
}
function useScopedAetherTheme(themeID, appearance) {
  useEffect(() => {
    if (themeID) swapRootClass("aether-theme-", themeID === DEFAULT_THEME_ID ? null : themeID);
    if (appearance) {
      document.documentElement.classList.toggle("aether-light-theme", appearance === "light");
      document.documentElement.dataset.aetherTheme = appearance;
    }
    return () => {
      applyAetherTheme();
      applyAppearance(storedAppearance());
    };
  }, [themeID, appearance]);
}
if (typeof document !== "undefined") {
  applyAppearance(storedAppearance());
  applyAetherTheme();
  applyAetherViewportTheme();
  if (typeof matchMedia === "function") {
    matchMedia("(prefers-color-scheme: light)").addEventListener?.("change", () => {
      if (storedAppearance() === "system") applyAppearance("system");
    });
  }
  if (typeof window !== "undefined") {
    window.addEventListener("storage", (event) => {
      if (event.key === APPEARANCE_KEY) applyAppearance(storedAppearance());
      if (event.key === THEME_KEY) applyAetherTheme();
      if (event.key === VIEWPORT_KEY) applyAetherViewportTheme();
      if (event.key === INTERFACE_COLORS_KEY || event.key === null) applyInterfaceColors();
    });
  }
}
function AppearanceToggle() {
  const [mode, setMode] = useState(storedAppearance);
  useEffect(() => {
    const follow = (event) => {
      if (event.key === APPEARANCE_KEY) setMode(storedAppearance());
    };
    const shared = () => setMode(storedAppearance());
    window.addEventListener("storage", follow);
    document.addEventListener("aether-appearance", shared);
    shared();
    return () => {
      window.removeEventListener("storage", follow);
      document.removeEventListener("aether-appearance", shared);
    };
  }, []);
  useEffect(() => {
    applyAppearance(mode);
    if (mode !== "system" || typeof matchMedia !== "function") return;
    const media = matchMedia("(prefers-color-scheme: light)");
    const follow = () => applyAppearance("system");
    media.addEventListener?.("change", follow);
    return () => media.removeEventListener?.("change", follow);
  }, [mode]);
  const title = APPEARANCE_TITLE[mode];
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      className: "aui-appearance-toggle",
      "aria-label": `Appearance ${title}`,
      title: "Appearance",
      onClick: () => {
        const next = APPEARANCE_ORDER[(APPEARANCE_ORDER.indexOf(mode) + 1) % APPEARANCE_ORDER.length];
        try {
          localStorage.setItem(APPEARANCE_KEY, next);
        } catch {
        }
        setMode(next);
        document.dispatchEvent(new CustomEvent("aether-appearance", { detail: next }));
      },
      children: /* @__PURE__ */ jsx(AetherIcon, { name: `appearance-${mode}` })
    }
  );
}
export {
  AppearanceToggle,
  StudioModeButton,
  WorkspaceWindowMenu,
  activeAetherTheme,
  activeAetherViewportTheme,
  installAetherTheme,
  setAetherAppearance,
  setAetherTheme,
  setAetherViewportTheme,
  storedAppearance,
  useScopedAetherTheme,
  useStudioDesignDefaults
};
