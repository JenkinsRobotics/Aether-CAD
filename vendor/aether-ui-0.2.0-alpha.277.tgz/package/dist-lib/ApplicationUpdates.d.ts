import { type ReactNode } from 'react';
import './ApplicationUpdates.css';
export interface ApplicationUpdate {
    id: string;
    title: string;
    description: string;
    status: 'Available' | 'Planned' | 'Preview';
    artwork: ReactNode;
    color?: string;
}
/** Products supply their own feature claims. This widget owns the home layout. */
export declare function ApplicationUpdates({ name, description, artwork, updates }: {
    name: string;
    description: string;
    artwork: ReactNode;
    updates?: readonly ApplicationUpdate[];
}): import("react").JSX.Element;
