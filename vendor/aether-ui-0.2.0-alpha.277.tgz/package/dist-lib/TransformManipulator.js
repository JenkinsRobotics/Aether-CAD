import "./TransformManipulator.css";
const artwork = {
  axis: '<path d="M10 19V9H5l7-7 7 7h-5v10Z"/>',
  rotation: '<path d="M4 9 2 3l6 1-2 2c6-2 13 3 12 9l3-1-2 7-5-5 3-1C18 10 12 6 7 8l2 2Z"/>',
  plane: '<path d="m5 3 13 5v13L5 16Z"/>',
  scale: '<path d="M6 6h12v12H6Z"/>',
  pivot: '<circle cx="12" cy="12" r="7"/><circle class="aui-manipulator-pivot-dot" cx="12" cy="12" r="2.5"/>',
  toward: '<circle cx="12" cy="12" r="8"/><circle class="aui-manipulator-axis-center" cx="12" cy="12" r="2.5"/>',
  away: '<circle cx="12" cy="12" r="8"/><path class="aui-manipulator-axis-tail" d="m9 9 6 6m0-6-6 6"/>'
};
function mountTransformManipulator(container, options) {
  const element = document.createElement("div");
  element.className = "aui-transform-manipulator";
  element.setAttribute("role", "group");
  element.setAttribute("aria-label", "Transform manipulator");
  const buttons = /* @__PURE__ */ new Map();
  let handles = [], disposed = false;
  let drag = null;
  const finish = (cancelled) => {
    if (!drag) return;
    const current = drag;
    drag = null;
    current.button.removeAttribute("data-dragging");
    if (current.button.hasPointerCapture?.(current.pointer)) current.button.releasePointerCapture(current.pointer);
    options.onEnd(current.handle, cancelled);
  };
  const escape = (event) => {
    if (event.key !== "Escape" || !drag) return;
    event.preventDefault();
    event.stopPropagation();
    finish(true);
  };
  window.addEventListener("keydown", escape, true);
  const blur = () => finish(true);
  window.addEventListener("blur", blur);
  const copy = document.createElement("button");
  copy.type = "button";
  copy.className = "aui-manipulator-copy";
  copy.textContent = "Copy";
  copy.setAttribute("aria-label", "Copy while moving");
  copy.onclick = () => options.onCopy?.();
  copy.hidden = true;
  element.append(copy);
  container.append(element);
  const update = (next, state = {}) => {
    handles = next;
    for (const handle of next) {
      let button = buttons.get(handle.id);
      if (!button) {
        button = document.createElement("button");
        button.type = "button";
        button.className = "aui-manipulator-handle";
        button.dataset.transformHandle = handle.id;
        const node = button;
        node.addEventListener("pointerdown", (event) => {
          if (event.button !== 0 || drag) return;
          const current = handles.find((h) => h.id === handle.id);
          if (!current) return;
          event.preventDefault();
          event.stopPropagation();
          if (options.onStart(current, event) === false) return;
          drag = { handle: current, pointer: event.pointerId, button: node };
          node.focus({ preventScroll: true });
          node.setPointerCapture(event.pointerId);
          node.dataset.dragging = "true";
        });
        node.addEventListener("pointermove", (event) => {
          if (drag?.button === node && drag.pointer === event.pointerId) {
            event.stopPropagation();
            options.onMove(drag.handle, event);
          }
        });
        node.addEventListener("pointerup", (event) => {
          if (drag?.button === node && drag.pointer === event.pointerId) {
            event.stopPropagation();
            finish(false);
          }
        });
        node.addEventListener("pointercancel", () => finish(true));
        node.addEventListener("lostpointercapture", () => finish(true));
        node.onkeydown = (event) => {
          const current = handles.find((h) => h.id === handle.id);
          if (current) options.onKey?.(current, event);
        };
        node.ondblclick = (event) => {
          if (handle.kind === "pivot") {
            event.stopPropagation();
            options.onResetPivot?.();
          }
        };
        buttons.set(handle.id, node);
        element.append(node);
      }
      button.hidden = false;
      button.disabled = Boolean(state.disabled) && !drag;
      button.dataset.kind = handle.kind;
      button.setAttribute("aria-label", handle.label);
      const axisView = handle.kind === "axis" ? handle.axisView : void 0;
      button.dataset.axisView = axisView ?? "";
      button.title = axisView ? `${handle.label} \u2014 axis points ${axisView === "toward" ? "toward" : "away from"} you. Drag up/down or use arrow keys.` : handle.label;
      const glyphKind = axisView ?? handle.kind;
      const glyph = `<svg viewBox="0 0 24 24" aria-hidden="true">${artwork[glyphKind]}</svg>`;
      if (button.dataset.glyph !== glyphKind) {
        button.innerHTML = glyph;
        button.dataset.glyph = glyphKind;
      }
      button.style.left = `${handle.x}px`;
      button.style.top = `${handle.y}px`;
      button.style.setProperty("--manipulator-angle", `${handle.angle ?? 0}deg`);
      if (handle.polygon?.length) {
        const x = Math.min(...handle.polygon.map((p) => p.x)), y = Math.min(...handle.polygon.map((p) => p.y));
        const w = Math.max(...handle.polygon.map((p) => p.x)) - x, h = Math.max(...handle.polygon.map((p) => p.y)) - y;
        const svg = button.querySelector("svg");
        svg.setAttribute("viewBox", `${x - 2} ${y - 2} ${w + 4} ${h + 4}`);
        svg.innerHTML = `<polygon points="${handle.polygon.map((p) => `${p.x},${p.y}`).join(" ")}"/>`;
        button.style.width = `${Math.max(22, w + 8)}px`;
        button.style.height = `${Math.max(22, h + 8)}px`;
      }
    }
    for (const [id, button] of buttons) if (!next.some((h) => h.id === id) && drag?.button !== button) button.hidden = true;
    copy.hidden = !options.onCopy || !state.copyPosition || !next.length;
    copy.disabled = Boolean(state.disabled) || !!drag;
    copy.setAttribute("aria-pressed", String(Boolean(state.copy)));
    if (state.copyPosition) {
      copy.style.left = `${state.copyPosition.x}px`;
      copy.style.top = `${state.copyPosition.y}px`;
    }
  };
  return { element, update, cancel: () => finish(true), dispose() {
    if (disposed) return;
    disposed = true;
    finish(true);
    window.removeEventListener("keydown", escape, true);
    window.removeEventListener("blur", blur);
    element.remove();
  } };
}
export {
  mountTransformManipulator
};
