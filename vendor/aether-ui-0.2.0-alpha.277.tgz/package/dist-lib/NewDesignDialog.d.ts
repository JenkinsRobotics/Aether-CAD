import { type ReactNode } from "react";
import "./NewDesignDialog.css";
/**
 * "What do you want to design?" — the chooser an app shows when creating a
 * document could mean several different things.
 *
 * Jonathan supplied Fusion's dialog as the reference (2026-10-04) and asked
 * for it as an Aether UI standard, so nothing here is CAD-specific: an app
 * passes the kinds it offers, and each kind carries its own description and
 * optional settings. Aether Map would offer a show and a surface template the
 * same way.
 *
 * Kinds an app cannot create yet are passed with `unavailable` rather than
 * omitted. Showing the whole menu with its gaps named is how someone learns
 * what the application is for; a short menu just looks like the whole product.
 */
export interface DesignKind {
    id: string;
    title: string;
    /** One line under the title, and the heading of the detail panel. */
    summary: string;
    /** The paragraph in the detail panel. */
    description?: string;
    icon?: ReactNode;
    /** Why it cannot be chosen. Shown in the panel; the card stays visible. */
    unavailable?: string;
    /** Extra controls for this kind alone — a template picker, a template list. */
    settings?: ReactNode;
}
export interface NewDesignDialogProps {
    title?: string;
    kinds: readonly DesignKind[];
    /** Pre-selected kind; defaults to the first that is available. */
    defaultKindID?: string;
    /** Shown for every kind, as Fusion shows its unit system. */
    units?: {
        label: string;
        value: string;
        options: readonly {
            value: string;
            label: string;
        }[];
        onChange: (value: string) => void;
    };
    /** A documentation link, bottom left. */
    learnMoreHref?: string;
    createLabel?: string;
    busy?: boolean;
    onCreate: (kindID: string) => void;
    onClose: () => void;
}
export declare function NewDesignDialog({ title, kinds, defaultKindID, units, learnMoreHref, createLabel, busy, onCreate, onClose, }: NewDesignDialogProps): import("react").JSX.Element;
