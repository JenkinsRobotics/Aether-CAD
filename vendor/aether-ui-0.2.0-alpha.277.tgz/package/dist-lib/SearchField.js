import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
function SearchField({
  id,
  value,
  defaultValue = "",
  onQueryChange,
  onSearch,
  delayMilliseconds = 180,
  placeholder = "Search",
  ariaLabel = "Search",
  resultCount,
  scopes = [],
  scopeID,
  onScopeChange,
  disabled = false,
  autoFocus = false,
  inputRef,
  className
}) {
  const controlled = value !== void 0;
  const [internalValue, setInternalValue] = useState(defaultValue);
  const query = controlled ? value : internalValue;
  const timerRef = useRef(null);
  const firstControlledValue = useRef(true);
  const cancelPending = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = null;
  };
  const scheduleSearch = (next) => {
    cancelPending();
    if (!onSearch) return;
    timerRef.current = setTimeout(() => {
      timerRef.current = null;
      onSearch(next);
    }, Math.max(0, delayMilliseconds));
  };
  const update = (next, immediate = false) => {
    if (!controlled) setInternalValue(next);
    onQueryChange?.(next);
    if (immediate) {
      cancelPending();
      onSearch?.(next);
    } else {
      scheduleSearch(next);
    }
  };
  useEffect(() => () => cancelPending(), []);
  useEffect(() => {
    if (!controlled) return;
    if (firstControlledValue.current) {
      firstControlledValue.current = false;
      return;
    }
    scheduleSearch(value);
  }, [controlled, value]);
  const onKeyDown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      cancelPending();
      onSearch?.(query);
      return;
    }
    if (event.key === "Escape" && query) {
      event.preventDefault();
      update("", true);
    }
  };
  const classes = ["aui-search-field", className].filter(Boolean).join(" ");
  const countLabel = resultCount === void 0 ? null : `${resultCount.toLocaleString()} ${resultCount === 1 ? "result" : "results"}`;
  return /* @__PURE__ */ jsxs("div", { className: classes, "data-empty": query.length === 0 || void 0, children: [
    /* @__PURE__ */ jsx("span", { className: "aui-search-field-icon", "aria-hidden": true, children: "\u2315" }),
    scopes.length > 0 ? /* @__PURE__ */ jsx(
      "select",
      {
        className: "aui-search-field-scope",
        "aria-label": `${ariaLabel} scope`,
        value: scopeID ?? scopes[0]?.id,
        disabled,
        onChange: (event) => onScopeChange?.(event.target.value),
        children: scopes.map((scope) => /* @__PURE__ */ jsx("option", { value: scope.id, children: scope.label }, scope.id))
      }
    ) : null,
    /* @__PURE__ */ jsx(
      "input",
      {
        id,
        ref: (element) => {
          if (typeof inputRef === "function") inputRef(element);
          else if (inputRef) inputRef.current = element;
        },
        type: "search",
        "aria-label": ariaLabel,
        value: query,
        placeholder,
        disabled,
        autoFocus,
        onChange: (event) => update(event.target.value),
        onKeyDown
      }
    ),
    countLabel ? /* @__PURE__ */ jsx("output", { className: "aui-search-field-count", "aria-live": "polite", children: countLabel }) : null,
    query ? /* @__PURE__ */ jsx("button", { type: "button", className: "aui-search-field-clear", "aria-label": `Clear ${ariaLabel.toLocaleLowerCase()}`, disabled, onClick: () => update("", true), children: "\xD7" }) : null
  ] });
}
export {
  SearchField
};
