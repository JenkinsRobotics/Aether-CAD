/** Presentation only. The selected object and editing transactions belong to the app. */
export declare const InspectorContext: import("react").Context<boolean>;
