import { jsx, jsxs } from "react/jsx-runtime";
import { useContext, useId, useState } from "react";
import { InspectorContext } from "./InspectorContext.js";
import { NumberField } from "./NumberField.js";
import { Slider } from "./Slider.js";
import "./ParameterRow.css";
function ParameterRow({ label, ariaLabel = label, icon, value, onChange, min, max, step = 1, unit = "", sliderRange, help, disabled, modulation }) {
  const id = useId();
  const inspector = useContext(InspectorContext);
  const [showHelp, setShowHelp] = useState(false);
  const labelElement = /* @__PURE__ */ jsxs("label", { htmlFor: id, className: "aui-parameter-label", title: label, children: [
    icon && /* @__PURE__ */ jsx("span", { "aria-hidden": true, className: "aui-parameter-icon", children: icon }),
    /* @__PURE__ */ jsx("span", { children: label })
  ] });
  return /* @__PURE__ */ jsxs("div", { className: "aui-parameter", "data-modulated": modulation ? true : void 0, "data-disabled": disabled || void 0, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-parameter-row", children: [
      inspector && help ? /* @__PURE__ */ jsxs("div", { className: "aui-inspector-parameter-heading", children: [
        labelElement,
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            className: "aui-inspector-info",
            "aria-label": `About ${ariaLabel}`,
            "aria-expanded": showHelp,
            "aria-controls": `${id}-help`,
            onClick: () => setShowHelp((value2) => !value2),
            children: "i"
          }
        )
      ] }) : labelElement,
      sliderRange && /* @__PURE__ */ jsx(
        Slider,
        {
          ariaLabel,
          value,
          min: Math.min(sliderRange.min, value),
          max: Math.max(sliderRange.max, value),
          step,
          unit,
          showValue: false,
          disabled,
          onChange,
          range: modulation?.range
        }
      ),
      /* @__PURE__ */ jsx("span", { className: "aui-parameter-entry", children: /* @__PURE__ */ jsx(
        NumberField,
        {
          id,
          className: "aui-parameter-value",
          "aria-label": ariaLabel,
          "aria-describedby": help ? `${id}-help` : void 0,
          value,
          min,
          max,
          step,
          unit,
          disabled,
          onValueChange: (next) => next !== null && onChange(next)
        }
      ) })
    ] }),
    modulation && /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        className: "aui-parameter-assignment",
        disabled,
        "aria-label": `Edit ${ariaLabel} modulation`,
        onClick: modulation.onEdit,
        children: modulation.label
      }
    ),
    help && /* @__PURE__ */ jsx("p", { id: `${id}-help`, className: "aui-parameter-help", hidden: inspector && !showHelp, children: help })
  ] });
}
export {
  ParameterRow
};
