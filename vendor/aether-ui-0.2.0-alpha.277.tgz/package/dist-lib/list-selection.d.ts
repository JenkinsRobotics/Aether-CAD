export declare function selectListItems(ids: readonly string[], selected: ReadonlySet<string>, anchor: string | null, target: string, range: boolean, additive: boolean): Set<string>;
