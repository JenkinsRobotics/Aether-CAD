import { type MouseEvent } from 'react';
import { type MenuItem } from './Menu.js';
import { type DocumentTabControls } from './DocumentTabTray.js';
type Target = {
    kind: 'tab' | 'folder';
    id: string;
} | {
    kind: 'background';
};
/** Files and its item menus share real callbacks with the tray and header. */
export declare function useDocumentBrowserContext(props: DocumentTabControls, options: {
    view: 'list' | 'gallery';
    folderID: string | null;
    rootLabel: string;
    setView: (view: 'list' | 'gallery') => void;
    setFolder: (id: string | null) => void;
}): {
    creationItems: MenuItem[];
    actionItems: MenuItem[];
    selectBackground: (action: string) => void;
    shortcut: (target: Target, key: string) => boolean;
    folderItems: MenuItem[];
    selectFolder: (id: string, action: string) => void;
    tabItems: (id: string) => MenuItem[];
    selectTab: (id: string, action: string) => void;
    open: (event: MouseEvent, target: Target) => void;
    overlays: import("react").JSX.Element;
};
export {};
