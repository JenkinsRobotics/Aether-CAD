import { type ReactNode } from "react";
import { type FlowDocumentChange } from "./FlowDiagramInspector.js";
import { type FlowDocument } from "./flow-diagram-model.js";
import "./FlowDiagramEditor.css";
export interface FlowDiagramEditorProps {
    value: FlowDocument;
    onChange: FlowDocumentChange;
    onUndo?: () => void;
    onRedo?: () => void;
    canUndo?: boolean;
    canRedo?: boolean;
    paused?: boolean;
    playbackRate?: number;
    highlightedRouteIds?: readonly string[];
    actions?: ReactNode;
}
/** Controlled editing surface. The host owns persistence and history; routes derive from the document. */
export declare function FlowDiagramEditor({ value, onChange, onUndo, onRedo, canUndo, canRedo, paused, playbackRate, highlightedRouteIds, actions }: FlowDiagramEditorProps): import("react").JSX.Element;
