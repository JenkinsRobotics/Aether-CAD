import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
function ToolTrayScroll({ children, label, role }) {
  const ref = useRef(null);
  const [edges, setEdges] = useState({ overflow: false, start: true, end: true });
  useEffect(() => {
    const el = ref.current;
    const measure = () => setEdges((previous) => {
      const next = { overflow: el.scrollWidth > el.clientWidth + 1, start: el.scrollLeft <= 1, end: el.scrollLeft + el.clientWidth >= el.scrollWidth - 1 };
      return Object.keys(next).every((key) => next[key] === previous[key]) ? previous : next;
    });
    const wheel = (event) => {
      if (event.ctrlKey || el.scrollWidth <= el.clientWidth) return;
      const delta = Math.abs(event.deltaX) >= Math.abs(event.deltaY) ? event.deltaX : event.deltaY;
      if (!delta) return;
      el.scrollLeft += delta * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? el.clientWidth : 1);
      event.preventDefault();
      event.stopPropagation();
      measure();
    };
    el.addEventListener("wheel", wheel, { passive: false });
    el.addEventListener("scroll", measure);
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(el);
    if (el.firstElementChild) observer?.observe(el.firstElementChild);
    measure();
    return () => {
      observer?.disconnect();
      el.removeEventListener("wheel", wheel);
      el.removeEventListener("scroll", measure);
    };
  }, [children]);
  const move = (direction) => {
    const el = ref.current;
    if (el) {
      el.scrollLeft += direction * Math.max(120, el.clientWidth * 0.75);
      el.dispatchEvent(new Event("scroll"));
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon-tools", role, "aria-label": label, children: [
    edges.overflow && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-tool-tray-scroll", "aria-label": "Scroll tools left", title: "Left", disabled: edges.start, onClick: () => move(-1), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-left" }) }),
    /* @__PURE__ */ jsx("div", { ref, className: "aui-tool-tray-viewport", tabIndex: 0, "aria-label": `${label} scroll area`, onKeyDown: (event) => {
      if (event.target !== event.currentTarget || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      const el = event.currentTarget;
      if (event.key === "Home" || event.key === "End") {
        el.scrollLeft = event.key === "Home" ? 0 : el.scrollWidth;
        el.dispatchEvent(new Event("scroll"));
      } else move(event.key === "ArrowLeft" ? -1 : 1);
    }, children }),
    edges.overflow && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-tool-tray-scroll", "aria-label": "Scroll tools right", title: "Right", disabled: edges.end, onClick: () => move(1), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right" }) })
  ] });
}
export {
  ToolTrayScroll
};
