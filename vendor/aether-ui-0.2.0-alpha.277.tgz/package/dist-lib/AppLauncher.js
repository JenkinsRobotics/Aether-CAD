import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { AppIcon } from "./AppIcon.js";
import { Popover } from "./Popover.js";
function AppLauncher({
  apps,
  currentID,
  homeUrl = "/",
  homeName = "Aether Studio",
  label,
  className = "aui-app-launcher-button",
  placement = "bottom-start"
}) {
  const [open, setOpen] = useState(false);
  const button = useRef(null);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        ref: button,
        type: "button",
        className,
        "aria-haspopup": "menu",
        "aria-expanded": open,
        "aria-label": `${homeName} applications`,
        title: "Apps",
        onClick: () => setOpen((value) => !value),
        children: label ? /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("span", { className: "aui-app-launcher-icon", "aria-hidden": "true", children: /* @__PURE__ */ jsx(AetherIcon, { name: "apps" }) }),
          /* @__PURE__ */ jsx("span", { className: "aui-sidebar-label", children: label })
        ] }) : /* @__PURE__ */ jsx(AetherIcon, { name: "apps" })
      }
    ),
    /* @__PURE__ */ jsxs(
      Popover,
      {
        open,
        anchor: button.current,
        onClose: () => setOpen(false),
        ariaLabel: `${homeName} applications`,
        placement,
        focus: "first",
        className: "aui-app-launcher",
        children: [
          /* @__PURE__ */ jsxs("a", { className: "aui-app-launcher-home", href: homeUrl, children: [
            /* @__PURE__ */ jsx(AppIcon, { app: "studio", size: 20 }),
            /* @__PURE__ */ jsx("span", { children: homeName })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "aui-app-launcher-grid", role: "menu", children: apps.map(
            (app) => app.comingSoon ? /* @__PURE__ */ jsxs(
              "span",
              {
                className: "aui-app-launcher-app is-soon",
                role: "menuitem",
                "aria-disabled": "true",
                title: `${app.name} \u2014 not built yet`,
                children: [
                  /* @__PURE__ */ jsx(AppIcon, { app: app.id, size: 32 }),
                  /* @__PURE__ */ jsx("strong", { children: app.name }),
                  /* @__PURE__ */ jsx("small", { children: "Coming soon" })
                ]
              },
              app.id
            ) : /* @__PURE__ */ jsxs(
              "a",
              {
                className: "aui-app-launcher-app",
                role: "menuitem",
                href: app.url,
                "aria-current": app.id === currentID ? "page" : void 0,
                title: app.description ?? app.name,
                children: [
                  /* @__PURE__ */ jsx(AppIcon, { app: app.id, size: 32 }),
                  /* @__PURE__ */ jsx("strong", { children: app.name }),
                  app.description ? /* @__PURE__ */ jsx("small", { children: app.description }) : null
                ]
              },
              app.id
            )
          ) })
        ]
      }
    )
  ] });
}
export {
  AppLauncher
};
