import { type CSSProperties, type ReactNode, type Ref } from "react";
import "./StudioAppLayout.css";
/** Shared measurements for the standard studio application. Values are CSS pixels. */
export declare const STUDIO_APP_LAYOUT_METRICS: {
    readonly headerHeight: 56;
    readonly inset: 20;
    readonly auxWidth: 360;
    readonly sideWidth: 216;
    readonly sideMinWidth: 180;
    readonly sideMaxWidth: 480;
    readonly centerToolbarMaxWidth: 620;
};
export type StudioAppRegion = "header" | "aux" | "left" | "center" | "right" | "footer";
export interface StudioAppLayoutProps {
    /** Header: identity, document, workspace version, search, user and sharing. Full width. */
    header?: ReactNode;
    /** Aux sidebar: comments, AI chat, version control. Full height below the header. */
    aux?: ReactNode;
    /** Keep aux content mounted (drafts, history) while it is closed. */
    auxOpen?: boolean;
    auxLabel?: string;
    /** Left sidebar: document structure (feature tree, layers, components). */
    left?: ReactNode;
    /** Right sidebar: properties for the selection and workspace. */
    right?: ReactNode;
    /** Center: the canvas, viewport or editor. Runs edge to edge behind the side cards. */
    children: ReactNode;
    centerLabel: string;
    /** Center top: workspace selector and its display controls. */
    centerTop?: ReactNode;
    /** Center bottom: the main tool bar and command field. */
    centerBottom?: ReactNode;
    /** Small toolbars under the side cards: workspace panels (left) and view tools (right). */
    leftTools?: ReactNode;
    rightTools?: ReactNode;
    /** Footer: document/part tabs under Left, Center and Right (not under Aux). */
    footer?: ReactNode;
    /** App overlays over the center (popups, status line, context menu), drawn above the cards. */
    overlays?: ReactNode;
    /** Resizable left card. Omit `onLeftWidthChange` for a fixed width. */
    leftWidth?: number;
    onLeftWidthChange?: (width: number | undefined) => void;
    leftResizeLabel?: string;
    /** Narrow windows show one side card at a time over the center. */
    mobilePanel?: "left" | "right" | null;
    className?: string;
    style?: CSSProperties;
    rootRef?: Ref<HTMLDivElement>;
    /** Extra data attributes for app-specific state. */
    data?: Record<`data-${string}`, string | boolean | undefined>;
}
/** Standard Aether studio app: Header / Aux / Left / Center / Right / Footer.
 * Apps provide widgets in each slot; this component owns spacing, spans and breakpoints. */
export declare function StudioAppLayout({ header, aux, auxOpen, auxLabel, left, right, children, centerLabel, centerTop, centerBottom, leftTools, rightTools, footer, overlays, leftWidth, onLeftWidthChange, leftResizeLabel, mobilePanel, className, style, rootRef, data }: StudioAppLayoutProps): import("react").JSX.Element;
