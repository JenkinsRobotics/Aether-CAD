import { type ReactNode } from "react";
import "./FileManagerPanel.css";
/**
 * The file manager every Aether app shows in its left rail.
 *
 * Jonathan, 2026-10-03, with Onshape and Fusion side by side: Onshape's tab
 * manager lists what the open document is made of, Fusion's tree browses the
 * directory the document sits in, "and I want both these functions". So this
 * is one panel with two registers — what is *inside* this document, and where
 * it *lives* — rather than two panels a person has to choose between.
 *
 * Presentation only. It is given its two lists and reports what was clicked;
 * the product owns the transport, which is what lets Aether CAD, Map and
 * Animation show the same panel over entirely different stores.
 */
export type FileManagerKind = "folder" | "file" | "part" | "assembly" | "drawing" | "scene" | "layer" | "component";
export interface FileManagerItem {
    id: string;
    name: string;
    kind: FileManagerKind;
    /** The second line: "Part Studio", "Assembly", a date — whatever names the row's type. */
    detail?: string;
    /** The version chip at the row's trailing edge. */
    badge?: string;
    /** What the chip means on hover — the named version behind the number. */
    badgeTitle?: string;
    /** Overrides the icon the kind would choose. */
    icon?: ReactNode;
    /** A preview, drawn in place of the icon when present. */
    thumbnail?: ReactNode;
    disabled?: boolean;
}
export interface FileManagerGroup {
    id: string;
    label: string;
    items: readonly FileManagerItem[];
    /** Shown in place of an empty list, so a group never reads as broken. */
    emptyText?: string;
}
export interface FileManagerPanelProps {
    /** The open document. Omitted when the app has none, and the panel then shows only the library. */
    documentName?: string;
    /** What the open document is made of — Onshape's tabs, grouped by kind. */
    documentGroups?: readonly FileManagerGroup[];
    /** Where the document lives — Fusion's tree. Root first, current folder last. */
    path?: readonly {
        id: string | null;
        name: string;
    }[];
    libraryItems?: readonly FileManagerItem[];
    libraryLabel?: string;
    /** Hide library browsing when this panel is used for document contents only. */
    showLibrary?: boolean;
    libraryEmptyText?: string;
    /** The row drawn as current, usually the open part or document. */
    activeID?: string | null;
    busy?: boolean;
    error?: string;
    onOpen: (item: FileManagerItem) => void;
    /** A folder row, or a crumb. Null is the library root. */
    onNavigate?: (folderID: string | null) => void;
    onRefresh?: () => void;
    /** Rendered beside the heading — an app's own New or Upload actions. */
    actions?: ReactNode;
    libraryActions?: ReactNode;
    ariaLabel?: string;
}
export declare function FileManagerPanel({ documentName, documentGroups, path, libraryItems, libraryLabel, showLibrary, libraryEmptyText, activeID, busy, error, onOpen, onNavigate, onRefresh, actions, libraryActions, ariaLabel, }: FileManagerPanelProps): import("react").JSX.Element;
