import { type FeatureWindow, type FeatureWindowOptions } from "./FeatureWindow.js";
export type CompactFeatureWindowOptions = Omit<FeatureWindowOptions, "variant" | "headerIcon" | "acceptLabel" | "discardLabel"> & {
    /** Tool artwork name; anything unknown shows the generic properties artwork. */
    icon: string;
    acceptLabel?: string;
    discardLabel?: string;
};
export declare function openCompactFeatureWindow(options: CompactFeatureWindowOptions): FeatureWindow;
