import type { AgentImage, AgentToolContent, AgentToolReply } from './AgentServices.js';
export declare const AGENT_IMAGE_BYTES: number;
export declare const AGENT_IMAGE_EDGE = 1024;
export declare const AGENT_IMAGES_PER_TURN = 8;
/** Explicit opt-in envelope; ordinary product JSON remains backward compatible. */
export declare function agentToolContent(value: unknown, image: AgentImage): AgentToolContent;
export declare function agentToolReply(value: unknown, imagesSupported: boolean, imagesUsed: number): AgentToolReply;
export declare function validateAgentImage(image: AgentImage): void;
/** Encode only a product-owned canvas, never the page, panels or desktop. */
export declare function agentCanvasImage(source: HTMLCanvasElement, signal: AbortSignal): AgentImage;
