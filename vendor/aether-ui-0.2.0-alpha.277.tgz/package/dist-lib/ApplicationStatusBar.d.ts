import { type ApplicationStatusProps } from "./application-status.js";
import "./ApplicationStatusBar.css";
/** Standard window footer: connection + product left, configured company right. */
export declare function ApplicationStatusBar(props: ApplicationStatusProps): import("react").JSX.Element;
