import { jsx, jsxs } from "react/jsx-runtime";
import { FileIcon } from "./FileIcon.js";
import { fileTypeFor } from "./file-types.js";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { useEffect, useRef, useState } from "react";
import { FileManagerPanel } from "./FileManagerPanel.js";
function DocumentFileManager({ connection, documentGroups = [], activeID, onOpenItem, fileType }) {
  const [scope, setScope] = useState("personal");
  const [path, setPath] = useState([{ id: null, name: "My files" }]);
  const [rows, setRows] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const generation = useRef(0);
  const current = useRef(connection);
  current.current = connection;
  const browse = async (trail, view = scope) => {
    const request = ++generation.current;
    setBusy(true);
    setError("");
    try {
      const reply = await current.current.call("list", { view, parent: trail.at(-1)?.id ?? null });
      if (request !== generation.current) return;
      setRows(reply.files ?? []);
      setPath(trail);
    } catch (e) {
      if (request === generation.current) setError(e.message);
    } finally {
      if (request === generation.current) setBusy(false);
    }
  };
  useEffect(() => {
    setRows([]);
    setScope("personal");
    void browse([{ id: null, name: "My files" }], "personal");
    return () => {
      generation.current++;
    };
  }, [connection.key]);
  const navigate = (id) => {
    const index = path.findIndex((crumb) => crumb.id === id);
    void browse(index >= 0 ? path.slice(0, index + 1) : [...path, { id, name: rows.find((row) => row.id === id)?.name ?? "Folder" }]);
  };
  const open = async (item) => {
    setError("");
    try {
      if (documentGroups.some((group) => group.items.includes(item))) await onOpenItem?.(item);
      else if (connection.openDocument) await connection.openDocument(item.id);
      else throw new Error("Opening library documents is not available in this workspace.");
    } catch (e) {
      setError(e.message);
    }
  };
  return /* @__PURE__ */ jsx(
    FileManagerPanel,
    {
      ariaLabel: "Part manager",
      documentName: connection.name,
      documentGroups,
      activeID,
      path,
      libraryItems: rows.map((row) => ({
        id: row.id,
        name: row.name,
        kind: row.kind === "folder" ? "folder" : "file",
        icon: /* @__PURE__ */ jsx(FileIcon, { file: { ...row, app: row.app ?? connection.key.split(":")[0] } }),
        detail: row.kind === "folder" ? "Folder" : fileType?.(row.name) ?? fileTypeFor({ ...row, app: row.app ?? connection.key.split(":")[0] }).label,
        badge: row.versions ? `V${row.versions}` : void 0,
        badgeTitle: row.latest_version ? `Latest version: ${row.latest_version}` : void 0,
        disabled: busy
      })),
      busy,
      error,
      onOpen: (item) => void open(item),
      onNavigate: navigate,
      onRefresh: () => void browse(path),
      actions: connection.openLibrary ? /* @__PURE__ */ jsx(IconButton, { label: "Open Aether Drive", onClick: connection.openLibrary, children: /* @__PURE__ */ jsx(AetherIcon, { name: "open-external" }) }) : void 0,
      libraryEmptyText: busy ? "Loading files\u2026" : "No documents here yet.",
      libraryActions: /* @__PURE__ */ jsxs(
        "select",
        {
          className: "aui-file-manager-scope",
          "aria-label": "File library",
          value: scope,
          disabled: busy,
          onChange: (event) => {
            const view = event.target.value;
            setScope(view);
            void browse([{ id: null, name: view === "personal" ? "My files" : "Workspace files" }], view);
          },
          children: [
            /* @__PURE__ */ jsx("option", { value: "personal", children: "My files" }),
            /* @__PURE__ */ jsx("option", { value: "workspace", children: "Workspace files" })
          ]
        }
      )
    }
  );
}
export {
  DocumentFileManager
};
