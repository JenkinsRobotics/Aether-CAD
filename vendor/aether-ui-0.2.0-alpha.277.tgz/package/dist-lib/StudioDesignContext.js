import { createContext } from "react";
const StudioDesignContext = createContext(false);
export {
  StudioDesignContext
};
