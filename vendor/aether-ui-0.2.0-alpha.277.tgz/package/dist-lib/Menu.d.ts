import { type ToolHelpContent } from "./ToolHelp.js";
import type { ButtonHTMLAttributes, CSSProperties, ReactNode } from "react";
import { type OverlayAnchor, type OverlayPlacement } from "./overlay-position.js";
export type MenuItemKind = "command" | "checkbox" | "radio";
export interface MenuItem {
    help?: ToolHelpContent;
    id: string;
    label: string;
    icon?: ReactNode;
    shortcut?: string;
    kind?: MenuItemKind;
    checked?: boolean;
    disabled?: boolean;
    disabledReason?: string;
    danger?: boolean;
    separatorBefore?: boolean;
    /** Names the section this item opens, for menus long enough to need finding
     *  rather than reading. A bare separator divides; a heading says what into. */
    heading?: string;
    children?: readonly MenuItem[];
}
export interface MenuProps {
    /** Comfortable spacing for creation pickers; context menus remain compact. */
    density?: "compact" | "comfortable";
    /** Explicit opt-in for appending registered work-area commands. */
    applicationCommands?: boolean;
    open: boolean;
    anchor: OverlayAnchor | null;
    items: readonly MenuItem[];
    onSelect: (id: string) => void;
    onClose: () => void;
    ariaLabel: string;
    placement?: OverlayPlacement;
    returnFocus?: boolean;
    className?: string;
    style?: CSSProperties;
}
/** Controlled popup menu. All menu surfaces consume the same item model and
 * report command IDs; product code owns availability and execution. */
export declare function Menu({ open, anchor: suppliedAnchor, items, onSelect, onClose, ariaLabel, placement, returnFocus, className, style, applicationCommands, density, }: MenuProps): import("react").ReactPortal | null;
export interface MenuButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "onSelect"> {
    density?: "compact" | "comfortable";
    label: string;
    items: readonly MenuItem[];
    onSelect: (id: string) => void;
    children: ReactNode;
    placement?: OverlayPlacement;
    menuClassName?: string;
    /** What the menu lines up with.
     *
     *  `"trigger"` is the button itself. `"group"` is the element containing it,
     *  for a trigger that is only part of a control — a ribbon tool is a button
     *  plus a caret, and a menu hanging off the caret opens halfway across the
     *  tool it belongs to. */
    anchorTo?: "trigger" | "group";
}
/** Standard anchor button for a Menu. Context menus use Menu directly with a
 * pointer position anchor. */
export declare function MenuButton({ label, items, onSelect, children, placement, anchorTo, density, className, menuClassName, ...buttonProps }: MenuButtonProps): import("react").JSX.Element;
