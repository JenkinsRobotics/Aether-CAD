import { type HTMLAttributes } from "react";
/** Keep menus/popovers in a themed subtree when multiple specimen themes coexist.
 * Leave the scope untransformed so viewport-positioned overlays retain their coordinates.
 * Outside a scope, existing consumers still portal to document.body.
 */
export declare function OverlayScope({ children, ...props }: HTMLAttributes<HTMLDivElement>): import("react").JSX.Element;
export declare function useOverlayHost(): HTMLElement | null;
