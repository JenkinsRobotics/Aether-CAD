import { jsx, jsxs } from "react/jsx-runtime";
import { FileIcon } from "./FileIcon.js";
import { useMemo, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
import { IconButton } from "./IconButton.js";
import "./FileManagerPanel.css";
const KIND_ICON = {
  folder: "file-folder",
  file: "file-generic",
  part: "file-part",
  assembly: "file-assembly",
  drawing: "file-drawing",
  scene: "image",
  layer: "layers",
  component: "cube"
};
const itemIcon = (item) => item.icon ?? (item.kind === "file" ? /* @__PURE__ */ jsx(FileIcon, { file: item }) : /* @__PURE__ */ jsx(AetherIcon, { name: KIND_ICON[item.kind] }));
const matches = (item, needle) => !needle || `${item.name} ${item.detail ?? ""}`.toLowerCase().includes(needle);
function FileManagerPanel({
  documentName,
  documentGroups = [],
  path = [],
  libraryItems = [],
  libraryLabel = "Library",
  showLibrary = true,
  libraryEmptyText = "This folder is empty.",
  activeID = null,
  busy = false,
  error = "",
  onOpen,
  onNavigate,
  onRefresh,
  actions,
  libraryActions,
  ariaLabel = "Files"
}) {
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("document");
  const [filter, setFilter] = useState("all");
  const [compact, setCompact] = useState(false);
  const needle = query.trim().toLowerCase();
  const allItems = [...documentGroups.flatMap((group) => group.items), ...libraryItems];
  const types = [...new Set(allItems.map((item) => item.detail || item.kind))];
  const active = allItems.find((item) => item.id === activeID);
  const arrange = (items) => items.filter((item) => matches(item, needle) && (filter === "all" || (item.detail || item.kind) === filter)).sort((a, b) => sort === "name" ? a.name.localeCompare(b.name, void 0, { numeric: true }) : sort === "type" ? (a.detail || a.kind).localeCompare(b.detail || b.kind) || a.name.localeCompare(b.name) : 0);
  const groups = useMemo(
    () => documentGroups.map((group) => ({ ...group, items: arrange(group.items) })),
    [documentGroups, needle, sort, filter]
  );
  const library = useMemo(() => arrange(libraryItems), [libraryItems, needle, sort, filter]);
  const nothingFound = Boolean(needle || filter !== "all") && !library.length && groups.every((group) => !group.items.length);
  const row = (item) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
    "button",
    {
      type: "button",
      className: "aui-file-row",
      "data-kind": item.kind,
      "data-active": item.id === activeID || void 0,
      "aria-current": item.id === activeID ? "true" : void 0,
      disabled: item.disabled,
      title: item.detail ? `${item.name} \u2014 ${item.detail}` : item.name,
      onClick: () => item.kind === "folder" && onNavigate ? onNavigate(item.id) : onOpen(item),
      children: [
        /* @__PURE__ */ jsx("span", { className: "aui-file-row-icon", "aria-hidden": "true", children: item.thumbnail ?? itemIcon(item) }),
        /* @__PURE__ */ jsxs("span", { className: "aui-file-row-text", children: [
          /* @__PURE__ */ jsx("span", { className: "aui-file-row-name", children: item.name }),
          item.detail ? /* @__PURE__ */ jsx("small", { children: item.detail }) : null
        ] }),
        item.badge ? /* @__PURE__ */ jsx("span", { className: "aui-file-row-badge", title: item.badgeTitle, children: item.badge }) : null,
        item.kind === "folder" ? /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right", className: "aui-file-row-into", "aria-hidden": "true" }) : null
      ]
    }
  ) }, item.id);
  return /* @__PURE__ */ jsxs("section", { className: "aui-file-manager", "data-compact": compact || void 0, "aria-label": ariaLabel, "aria-busy": busy || void 0, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-file-manager-head", children: [
      /* @__PURE__ */ jsx("h2", { children: ariaLabel }),
      /* @__PURE__ */ jsx(MenuButton, { label: "Sort files", items: [
        { id: "document", label: "Document order", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "part-manager" }), kind: "radio", checked: sort === "document" },
        { id: "name", label: "Name", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "text" }), kind: "radio", checked: sort === "name" },
        { id: "type", label: "Type", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }), kind: "radio", checked: sort === "type" }
      ], onSelect: setSort, children: /* @__PURE__ */ jsx(AetherIcon, { name: "sort-chevron" }) }),
      /* @__PURE__ */ jsx(MenuButton, { label: "Filter files by type", items: [
        { id: "all", label: "All types", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "part-manager" }), kind: "radio", checked: filter === "all" },
        ...types.map((type) => ({ id: type, label: type, icon: itemIcon(allItems.find((item) => (item.detail || item.kind) === type)), kind: "radio", checked: filter === type }))
      ], onSelect: setFilter, children: /* @__PURE__ */ jsx(AetherIcon, { name: "filter" }) }),
      /* @__PURE__ */ jsx(IconButton, { label: "Compact file list", "aria-pressed": compact, onClick: () => setCompact(!compact), children: /* @__PURE__ */ jsx(AetherIcon, { name: "list" }) }),
      actions,
      onRefresh ? /* @__PURE__ */ jsx(IconButton, { label: "Refresh files", disabled: busy, onClick: onRefresh, children: /* @__PURE__ */ jsx(AetherIcon, { name: "refresh" }) }) : null
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-file-manager-search", children: [
      /* @__PURE__ */ jsx(
        "input",
        {
          type: "search",
          value: query,
          placeholder: "Search files",
          "aria-label": "Search files",
          onChange: (event) => setQuery(event.target.value)
        }
      ),
      /* @__PURE__ */ jsx(AetherIcon, { name: "search", "aria-hidden": "true" })
    ] }),
    error ? /* @__PURE__ */ jsx("p", { className: "aui-file-manager-error", role: "alert", children: error }) : null,
    filter !== "all" || needle ? /* @__PURE__ */ jsx("button", { className: "aui-file-manager-clear", type: "button", onClick: () => {
      setFilter("all");
      setQuery("");
    }, children: "Clear filters" }) : null,
    /* @__PURE__ */ jsxs("div", { className: "aui-file-manager-contents", children: [
      documentName ? /* @__PURE__ */ jsxs("div", { className: "aui-file-manager-document", children: [
        /* @__PURE__ */ jsxs("h3", { title: documentName, children: [
          /* @__PURE__ */ jsx(AetherIcon, { name: "document-text", "aria-hidden": "true" }),
          documentName
        ] }),
        groups.map((group) => /* @__PURE__ */ jsxs("div", { className: "aui-file-manager-group", children: [
          /* @__PURE__ */ jsx("h4", { children: group.label }),
          group.items.length ? /* @__PURE__ */ jsx("ul", { children: group.items.map(row) }) : needle ? null : /* @__PURE__ */ jsx("p", { className: "aui-file-manager-dim", children: group.emptyText ?? "None yet." })
        ] }, group.id))
      ] }) : null,
      showLibrary && /* @__PURE__ */ jsxs("div", { className: "aui-file-manager-group aui-file-manager-library", children: [
        /* @__PURE__ */ jsx("h4", { children: libraryLabel }),
        libraryActions,
        path.length && onNavigate ? /* @__PURE__ */ jsx("nav", { className: "aui-file-manager-path", "aria-label": "Folder path", children: path.map((crumb, index) => /* @__PURE__ */ jsxs("span", { children: [
          index ? /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right", "aria-hidden": "true" }) : null,
          /* @__PURE__ */ jsx("button", { type: "button", disabled: index === path.length - 1, onClick: () => onNavigate(crumb.id), children: crumb.name })
        ] }, crumb.id ?? "root")) }) : null,
        library.length ? /* @__PURE__ */ jsx("ul", { children: library.map(row) }) : null,
        !library.length && !needle ? /* @__PURE__ */ jsx("p", { className: "aui-file-manager-dim", children: libraryEmptyText }) : null
      ] }),
      nothingFound ? /* @__PURE__ */ jsx("p", { className: "aui-file-manager-dim", children: needle ? `Nothing matches \u201C${query.trim()}\u201D.` : "No items match this type." }) : null
    ] }),
    active && /* @__PURE__ */ jsxs("aside", { className: "aui-file-manager-preview", "aria-label": "Selected item preview", children: [
      /* @__PURE__ */ jsxs("strong", { children: [
        itemIcon(active),
        active.name
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-file-manager-preview-art", "aria-hidden": "true", children: active.thumbnail ?? itemIcon(active) }),
      /* @__PURE__ */ jsxs("small", { children: [
        active.detail || active.kind,
        active.badge ? ` \xB7 ${active.badge}` : ""
      ] })
    ] })
  ] });
}
export {
  FileManagerPanel
};
