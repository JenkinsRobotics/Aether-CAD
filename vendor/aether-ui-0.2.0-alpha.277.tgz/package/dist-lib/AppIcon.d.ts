import type { ImgHTMLAttributes } from "react";
/** Product identity artwork, separate from monochrome toolbar symbols. */
export declare function AppIcon({ app, size, alt, style, ...props }: Omit<ImgHTMLAttributes<HTMLImageElement>, "src"> & {
    app?: string;
    size?: number;
}): import("react").JSX.Element;
