import { jsx, jsxs } from "react/jsx-runtime";
import { useRef, useState } from "react";
function RadioGroup({ options, value, defaultValue, onChange, label, name, orientation = "vertical", disabled = false, error, className }) {
  const [internal, setInternal] = useState(defaultValue ?? options.find((item) => !item.disabled)?.id ?? "");
  const selected = value ?? internal;
  const refs = useRef(/* @__PURE__ */ new Map());
  const select = (id) => {
    if (value === void 0) setInternal(id);
    onChange?.(id);
  };
  const move = (event, id) => {
    const enabled = options.filter((item) => !disabled && !item.disabled);
    const current = enabled.findIndex((item) => item.id === id);
    let next = current;
    if (event.key === "ArrowRight" || event.key === "ArrowDown") next = (current + 1) % enabled.length;
    else if (event.key === "ArrowLeft" || event.key === "ArrowUp") next = (current - 1 + enabled.length) % enabled.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = enabled.length - 1;
    else return;
    event.preventDefault();
    const option = enabled[next];
    if (!option) return;
    select(option.id);
    refs.current.get(option.id)?.focus();
  };
  return /* @__PURE__ */ jsxs("fieldset", { className: ["aui-radio-group", `aui-radio-group--${orientation}`, className].filter(Boolean).join(" "), disabled, "aria-invalid": Boolean(error) || void 0, children: [
    /* @__PURE__ */ jsx("legend", { children: label }),
    /* @__PURE__ */ jsx("div", { className: "aui-radio-options", children: options.map((option) => /* @__PURE__ */ jsxs("label", { className: "aui-radio-option", children: [
      /* @__PURE__ */ jsx(
        "input",
        {
          ref: (element) => {
            if (element) refs.current.set(option.id, element);
            else refs.current.delete(option.id);
          },
          type: "radio",
          name,
          value: option.id,
          checked: selected === option.id,
          disabled: option.disabled,
          onChange: () => select(option.id),
          onKeyDown: (event) => move(event, option.id)
        }
      ),
      /* @__PURE__ */ jsx("span", { className: "aui-radio-mark", "aria-hidden": true }),
      /* @__PURE__ */ jsxs("span", { children: [
        /* @__PURE__ */ jsx("span", { className: "aui-radio-label", children: option.label }),
        option.description ? /* @__PURE__ */ jsx("span", { className: "aui-radio-description", children: option.description }) : null
      ] })
    ] }, option.id)) }),
    error ? /* @__PURE__ */ jsx("div", { className: "aui-field-error", role: "alert", children: error }) : null
  ] });
}
export {
  RadioGroup
};
