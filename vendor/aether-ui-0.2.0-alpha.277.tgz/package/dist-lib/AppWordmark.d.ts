import { type SVGProps } from "react";
import { type AppWordmarkName } from "@aether/assets/branding/wordmarks/data";
import "./AppWordmark.css";
export type { AppWordmarkName } from "@aether/assets/branding/wordmarks/data";
export interface AppWordmarkProps extends Omit<SVGProps<SVGSVGElement>, "children" | "width" | "height"> {
    app: AppWordmarkName;
    /** Overall logo height. 28, 36 and 40 fit the standard header sizes. */
    size?: number;
    /** Auto follows the surrounding Aether surface; explicit values suit fixed artwork. */
    appearance?: "auto" | "light" | "dark";
    /** Hide from assistive technology when its parent link already names the app. */
    decorative?: boolean;
}
/** Resolve only registered identities; custom app names keep their own branding. */
export declare function resolveAppWordmark(identity: string): AppWordmarkName | undefined;
/** Header identity: the app's original A and font-independent outlined lettering.
 * This composition has no button, tile, frame or navigation behavior of its own. */
export declare function AppWordmark({ app, size, appearance, decorative, className, style, ...props }: AppWordmarkProps): import("react").JSX.Element;
