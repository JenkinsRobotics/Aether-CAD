import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
import { activeAetherTheme, activeAetherViewportTheme, setAetherTheme, setAetherViewportTheme } from "./StudioChrome.js";
import { aetherThemes, aetherViewportThemes } from "./themes.js";
import { SettingsWindow } from "./SettingsWindow.js";
import { SharedAppearanceSettings } from "./SharedAppearanceSettings.js";
function ThemeMenu() {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [theme, setTheme] = useState(activeAetherTheme);
  const [viewport, setViewport] = useState(activeAetherViewportTheme);
  useEffect(() => {
    const follow = () => {
      setTheme(activeAetherTheme());
      setViewport(activeAetherViewportTheme());
    };
    document.addEventListener("aether-theme", follow);
    window.addEventListener("storage", follow);
    return () => {
      document.removeEventListener("aether-theme", follow);
      window.removeEventListener("storage", follow);
    };
  }, []);
  const current = aetherThemes.find((t) => t.id === theme)?.name ?? theme;
  const items = [
    ...aetherThemes.map((t, i) => ({ id: `theme:${t.id}`, label: t.name, kind: "radio", checked: t.id === theme, heading: i === 0 ? "Interface theme" : void 0 })),
    { id: "viewport:", label: "Theme default", kind: "radio", checked: !viewport, separatorBefore: true, heading: "Viewport" },
    ...aetherViewportThemes.map((v) => ({ id: `viewport:${v.id}`, label: v.name, kind: "radio", checked: v.id === viewport })),
    { id: "settings", label: "Appearance & icons\u2026", separatorBefore: true, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }) }
  ];
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      MenuButton,
      {
        label: `Interface theme: ${current}`,
        className: "aui-icon-button",
        items,
        onSelect: (id) => {
          if (id === "settings") setSettingsOpen(true);
          else if (id.startsWith("theme:")) setAetherTheme(id.slice(6));
          else setAetherViewportTheme(id.slice(9) || null);
        },
        children: /* @__PURE__ */ jsx(AetherIcon, { name: "palette" })
      }
    ),
    /* @__PURE__ */ jsx(
      SettingsWindow,
      {
        open: settingsOpen,
        title: "Aether appearance settings",
        sections: [],
        activePaneID: "",
        onSelectPane: () => void 0,
        onClose: () => setSettingsOpen(false),
        children: /* @__PURE__ */ jsx(SharedAppearanceSettings, {})
      }
    )
  ] });
}
export {
  ThemeMenu
};
