import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { NumberField } from "./NumberField.js";
import "./TransformFields.css";
function TransformFields({ label, values, unit, disabled, min, max, step, locked, onCommit, onToggleLock }) {
  return /* @__PURE__ */ jsxs("section", { className: "aui-transform-fields", "aria-label": label, children: [
    /* @__PURE__ */ jsx("h3", { children: label }),
    ["X", "Y", "Z"].map((axis, index) => /* @__PURE__ */ jsxs("div", { className: "aui-transform-axis", children: [
      /* @__PURE__ */ jsx("span", { children: axis }),
      /* @__PURE__ */ jsx(
        NumberField,
        {
          "aria-label": `${label} ${axis}`,
          value: values[index] ?? 0,
          unit,
          min,
          max,
          step,
          disabled: disabled || locked?.[index],
          onCommit: (value) => onCommit(index, value)
        }
      ),
      onToggleLock && /* @__PURE__ */ jsx(IconButton, { label: `${locked?.[index] ? "Unlock" : "Lock"} ${label} ${axis}`, appearance: "glyph", size: "small", disabled, "aria-pressed": !!locked?.[index], onClick: () => onToggleLock(index), children: /* @__PURE__ */ jsx(AetherIcon, { name: locked?.[index] ? "lock" : "unlock" }) })
    ] }, axis))
  ] });
}
export {
  TransformFields
};
