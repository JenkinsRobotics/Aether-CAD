import type { ContextCommand } from './context-commands.js';
/** Capture before the menu takes focus; never send a field command to the scene. */
export declare function textContextCommands(target: Element): ContextCommand[] | null;
