import { jsx, jsxs } from "react/jsx-runtime";
import { DashboardCard } from "./DashboardCards.js";
import { Button } from "./Button.js";
import "./WorkflowWidgets.css";
function BatchActionReview({ title, description, totalLabel, fields, onRun, onCancel, busy }) {
  return /* @__PURE__ */ jsx(DashboardCard, { contentOnly: true, density: "compact", title, className: "aui-workflow", children: /* @__PURE__ */ jsxs("div", { className: "aui-workflow-stack", children: [
    /* @__PURE__ */ jsx("p", { children: description }),
    /* @__PURE__ */ jsx("p", { className: "aui-workflow-hint", children: totalLabel }),
    /* @__PURE__ */ jsx("dl", { className: "aui-workflow-summary", children: fields.map((field) => /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("dt", { children: field.label }),
      /* @__PURE__ */ jsx("dd", { children: field.value })
    ] }, field.label)) }),
    /* @__PURE__ */ jsxs("div", { className: "aui-workflow-actions", children: [
      onCancel && /* @__PURE__ */ jsx(Button, { onClick: onCancel, children: "Cancel" }),
      /* @__PURE__ */ jsx(Button, { primary: true, onClick: onRun, disabled: busy, children: busy ? "Generating\u2026" : "Generate" })
    ] })
  ] }) });
}
export {
  BatchActionReview
};
