import type { FlowDiagramRoute, FlowDiagramTone } from "./FlowDiagram.js";
export interface FlowPoint {
    x: number;
    y: number;
}
export type FlowPortSide = "left" | "right" | "top" | "bottom";
export interface FlowPort {
    id: string;
    label: string;
    side: FlowPortSide;
    /** Position along the side, from 0 to 1. */
    offset: number;
    direction: "input" | "output";
}
export interface FlowNode extends FlowPoint {
    id: string;
    label: string;
    detail: string;
    notes: string;
    width: number;
    height: number;
    kind: "source" | "module" | "gate" | "processor";
    tone: FlowDiagramTone;
    ports: FlowPort[];
}
export interface FlowEndpoint {
    nodeId: string;
    portId: string;
}
export interface FlowConnection {
    id: string;
    label: string;
    notes: string;
    source: FlowEndpoint;
    target: FlowEndpoint;
    tone: FlowDiagramTone;
    dashed: boolean;
    /** Optional authored route points; empty means automatic routing. */
    waypoints: FlowPoint[];
}
/** Unit-neutral diagram geometry. Product execution and transport are not represented. */
export interface FlowDocument {
    version: 1;
    width: number;
    height: number;
    nodes: FlowNode[];
    connections: FlowConnection[];
}
export type FlowSelection = {
    kind: "node";
    id: string;
} | {
    kind: "port";
    nodeId: string;
    id: string;
} | {
    kind: "connection";
    id: string;
};
export declare const FLOW_TONES: readonly FlowDiagramTone[];
export declare const FLOW_SIDES: readonly FlowPortSide[];
export declare const flowClamp: (value: number, min: number, max: number) => number;
export declare function flowPortPoint(node: FlowNode, port: FlowPort): FlowPoint;
export declare function flowEndpoint(document: FlowDocument, endpoint: FlowEndpoint): {
    node: FlowNode;
    port: FlowPort;
    point: FlowPoint;
} | undefined;
export declare function flowConnectionError(document: FlowDocument, source: FlowEndpoint, target: FlowEndpoint, ignoreId?: string): string | null;
/** Rounded polyline, preserving authored bends and exact endpoint positions. */
export declare function flowRoundedPath(points: readonly FlowPoint[], radius?: number): string;
export declare function flowConnectionPath(document: FlowDocument, edge: FlowConnection): string;
export declare function flowRoutes(document: FlowDocument): FlowDiagramRoute[];
export declare function flowNodeBounds(document: FlowDocument, node: FlowNode): {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
};
export declare function flowMoveNode(document: FlowDocument, id: string, point: FlowPoint): FlowDocument;
export declare function flowMovePort(document: FlowDocument, nodeId: string, id: string, point: FlowPoint): FlowDocument;
export declare function flowDelete(document: FlowDocument, selection: FlowSelection): FlowDocument;
/** Validate imported data before it becomes interactive SVG or a saved draft. */
export declare function parseFlowDocument(text: string): FlowDocument;
