import './SurfacePresetPicker.css';
export interface SurfacePreset {
    id: string;
    name: string;
    color: string;
    roughness?: number;
    metalness?: number;
}
/** Content only; hosts provide the sidebar, popover or floating-panel container. */
export declare function SurfacePresetPicker({ presets, selectedId, disabled, onSelect }: {
    presets: readonly SurfacePreset[];
    selectedId?: string;
    disabled?: boolean;
    onSelect: (id: string) => void;
}): import("react").JSX.Element;
