import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ApplicationIdentity, ApplicationSettings, ApplicationAccountControls } from "./ApplicationChrome.js";
import "./ApplicationHome.css";
import { StudioDocumentBar } from "./StudioDocumentBar.js";
function ApplicationHomeFrame({ children, className = "", layout = "header", design = "standard" }) {
  return /* @__PURE__ */ jsx("div", { className: `aui-application-home${design === "studio" ? " aui-application-home--studio" : ""}${layout === "sidebar" ? " aui-application-home--sidebar" : ""} ${className}`, children });
}
function ApplicationHomeHeader({ app, name, apps, search, className = "", identity = true, onSettings, design = "standard" }) {
  if (design === "studio" && identity) return /* @__PURE__ */ jsx(
    StudioDocumentBar,
    {
      className: `aui-application-home-header ${className}`,
      application: { id: app, name, apps, onSettings },
      trailing: search
    }
  );
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("header", { className: `aui-application-home-header${identity ? "" : " aui-application-home-header--search"} ${className}`, children: [
      identity && /* @__PURE__ */ jsx(ApplicationIdentity, { id: app, name, apps }),
      search,
      identity && /* @__PURE__ */ jsx(ApplicationAccountControls, {})
    ] }),
    /* @__PURE__ */ jsx(ApplicationSettings, { name, onSettings })
  ] });
}
export {
  ApplicationHomeFrame,
  ApplicationHomeHeader
};
