import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import "./WorkflowElements.css";
function SettingsLink({ label, description, destructive, className = "", ...props }) {
  return /* @__PURE__ */ jsxs("button", { type: "button", ...props, className: `aui-settings-link ${className}`, "data-destructive": destructive || void 0, children: [
    /* @__PURE__ */ jsxs("span", { children: [
      /* @__PURE__ */ jsx("strong", { children: label }),
      description && /* @__PURE__ */ jsx("small", { children: description })
    ] }),
    /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right" })
  ] });
}
export {
  SettingsLink
};
