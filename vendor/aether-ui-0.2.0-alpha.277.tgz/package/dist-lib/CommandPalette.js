import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { normalize, fuzzyScore } from "./command-matching.js";
import { createPortal } from "react-dom";
import { useEffect, useId, useMemo, useRef, useState } from "react";
function groupedCommands(ranked, query, recentLabel, uncategorizedLabel) {
  const groups = [];
  const add = (label, item) => {
    let group = groups.find((candidate) => candidate.label === label);
    if (!group) {
      group = { label, items: [] };
      groups.push(group);
    }
    group.items.push(item);
  };
  if (!normalize(query)) {
    for (const item of ranked.filter(({ command }) => command.recent)) add(recentLabel, item);
    for (const item of ranked.filter(({ command }) => !command.recent)) add(item.command.category ?? uncategorizedLabel, item);
    return groups;
  }
  for (const item of ranked) add(item.command.category ?? uncategorizedLabel, item);
  return groups;
}
const FOCUSABLE = 'button, input, [href], [tabindex]:not([tabindex="-1"])';
function CommandPalette({
  open,
  commands,
  onSelect,
  onClose,
  title = "Command palette",
  placeholder = "Search commands",
  emptyMessage = "No matching commands",
  recentLabel = "Recent",
  uncategorizedLabel = "Commands"
}) {
  const [query, setQuery] = useState("");
  const [activeID, setActiveID] = useState(null);
  const [pendingCommand, setPendingCommand] = useState(null);
  const [argument, setArgument] = useState("");
  const [argumentError, setArgumentError] = useState(false);
  const dialogRef = useRef(null);
  const searchRef = useRef(null);
  const argumentRef = useRef(null);
  const openerRef = useRef(null);
  const listID = useId();
  const ranked = useMemo(() => commands.map((command, index) => ({ command, score: fuzzyScore(command, query), index })).filter((item) => item.score !== null).sort((a, b) => b.score - a.score || a.index - b.index), [commands, query]);
  const groups = groupedCommands(ranked, query, recentLabel, uncategorizedLabel);
  const displayed = groups.flatMap((group) => group.items);
  const enabled = displayed.filter(({ command }) => !command.disabled);
  useEffect(() => {
    if (!open) return;
    openerRef.current = document.activeElement;
    setQuery("");
    setPendingCommand(null);
    setArgument("");
    setArgumentError(false);
    queueMicrotask(() => searchRef.current?.focus());
    return () => {
      openerRef.current?.focus?.();
      openerRef.current = null;
    };
  }, [open]);
  useEffect(() => {
    if (!open) return;
    const first = enabled[0]?.command.id ?? null;
    if (!activeID || !enabled.some(({ command }) => command.id === activeID)) setActiveID(first);
  }, [activeID, enabled, open]);
  useEffect(() => {
    if (pendingCommand) queueMicrotask(() => argumentRef.current?.focus());
  }, [pendingCommand]);
  useEffect(() => {
    if (!open) return;
    const onDocumentKeyDown = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        if (pendingCommand) {
          setPendingCommand(null);
          setArgumentError(false);
          queueMicrotask(() => searchRef.current?.focus());
        } else onClose();
        return;
      }
      if (event.key !== "Tab" || !dialogRef.current) return;
      const focusable = Array.from(dialogRef.current.querySelectorAll(FOCUSABLE)).filter((element) => !element.hasAttribute("disabled"));
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      const current = document.activeElement;
      if (event.shiftKey && (current === first || !dialogRef.current.contains(current))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (current === last || !dialogRef.current.contains(current))) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onDocumentKeyDown, true);
    return () => document.removeEventListener("keydown", onDocumentKeyDown, true);
  }, [onClose, open, pendingCommand]);
  const choose = (command) => {
    if (command.disabled) return;
    if (command.argument) {
      setPendingCommand(command);
      setArgument(command.argument.initialValue ?? "");
      setArgumentError(false);
      return;
    }
    onSelect(command.id);
    onClose();
  };
  const submitArgument = () => {
    if (!pendingCommand?.argument) return;
    const next = argument.trim();
    if (pendingCommand.argument.required && !next) {
      setArgumentError(true);
      return;
    }
    onSelect(pendingCommand.id, next);
    onClose();
  };
  const move = (event) => {
    if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    if (enabled.length === 0) return;
    const current = enabled.findIndex(({ command }) => command.id === activeID);
    let next = 0;
    if (event.key === "End") next = enabled.length - 1;
    else if (event.key === "ArrowUp") next = current <= 0 ? enabled.length - 1 : current - 1;
    else if (event.key === "ArrowDown") next = current < 0 || current === enabled.length - 1 ? 0 : current + 1;
    setActiveID(enabled[next]?.command.id ?? null);
  };
  if (!open || typeof document === "undefined") return null;
  return createPortal(
    /* @__PURE__ */ jsx("div", { className: "aui-command-palette-scrim", onPointerDown: (event) => {
      if (event.target === event.currentTarget) onClose();
    }, children: /* @__PURE__ */ jsx("div", { ref: dialogRef, className: "aui-command-palette", role: "dialog", "aria-modal": "true", "aria-label": title, children: pendingCommand?.argument ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("header", { children: [
        /* @__PURE__ */ jsx("button", { type: "button", className: "aui-command-palette-back", onClick: () => {
          setPendingCommand(null);
          setArgumentError(false);
          queueMicrotask(() => searchRef.current?.focus());
        }, "aria-label": "Back to commands", children: "\u2039" }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("strong", { children: pendingCommand.label }),
          /* @__PURE__ */ jsx("span", { children: pendingCommand.argument.label })
        ] }),
        /* @__PURE__ */ jsx("button", { type: "button", className: "aui-command-palette-close", onClick: onClose, "aria-label": "Close", children: "\xD7" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-command-palette-argument", children: [
        /* @__PURE__ */ jsx(
          "input",
          {
            ref: argumentRef,
            "aria-label": pendingCommand.argument.label,
            placeholder: pendingCommand.argument.placeholder,
            value: argument,
            "aria-invalid": argumentError || void 0,
            onChange: (event) => {
              setArgument(event.target.value);
              setArgumentError(false);
            },
            onKeyDown: (event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                submitArgument();
              }
            }
          }
        ),
        pendingCommand.argument.help ? /* @__PURE__ */ jsx("div", { className: "aui-field-help", children: pendingCommand.argument.help }) : null,
        argumentError ? /* @__PURE__ */ jsx("div", { className: "aui-field-error", role: "alert", children: "A value is required." }) : null,
        /* @__PURE__ */ jsx("button", { type: "button", className: "aui-button aui-button--primary", onClick: submitArgument, children: pendingCommand.argument.submitLabel ?? "Run" })
      ] })
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-command-palette-search", children: [
        /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: "\u2315" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            ref: searchRef,
            role: "combobox",
            "aria-label": placeholder,
            "aria-controls": listID,
            "aria-expanded": "true",
            "aria-autocomplete": "list",
            "aria-activedescendant": activeID ? `${listID}-${activeID}` : void 0,
            placeholder,
            value: query,
            onChange: (event) => setQuery(event.target.value),
            onKeyDown: (event) => {
              move(event);
              if (event.key === "Enter") {
                event.preventDefault();
                const command = enabled.find(({ command: candidate }) => candidate.id === activeID)?.command;
                if (command) choose(command);
              }
            }
          }
        ),
        /* @__PURE__ */ jsx("kbd", { children: "Esc" })
      ] }),
      /* @__PURE__ */ jsx("div", { id: listID, className: "aui-command-palette-list", role: "listbox", "aria-label": "Commands", children: groups.length === 0 ? /* @__PURE__ */ jsx("div", { className: "aui-command-palette-empty", children: emptyMessage }) : groups.map((group) => /* @__PURE__ */ jsxs("section", { "aria-label": group.label, children: [
        /* @__PURE__ */ jsx("h3", { children: group.label }),
        group.items.map(({ command }) => /* @__PURE__ */ jsxs(
          "button",
          {
            id: `${listID}-${command.id}`,
            type: "button",
            role: "option",
            "aria-selected": activeID === command.id,
            "aria-disabled": command.disabled || void 0,
            className: "aui-command-palette-item",
            title: command.disabled ? command.disabledReason : void 0,
            onPointerMove: () => {
              if (!command.disabled) setActiveID(command.id);
            },
            onClick: () => choose(command),
            children: [
              /* @__PURE__ */ jsx("span", { className: "aui-command-palette-icon", "aria-hidden": true, children: command.icon ?? "" }),
              /* @__PURE__ */ jsxs("span", { className: "aui-command-palette-copy", children: [
                /* @__PURE__ */ jsx("strong", { children: command.label }),
                command.disabled && command.disabledReason ? /* @__PURE__ */ jsx("small", { children: command.disabledReason }) : command.description ? /* @__PURE__ */ jsx("small", { children: command.description }) : null
              ] }),
              command.shortcut ? /* @__PURE__ */ jsx("kbd", { children: command.shortcut }) : null,
              command.argument ? /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: "\u203A" }) : null
            ]
          },
          command.id
        ))
      ] }, group.label)) }),
      /* @__PURE__ */ jsxs("footer", { children: [
        /* @__PURE__ */ jsx("span", { children: "\u2191\u2193 Navigate" }),
        /* @__PURE__ */ jsx("span", { children: "\u21B5 Run" }),
        /* @__PURE__ */ jsx("span", { children: "Esc Close" })
      ] })
    ] }) }) }),
    document.body
  );
}
export {
  CommandPalette
};
