import { jsx, jsxs } from "react/jsx-runtime";
import { useId } from "react";
import "./SignalMonitor.css";
function SignalMonitor({
  traces,
  caption = "",
  duration = "1 s"
}) {
  const id = useId();
  return /* @__PURE__ */ jsxs("figure", { className: "aui-signal-monitor", children: [
    /* @__PURE__ */ jsxs("figcaption", { children: [
      caption,
      /* @__PURE__ */ jsx("span", { children: duration })
    ] }),
    /* @__PURE__ */ jsxs(
      "svg",
      {
        viewBox: "0 0 700 90",
        role: "img",
        "aria-label": caption || "Signal traces",
        preserveAspectRatio: "none",
        children: [
          /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("pattern", { id, width: "35", height: "18", patternUnits: "userSpaceOnUse", children: /* @__PURE__ */ jsx(
            "path",
            {
              d: "M35 0H0V18",
              fill: "none",
              stroke: "var(--aether-color-border)",
              strokeWidth: ".5"
            }
          ) }) }),
          /* @__PURE__ */ jsx("rect", { width: "700", height: "90", fill: `url(#${id})` }),
          traces.map((trace, index) => /* @__PURE__ */ jsx(
            "polyline",
            {
              fill: "none",
              stroke: trace.color || "var(--aether-color-accent)",
              strokeWidth: "2",
              points: trace.values.map(
                (v, i) => `${i * 700 / Math.max(1, trace.values.length - 1)},${(index + 1) * 90 / (traces.length + 1) - Math.max(0, Math.min(1, v)) * 20}`
              ).join(" ")
            },
            trace.id
          ))
        ]
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "aui-signal-legend", children: traces.map((t) => /* @__PURE__ */ jsxs("span", { children: [
      /* @__PURE__ */ jsx(
        "i",
        {
          style: { background: t.color || "var(--aether-color-accent)" }
        }
      ),
      t.label
    ] }, t.id)) })
  ] });
}
export {
  SignalMonitor
};
