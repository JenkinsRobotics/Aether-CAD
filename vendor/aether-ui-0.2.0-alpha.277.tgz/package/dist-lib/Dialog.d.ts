import type { ReactNode } from "react";
export interface DialogProps {
    open: boolean;
    title: string;
    onClose: () => void;
    actions?: ReactNode;
    children: ReactNode;
    /** Show the same window in document flow, without a scrim or modal focus behavior. */
    inline?: boolean;
}
/** Modal dialog with scrim. Escape or scrim click closes; focus moves
 *  into the dialog on open, Tab cycles within it, and focus returns to
 *  the opener on close. */
export declare function Dialog({ open, title, onClose, actions, children, inline }: DialogProps): import("react").JSX.Element | null;
