import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { AppWordmark, resolveAppWordmark } from "./AppWordmark.js";
import { Button } from "./Button.js";
import { DocumentBar } from "./DocumentBar.js";
import "./AppNavigationBar.css";
function AppNavigationBar({ brand, app, mark, items, activeID, onNavigate, onHome, actions, className }) {
  const identity = app ?? resolveAppWordmark(brand);
  return /* @__PURE__ */ jsx("div", { className: ["aui-app-navigation", className].filter(Boolean).join(" "), children: /* @__PURE__ */ jsx(
    DocumentBar,
    {
      windowChrome: false,
      className: "aui-app-navigation__bar",
      leading: /* @__PURE__ */ jsx(Button, { appearance: "link", className: "aui-app-navigation__brand", "aria-label": `${brand} home`, onClick: onHome, children: identity ? /* @__PURE__ */ jsx(AppWordmark, { app: identity, size: 32, decorative: true }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        mark && /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: mark }),
        /* @__PURE__ */ jsx("strong", { children: brand })
      ] }) }),
      center: /* @__PURE__ */ jsx("nav", { "aria-label": brand, className: "aui-app-navigation__pages", children: items.map((item) => /* @__PURE__ */ jsx(
        Button,
        {
          appearance: "link",
          disabled: item.disabled,
          "aria-current": item.id === activeID ? "page" : void 0,
          onClick: () => onNavigate(item.id),
          children: item.label
        },
        item.id
      )) }),
      trailing: actions
    }
  ) });
}
export {
  AppNavigationBar
};
