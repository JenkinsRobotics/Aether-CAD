import type { ReactNode } from "react";
import "./ApplicationList.css";
/** A consistent list heading. Counts belong to selection feedback, not page titles. */
export declare function ApplicationListHeading({ children, description }: {
    children: ReactNode;
    description?: ReactNode;
}): import("react").JSX.Element;
/** Filters, optional name search and commands always precede list content. */
export declare function ApplicationListControls({ filters, search, actions }: {
    filters?: ReactNode;
    search?: ReactNode;
    actions?: ReactNode;
}): import("react").JSX.Element;
/** Sort/view pickers use the same menu surface and keyboard model as context menus. */
export declare function ListToolMenu({ label, ariaLabel, icon, items, onPick }: {
    label: ReactNode;
    ariaLabel?: string;
    icon?: ReactNode;
    items: {
        id: string;
        label: string;
        icon?: ReactNode;
        checked?: boolean;
    }[];
    onPick: (id: string) => void;
}): import("react").JSX.Element;
