import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { SelectField } from "./SelectField.js";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { IconButton } from "./IconButton.js";
import { Menu } from "./Menu.js";
import { Popover } from "./Popover.js";
import { commentImage, commentScreenshot } from "./comment-images.js";
import "./DocumentCommentsView.css";
const when = (seconds) => {
  const date = new Date(seconds * 1e3), today = /* @__PURE__ */ new Date();
  const time = date.toLocaleTimeString(void 0, { hour: "numeric", minute: "2-digit" });
  return `${time} ${date.toDateString() === today.toDateString() ? "Today" : date.toLocaleDateString()}`;
};
function DocumentCommentsView(props) {
  const { connection, state, text, editing, reply, busy, error, conflict, conflicted } = props;
  const [filter, setFilter] = useState("all"), [scope, setScope] = useState(connection.branch ?? "Main");
  const [images, setImages] = useState([]), [revision, setRevision] = useState();
  const [history, setHistory] = useState(null), [tagOpen, setTagOpen] = useState(false);
  const [imageError, setImageError] = useState(""), [capturing, setCapturing] = useState(false);
  const [menu, setMenu] = useState(null);
  const tagAnchor = useRef(null), fileInput = useRef(null), editor = useRef(null);
  const captureGeneration = useRef(0);
  useEffect(() => {
    let live = true;
    setScope(connection.branch ?? "Main");
    setImages([]);
    setRevision(void 0);
    setImageError("");
    setTagOpen(false);
    setMenu(null);
    setHistory(null);
    void connection.call("history").then((h) => {
      if (live) setHistory(h);
    }).catch(() => {
    });
    return () => {
      live = false;
      captureGeneration.current++;
    };
  }, [connection.key]);
  useEffect(() => {
    captureGeneration.current++;
    const item = state?.comments.find((i) => i.id === editing);
    setImages(item?.attachments ?? []);
    setRevision(item?.revision);
    setImageError("");
    if (editing || reply) editor.current?.focus();
  }, [editing, reply, props.draftReset]);
  const clear = () => {
    captureGeneration.current++;
    props.onCancel();
    setImages([]);
    setRevision(void 0);
    setImageError("");
  };
  const addImage = async (load) => {
    if (images.length >= 3) {
      setImageError("Attach up to three images.");
      return;
    }
    const generation = captureGeneration.current;
    setCapturing(true);
    setImageError("");
    try {
      const image = await load();
      if (generation === captureGeneration.current) setImages((old) => [...old, image].slice(0, 3));
    } catch (e) {
      if (generation === captureGeneration.current && e.name !== "NotAllowedError") setImageError(e.message);
    } finally {
      setCapturing(false);
    }
  };
  const branches = [.../* @__PURE__ */ new Set(["Main", connection.branch ?? "Main", ...history?.branches.map((b) => b.name) ?? [], ...state?.comments.map((i) => i.branch ?? "Main") ?? []])];
  const person = (id) => state?.members.find((member) => member.id === id);
  const allowed = (item) => item.author === state?.actor || state?.actor === state?.owner;
  const threads = state?.comments.filter((item) => !item.parent && (!item.deleted || state.comments.some((c) => c.parent === item.id && !c.deleted)) && (scope === "*" || (item.branch ?? "Main") === scope) && (filter === "all" || (filter === "resolved" ? item.resolved : !item.resolved))) ?? [];
  const options = menu ? [{ id: "edit", label: "Edit comment", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "pencil" }), disabled: busy }, { id: "remove", label: "Remove comment", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "delete" }), disabled: busy, danger: true }] : [];
  const renderComment = (item, child = false) => {
    const author = person(item.author), name = author?.name ?? "Former member";
    return /* @__PURE__ */ jsxs("li", { className: child ? "aui-comment-reply" : void 0, "data-resolved": item.resolved || void 0, children: [
      /* @__PURE__ */ jsxs("article", { "aria-label": `Comment by ${name}`, children: [
        /* @__PURE__ */ jsxs("header", { className: "aui-comment-author", children: [
          author?.avatar ? /* @__PURE__ */ jsx("img", { className: "aui-comment-avatar", src: author.avatar, alt: "" }) : /* @__PURE__ */ jsx("span", { className: "aui-comment-avatar", "aria-hidden": "true", children: name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("") }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("strong", { children: name }),
            /* @__PURE__ */ jsxs("time", { dateTime: new Date(item.created * 1e3).toISOString(), children: [
              when(item.created),
              item.updated > item.created ? " \xB7 Edited" : ""
            ] })
          ] }),
          !child && !item.deleted && /* @__PURE__ */ jsx("input", { type: "checkbox", "aria-label": item.resolved ? "Reopen discussion" : "Resolve discussion", title: item.resolved ? "Reopen discussion" : "Resolve discussion", checked: !!item.resolved, disabled: busy || !allowed(item), onChange: () => props.onResolve(item) }),
          !item.deleted && allowed(item) && /* @__PURE__ */ jsx(IconButton, { className: "aui-comment-more", label: "Comment actions", "aria-haspopup": "menu", onClick: (e) => setMenu({ item, anchor: e.currentTarget }), children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "aui-comment-text", children: item.deleted ? "Comment removed" : item.text }),
        !item.deleted && !!item.attachments?.length && /* @__PURE__ */ jsx("div", { className: "aui-comment-images", children: item.attachments.map((image, i) => /* @__PURE__ */ jsx("a", { href: image.data_url, download: image.name, title: `Download ${image.name}`, children: /* @__PURE__ */ jsx("img", { src: image.data_url, alt: image.name }) }, i)) }),
        /* @__PURE__ */ jsxs("footer", { className: "aui-comment-footer", children: [
          !child && !item.deleted && /* @__PURE__ */ jsx("button", { type: "button", className: "aui-comment-link", disabled: busy, onClick: () => props.onReply(item), children: "Reply" }),
          /* @__PURE__ */ jsxs("span", { className: "aui-comment-workspace", title: item.revision ? item.reference_name ?? "Saved state" : void 0, children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: item.revision ? "price-tag" : "workspace" }),
            item.reference_name || (item.branch ?? "Main")
          ] })
        ] })
      ] }),
      !child && /* @__PURE__ */ jsx("ol", { "aria-label": `Replies to ${name}`, children: state?.comments.filter((c) => c.parent === item.id && !c.deleted).map((c) => renderComment(c, true)) })
    ] }, item.id);
  };
  return /* @__PURE__ */ jsxs("section", { className: "aui-comments-panel", "aria-label": "Comments", children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-comments-header", children: [
      /* @__PURE__ */ jsx("h3", { children: "Comments" }),
      /* @__PURE__ */ jsx(IconButton, { label: props.following ? "Pause live comment updates" : "Follow live comment updates", "aria-pressed": props.following, disabled: !state, onClick: () => props.onFollowing(!props.following), children: /* @__PURE__ */ jsx(AetherIcon, { name: "bell" }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "aui-comments-filters", children: [
      /* @__PURE__ */ jsx(
        SelectField,
        {
          title: "Workspace",
          "aria-label": "Comments workspace",
          icon: /* @__PURE__ */ jsx(AetherIcon, { name: "workspace" }),
          value: scope,
          onChange: (e) => setScope(e.target.value),
          options: [{ value: "*", label: "All workspaces" }, ...branches.map((branch) => ({ value: branch, label: branch }))]
        }
      ),
      /* @__PURE__ */ jsx(
        SelectField,
        {
          "aria-label": "Comments filter",
          icon: /* @__PURE__ */ jsx(AetherIcon, { name: "filter" }),
          value: filter,
          onChange: (e) => setFilter(e.target.value),
          options: [{ value: "all", label: "All" }, { value: "open", label: "Open" }, { value: "resolved", label: "Resolved" }]
        }
      )
    ] }),
    (error || imageError) && /* @__PURE__ */ jsx("p", { className: "aui-comments-error", role: "alert", children: imageError || error }),
    conflict,
    /* @__PURE__ */ jsxs("form", { "aria-label": "Comment composer", className: "aui-comments-composer", onSubmit: (e) => {
      e.preventDefault();
      void props.onSubmit({ branch: connection.branch ?? "Main", revision: revision ?? null, attachments: images }).then((ok) => {
        if (ok) {
          setImages([]);
          setRevision(void 0);
          setImageError("");
        }
      });
    }, children: [
      (reply || editing) && /* @__PURE__ */ jsx("small", { children: editing ? "Editing comment" : `Replying to ${person(state?.comments.find((i) => i.id === reply)?.author ?? "")?.name ?? "discussion"}` }),
      /* @__PURE__ */ jsx("textarea", { ref: editor, "aria-label": "Comments text", placeholder: "Add a comment\u2026", value: text, onChange: (e) => props.onText(e.target.value), rows: 3, maxLength: 1e4 }),
      /* @__PURE__ */ jsxs("div", { className: "aui-comments-compose-tools", children: [
        /* @__PURE__ */ jsx("div", { ref: tagAnchor, children: /* @__PURE__ */ jsx(IconButton, { label: "Tag a saved state", "aria-haspopup": "dialog", "aria-expanded": tagOpen, disabled: busy, onClick: () => {
          setTagOpen(!tagOpen);
          void connection.call("history").then(setHistory).catch((e) => setImageError(e.message));
        }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "price-tag" }) }) }),
        /* @__PURE__ */ jsx(IconButton, { label: "Attach screenshot", disabled: busy || capturing || images.length >= 3, onClick: () => void addImage(commentScreenshot), children: /* @__PURE__ */ jsx(AetherIcon, { name: "screenshot" }) }),
        /* @__PURE__ */ jsx(IconButton, { label: "Attach image", disabled: busy || capturing || images.length >= 3, onClick: () => fileInput.current?.click(), children: /* @__PURE__ */ jsx(AetherIcon, { name: "image" }) }),
        /* @__PURE__ */ jsx("input", { ref: fileInput, type: "file", accept: "image/png,image/jpeg,image/webp", "aria-label": "Comment image file", hidden: true, onChange: (e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) void addImage(() => commentImage(file));
        } })
      ] }),
      revision != null && /* @__PURE__ */ jsxs("div", { className: "aui-comment-reference", children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "price-tag" }),
        history?.versions.find((v) => v.revision === revision)?.name ?? "Saved state",
        /* @__PURE__ */ jsx(IconButton, { label: "Remove saved-state tag", onClick: () => setRevision(void 0), children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
      ] }),
      !!images.length && /* @__PURE__ */ jsx("div", { className: "aui-comment-draft-images", children: images.map((image, i) => /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("img", { src: image.data_url, alt: image.name }),
        /* @__PURE__ */ jsx(IconButton, { label: `Remove ${image.name}`, onClick: () => setImages((old) => old.filter((_, index) => index !== i)), children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
      ] }, i)) }),
      /* @__PURE__ */ jsxs("div", { className: "aui-comments-submit", children: [
        /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", disabled: busy || capturing || conflicted || !state || !text.trim(), children: editing ? "Save" : reply ? "Reply" : "Add" }),
        /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: clear, children: "Cancel" }),
        capturing && /* @__PURE__ */ jsx("small", { role: "status", children: "Preparing image\u2026" })
      ] })
    ] }),
    !state && /* @__PURE__ */ jsx("p", { role: "status", children: "Loading comments\u2026" }),
    /* @__PURE__ */ jsx("ol", { className: "aui-comments-list", "aria-label": "Discussions", children: threads.map((item) => renderComment(item)) }),
    /* @__PURE__ */ jsx(Menu, { open: !!menu, anchor: menu?.anchor ?? null, ariaLabel: "Comment actions", items: options, onSelect: (id) => {
      if (menu) {
        if (id === "edit") props.onEdit(menu.item);
        else props.onRemove(menu.item);
      }
      setMenu(null);
    }, onClose: () => setMenu(null) }),
    /* @__PURE__ */ jsxs(Popover, { open: tagOpen, anchor: tagAnchor.current, ariaLabel: "Tag a saved state", className: "aui-comment-tag-picker", onClose: () => setTagOpen(false), children: [
      /* @__PURE__ */ jsxs("label", { children: [
        "Saved state",
        /* @__PURE__ */ jsxs("select", { "aria-label": "Saved-state tag", value: revision ?? "", onChange: (e) => setRevision(e.target.value ? Number(e.target.value) : void 0), children: [
          /* @__PURE__ */ jsx("option", { value: "", children: "No tag" }),
          history?.branches.map((b) => /* @__PURE__ */ jsxs("option", { value: b.head_revision, children: [
            b.name,
            " \xB7 current saved state"
          ] }, `branch:${b.name}`)),
          history?.versions.map((v) => /* @__PURE__ */ jsx("option", { value: v.revision, children: v.name }, `version:${v.name}`))
        ] })
      ] }),
      /* @__PURE__ */ jsx(Button, { onClick: () => setTagOpen(false), children: "Done" })
    ] })
  ] });
}
export {
  DocumentCommentsView
};
