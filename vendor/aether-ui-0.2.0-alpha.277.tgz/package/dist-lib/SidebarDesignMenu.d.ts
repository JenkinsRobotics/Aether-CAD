import type { WorkspaceShellProps } from "./WorkspaceShell.js";
export type SidebarDesign = NonNullable<WorkspaceShellProps["sidebarVariant"]>;
export declare const sidebarDesignOptions: readonly {
    id: SidebarDesign;
    label: string;
}[];
/** Presentation only; the owning application chooses where preferences live. */
export declare function SidebarDesignMenu({ value: appValue, onChange }: {
    value: SidebarDesign;
    onChange: (value: SidebarDesign) => void;
}): import("react").JSX.Element;
