/**
 * The theme pack: every manifest in core/assets/themes, resolved. A theme is
 * one JSON of data — colour modes, geometry, font, effects and the viewport
 * look — and may `extends` another. dev/build-theme-css.mjs turns the same
 * manifests into tokens.css; this module gives the running app the list
 * (for a theme menu or a preview) and the resolver for hot installs.
 * Viewport themes live beside them and set the `viewport-*` tokens only.
 */
export interface AetherThemeManifest {
    id: string;
    name: string;
    description?: string;
    /** Inherit every token from this theme (the default when omitted) and override some. */
    extends?: string;
    /** Extra selectors that carry the theme, for a subtree that has its own class (`.aether-home-theme`). */
    aliases?: readonly string[];
    modes: {
        dark?: Record<string, string>;
        light?: Record<string, string>;
    };
    geometry?: Record<string, string>;
    font?: Record<string, string>;
    effects?: Record<string, string>;
    /** Geometry overrides applied under `@media (pointer: coarse)`. */
    touch?: Record<string, string>;
}
export interface ResolvedTheme {
    id: string;
    name: string;
    description: string;
    aliases: readonly string[];
    modes: {
        dark: Record<string, string>;
        light: Record<string, string>;
    };
    geometry: Record<string, string>;
    font: Record<string, string>;
    effects: Record<string, string>;
    touch: Record<string, string>;
}
export declare const DEFAULT_THEME_ID = "aether-default";
/** Same algorithm as dev/build-theme-css.mjs — keep in step. */
export declare function resolveTheme(manifest: AetherThemeManifest, registry?: Record<string, AetherThemeManifest>, seen?: string[]): ResolvedTheme;
/** The interface themes, default first then by name. */
export declare const aetherThemes: readonly ResolvedTheme[];
/** The viewport themes: only `viewport-*` tokens, applied on top of any interface theme. */
export declare const aetherViewportThemes: readonly ResolvedTheme[];
export declare const aetherTheme: (id: string) => ResolvedTheme | undefined;
/** The scoped CSS for one resolved theme — identical to what the build emits, for hot installs. */
export declare function themeCSS(theme: ResolvedTheme, className?: string): string;
