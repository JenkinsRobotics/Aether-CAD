import { type ReactNode } from "react";
import "./DashboardCards.css";
/** Reusable dashboard surfaces. Values, formatting and business semantics stay with the caller. */
export declare function DashboardCard({ title, caption, action, children, className, density, contentOnly }: {
    title: string;
    caption?: ReactNode;
    action?: ReactNode;
    children: ReactNode;
    className?: string;
    density?: "standard" | "compact"; /** Widget content inherits its host frame. */
    contentOnly?: boolean;
}): import("react").JSX.Element;
export declare function MetricCard({ label, value, icon, change, trend, detail }: {
    label: string;
    value: string;
    icon?: ReactNode;
    change: string;
    trend?: "positive" | "negative" | "neutral";
    detail?: string;
}): import("react").JSX.Element;
export declare function GoalProgress({ label, value, target, format }: {
    label: string;
    value: number;
    target: number;
    format?: (n: number) => string;
}): import("react").JSX.Element;
export interface DashboardActivity {
    id: string;
    text: string;
    time: string;
    tone: "positive" | "negative" | "warning" | "accent";
}
export declare function ActivityList({ items, onSelect }: {
    items: readonly DashboardActivity[];
    onSelect?: (id: string) => void;
}): import("react").JSX.Element;
import { type DataTableProps } from "./DataTable.js";
/** Spacious, row-divided table presentation for dashboard cards; uses shared sorting/selection. */
export declare function DashboardTable<Row>({ density, ...props }: DataTableProps<Row> & {
    density?: "standard" | "compact";
}): import("react").JSX.Element;
