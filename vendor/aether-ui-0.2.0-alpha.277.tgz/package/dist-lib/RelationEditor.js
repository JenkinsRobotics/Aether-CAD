import { jsx, jsxs } from "react/jsx-runtime";
import { Button } from "./Button.js";
import { Checkbox } from "./Checkbox.js";
import { NumberField } from "./NumberField.js";
import { SelectField } from "./SelectField.js";
import "./RelationEditor.css";
function RelationEditor(props) {
  const { value, onChange, busy = false } = props;
  const change = (patch) => onChange({ ...value, ...patch });
  const numbersValid = Number.isFinite(value.magnitude) && value.magnitude > 0 && Number.isFinite(value.offset);
  return /* @__PURE__ */ jsxs("form", { className: "aui-relation-editor", "aria-label": "Advanced relation", onSubmit: (event) => {
    event.preventDefault();
    if (!busy && numbersValid && value.driver && value.driven && value.driver !== value.driven && props.valid !== false) props.onApply();
  }, children: [
    /* @__PURE__ */ jsxs("fieldset", { disabled: busy, children: [
      /* @__PURE__ */ jsx("legend", { children: "RELATION TYPE" }),
      /* @__PURE__ */ jsxs("label", { children: [
        "Type",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Relation type", disabled: props.editing, value: value.kind, onChange: (event) => change({ kind: event.target.value, driver: "", driven: "" }), options: props.kinds })
      ] }),
      props.compatibility && /* @__PURE__ */ jsx("p", { children: props.compatibility })
    ] }),
    /* @__PURE__ */ jsxs("fieldset", { disabled: busy, children: [
      /* @__PURE__ */ jsx("legend", { children: "COUPLED MATE DOFS" }),
      /* @__PURE__ */ jsxs("label", { children: [
        "Driver",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Relation driver", value: value.driver, onChange: (event) => change({ driver: event.target.value }), options: [{ value: "", label: "Choose driver\u2026" }, ...props.drivers] })
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "Driven",
        /* @__PURE__ */ jsx(SelectField, { "aria-label": "Relation driven", disabled: props.editing, value: value.driven, onChange: (event) => change({ driven: event.target.value }), options: [{ value: "", label: "Choose driven\u2026" }, ...props.driven] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("fieldset", { disabled: busy, children: [
      /* @__PURE__ */ jsx("legend", { children: "RELATIONSHIP" }),
      /* @__PURE__ */ jsxs("label", { children: [
        props.ratioLabel,
        /* @__PURE__ */ jsx(NumberField, { "aria-label": props.ratioLabel, value: Number.isFinite(value.magnitude) ? value.magnitude : null, min: 1e-6, step: 0.1, unit: props.ratioUnit, onValueChange: (number) => change({ magnitude: number ?? NaN }) })
      ] }),
      /* @__PURE__ */ jsx(Checkbox, { label: "Reverse direction", checked: value.reversed, onChange: (event) => change({ reversed: event.target.checked }) }),
      /* @__PURE__ */ jsxs("label", { children: [
        "Driven offset",
        /* @__PURE__ */ jsx(NumberField, { "aria-label": "Driven offset", value: Number.isFinite(value.offset) ? value.offset : null, unit: props.offsetUnit, onValueChange: (number) => change({ offset: number ?? NaN }) })
      ] })
    ] }),
    props.description && /* @__PURE__ */ jsx("p", { children: props.description }),
    props.error && /* @__PURE__ */ jsx("p", { role: "alert", children: props.error }),
    /* @__PURE__ */ jsxs("footer", { children: [
      /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: props.onCancel, children: "Cancel" }),
      props.onRemove && /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: props.onRemove, children: "Remove relation" }),
      /* @__PURE__ */ jsx(Button, { type: "submit", primary: true, disabled: busy || !numbersValid || !value.driver || !value.driven || value.driver === value.driven || props.valid === false, children: busy ? "Applying\u2026" : props.editing ? "Apply relation" : "Create relation" })
    ] })
  ] });
}
export {
  RelationEditor
};
