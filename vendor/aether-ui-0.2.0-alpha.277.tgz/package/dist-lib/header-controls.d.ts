export declare const HEADER_PINS_KEY = "aether-header-pins-v1";
export declare const LEGACY_HEADER_PINS_KEY = "aether-workspace-quick-controls";
export declare const DEFAULT_HEADER_PINS: readonly ["theme", "share", "apps"];
export declare function readHeaderPins(appID: string, defaults?: readonly string[]): string[];
export declare function setHeaderPins(appID: string, ids: readonly string[]): void;
export declare function useHeaderPins(appID: string, defaults?: readonly string[]): string[];
export interface HeaderControlOption {
    id: string;
    label: string;
    icon: string;
}
export interface HeaderControlConfiguration {
    appID: string;
    name: string;
    controls: readonly HeaderControlOption[];
    defaults: readonly string[];
}
export declare function registerHeaderControls(owner: string, config: HeaderControlConfiguration): () => void;
export declare function useAvailableHeaderControls(): readonly HeaderControlConfiguration[];
