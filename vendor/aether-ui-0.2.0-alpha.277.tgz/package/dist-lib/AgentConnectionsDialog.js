import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { SegmentedControl } from "./SegmentedControl.js";
import { SelectField } from "./SelectField.js";
import { TextField } from "./TextField.js";
function AgentConnectionsDialog({ open, onClose, app, service, access, sharing, plugins, onChanged, provider, onProvider, models, model, onModel, busy }) {
  const [tab, setTab] = useState("providers"), [error, setError] = useState(""), [notice, setNotice] = useState(""), [working, setWorking] = useState(false);
  const [job, setJob] = useState(null), [code, setCode] = useState("");
  const [listing, setListing] = useState(null), [label, setLabel] = useState(""), [permission, setPermission] = useState("content"), [hours, setHours] = useState("24");
  const [issued, setIssued] = useState(null);
  const activeJob = useRef(null);
  activeJob.current = job;
  const epoch = useRef(0), changed = useRef(onChanged);
  changed.current = onChanged;
  useLayoutEffect(() => {
    epoch.current++;
    setIssued(null);
    setListing(null);
    setError("");
    setNotice("");
    setWorking(false);
    setJob(null);
    setCode("");
    if (open) void refresh();
    return () => {
      epoch.current++;
      const pending = activeJob.current;
      if (pending?.state === "running") void service.call("cancel", { id: pending.id }).catch(() => {
      });
    };
  }, [service, access, app, open]);
  async function refresh() {
    if (!access) return;
    const generation = epoch.current;
    try {
      const next = await access.call("list");
      if (generation === epoch.current) {
        setListing(next);
        if (next.saved_content_editing_available === false) setPermission((value) => value === "content" ? "read" : value);
      }
    } catch (e) {
      if (generation === epoch.current) setError(e.message);
    }
  }
  useEffect(() => {
    if (job?.state !== "running") return;
    let live = true, timer;
    const tick = async () => {
      try {
        const next = await service.call("job", { id: job.id });
        if (!live) return;
        setJob(next);
        if (next.state === "running") timer = setTimeout(() => void tick(), 700);
        else {
          if (next.error) setError(next.error);
          changed.current();
        }
      } catch (e) {
        if (live) {
          setError(e.message);
          setJob(null);
          changed.current();
        }
      }
    };
    timer = setTimeout(() => void tick(), 300);
    return () => {
      live = false;
      clearTimeout(timer);
    };
  }, [job?.id, job?.state, service]);
  async function action(id, action2) {
    const generation = epoch.current;
    setWorking(true);
    setError("");
    setCode("");
    try {
      const result = await service.call(action2, { provider: id });
      if (generation !== epoch.current) {
        if ("id" in result) void service.call("cancel", { id: result.id }).catch(() => {
        });
        return;
      }
      if ("id" in result) setJob(result);
      else {
        setJob(null);
        changed.current();
      }
    } catch (e) {
      if (generation === epoch.current) setError(e.message);
    } finally {
      if (generation === epoch.current) setWorking(false);
    }
  }
  async function create() {
    if (!access || !label.trim() || !listing?.apps.some((item) => item.id === app) || permission === "content" && listing.saved_content_editing_available === false) return;
    const generation = epoch.current;
    setWorking(true);
    setError("");
    try {
      const result = await access.call("create", { label: label.trim(), apps: [app], can_write: permission !== "read", can_edit_content: permission === "content", lifetime_hours: Number(hours) });
      if (generation !== epoch.current) return;
      setIssued({ id: result.connection.id, token: result.token });
      setLabel("");
      await refresh();
    } catch (e) {
      if (generation === epoch.current) setError(e.message);
    } finally {
      if (generation === epoch.current) setWorking(false);
    }
  }
  async function revoke(id) {
    if (!access) return;
    const generation = epoch.current;
    setWorking(true);
    setError("");
    try {
      await access.call("revoke", { id });
      if (generation !== epoch.current) return;
      if (issued?.id === id) setIssued(null);
      await refresh();
      setNotice("Agent access revoked.");
    } catch (e) {
      if (generation === epoch.current) setError(e.message);
    } finally {
      if (generation === epoch.current) setWorking(false);
    }
  }
  async function copy(text, label2) {
    const generation = epoch.current;
    try {
      await navigator.clipboard.writeText(text);
      if (generation !== epoch.current) return;
      setNotice(`${label2} copied.`);
    } catch {
      if (generation !== epoch.current) return;
      setError("Select the field and copy it manually.");
    }
  }
  const appName = listing?.apps.find((item) => item.id === app)?.name ?? app.toUpperCase();
  const running = working || job?.state === "running", ready = plugins.filter((p) => p.enabled && p.runtimeReady && p.account.connected);
  const loginURL = job?.login?.url && /^https?:\/\//.test(job.login.url) ? job.login.url : void 0;
  const shared = sharing && ["connecting", "shared", "working"].includes(sharing.state);
  return /* @__PURE__ */ jsx(Dialog, { open, title: "Agent connections", onClose, actions: /* @__PURE__ */ jsx(Button, { onClick: onClose, children: "Done" }), children: /* @__PURE__ */ jsxs("div", { className: "aui-agent-connections", children: [
    /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Agent connection type", value: tab, onChange: setTab, options: [{ id: "providers", label: "AI providers" }, { id: "mcp", label: "MCP agents" }] }),
    error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
    notice && /* @__PURE__ */ jsx("p", { role: "status", children: notice }),
    tab === "providers" ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("p", { children: "Connect your account to ask the agent to inspect and edit this workspace." }),
      ready.length > 0 && /* @__PURE__ */ jsxs("div", { className: "aui-agent-connection-form", children: [
        /* @__PURE__ */ jsxs("label", { children: [
          "Provider",
          /* @__PURE__ */ jsx(SelectField, { "aria-label": "Agent provider", value: provider, disabled: busy, onChange: (e) => onProvider(e.target.value), options: ready.map((p) => ({ value: p.id, label: p.name })) })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "Model",
          /* @__PURE__ */ jsx(SelectField, { "aria-label": "Agent model", value: model, disabled: busy, onChange: (e) => onModel(e.target.value), options: [{ value: "", label: "Account default" }, ...models.map((m) => ({ value: m.id, label: m.name }))] })
        ] })
      ] }),
      plugins.map((p) => /* @__PURE__ */ jsxs("section", { className: "aui-agent-connection-card", "aria-label": `${p.name} connection`, children: [
        /* @__PURE__ */ jsxs("header", { children: [
          /* @__PURE__ */ jsx("strong", { children: p.name }),
          /* @__PURE__ */ jsx("small", { children: p.account.connected ? "Connected" : p.enabled && p.runtimeReady ? "Not connected" : p.installed ? "Unavailable" : "Not installed" })
        ] }),
        p.account.connected && /* @__PURE__ */ jsx("small", { children: p.account.label }),
        p.enabled && p.runtimeReady ? /* @__PURE__ */ jsxs("div", { className: "aui-agent-connection-actions", children: [
          /* @__PURE__ */ jsx(Button, { disabled: running || busy, onClick: () => void action(p.id, "login"), children: p.account.connected ? "Reconnect" : `Connect ${p.name}` }),
          p.account.connected && /* @__PURE__ */ jsx(Button, { disabled: running || busy, onClick: () => void action(p.id, "disconnect"), children: "Disconnect" })
        ] }) : /* @__PURE__ */ jsx("a", { href: "/?plugins", target: "_blank", rel: "noopener noreferrer", children: "Manage this provider in Studio Plugins" })
      ] }, p.id)),
      !plugins.length && /* @__PURE__ */ jsx("p", { children: "No providers are available yet. Install a provider in Studio Plugins." }),
      job?.state === "running" && /* @__PURE__ */ jsxs("section", { className: "aui-agent-connection-card", "aria-label": "Provider sign-in", children: [
        /* @__PURE__ */ jsx("p", { role: "status", children: job.login?.instruction ?? "Waiting for provider\u2026" }),
        loginURL && /* @__PURE__ */ jsx("a", { href: loginURL, target: "_blank", rel: "noopener noreferrer", children: "Continue sign-in" }),
        job.login?.acceptsCode && /* @__PURE__ */ jsxs("form", { onSubmit: (e) => {
          e.preventDefault();
          void service.call("code", { id: job.id, code }).then(() => setCode("")).catch((e2) => setError(e2.message));
        }, children: [
          /* @__PURE__ */ jsx(TextField, { "aria-label": "Sign-in callback URL", value: code, autoComplete: "off", onChange: (e) => setCode(e.target.value), placeholder: "Paste callback URL if requested" }),
          /* @__PURE__ */ jsx(Button, { type: "submit", disabled: !code.trim(), children: "Complete sign-in" })
        ] }),
        /* @__PURE__ */ jsx(Button, { onClick: () => void service.call("cancel", { id: job.id }).then(setJob).catch((e) => setError(e.message)), children: "Cancel sign-in" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-agent-connection-actions", children: [
        /* @__PURE__ */ jsx(Button, { onClick: () => changed.current(), children: "Refresh providers" }),
        /* @__PURE__ */ jsx("a", { href: "/?plugins", target: "_blank", rel: "noopener noreferrer", children: "Plugins" })
      ] })
    ] }) : /* @__PURE__ */ jsx(Fragment, { children: access ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("section", { className: "aui-agent-connection-card", children: [
        /* @__PURE__ */ jsx("strong", { children: "Connect an MCP client" }),
        /* @__PURE__ */ jsx("p", { children: "Add this URL to a compatible client, then sign in to Studio and allow editing for this app." }),
        /* @__PURE__ */ jsx(TextField, { "aria-label": "MCP server URL", value: access.mcpURL, readOnly: true, onFocus: (e) => e.target.select() }),
        /* @__PURE__ */ jsx(Button, { onClick: () => void copy(access.mcpURL, "MCP URL"), children: "Copy MCP URL" }),
        /* @__PURE__ */ jsx("small", { children: "A localhost URL works on this computer. Remote clients need your reachable Studio address." })
      ] }),
      sharing && /* @__PURE__ */ jsxs("section", { className: "aui-agent-connection-card", "aria-label": "Live editor access", children: [
        /* @__PURE__ */ jsx("strong", { children: "This editor" }),
        /* @__PURE__ */ jsx("p", { role: "status", children: sharing.message || (sharing.available ? "Share this editor so authorized MCP agents can use its live tools and Undo." : "Save this document to Studio to share its editor.") }),
        /* @__PURE__ */ jsx(Button, { disabled: !sharing.available || sharing.state === "connecting", onClick: shared ? sharing.stop : sharing.start, children: shared ? "Stop sharing editor" : "Share this editor" })
      ] }),
      /* @__PURE__ */ jsxs("details", { children: [
        /* @__PURE__ */ jsx("summary", { children: "Use a connection key" }),
        /* @__PURE__ */ jsxs("form", { className: "aui-agent-connection-form", onSubmit: (e) => {
          e.preventDefault();
          void create();
        }, children: [
          /* @__PURE__ */ jsxs("label", { children: [
            "Name",
            /* @__PURE__ */ jsx(TextField, { "aria-label": "Agent connection name", value: label, maxLength: 80, onChange: (e) => setLabel(e.target.value), placeholder: `My ${appName} agent` })
          ] }),
          /* @__PURE__ */ jsxs("label", { children: [
            "Access",
            /* @__PURE__ */ jsx(SelectField, { "aria-label": "Agent access level", value: permission, onChange: (e) => setPermission(e.target.value), options: [{ value: "read", label: "Read documents" }, { value: "edit", label: "Read, rename and create versions" }, ...listing?.saved_content_editing_available === false ? [] : [{ value: "content", label: "Edit documents and shared editors" }]] })
          ] }),
          /* @__PURE__ */ jsxs("label", { children: [
            "Expires",
            /* @__PURE__ */ jsx(SelectField, { value: hours, onChange: (e) => setHours(e.target.value), options: [{ value: "1", label: "1 hour" }, { value: "24", label: "1 day" }, { value: "168", label: "7 days" }] })
          ] }),
          /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", disabled: working || !!issued || !listing?.apps.some((a) => a.id === app) || !label.trim(), children: "Create connection key" })
        ] })
      ] }),
      issued && /* @__PURE__ */ jsxs("section", { className: "aui-agent-connection-card", "aria-label": "New connection key", children: [
        /* @__PURE__ */ jsx("p", { children: "Copy this key into your client's private connection settings. It disappears when you close this dialog." }),
        /* @__PURE__ */ jsx(TextField, { "aria-label": "Connection key", value: issued.token, readOnly: true, autoComplete: "off", spellCheck: false, onFocus: (e) => e.target.select() }),
        /* @__PURE__ */ jsx(Button, { onClick: () => void copy(issued.token, "Connection key"), children: "Copy key" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "aui-agent-connection-actions", children: [
        /* @__PURE__ */ jsxs("strong", { children: [
          appName,
          " connections"
        ] }),
        /* @__PURE__ */ jsx(Button, { onClick: () => void refresh(), children: "Refresh connections" })
      ] }),
      listing?.connections.filter((c) => c.apps.includes(app)).map((c) => /* @__PURE__ */ jsxs("section", { className: "aui-agent-connection-card", children: [
        /* @__PURE__ */ jsxs("header", { children: [
          /* @__PURE__ */ jsx("strong", { children: c.label }),
          /* @__PURE__ */ jsx(Button, { disabled: working || !c.active || c.expires * 1e3 < Date.now(), onClick: () => void revoke(c.id), children: "Revoke" })
        ] }),
        /* @__PURE__ */ jsxs("small", { children: [
          c.can_edit_content ? "Content editing" : c.can_write ? "Document management" : "Read only",
          " \xB7 ",
          c.active && c.expires * 1e3 > Date.now() ? `Expires ${new Date(c.expires * 1e3).toLocaleString()}` : "Inactive"
        ] })
      ] }, c.id)),
      listing && !listing.connections.some((c) => c.apps.includes(app)) && /* @__PURE__ */ jsx("p", { children: "No agent connections for this app yet." })
    ] }) : /* @__PURE__ */ jsx("p", { children: "Connect this workspace to Studio to use external MCP agents." }) })
  ] }) });
}
export {
  AgentConnectionsDialog
};
