import type { ReactNode } from "react";
export interface ProgressOverlayProps {
    open: boolean;
    label: ReactNode;
    detail?: ReactNode;
    phase?: ReactNode;
    value?: number;
    max?: number;
    onCancel?: () => void;
    onBackground?: () => void;
    inline?: boolean;
}
/** Progress surface for observable, cancellable, or backgroundable work. */
export declare function ProgressOverlay({ open, label, detail, phase, value, max, onCancel, onBackground, inline, }: ProgressOverlayProps): import("react").JSX.Element | null;
