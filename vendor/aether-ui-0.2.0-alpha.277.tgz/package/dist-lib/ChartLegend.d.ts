import "./AnalyticsElements.css";
export interface ChartSeries {
    id: string;
    label: string;
    color: string;
}
/** Shared labelled swatches, optionally toggling the visibility of each series. */
export declare function ChartLegend({ series, hidden, onToggle, label }: {
    series: readonly ChartSeries[];
    hidden?: readonly string[];
    onToggle?: (id: string) => void;
    label?: string;
}): import("react").JSX.Element;
