import { type DocumentHistory } from "./DocumentServices.js";
import type { HistoryMilestone } from "./document-history-graph.js";
export type BranchFilter = "all" | "workspaces" | "current" | "parents";
export type HistoryChange = DocumentHistory["revisions"][number];
/** Follow first-parent history: merged source changes remain on their own branch. */
export declare function milestoneChanges(row: HistoryMilestone, history: DocumentHistory): HistoryChange[];
export declare function visibleHistory(rows: HistoryMilestone[], history: DocumentHistory, branch: string, filter: BranchFilter, automatic: boolean, query: string): HistoryMilestone[];
type HistoryLinks = {
    id: string;
    parents: readonly string[];
    primaryParents: readonly string[];
};
/** Reconnect through filtered nodes, never leave dangling lines to hidden rows. */
export declare function visibleParents(row: HistoryLinks, all: readonly HistoryLinks[], shown: readonly HistoryLinks[], merges: boolean): string[];
export {};
