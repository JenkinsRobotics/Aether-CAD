import { jsx, jsxs } from "react/jsx-runtime";
import { useContext, useId, useState } from "react";
import { InspectorContext } from "./InspectorContext.js";
import "./Inspector.css";
function FieldRow({
  label,
  htmlFor,
  children,
  help,
  error,
  modified,
  required,
  onReset,
  className,
  layout
}) {
  const inspector = useContext(InspectorContext);
  const inline = layout ? layout === "inline" : inspector;
  const [showHelp, setShowHelp] = useState(false);
  const helpID = useId();
  const classes = ["aui-field-row"];
  if (inline) classes.push("aui-field-row--inline");
  if (layout === "stacked") classes.push("aui-field-row--stacked");
  if (error) classes.push("aui-field-row--error");
  if (modified) classes.push("aui-field-row--modified");
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs("div", { className: classes.join(" "), children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-field-row-heading", children: [
      /* @__PURE__ */ jsxs("label", { htmlFor, children: [
        modified ? /* @__PURE__ */ jsx("span", { className: "aui-field-row-modified", "aria-hidden": true, title: "Modified", children: "\u2022" }) : null,
        label,
        required ? /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: " *" }) : null
      ] }),
      inline && help && !error ? /* @__PURE__ */ jsx(
        "button",
        {
          type: "button",
          className: "aui-inspector-info",
          "aria-label": typeof label === "string" ? `About ${label}` : "About this setting",
          "aria-expanded": showHelp,
          "aria-controls": helpID,
          onClick: () => setShowHelp((value) => !value),
          children: "i"
        }
      ) : null,
      onReset ? /* @__PURE__ */ jsx("button", { type: "button", onClick: onReset, children: "Reset" }) : null
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-field-row-editor", children }),
    error ? /* @__PURE__ */ jsx("div", { className: "aui-field-row-error", role: "alert", children: error }) : null,
    !error && help ? /* @__PURE__ */ jsx("div", { id: helpID, className: "aui-field-row-help", hidden: inline && !showHelp, children: help }) : null
  ] });
}
export {
  FieldRow
};
