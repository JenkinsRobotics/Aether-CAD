import { jsx, jsxs } from "react/jsx-runtime";
import "./WorkflowElements.css";
function StructureStep({ title, description, position }) {
  return /* @__PURE__ */ jsxs("div", { className: "aui-structure-step", children: [
    /* @__PURE__ */ jsx("span", { className: "aui-structure-step-marker", "aria-label": `Step ${position}`, children: position }),
    /* @__PURE__ */ jsxs("span", { children: [
      /* @__PURE__ */ jsx("strong", { children: title }),
      /* @__PURE__ */ jsx("small", { children: description })
    ] })
  ] });
}
export {
  StructureStep
};
