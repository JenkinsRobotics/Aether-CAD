import { jsx } from "react/jsx-runtime";
import packagedAssets0 from "@aether/assets/catalogs/c0b2566acef0ce";
import { useId, useSyncExternalStore } from "react";
const files = packagedAssets0;
const icons = Object.fromEntries(
  Object.entries(files).map(([path, markup]) => [path.slice(path.lastIndexOf("/") + 1, -".svg".length), markup])
);
const aetherIconNames = Object.keys(icons).sort();
let activeIconPack = null;
let iconPackVersion = 0;
const iconPackListeners = /* @__PURE__ */ new Set();
const subscribeIconPack = (listener) => {
  iconPackListeners.add(listener);
  return () => iconPackListeners.delete(listener);
};
function registerIconPack(pack) {
  activeIconPack = pack;
  iconPackVersion += 1;
  for (const listener of iconPackListeners) listener();
}
function AetherIcon({ name, ...props }) {
  const instanceID = useId().replace(/[^a-zA-Z0-9_-]/g, "");
  useSyncExternalStore(subscribeIconPack, () => iconPackVersion, () => iconPackVersion);
  const source = activeIconPack?.[name] ?? icons[name];
  const body = (source ?? "").replace(/^<svg[^>]*>/, "").replace(/<\/svg>\s*$/, "");
  const ids = new Set([...body.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]));
  const scoped = (id) => ids.has(id) ? `aui-${instanceID}-${id}` : id;
  const markup = body.replace(/\bid="([^"]+)"/g, (_, id) => `id="${scoped(id)}"`).replace(/url\(#([^)]+)\)/g, (_, id) => `url(#${scoped(id)})`).replace(/\bhref="#([^"]+)"/g, (_, id) => `href="#${scoped(id)}"`);
  return /* @__PURE__ */ jsx(
    "svg",
    {
      "aria-hidden": "true",
      focusable: "false",
      "data-icon": name,
      "data-icon-missing": source ? void 0 : "",
      viewBox: "0 0 24 24",
      width: "1em",
      height: "1em",
      fill: "none",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: "1.7",
      ...props,
      dangerouslySetInnerHTML: { __html: markup }
    }
  );
}
export {
  AetherIcon,
  aetherIconNames,
  registerIconPack
};
