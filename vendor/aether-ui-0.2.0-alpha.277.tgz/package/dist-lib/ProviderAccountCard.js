import { jsx, jsxs } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import "./ProviderAccountCard.css";
function ProviderAccountCard({ name, publisher, icon, status, enabled, capabilities, account, actions, children, footer }) {
  return /* @__PURE__ */ jsxs("article", { className: "aui-provider-card", "aria-label": `${name} plugin`, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-provider-card__header", children: [
      /* @__PURE__ */ jsx("div", { className: "aui-provider-card__icon", children: icon }),
      /* @__PURE__ */ jsx("span", { className: `aui-provider-card__status${enabled ? " aui-provider-card__status--enabled" : ""}`, children: status }),
      /* @__PURE__ */ jsxs("div", { className: "aui-provider-card__identity", children: [
        /* @__PURE__ */ jsx("h2", { children: name }),
        /* @__PURE__ */ jsxs("span", { children: [
          publisher,
          " \xB7 Aether integration"
        ] })
      ] })
    ] }),
    capabilities && /* @__PURE__ */ jsx("div", { className: "aui-provider-card__capabilities", children: capabilities }),
    account && /* @__PURE__ */ jsxs("div", { className: "aui-provider-card__account", children: [
      /* @__PURE__ */ jsx("span", { className: "aui-provider-card__account-label", children: account.connected ? "Connected account" : "Not signed in" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "character" }),
        /* @__PURE__ */ jsx("span", { children: account.connected ? account.label || "Connected account" : "No account connected" }),
        account.connected && /* @__PURE__ */ jsx(AetherIcon, { name: "check" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-provider-card__actions", children: actions }),
    /* @__PURE__ */ jsx("div", { className: "aui-provider-card__details", children }),
    footer && /* @__PURE__ */ jsx("footer", { className: "aui-provider-card__footer", children: footer })
  ] });
}
export {
  ProviderAccountCard
};
