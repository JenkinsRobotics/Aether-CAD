import type { ButtonHTMLAttributes, ReactNode } from "react";
import "./IconButton.css";
export type IconButtonSize = "small" | "medium" | "large";
export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    /** Accessible name; rendered as title + aria-label. */
    label: string;
    /** Active treatment. Rounded is standard; "default" and retired "plain" are compatibility inputs that render rounded. */
    appearance?: "default" | "plain" | "rounded" | "cell" | "glyph";
    /** Desktop standard: small 28px, medium 36px, large 40px. Omit to retain host defaults. */
    size?: IconButtonSize;
    children: ReactNode;
}
/** A rounded icon command with a quiet resting surface and filled selection. */
export declare function IconButton({ label, children, className, appearance, size, ...rest }: IconButtonProps): import("react").JSX.Element;
