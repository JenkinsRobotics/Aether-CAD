import { jsx, jsxs } from "react/jsx-runtime";
import { SettingsCard, SettingsRow } from "./SettingsWindow.js";
import { NumberField } from "./NumberField.js";
import { Button } from "./Button.js";
import { DEFAULT_WORKSPACE_SPACING, setWorkspaceSpacing, useWorkspaceSpacing } from "./WorkspaceSpacing.js";
function SharedWorkspaceSettings() {
  const spacing = useWorkspaceSpacing();
  return /* @__PURE__ */ jsxs(SettingsCard, { title: "Workspace spacing", caption: "Safe areas are always active. Aether UI defaults apply automatically; custom spacing is shared across apps in this browser.", children: [
    /* @__PURE__ */ jsx(SettingsRow, { label: "Workspace margin", caption: "Space around framed content and canvas controls when an edge is clear. Default: 10 px.", children: /* @__PURE__ */ jsx(
      NumberField,
      {
        "aria-label": "Workspace margin",
        unit: "px",
        min: 0,
        max: 64,
        precision: 0,
        value: spacing.margin,
        onCommit: (margin) => setWorkspaceSpacing({ margin })
      }
    ) }),
    /* @__PURE__ */ jsx(SettingsRow, { label: "Floating control clearance", caption: "Extra space between content or canvas controls and floating toolbars or panels. Default: 22 px.", children: /* @__PURE__ */ jsx(
      NumberField,
      {
        "aria-label": "Floating control clearance",
        unit: "px",
        min: 0,
        max: 64,
        precision: 0,
        value: spacing.clearance,
        onCommit: (clearance) => setWorkspaceSpacing({ clearance })
      }
    ) }),
    /* @__PURE__ */ jsx(Button, { onClick: () => setWorkspaceSpacing(DEFAULT_WORKSPACE_SPACING), children: "Restore Aether UI defaults" })
  ] });
}
export {
  SharedWorkspaceSettings
};
