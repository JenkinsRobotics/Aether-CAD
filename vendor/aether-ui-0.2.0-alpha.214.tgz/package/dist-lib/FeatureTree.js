import { jsx } from "react/jsx-runtime";
import { useMemo, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { TreePanel } from "./TreePanel.js";
import { featureTreePanelControls } from "./feature-tree-panel-controls.js";
import { TreePanelSplit } from "./TreePanelSplit.js";
import { DEFAULT_FEATURE_GEOMETRY, FeatureTypeIcon, featureTreeActions, featureTreeMenuItems, flattenFeatureItems } from "./feature-tree.js";
import "./FeatureTree.css";
const GEOMETRY = "__feature-tree-geometry__", ROLLBACK = "__feature-tree-rollback__";
const NO_COMMANDS = [];
function FeatureTree({
  features,
  parts,
  defaultGeometry = DEFAULT_FEATURE_GEOMETRY,
  selectedIDs,
  onSelect,
  availableCommands = NO_COMMANDS,
  onCommand,
  canCommand,
  rollbackIndex,
  filter,
  onFilterChange,
  ariaLabel = "Features",
  partsLabel = "Parts",
  className = "",
  storageKey
}) {
  const [expanded, setExpanded] = useState(() => /* @__PURE__ */ new Set([
    GEOMETRY,
    ...flattenFeatureItems([...features, ...parts]).filter((item) => item.children?.length).map((item) => item.id)
  ]));
  const [localFilter, setLocalFilter] = useState("");
  const query = filter ?? localFilter;
  const [category, setCategory] = useState("all");
  const filtered = !!query || category !== "all";
  const [renaming, setRenaming] = useState(null);
  const all = useMemo(() => flattenFeatureItems([...defaultGeometry, ...features, ...parts]), [defaultGeometry, features, parts]);
  const history = useMemo(() => flattenFeatureItems(features).filter((item) => item.kind === "feature"), [features]);
  const cutoff = Math.max(0, Math.min(history.length, rollbackIndex ?? history.length));
  const get = (id) => all.find((item) => item.id === id);
  const selectedFor = (id) => selectedIDs.has(id) ? all.filter((item) => selectedIDs.has(item.id)) : all.filter((item) => item.id === id);
  const can = (request) => !(filtered && ["move", "add-to-folder", "new-folder", "rollback"].includes(request.command)) && !!onCommand && availableCommands.includes(request.command) && (canCommand?.(request) ?? true) === true;
  const dispatch = (request) => {
    if (can(request)) onCommand?.(request);
  };
  const actions = (id) => {
    const item = get(id);
    return item ? featureTreeActions(item, { selected: selectedFor(id), features, rollbackIndex: cutoff, available: onCommand ? availableCommands : NO_COMMANDS, canCommand: (request) => filtered && ["move", "add-to-folder", "new-folder", "rollback"].includes(request.command) ? "Clear the filter before changing history order." : canCommand?.(request) ?? true }) : [];
  };
  const run = (id, commandID) => {
    const action = actions(id).find((action2) => action2.item.id === commandID);
    if (!action || action.item.disabled) return;
    if (action.request.command === "rename") setRenaming(id);
    else dispatch(action.request);
  };
  function present(items) {
    return items.map((item) => {
      const index = history.findIndex((row) => row.id === item.id), rolledBack = index >= cutoff && index >= 0;
      const visibility = { command: "visibility", ids: [item.id], value: !!item.hidden };
      return {
        id: item.id,
        label: item.label,
        category: item.type,
        searchText: item.type,
        draggable: !filtered && (item.kind === "feature" || item.kind === "folder") && availableCommands.includes("move"),
        dropMode: item.kind === "folder" ? "hierarchy" : "reorder",
        icon: item.icon ?? /* @__PURE__ */ jsx(FeatureTypeIcon, { type: item.type }),
        dimmed: item.hidden || item.suppressed || rolledBack,
        tone: item.error ? "error" : void 0,
        className: ["aui-feature-tree-item", item.suppressed ? "aui-feature-tree-item--suppressed" : "", rolledBack ? "aui-feature-tree-item--rolled-back" : ""].join(" "),
        status: [...item.dimensionsShown ? [{ id: "dimensions", label: "Dimensions shown", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "ruler" }) }] : [], ...item.dynamicSuppression ? [{ id: "dynamic", label: "Dynamic suppression", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }) }] : [], ...item.suppressed ? [{ id: "suppressed", label: "Suppressed", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "pause" }) }] : [], ...rolledBack ? [{ id: "rollback", label: "Rolled back", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "history" }) }] : [], ...item.error ? [{ id: "error", label: item.error, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "status-error" }) }] : []],
        actions: can(visibility) ? [{ id: "visibility", label: `${item.hidden ? "Show" : "Hide"} ${item.label}`, icon: /* @__PURE__ */ jsx(AetherIcon, { name: item.hidden ? "hidden" : "visible" }), pinned: !!item.hidden, state: true }] : [],
        children: item.children && present(item.children)
      };
    });
  }
  const historyNodes = present(features);
  if (rollbackIndex !== void 0 && !filtered) {
    let remaining = cutoff, inserted = false;
    const line = { id: ROLLBACK, label: `Rollback: ${cutoff} of ${history.length} features`, variant: "divider", draggable: availableCommands.includes("rollback"), className: "aui-feature-tree-rollback" };
    const place = (rows) => {
      for (let i = 0; i < rows.length; i++) {
        if (rows[i].children) {
          const children = [...rows[i].children];
          place(children);
          rows[i] = { ...rows[i], children };
          if (inserted) return;
        } else if (get(rows[i].id)?.kind === "feature") {
          if (remaining === 0) {
            rows.splice(i, 0, line);
            inserted = true;
            return;
          }
          remaining--;
        }
      }
    };
    place(historyNodes);
    if (!inserted) historyNodes.push(line);
  }
  const canMove = (sourceID, targetID, position) => {
    if (filtered) return false;
    const source = get(sourceID), target = get(targetID);
    if (sourceID === ROLLBACK) return target?.kind === "feature" && position !== "inside" && can({ command: "rollback", ids: [], index: history.findIndex((row) => row.id === targetID) + (position === "after" ? 1 : 0) });
    if (!source || !target || sourceID === targetID || source.kind === "reference" || source.kind === "part" || target.kind === "reference" || target.kind === "part") return false;
    if (position === "inside" && target.kind !== "folder") return false;
    if (flattenFeatureItems(source.children ?? []).some((item) => item.id === targetID)) return false;
    return can({ command: "move", ids: [sourceID], targetID, position });
  };
  const move = (sourceID, targetID, position) => {
    if (!canMove(sourceID, targetID, position)) return;
    dispatch(sourceID === ROLLBACK ? { command: "rollback", ids: [], index: history.findIndex((row) => row.id === targetID) + (position === "after" ? 1 : 0) } : { command: "move", ids: [sourceID], targetID, position });
  };
  const selection = all.filter((item) => selectedIDs.has(item.id)), single = selection.length === 1 ? selection[0] : void 0;
  const controls = [
    { id: "new-folder", label: "New folder", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder-add" }), disabled: !can({ command: "new-folder", ids: [] }), onClick: () => dispatch({ command: "new-folder", ids: [] }) },
    { id: "rename", label: "Rename", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "pencil" }), shortcut: "F2", disabled: !single || single.kind === "reference" || !can({ command: "rename", ids: [single.id] }), onClick: () => single && setRenaming(single.id) },
    { id: "delete", label: "Delete", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "delete" }), shortcut: "Delete", disabled: !selection.length || selection.some((item) => item.kind === "reference") || !can({ command: "delete", ids: selection.map((item) => item.id) }), onClick: () => dispatch({ command: "delete", ids: selection.map((item) => item.id) }) }
  ].filter((control) => availableCommands.includes(control.id));
  const common = {
    expandedIDs: expanded,
    onToggle: (id, open) => setExpanded((current) => {
      const next = new Set(current);
      if (open) next.add(id);
      else next.delete(id);
      return next;
    }),
    selectedIDs,
    onSelect: (ids, mode) => {
      const rows = ids.filter((id) => id !== ROLLBACK && id !== GEOMETRY);
      if (rows.length) onSelect(rows, mode);
    },
    menuItems: (id) => featureTreeMenuItems(actions(id)),
    onCommand: run,
    onAction: (id) => {
      const item = get(id);
      if (item) dispatch({ command: "visibility", ids: [id], value: !!item.hidden });
    },
    onActivate: (id) => run(id, "edit"),
    renamingID: renaming,
    onCancelRename: () => setRenaming(null),
    onRename: (id, name) => {
      if (name.trim()) dispatch({ command: "rename", ids: [id], name: name.trim() });
      setRenaming(null);
    },
    controls: controls.filter((control) => control.id !== "new-folder"),
    controlsLabel: "Feature commands"
  };
  return /* @__PURE__ */ jsx("div", { className: `aui-feature-tree ${className}`, onKeyDownCapture: (event) => {
    if (!(event.target instanceof HTMLElement) || !event.target.classList.contains("aui-feature-tree-rollback")) return;
    const index = event.key === "ArrowUp" ? cutoff - 1 : event.key === "ArrowDown" ? cutoff + 1 : event.key === "Home" ? 0 : event.key === "End" ? history.length : null;
    if (index !== null) {
      event.preventDefault();
      event.stopPropagation();
      dispatch({ command: "rollback", ids: [], index: Math.max(0, Math.min(history.length, index)) });
    }
  }, children: /* @__PURE__ */ jsx(TreePanelSplit, { defaultRatio: 0.78, primaryLabel: ariaLabel, secondaryLabel: partsLabel, storageKey, primary: /* @__PURE__ */ jsx(
    TreePanel,
    {
      ...common,
      title: `Features (${history.length})`,
      ariaLabel,
      menuLabel: "Feature actions",
      filterLabel: "Filter by name or type",
      filter: query,
      onFilterChange: onFilterChange ?? setLocalFilter,
      onCategoryChange: setCategory,
      filterOptions: [...new Set(history.map((item) => item.type))].map((type) => ({ id: type, label: type.charAt(0).toUpperCase() + type.slice(1), icon: /* @__PURE__ */ jsx(FeatureTypeIcon, { type }) })),
      controls: [...controls, ...featureTreePanelControls(features, availableCommands, can, dispatch, history.length)],
      headerControls: controls.filter((control) => control.id === "new-folder"),
      nodes: [{ id: GEOMETRY, draggable: false, label: "Default geometry", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "planes-axes" }), children: present(defaultGeometry) }, ...historyNodes],
      onMove: move,
      canMove,
      emptyState: "No matching features"
    }
  ), secondary: /* @__PURE__ */ jsx(TreePanel, { ...common, controls: [...common.controls, ...featureTreePanelControls(parts, availableCommands, can, dispatch)], title: `${partsLabel} (${parts.length})`, ariaLabel: partsLabel, menuLabel: "Part actions", showFilter: false, filter: query, nodes: present(parts), emptyState: "No parts" }) }) });
}
export {
  FeatureTree
};
