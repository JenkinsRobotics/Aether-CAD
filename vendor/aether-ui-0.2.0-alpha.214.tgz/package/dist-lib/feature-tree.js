import { jsx } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { ToolIcon } from "./ToolIcon.js";
const DEFAULT_FEATURE_GEOMETRY = [
  { id: "origin", label: "Origin", kind: "reference", type: "point" },
  ...["Top", "Front", "Right"].map((label) => ({ id: label.toLowerCase(), label, kind: "reference", type: "plane" }))
];
const iconNames = {
  sketch: "sketch",
  profile: "sketch",
  revolve: "revolve",
  fillet: "fillet",
  chamfer: "chamfer",
  extrude: "extrude",
  shell: "shell",
  sweep: "sweep",
  loft: "loft",
  hole: "hole",
  mirror: "mirror",
  pattern: "pattern",
  transform: "move",
  plane: "plane",
  point: "point",
  axis: "axis",
  part: "part",
  body: "part",
  boolean: "boolean",
  draft: "draft",
  "offset-face": "offset",
  "face-extrude": "extrude",
  "import-cad": "part",
  "import-step": "part"
};
function FeatureTypeIcon({ type }) {
  if (type === "folder") return /* @__PURE__ */ jsx(AetherIcon, { name: "collection-folder" });
  return iconNames[type] ? /* @__PURE__ */ jsx(ToolIcon, { name: iconNames[type] }) : /* @__PURE__ */ jsx(AetherIcon, { name: type === "appearance" ? "appearance" : type === "lighting" ? "lighting" : "cube" });
}
const flattenFeatureItems = (items) => items.flatMap((item) => [item, ...flattenFeatureItems(item.children ?? [])]);
const isSketchFeature = (item) => item.type === "sketch" || item.type === "profile";
function featureTreeActions(item, options) {
  const { selected, available, canCommand } = options;
  const ids = selected.map((row) => row.id), single = ids.length === 1;
  const history = flattenFeatureItems(options.features).filter((row) => row.kind === "feature");
  const folders = flattenFeatureItems(options.features).filter((row) => row.kind === "folder");
  const index = history.findIndex((row) => row.id === item.id);
  const result = [];
  function add(id, label, command, icon, payload = {}, config = {}, valid = true) {
    if (!available.includes(command)) return;
    const request = { command, ids, ...payload };
    const allowed = valid ? canCommand?.(request) : void 0;
    const reason = !valid ? "Not available for this selection." : typeof allowed === "string" ? allowed : allowed === false ? "The document does not allow this action." : void 0;
    result.push({ request, item: { id, label, icon: /* @__PURE__ */ jsx(AetherIcon, { name: icon }), ...config, disabled: Boolean(reason), disabledReason: reason } });
  }
  const editable = selected.every((row) => row.kind !== "reference");
  add("rename", "Rename", "rename", "pencil", {}, { shortcut: "F2" }, single && editable);
  if (item.kind === "feature") add("edit", "Edit\u2026", "edit", "settings", {}, {}, single);
  if (isSketchFeature(item)) {
    add("copy-sketch", "Copy sketch", "copy-sketch", "copy", {}, {}, single);
    add("dimensions", item.dimensionsShown ? "Hide dimensions" : "Show dimensions", "dimensions", "ruler", { value: !item.dimensionsShown }, {}, single);
  }
  if (item.kind === "feature" || item.kind === "folder") {
    add("new-folder-selection", "Add selection to new folder", "new-folder", "folder-add", {}, {}, selected.every((row) => row.kind === "feature" || row.kind === "folder"));
    for (const folder of folders.filter((folder2) => !ids.includes(folder2.id))) add(`folder:${folder.id}`, `Move to ${folder.label}`, "add-to-folder", "collection-folder", { targetID: folder.id }, {}, selected.every((row) => row.kind === "feature" || row.kind === "folder"));
  }
  add("visibility", selected.every((row) => row.hidden) ? "Show" : "Hide", "visibility", item.hidden ? "visible" : "hidden", { value: selected.every((row) => row.hidden) }, { separatorBefore: true });
  if (isSketchFeature(item)) {
    add("hide-other-sketches", "Hide other sketches", "hide-other-sketches", "hidden", {}, {}, single);
    add("hide-all-sketches", "Hide all sketches", "hide-all-sketches", "hidden");
  }
  if (item.kind === "feature") {
    add("suppress", selected.every((row) => row.suppressed) ? "Unsuppress" : "Suppress", "suppress", "pause", { value: !selected.every((row) => row.suppressed) }, { separatorBefore: true }, selected.every((row) => row.kind === "feature"));
    add("dynamic-suppression", "Dynamic suppression\u2026", "dynamic-suppression", "settings", {}, {}, single);
  }
  add("comment", "Add comment", "comment", "comment", {}, { separatorBefore: true });
  if (isSketchFeature(item) || item.type === "plane") add("view-normal", "View normal to", "view-normal", "view", {}, {}, single);
  if (item.kind === "feature") {
    add("dependencies", "Show dependencies\u2026", "dependencies", "nodes", {}, {}, single);
    add("rollback-here", "Roll to here", "rollback", "history", { index: index + 1 }, { separatorBefore: true }, single && index >= 0);
    add("rollback-before", "Roll before", "rollback", "history", { index }, {}, single && index >= 0);
    add("rollback-end", "Roll to end", "rollback", "history", { index: history.length });
    for (const [step, label] of [[-1, "Move up"], [1, "Move down"]]) {
      const target = history[index + step];
      add(step < 0 ? "move-up" : "move-down", label, "move", step < 0 ? "chevron-up" : "chevron-down", { targetID: target?.id, position: step < 0 ? "before" : "after" }, { separatorBefore: step < 0 }, single && !!target);
    }
  }
  if (isSketchFeature(item) || item.kind === "part") add("appearance", "Edit appearance\u2026", "appearance", "appearance", {}, { separatorBefore: true }, single);
  if (item.kind !== "reference") add("delete", item.kind === "folder" ? "Dissolve folder" : "Delete", "delete", "delete", {}, { separatorBefore: true, danger: true, shortcut: "Delete" }, editable);
  return result;
}
function featureTreeMenuItems(actions) {
  const folderActions = actions.filter((action) => action.item.id === "new-folder-selection" || action.item.id.startsWith("folder:"));
  return actions.flatMap((action) => action.item.id.startsWith("folder:") ? [] : action.item.id === "new-folder-selection" ? [{ id: "folder-menu", label: "Add selection to folder\u2026", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "collection-folder" }), children: folderActions.map((entry) => entry.item) }] : [action.item]);
}
export {
  DEFAULT_FEATURE_GEOMETRY,
  FeatureTypeIcon,
  featureTreeActions,
  featureTreeMenuItems,
  flattenFeatureItems,
  isSketchFeature
};
