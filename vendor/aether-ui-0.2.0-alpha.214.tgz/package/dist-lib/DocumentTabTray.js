import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { DocumentTabBar } from "./DocumentTabBar.js";
import { DocumentTabs } from "./DocumentTabs.js";
import { Menu, MenuButton } from "./Menu.js";
import "./DocumentTabTray.css";
function assignTabFolder(folders, tabID, folderID) {
  return folders.map((folder) => ({ ...folder, tabs: [...folder.tabs.filter((id) => id !== tabID), ...folder.id === folderID ? [tabID] : []] }));
}
const documentTabAddItems = (onManage) => [{ id: "create", label: "Create new design\u2026" }, ...onManage ? [{ id: "manage", label: "Manage and import files\u2026" }] : []];
function documentTabMenu({ tabs, tabActions, onTabAction, onOrganize, onReorder, onDetach }) {
  const itemsFor = (id) => {
    const tab = tabs.find((item) => item.id === id);
    if (!tab) return [];
    const index = tabs.indexOf(tab);
    return [
      ...tabActions?.(id) ?? [],
      { id: "arrange", label: "Arrange tab", separatorBefore: Boolean(tabActions), children: [
        { id: "left", label: "Move left", disabled: index === 0 },
        { id: "right", label: "Move right", disabled: index === tabs.length - 1 },
        { id: "detach", label: "Open in separate window", disabled: id === "draft" },
        ...onOrganize ? [{ id: "organize", label: "Organize tabs\u2026" }] : []
      ] },
      ...tab.onClose ? [{ id: "close", label: "Close tab", separatorBefore: true }] : []
    ];
  };
  const choose = (id, action) => {
    const tab = tabs.find((item) => item.id === id);
    if (!tab) return;
    const index = tabs.indexOf(tab);
    if (action === "left" && index > 0) onReorder(id, tabs[index - 1].id);
    else if (action === "right" && index < tabs.length - 1) onReorder(id, tabs[index + 1].id);
    else if (action === "detach" && id !== "draft") onDetach(id);
    else if (action === "organize") onOrganize?.();
    else if (action === "close") tab.onClose?.();
    else onTabAction?.(id, action);
  };
  return { itemsFor, choose };
}
function DocumentTabTray(props) {
  const { tabs, placement, label, saveStatus, onAdd, onReorder, onDetach, onManage, folders = [], onFoldersChange, onOrganize, leading, revisionForTab, className } = props;
  const gesture = useRef(null);
  const suppressClick = useRef(false);
  const [ghost, setGhost] = useState(null);
  const current = tabs.find((tab) => tab.current);
  const saveTone = !saveStatus ? void 0 : ["Saved", "Downloaded"].includes(saveStatus) ? "saved" : ["Saving\u2026", "Saved in this tab"].includes(saveStatus) ? "pending" : "error";
  const tabAt = (element) => element?.closest("[data-document-tab-id]")?.dataset.documentTabId;
  const [context, setContext] = useState(null);
  useEffect(() => {
    if (context?.id && !tabs.some((tab) => tab.id === context.id)) setContext(null);
  }, [tabs, context]);
  const { itemsFor, choose } = documentTabMenu(props);
  const tabMenu = (id) => /* @__PURE__ */ jsx(
    MenuButton,
    {
      className: "aui-tab-menu",
      label: `Options for ${tabs.find((tab) => tab.id === id).label}`,
      placement: "top-end",
      items: itemsFor(id),
      onSelect: (action) => choose(id, action),
      children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: "rotate(90deg)" } })
    }
  );
  const openContext = (target, x, y) => {
    const id = tabAt(target);
    if (!id) {
      if (target.closest('input, textarea, [contenteditable="true"], [role="menu"]')) return false;
      const bounds2 = target.getBoundingClientRect();
      setContext({ id: null, x: x ?? bounds2.left, y: y ?? bounds2.top });
      return true;
    }
    const tab = target.closest(".aui-document-tab").querySelector('[role="tab"]');
    tab.focus();
    const bounds = tab.getBoundingClientRect();
    gesture.current = null;
    setGhost(null);
    setContext({ id, x: x ?? bounds.left, y: y ?? bounds.top });
    return true;
  };
  const presented = tabs.map((tab) => ({
    ...tab,
    // Closing remains in the per-document menu, alongside the other CAD actions.
    onClose: void 0,
    detail: [tab.detail ?? "CAD document", revisionForTab?.(tab.id).label].filter(Boolean).join(" \xB7 "),
    status: tab.current ? saveStatus : void 0,
    icon: tab.icon
  }));
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: `aui-document-tab-tray ${className ?? ""}`,
      "data-save-tone": saveTone,
      onContextMenu: (event) => {
        if (event.target instanceof Element && openContext(event.target, event.clientX, event.clientY)) {
          event.preventDefault();
          event.stopPropagation();
        }
      },
      onDragStart: (event) => event.preventDefault(),
      onPointerDown: (event) => {
        if (event.button !== 0 || !(event.target instanceof Element) || event.target.closest('.aui-document-tab-close, .aui-tab-menu, [role="menu"]')) return;
        const id = tabAt(event.target);
        if (id) {
          gesture.current = { id, x: event.clientX, y: event.clientY, dragging: false };
          suppressClick.current = false;
        }
      },
      onPointerMove: (event) => {
        const start = gesture.current;
        if (!start) return;
        if (!start.dragging && Math.hypot(event.clientX - start.x, event.clientY - start.y) < 8) return;
        start.dragging = true;
        suppressClick.current = true;
        event.currentTarget.setPointerCapture(event.pointerId);
        setGhost({ label: tabs.find((tab) => tab.id === start.id)?.label ?? "", x: event.clientX, y: event.clientY });
      },
      onPointerCancel: () => {
        gesture.current = null;
        setGhost(null);
      },
      onPointerUp: (event) => {
        const start = gesture.current;
        gesture.current = null;
        setGhost(null);
        if (!start?.dragging) return;
        setTimeout(() => {
          suppressClick.current = false;
        }, 0);
        const bounds = event.currentTarget.getBoundingClientRect();
        if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
        const hit = document.elementFromPoint(event.clientX, event.clientY);
        const target = tabAt(hit);
        const folder = hit?.closest("[data-tab-folder]")?.dataset.tabFolder;
        if (folder) onFoldersChange?.(assignTabFolder(folders, start.id, folder));
        else if (target) onFoldersChange?.(assignTabFolder(folders, start.id, ""));
        if (target && target !== start.id) onReorder(start.id, target);
        else if (event.clientY < bounds.top - 48 || event.clientY > bounds.bottom + 48) onDetach(start.id);
      },
      onClickCapture: (event) => {
        if (suppressClick.current) {
          event.preventDefault();
          event.stopPropagation();
          suppressClick.current = false;
        }
      },
      onKeyDownCapture: (event) => {
        if ((event.key === "ContextMenu" || event.shiftKey && event.key === "F10") && event.target instanceof Element && openContext(event.target)) {
          event.preventDefault();
          event.stopPropagation();
          return;
        }
        if (event.key === "Escape") {
          gesture.current = null;
          setGhost(null);
        }
        if (!event.altKey || !["ArrowLeft", "ArrowRight"].includes(event.key) || !(event.target instanceof Element)) return;
        const id = tabAt(event.target), index = tabs.findIndex((tab) => tab.id === id);
        const target = tabs[index + (event.key === "ArrowLeft" ? -1 : 1)];
        if (id && target) {
          event.preventDefault();
          event.stopPropagation();
          onReorder(id, target.id);
        }
      },
      children: [
        /* @__PURE__ */ jsx(
          DocumentTabBar,
          {
            variant: "studio",
            placement,
            ariaLabel: label,
            tabs: presented,
            addLabel: props.creation?.label ?? "Create or open a design",
            addItems: props.creation?.items ?? documentTabAddItems(onManage),
            onAdd: (id) => {
              if (props.creation) {
                props.creation.onSelect(id);
                return;
              }
              if (id === "create") onAdd();
              else if (id === "manage") onManage?.();
            },
            renderTabActions: (tab) => tabMenu(tab.id),
            renderTabs: folders.length ? (props2) => /* @__PURE__ */ jsxs("div", { className: "aui-document-tab-groups", children: [
              /* @__PURE__ */ jsx(DocumentTabs, { ...props2, tabs: props2.tabs.filter((tab) => !folders.some((folder) => folder.tabs.includes(tab.id))) }),
              folders.map((folder) => /* @__PURE__ */ jsxs("div", { className: "aui-tab-folder", "data-tab-folder": folder.id, children: [
                /* @__PURE__ */ jsxs("button", { className: "aui-tab-folder-label", "aria-expanded": !folder.collapsed, title: `${folder.name} \u2014 click to ${folder.collapsed ? "expand" : "collapse"}`, onClick: () => onFoldersChange?.(folders.map((item) => item.id === folder.id ? { ...item, collapsed: !item.collapsed } : item)), children: [
                  /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }),
                  folder.name || "Untitled folder",
                  " ",
                  /* @__PURE__ */ jsx("small", { children: tabs.filter((tab) => folder.tabs.includes(tab.id)).length })
                ] }),
                /* @__PURE__ */ jsx(DocumentTabs, { ...props2, tabs: props2.tabs.filter((tab) => folder.tabs.includes(tab.id) && (!folder.collapsed || tab.id === current?.id)) })
              ] }, folder.id))
            ] }) : void 0,
            trailing: /* @__PURE__ */ jsxs(Fragment, { children: [
              onOrganize && /* @__PURE__ */ jsx("button", { "aria-label": "Organize tabs", title: "Folder manager", onClick: onOrganize, children: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }) }),
              onManage && /* @__PURE__ */ jsx("button", { "aria-label": "Manage files", title: "Manage and import files", onClick: onManage, children: /* @__PURE__ */ jsx(AetherIcon, { name: "part-manager" }) }),
              leading
            ] })
          }
        ),
        /* @__PURE__ */ jsx(
          Menu,
          {
            open: Boolean(context),
            anchor: context,
            applicationCommands: false,
            ariaLabel: `Tab options for ${tabs.find((tab) => tab.id === context?.id)?.label ?? ""}`,
            items: context?.id ? itemsFor(context.id) : [...props.creation?.items ?? documentTabAddItems(onManage), ...onOrganize ? [{ id: "organize", label: "Organize folders\u2026" }] : []],
            onSelect: (action) => {
              if (context?.id) choose(context.id, action);
              else if (props.creation?.items.some((item) => item.id === action)) props.creation.onSelect(action);
              else if (action === "create") onAdd();
              else if (action === "manage") onManage?.();
              else if (action === "organize") onOrganize?.();
              setContext(null);
            },
            onClose: () => setContext(null)
          }
        ),
        ghost && /* @__PURE__ */ jsx("div", { className: "aui-tab-drag-preview", style: { left: ghost.x + 12, top: ghost.y - 36 }, children: ghost.label })
      ]
    }
  );
}
export {
  DocumentTabTray,
  assignTabFolder,
  documentTabAddItems,
  documentTabMenu
};
