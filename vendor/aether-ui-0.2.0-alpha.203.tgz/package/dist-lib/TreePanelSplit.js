import { jsx, jsxs } from "react/jsx-runtime";
import { useLayoutEffect, useRef, useState } from "react";
import { PanelResizeHandle } from "./PanelResizeHandle.js";
import "./TreePanelSplit.css";
const bounded = (ratio) => Math.max(0.2, Math.min(0.8, ratio));
function TreePanelSplit({ primary, secondary, primaryLabel, secondaryLabel, defaultRatio = 0.65, storageKey }) {
  const root = useRef(null);
  const [height, setHeight] = useState(600);
  useLayoutEffect(() => {
    const element = root.current;
    if (!element) return;
    const measure = () => {
      const size = element.getBoundingClientRect().height - 6;
      if (size > 0) setHeight(size);
    };
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  const initial = Number.isFinite(defaultRatio) ? bounded(defaultRatio) : 0.65;
  const [ratio, setRatio] = useState(() => {
    try {
      const saved = storageKey && localStorage.getItem(storageKey);
      return saved && Number.isFinite(Number(saved)) ? bounded(Number(saved)) : initial;
    } catch {
      return initial;
    }
  });
  const update = (value) => {
    const next = bounded(value);
    setRatio(next);
    try {
      if (storageKey) localStorage.setItem(storageKey, String(next));
    } catch {
    }
  };
  return /* @__PURE__ */ jsxs("div", { ref: root, className: "aui-tree-panel-split", style: { gridTemplateRows: `minmax(0, ${ratio}fr) 6px minmax(0, ${1 - ratio}fr)` }, children: [
    /* @__PURE__ */ jsx("section", { className: "aui-tree-panel-split-section", "aria-label": primaryLabel, children: primary }),
    /* @__PURE__ */ jsx("div", { className: "aui-tree-panel-split-divider", children: /* @__PURE__ */ jsx(
      PanelResizeHandle,
      {
        edge: "bottom",
        label: `Resize ${primaryLabel} and ${secondaryLabel}`,
        value: height * ratio,
        min: height * 0.2,
        max: height * 0.8,
        onChange: (size) => update(size / height),
        onReset: () => update(initial)
      }
    ) }),
    /* @__PURE__ */ jsx("section", { className: "aui-tree-panel-split-section", "aria-label": secondaryLabel, children: secondary })
  ] });
}
export {
  TreePanelSplit
};
