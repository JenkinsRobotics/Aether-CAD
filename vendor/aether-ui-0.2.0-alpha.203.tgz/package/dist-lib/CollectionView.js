import { jsx, jsxs } from "react/jsx-runtime";
import { createContext, useContext, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { Menu } from "./Menu.js";
import "./CollectionView.css";
const CollectionHost = createContext({});
function CollectionActions({ controls = [], primaryControls, label = "Item controls" }) {
  const host = useContext(CollectionHost), [open, setOpen] = useState(false), anchor = useRef(null);
  const unique = (items) => items.filter((item, i) => items.findIndex((other) => other.id === item.id) === i);
  const own = unique([...primaryControls ?? [], ...controls]);
  const preferred = primaryControls ?? [
    own.find((c) => /folder/i.test(c.id)),
    own.find((c) => /settings/i.test(c.id)),
    own.find((c) => !/folder/i.test(c.id) && /^(new|add|create)/i.test(c.id))
  ].filter((c) => Boolean(c));
  const primary = unique(preferred).slice(0, 2);
  const commands = unique([...own, ...host.controls ?? []]).filter((c) => !primary.some((p) => p.id === c.id));
  if (!primary.length && !commands.length) return null;
  return /* @__PURE__ */ jsxs("div", { className: "aui-collection-actions", role: "group", "aria-label": label, ref: anchor, children: [
    primary.map((control) => /* @__PURE__ */ jsx(
      IconButton,
      {
        label: control.label,
        disabled: control.disabled,
        onClick: control.onClick,
        children: control.icon
      },
      control.id
    )),
    commands.length > 0 && /* @__PURE__ */ jsx(
      IconButton,
      {
        label: `More ${label}`,
        "aria-haspopup": "menu",
        "aria-expanded": open,
        onClick: () => setOpen(!open),
        children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" })
      }
    ),
    open && commands.length > 0 && /* @__PURE__ */ jsx(
      Menu,
      {
        className: "aui-collection-popup",
        open: true,
        anchor: anchor.current,
        placement: "bottom-end",
        ariaLabel: label,
        items: commands.map((c) => ({ id: c.id, label: c.label, icon: c.icon, disabled: c.disabled, shortcut: c.shortcut, separatorBefore: c.separatorBefore })),
        onSelect: (id) => {
          commands.find((c) => c.id === id)?.onClick();
          setOpen(false);
        },
        onClose: () => setOpen(false)
      }
    )
  ] });
}
function CollectionView({ title, headerActions, filter, children, footer, controls, primaryControls, controlsLabel, className = "", id, onKeyDown }) {
  const host = useContext(CollectionHost);
  return /* @__PURE__ */ jsxs("div", { id, className: `aui-collection ${className}`, onKeyDown, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-collection-heading", children: [
      /* @__PURE__ */ jsx("strong", { children: title ?? host.title ?? "Items" }),
      /* @__PURE__ */ jsxs("span", { className: "aui-collection-heading-actions", children: [
        headerActions,
        /* @__PURE__ */ jsx(CollectionActions, { controls, primaryControls, label: controlsLabel })
      ] })
    ] }),
    filter && /* @__PURE__ */ jsx("div", { className: "aui-collection-search", children: filter }),
    children,
    footer
  ] });
}
export {
  CollectionActions,
  CollectionHost,
  CollectionView
};
