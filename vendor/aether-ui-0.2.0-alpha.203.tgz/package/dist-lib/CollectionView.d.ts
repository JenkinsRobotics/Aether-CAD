import { type ReactNode } from 'react';
import './CollectionView.css';
export interface CollectionControl {
    id: string;
    label: string;
    icon: ReactNode;
    disabled?: boolean;
    separatorBefore?: boolean;
    shortcut?: 'Delete' | 'F2';
    onClick: () => void;
}
/** Docking remains owned by WorkspaceShell; its commands join the collection menu. */
export declare const CollectionHost: import("react").Context<{
    title?: string;
    controls?: readonly CollectionControl[];
}>;
/** One command location for every collection: two primary buttons and overflow. */
export declare function CollectionActions({ controls, primaryControls, label }: {
    controls?: readonly CollectionControl[];
    primaryControls?: readonly CollectionControl[];
    label?: string;
}): import("react").JSX.Element | null;
export declare function CollectionView({ title, headerActions, filter, children, footer, controls, primaryControls, controlsLabel, className, id, onKeyDown }: {
    title?: string;
    headerActions?: ReactNode;
    filter?: ReactNode;
    children: ReactNode;
    footer?: ReactNode;
    controls?: readonly CollectionControl[];
    primaryControls?: readonly CollectionControl[];
    controlsLabel?: string;
    className?: string;
    id?: string;
    onKeyDown?: React.KeyboardEventHandler<HTMLDivElement>;
}): import("react").JSX.Element;
