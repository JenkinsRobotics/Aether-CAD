import { type ReactNode, type RefObject } from "react";
import { type CollectionFilterOption } from "./CollectionFilter.js";
import { type MenuItem } from "./Menu.js";
import { type TreeNode, type TreeProps } from "./Tree.js";
import "./TreePanel.css";
export interface TreeControl {
    id: string;
    label: string;
    icon: ReactNode;
    disabled?: boolean;
    separatorBefore?: boolean;
    shortcut?: "Delete" | "F2";
    onClick: () => void;
}
/** Shared commands act on the selection; row controls describe that row's state. */
export declare function TreeToolbar({ label, controls }: {
    label: string;
    controls: readonly TreeControl[];
}): import("react").JSX.Element;
export interface TreePanelProps extends TreeProps {
    id?: string;
    title?: string;
    headerActions?: ReactNode;
    /** Common tree commands promoted beside the collection heading. */
    headerControls?: readonly TreeControl[];
    showFilter?: boolean;
    /** @deprecated Collection commands now always live in the header. */
    showFooter?: boolean;
    filterOptions?: readonly CollectionFilterOption[];
    /** Reports type filtering so hosts can disable ambiguous ordering commands. */
    onCategoryChange?: (category: string) => void;
    /** Rows the filter is showing, announced beside the field. */
    filterResultCount?: number;
    onFilterChange?: (query: string) => void;
    filterInputRef?: RefObject<HTMLInputElement | null>;
    filterInputID?: string;
    filterLabel?: string;
    controls?: readonly TreeControl[];
    controlsLabel?: string;
    /** Re-evaluated while open so visibility/lock commands always reflect current state. */
    menuItems?: (id: string) => readonly MenuItem[];
    onCommand?: (nodeID: string, commandID: string) => void;
    menuLabel?: string;
    /** A related collection (for example bodies), below the primary tree. */
    secondary?: ReactNode;
}
/** The suite's authoring-tree panel: one scroll area, state rows, context menu and header commands. */
export declare function TreePanel({ id, controls, controlsLabel, menuItems, onCommand, filterResultCount, menuLabel, secondary, className, nodes, onContextMenu, onSelect, selectedIDs, title, headerActions, headerControls, showFilter, showFooter: _showFooter, filterOptions, onCategoryChange, onFilterChange, filterInputRef, filterInputID, filterLabel, filter, ...tree }: TreePanelProps): import("react").JSX.Element;
/** Type filters retain ancestors, so search results never imply a different hierarchy. */
export declare function filterTreeCategory(nodes: readonly TreeNode[], category: string): TreeNode[];
