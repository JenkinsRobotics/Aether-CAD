import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ToolHelp } from "./ToolHelp.js";
import { contextTargetAt, contextCommandsFor, contextCommandItems, runContextCommand } from "./context-commands.js";
import { createPortal } from "react-dom";
import { AetherIcon } from "./AetherIcon.js";
import { useOverlayHost } from "./OverlayScope.js";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  useOverlayPosition
} from "./overlay-position.js";
function menuRole(item) {
  if (item.kind === "checkbox") return "menuitemcheckbox";
  if (item.kind === "radio") return "menuitemradio";
  return "menuitem";
}
function Menu({
  open,
  anchor,
  items,
  onSelect,
  onClose,
  ariaLabel,
  placement = "bottom-start",
  returnFocus = true,
  className,
  style,
  applicationCommands = true,
  density = "compact"
}) {
  const contextTarget = applicationCommands ? contextTargetAt(anchor) : null;
  const commands = contextTarget ? contextCommandsFor(contextTarget).filter((c) => !items.some((item) => item.label === c.label)) : [];
  const displayedItems = commands.length ? [
    ...items,
    ...contextCommandItems(commands).map((item, index) => index === 0 ? { ...item, separatorBefore: items.length > 0 } : item)
  ] : items;
  const choose = (id) => {
    const command = commands.find((c) => `aether:${c.id}` === id);
    if (command) runContextCommand(command);
    else onSelect(id);
  };
  const overlayHost = useOverlayHost();
  const rootRef = useRef(null);
  const returnFocusRef = useRef(null);
  const [expandedIDs, setExpandedIDs] = useState(/* @__PURE__ */ new Set());
  const leaveTimer = useRef(null);
  const cancelLeave = () => {
    if (leaveTimer.current !== null) clearTimeout(leaveTimer.current);
    leaveTimer.current = null;
  };
  useEffect(() => {
    if (!open) cancelLeave();
    return cancelLeave;
  }, [open]);
  const branchFor = (id, entries = displayedItems, parents = []) => {
    for (const entry of entries) {
      if (entry.id === id) return [...parents, id];
      const found = entry.children && branchFor(id, entry.children, [...parents, entry.id]);
      if (found) return found;
    }
  };
  const position = useOverlayPosition({
    open,
    overlayRef: rootRef,
    anchor,
    placement
  });
  useLayoutEffect(() => {
    if (!open || position.visibility !== "visible") return;
    returnFocusRef.current = anchor instanceof HTMLElement && anchor.tabIndex >= 0 ? anchor : document.activeElement;
    setExpandedIDs(/* @__PURE__ */ new Set());
    rootRef.current?.querySelector(".aui-menu-item:not(:disabled)")?.focus();
  }, [anchor, open, position.visibility]);
  useEffect(() => {
    if (!open) return;
    const onDocumentKeyDown = (event) => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      event.stopPropagation();
      onClose();
    };
    const onPointerDown = (event) => {
      const target = event.target;
      if (rootRef.current?.contains(target)) return;
      if (anchor instanceof HTMLElement && anchor.contains(target)) return;
      onClose();
    };
    document.addEventListener("keydown", onDocumentKeyDown, true);
    document.addEventListener("pointerdown", onPointerDown, true);
    return () => {
      document.removeEventListener("keydown", onDocumentKeyDown, true);
      document.removeEventListener("pointerdown", onPointerDown, true);
      const focused = document.activeElement;
      if (returnFocus && (!focused || focused === document.body || rootRef.current?.contains(focused))) {
        returnFocusRef.current?.focus?.();
      }
      returnFocusRef.current = null;
    };
  }, [anchor, onClose, open, returnFocus]);
  const buttonsIn = (list) => Array.from(list.children).map((child) => child.querySelector(":scope > .aui-menu-item")).filter((button) => Boolean(button && !button.disabled));
  const onKeyDown = (event) => {
    const target = event.target.closest(
      ".aui-menu-item"
    );
    if (!target) return;
    const list = target.closest('[role="menu"]');
    if (!list) return;
    const buttons = buttonsIn(list);
    const index = buttons.indexOf(target);
    const focusAt = (next) => buttons[next]?.focus();
    switch (event.key) {
      case "ArrowDown":
        focusAt((index + 1) % buttons.length);
        break;
      case "ArrowUp":
        focusAt((index - 1 + buttons.length) % buttons.length);
        break;
      case "Home":
        focusAt(0);
        break;
      case "End":
        focusAt(buttons.length - 1);
        break;
      case "ArrowRight": {
        const id = target.dataset.menuItemId;
        if (!id || target.getAttribute("aria-haspopup") !== "menu") return;
        cancelLeave();
        setExpandedIDs(new Set(branchFor(id)));
        queueMicrotask(() => {
          const submenu = Array.from(
            rootRef.current?.querySelectorAll("[data-menu-parent]") ?? []
          ).find((candidate) => candidate.dataset.menuParent === id);
          submenu?.querySelector(".aui-menu-item:not(:disabled)")?.focus();
        });
        break;
      }
      case "ArrowLeft": {
        const parentID = list.dataset.menuParent;
        if (!parentID) return;
        setExpandedIDs((current) => {
          const next = new Set(current);
          next.delete(parentID);
          return next;
        });
        Array.from(
          rootRef.current?.querySelectorAll("[data-menu-item-id]") ?? []
        ).find((candidate) => candidate.dataset.menuItemId === parentID)?.focus();
        break;
      }
      case "Enter":
      case " ":
        target.click();
        break;
      case "Escape":
        onClose();
        break;
      default:
        return;
    }
    event.preventDefault();
    event.stopPropagation();
  };
  const renderItems = (menuItems, parentID, parents = []) => /* @__PURE__ */ jsx(
    "ul",
    {
      "data-density": density,
      className: [parentID ? "aui-menu aui-menu-submenu" : "aui-menu", className].filter(Boolean).join(" "),
      role: "menu",
      "aria-label": parentID ? void 0 : ariaLabel,
      "data-menu-parent": parentID,
      onKeyDown,
      ref: parentID ? void 0 : rootRef,
      style: parentID ? void 0 : { ...position, ...style },
      children: menuItems.map((item) => {
        const hasChildren = Boolean(item.children?.length);
        const expanded = hasChildren && expandedIDs.has(item.id);
        const classes = ["aui-menu-item"];
        if (item.danger) classes.push("aui-menu-item--danger");
        return /* @__PURE__ */ jsxs(
          "li",
          {
            className: "aui-menu-entry",
            role: "none",
            onMouseEnter: cancelLeave,
            onMouseLeave: () => {
              cancelLeave();
              leaveTimer.current = setTimeout(() => setExpandedIDs(new Set(parents)), 160);
            },
            children: [
              item.separatorBefore ? /* @__PURE__ */ jsx("div", { className: "aui-menu-separator", role: "separator" }) : null,
              item.heading ? /* @__PURE__ */ jsx("div", { className: "aui-menu-heading", role: "presentation", children: item.heading }) : null,
              /* @__PURE__ */ jsx(ToolHelp, { label: item.label, help: item.help, disabledReason: item.disabled ? item.disabledReason : void 0, children: /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  className: classes.join(" "),
                  role: menuRole(item),
                  "aria-checked": item.kind && item.kind !== "command" ? Boolean(item.checked) : void 0,
                  "aria-haspopup": hasChildren ? "menu" : void 0,
                  "aria-expanded": hasChildren ? expanded : void 0,
                  disabled: item.disabled,
                  title: !item.help && item.disabled ? item.disabledReason : void 0,
                  "data-menu-item-id": item.id,
                  onMouseEnter: () => {
                    cancelLeave();
                    setExpandedIDs(new Set(hasChildren && !item.disabled ? [...parents, item.id] : parents));
                  },
                  onClick: () => {
                    cancelLeave();
                    if (hasChildren) {
                      setExpandedIDs(/* @__PURE__ */ new Set([...parents, item.id]));
                      return;
                    }
                    choose(item.id);
                    onClose();
                  },
                  children: [
                    /* @__PURE__ */ jsx("span", { className: "aui-menu-check", "aria-hidden": true, children: item.checked && (item.kind === "radio" || item.kind === "checkbox") ? /* @__PURE__ */ jsx(AetherIcon, { name: "check" }) : "" }),
                    /* @__PURE__ */ jsx("span", { className: "aui-menu-icon", "aria-hidden": true, children: item.icon ?? "" }),
                    /* @__PURE__ */ jsx("span", { className: "aui-menu-label", children: item.label }),
                    /* @__PURE__ */ jsx("span", { className: "aui-menu-shortcut", children: item.shortcut ?? "" }),
                    /* @__PURE__ */ jsx("span", { className: "aui-menu-arrow", "aria-hidden": true, children: hasChildren ? "\u203A" : "" })
                  ]
                }
              ) }),
              expanded && item.children ? renderItems(item.children, item.id, [...parents, item.id]) : null
            ]
          },
          item.id
        );
      })
    }
  );
  if (!open || !anchor || typeof document === "undefined") return null;
  return createPortal(renderItems(displayedItems), overlayHost ?? document.body);
}
function MenuButton({
  label,
  items,
  onSelect,
  children,
  placement = "bottom-end",
  anchorTo = "trigger",
  density = "compact",
  className,
  ...buttonProps
}) {
  const anchorRef = useRef(null);
  const [open, setOpen] = useState(false);
  const classes = ["aui-menu-trigger"];
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        ...buttonProps,
        ref: anchorRef,
        type: "button",
        className: classes.join(" "),
        "aria-label": label,
        title: label,
        "aria-haspopup": "menu",
        "aria-expanded": open,
        onClick: () => setOpen((current) => !current),
        children
      }
    ),
    /* @__PURE__ */ jsx(
      Menu,
      {
        open,
        anchor: anchorTo === "group" ? anchorRef.current?.parentElement ?? anchorRef.current : anchorRef.current,
        items,
        onSelect,
        onClose: () => setOpen(false),
        ariaLabel: label,
        placement,
        density
      }
    )
  ] });
}
export {
  Menu,
  MenuButton
};
