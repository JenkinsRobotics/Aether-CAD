import { type ReactNode } from "react";
import "./TreePanelSplit.css";
export interface TreePanelSplitProps {
    primary: ReactNode;
    secondary: ReactNode;
    primaryLabel: string;
    secondaryLabel: string;
    /** Fraction of available height assigned to the first collection. */
    defaultRatio?: number;
    storageKey?: string;
}
/** Two independently scrolling collections sharing one card and a movable divider. */
export declare function TreePanelSplit({ primary, secondary, primaryLabel, secondaryLabel, defaultRatio, storageKey }: TreePanelSplitProps): import("react").JSX.Element;
