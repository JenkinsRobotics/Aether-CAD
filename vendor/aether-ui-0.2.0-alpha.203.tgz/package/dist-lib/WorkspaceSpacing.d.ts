export interface WorkspaceSpacing {
    margin: number;
    clearance: number;
}
export declare const DEFAULT_WORKSPACE_SPACING: Readonly<WorkspaceSpacing>;
export declare function readWorkspaceSpacing(raw: string | null): WorkspaceSpacing;
export declare function setWorkspaceSpacing(patch: Partial<WorkspaceSpacing>): void;
export declare function useWorkspaceSpacing(): WorkspaceSpacing;
