import { type ToolHelpContent } from "./ToolHelp.js";
import { type ReactNode } from "react";
import { type MenuItem } from "./Menu.js";
import type { FloatingToolbarAction } from "./FloatingToolbar.js";
import { type TabDefinition } from "./Tabs.js";
import "./WorkspaceRibbon.css";
export interface WorkspaceRibbonWorkspace {
    id: string;
    label: string;
    icon?: ReactNode;
    disabled?: boolean;
    disabledReason?: string;
}
export interface WorkspaceRibbonCommand {
    help?: ToolHelpContent;
    id: string;
    label: string;
    icon: ReactNode;
    active?: boolean;
    disabled?: boolean;
    disabledReason?: string;
    /**
     * Related commands that share this button: a caret beside it picks which,
     * and the button then shows the one picked. Onshape's Line / Midpoint line,
     * the rectangle kinds and the five arcs all work this way, and so do Aether
     * Map's rectangle and ellipse pairs.
     *
     * The button keeps the family's own `id`, so it has one stable identity
     * whichever variant is showing; `selectedVariantID` says which that is, and
     * the app gives the button the current variant's label and icon. Choosing
     * from the caret reports the variant's id; clicking the button reports the
     * family's, and the app runs whatever it currently means.
     */
    variants?: readonly WorkspaceRibbonCommand[];
    /** Which variant the button is showing; defaults to the command's own id. */
    selectedVariantID?: string;
}
export interface WorkspaceRibbonGroup {
    id: string;
    label: string;
    tools: readonly WorkspaceRibbonCommand[];
    /** Optional full command list; otherwise the caption menu lists the tools. */
    menuItems?: readonly MenuItem[];
}
export interface WorkspaceRibbonTab extends TabDefinition {
    groups: readonly WorkspaceRibbonGroup[];
}
/**
 * Where the workspace selector sits, and what it looks like.
 *
 * "strip" puts it in the tab strip as another set of tabs. "column" gives it a
 * button in a column of its own at the far left, spanning both rows, with the
 * tool tabs above the tools to its right — Fusion's arrangement, and the more
 * honest one: a workspace is not a peer of the tool tabs, because choosing one
 * changes which tool tabs exist.
 */
export type WorkspaceRibbonLayout = "strip" | "column" | "none";
/**
 * "panel" is the flat, in-page ribbon this component has always drawn.
 * "glass" is the floating concept look from Jonathan's 2026-09-23 render: a
 * translucent rounded slab, the workspace as a boxed column, pill tabs,
 * icon-only tool groups under their captions, and a glowing active tool. Tool
 * labels stay in the DOM for assistive tech; only their paint changes.
 */
export type WorkspaceRibbonAppearance = "panel" | "glass";
export interface WorkspaceRibbonProps {
    /** Inherits WorkspaceShell's layout by default. Docked toolbars span their host. */
    docked?: boolean;
    workspaces: readonly WorkspaceRibbonWorkspace[];
    workspaceID: string;
    onWorkspaceSelect: (id: string) => void;
    tabs: readonly WorkspaceRibbonTab[];
    /** Optional tabless icon strip used only at compact density. */
    compactGroups?: readonly WorkspaceRibbonGroup[];
    /** Keep every command as a direct icon in the compact studio tray. */
    compactTools?: boolean;
    activeTabID: string;
    onTabSelect: (id: string) => void;
    onCommand: (id: string) => void;
    /**
     * A variant chosen from a split tool's caret. Distinct from `onCommand`
     * because a family and its own first variant share an id: clicking the
     * button means "run whatever this is", while choosing from the caret means
     * "make it this one". Without it, the caret reports through `onCommand`.
     */
    onVariantSelect?: (commandID: string, variantID: string) => void;
    /** Defaults to the standard workspace selector column; none omits navigation when the host provides it. */
    workspaceLayout?: WorkspaceRibbonLayout;
    /** Defaults to the standard glass appearance; panel is an explicit variant. */
    appearance?: WorkspaceRibbonAppearance;
    /** Extra entries for the trailing "•••" menu, after the density choices — overflow, customisation, resets. */
    moreItems?: readonly MenuItem[];
    /** Accessible name of the "•••" menu. */
    moreLabel?: string;
    /** Suggested commands shown as toned chips at the right of the Studio tool bar's Command field. */
    commandShortcuts?: readonly FloatingToolbarAction[];
    /** Design review: also show the classic ribbon (tabs, workspace and "•••" density menu) with the Studio tool bar. */
    withClassicRibbon?: boolean;
    /** Controlled density; otherwise the ribbon keeps its own, starting at `defaultDensity`. */
    density?: WorkspaceRibbonDensity;
    defaultDensity?: WorkspaceRibbonDensity;
    onDensityChange?: (density: WorkspaceRibbonDensity) => void;
}
/**
 * The same three densities as the kit tool sidebar, chosen from the "•••"
 * menu: Compact collapses each group to one icon that opens its tools;
 * Standard shows the grouped tools under their captions; Expanded adds the
 * workspace column (the concept render). Jonathan, 2026-09-24: both toolbars
 * are equivalent.
 */
export type WorkspaceRibbonDensity = "compact" | "standard" | "expanded";
export declare const WORKSPACE_RIBBON_DENSITIES: readonly {
    id: WorkspaceRibbonDensity;
    label: string;
}[];
/** Controlled workspace selector, tab strip, and grouped command ribbon.
 * Commands and workspace semantics remain with the consuming application. */
export declare function WorkspaceRibbon({ workspaces, workspaceID, onWorkspaceSelect, tabs, compactGroups, compactTools, activeTabID, onTabSelect, onCommand, onVariantSelect, workspaceLayout: appWorkspaceLayout, appearance: appAppearance, moreItems, moreLabel, density: controlledDensity, defaultDensity, onDensityChange, docked, commandShortcuts, withClassicRibbon, }: WorkspaceRibbonProps): import("react").JSX.Element;
