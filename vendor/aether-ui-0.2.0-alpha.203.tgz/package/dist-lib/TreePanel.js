import { jsx, jsxs } from "react/jsx-runtime";
import { useMemo, useState } from "react";
import { CollectionView, CollectionActions } from "./CollectionView.js";
import { CollectionFilter } from "./CollectionFilter.js";
import { Menu } from "./Menu.js";
import { Tree } from "./Tree.js";
import "./TreePanel.css";
function TreeToolbar({ label, controls }) {
  return /* @__PURE__ */ jsx(CollectionActions, { label, controls });
}
function stateRows(nodes) {
  return nodes.map((node) => ({
    ...node,
    // Commands remain in the header/menu; only explicit state controls stay on rows.
    actions: node.actions?.filter((action) => action.pinned || action.state),
    children: node.children && stateRows(node.children)
  }));
}
function TreePanel({
  id,
  controls = [],
  controlsLabel = "Tree controls",
  menuItems,
  onCommand,
  filterResultCount,
  menuLabel = "Item options",
  secondary,
  className,
  nodes,
  onContextMenu,
  onSelect,
  selectedIDs,
  title,
  headerActions,
  headerControls,
  showFilter = true,
  showFooter: _showFooter,
  filterOptions,
  onCategoryChange,
  onFilterChange,
  filterInputRef,
  filterInputID,
  filterLabel,
  filter,
  ...tree
}) {
  const [query, setQuery] = useState(""), [category, setCategory] = useState("all");
  const effectiveQuery = onFilterChange ? filter ?? "" : query;
  const [menu, setMenu] = useState(null);
  const itemsFor = (id2) => {
    if (menuItems) return menuItems(id2);
    const find = (rows) => {
      for (const row of rows) {
        if (row.id === id2) return row;
        const child = row.children && find(row.children);
        if (child) return child;
      }
    };
    return find(nodes)?.actions?.map((action) => ({ id: action.id, label: action.label, icon: action.icon })) ?? [];
  };
  const presentation = useMemo(() => stateRows(filterTreeCategory(nodes, category)), [nodes, category]);
  const expanded = category === "all" ? tree.expandedIDs : new Set(allBranchIDs(presentation));
  return /* @__PURE__ */ jsxs(
    CollectionView,
    {
      id,
      title: title ?? tree.ariaLabel,
      headerActions,
      controls,
      primaryControls: headerControls,
      controlsLabel,
      className: ["aui-tree-panel", className].filter(Boolean).join(" "),
      filter: showFilter && /* @__PURE__ */ jsx(
        CollectionFilter,
        {
          query: effectiveQuery,
          onQueryChange: onFilterChange ?? setQuery,
          options: filterOptions,
          resultCount: filterResultCount,
          value: category,
          onChange: (value) => {
            setCategory(value);
            onCategoryChange?.(value);
          },
          ariaLabel: filterLabel ?? `Search ${tree.ariaLabel ?? "Items"}`,
          inputRef: filterInputRef,
          inputID: filterInputID
        }
      ),
      onKeyDown: (event) => {
        if (event.defaultPrevented) return;
        if (!(event.target instanceof HTMLElement) || !event.target.matches('[role="treeitem"][aria-selected="true"]')) return;
        const key = event.key === "Backspace" ? "Delete" : event.key;
        const control = controls.find((entry) => entry.shortcut === key && !entry.disabled);
        if (control && !event.metaKey && !event.ctrlKey && !event.altKey) {
          event.preventDefault();
          event.stopPropagation();
          control.onClick();
        }
      },
      children: [
        /* @__PURE__ */ jsx("div", { className: "aui-tree-panel-content", children: /* @__PURE__ */ jsx(
          Tree,
          {
            ...tree,
            rootInset: tree.rootInset ?? 7,
            rowHeight: tree.rowHeight ?? 24,
            expandedIDs: expanded,
            filter: effectiveQuery || filter,
            nodes: presentation,
            selectedIDs,
            onSelect,
            onContextMenu: (id2, x, y) => {
              if (!selectedIDs.has(id2)) onSelect([id2], "single");
              if (itemsFor(id2).length) setMenu({ id: id2, x, y });
              onContextMenu?.(id2, x, y);
            }
          }
        ) }),
        secondary && /* @__PURE__ */ jsx("div", { className: "aui-tree-panel-secondary", children: secondary }),
        menu && /* @__PURE__ */ jsx(
          Menu,
          {
            className: "aui-collection-popup",
            open: true,
            anchor: { x: menu.x, y: menu.y },
            ariaLabel: menuLabel,
            items: itemsFor(menu.id),
            onClose: () => setMenu(null),
            onSelect: (id2) => {
              (onCommand ?? tree.onAction)?.(menu.id, id2);
              setMenu(null);
            }
          }
        )
      ]
    }
  );
}
function allBranchIDs(nodes) {
  return nodes.flatMap((n) => n.children?.length ? [n.id, ...allBranchIDs(n.children)] : []);
}
function filterTreeCategory(nodes, category) {
  if (category === "all") return [...nodes];
  return nodes.flatMap((node) => {
    const children = node.children && filterTreeCategory(node.children, category);
    return node.category === category || children?.length ? [{ ...node, children }] : [];
  });
}
export {
  TreePanel,
  TreeToolbar,
  filterTreeCategory
};
