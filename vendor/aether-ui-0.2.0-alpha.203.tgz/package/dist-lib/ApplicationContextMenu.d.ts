/** Fallback for the whole application, including chrome, empty space and fields.
 * Existing item menus prevent default themselves and retain their own actions. */
export declare function ApplicationContextMenu({ name, enabled }: {
    name: string;
    enabled?: boolean;
}): import("react").JSX.Element;
