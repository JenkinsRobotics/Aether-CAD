"""Portable Drawing envelopes; CAD validates drawing features and source geometry."""
import copy
from .aether_workspace import AetherWorkspaceError


def drawing_entry(key, name, document):
    if (not isinstance(document, dict) or document.get("format") != "aether-drawing"
            or type(document.get("formatVersion")) is not int
            or document["formatVersion"] not in (1, 2)):
        raise AetherWorkspaceError("format_error", "Unsupported Drawing document.")
    if not isinstance(key, str) or not key or not isinstance(name, str) or not name.strip():
        raise AetherWorkspaceError("format_error", "Drawing requires an ID and name.")
    return {"id": key, "name": name, "document": {**copy.deepcopy(document), "documentId": key, "name": name}}


def read_drawings(entries, version):
    if not isinstance(entries, list) or len(entries) > 256 or (entries and version < 3):
        raise AetherWorkspaceError("format_error", "Invalid Drawing collection or graph version.")
    result = {}
    for entry in entries:
        if not isinstance(entry, dict) or not isinstance(entry.get("id"), str) or entry["id"] in result:
            raise AetherWorkspaceError("format_error", "Invalid or duplicate Drawing ID.")
        value = drawing_entry(entry["id"], entry.get("name"), entry.get("document"))
        if value["document"] != entry["document"]:
            raise AetherWorkspaceError("format_error", "Drawing identity differs from its container entry.")
        result[value["id"]] = value
    return result


def requires_drawing_reader(workspace):
    deleted = workspace.document_settings.get("deletedItems", {})
    return bool(workspace.drawings or (isinstance(deleted, dict) and any(
        isinstance(item, dict) and item.get("kind") == "drawing" for item in deleted.values()
    )))
