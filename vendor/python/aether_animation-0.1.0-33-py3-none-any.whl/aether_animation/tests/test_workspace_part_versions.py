"""The portable container retains CAD records without interpreting geometry."""
import copy

import pytest

from aether_animation.aether_project import edit_project, new_project
from aether_animation.aether_workspace import AetherWorkspace, AetherWorkspaceError


@pytest.mark.parametrize("version", [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29])
def test_part_feature_version_roundtrip(version):
    workspace = new_project("Part versions")
    document = {"format": "aether-part", "formatVersion": version, "features": [
        {"id": "pad", "type": "extrude", "directionVector": [0.6, 0, 0.8],
         "secondEnd": {"endType": "blind", "distanceMillimeters": 2}}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    original = copy.deepcopy(workspace.part_definitions)
    raw = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(raw)
    assert reopened.part_definitions == original
    assert reopened.to_bytes()[0] == raw


@pytest.mark.parametrize("version", [None, True, "3", 0, -1, 2.0, 30, 999])
def test_unsupported_embedded_part_version_is_not_interpreted(version):
    workspace = new_project("Part versions")
    with pytest.raises(AetherWorkspaceError, match="invalid authored Part projection"):
        edit_project(workspace, "add_part", {"name": "Part", "document": {
            "format": "aether-part", "formatVersion": version, "features": []}})


def test_part22_distance_side_intent_is_retained_without_interpretation():
    workspace = new_project("Distance intent")
    document = {"format": "aether-part", "formatVersion": 22, "features": [
        {"id": "sketch", "type": "profile", "profile": {"type": "drawing",
         "contours": [], "constraints": [{"id": "gap", "kind": "distance",
         "value": 5, "distanceSide": -1, "a": {"kind": "point", "contour": 0},
         "b": {"kind": "line", "contour": -1, "projectedContourId": "rail"}}]}}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    original = copy.deepcopy(workspace.part_definitions)
    raw = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(raw)
    assert reopened.part_definitions == original
    assert reopened.to_bytes()[0] == raw


def test_part23_surface_extents_and_merge_scope_are_retained_without_interpretation():
    workspace = new_project("Surface extrusion")
    document = {"format": "aether-part", "formatVersion": 23, "features": [
        {"id": "surface", "type": "surface-extrude", "operation": "add",
         "profileFeatureId": "sketch", "profileSelections": [
             {"profileFeatureId": "sketch", "profileContourId": "curve"}],
         "directionVector": [0, 0.6, 0.8], "startingOffsetMillimeters": 2,
         "endType": "up-to-part", "endPartId": "stop", "endOffsetMillimeters": -3,
         "targetBodyIds": ["first", "second"],
         "secondEnd": {"endType": "blind", "distanceMillimeters": 4}}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    original = copy.deepcopy(workspace.part_definitions)
    raw = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(raw)
    assert reopened.part_definitions == original
    assert reopened.to_bytes()[0] == raw


def test_part24_extrusion_output_identity_survives_primary_profile_removal():
    workspace = new_project("Extrude output identity")
    document = {"format": "aether-part", "formatVersion": 24, "features": [
        {"id": "extrude", "type": "extrude", "operation": "new",
         "profileFeatureId": "second", "outputProfileId": "original",
         "profileSelections": [{"profileFeatureId": "second", "profileContourId": "circle"}],
         "separateBodies": True, "bodyOutputs": ["stable-output"]}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    original = copy.deepcopy(workspace.part_definitions)
    raw = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(raw)
    assert reopened.part_definitions == original
    assert reopened.to_bytes()[0] == raw


def test_part25_independent_surface_outputs_are_preserved():
    workspace = new_project("Surface outputs")
    document = {"format": "aether-part", "formatVersion": 25, "features": [
        {"id": "surface", "type": "surface-extrude", "operation": "new",
         "profileFeatureId": "second", "outputProfileId": "original",
         "profileSelections": [{"profileFeatureId": "second", "profileContourId": "curve"}],
         "separateBodies": True, "bodyOutputs": ["part:surface-stable"]}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    original = copy.deepcopy(workspace.part_definitions)
    raw = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(raw)
    assert reopened.part_definitions == original
    assert reopened.to_bytes()[0] == raw


def test_part26_connected_surface_groups_are_preserved():
    workspace = new_project("Surface Add groups")
    document = {"format": "aether-part", "formatVersion": 26, "features": [
        {"id": "surface", "type": "surface-extrude", "operation": "add", "connectedMerge": True,
         "targetBodyId": "a", "targetBodyIds": ["a", "b"], "scopeResolution": {
             "targets": ["a", "b"], "groups": [{"bodyId": "a", "sources": ["a"]}, {"bodyId": "b", "sources": ["b"]}]}}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    original = copy.deepcopy(workspace.part_definitions)
    raw = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(raw)
    assert reopened.part_definitions == original
    assert reopened.to_bytes()[0] == raw


@pytest.mark.parametrize("reference", [
    {"kind": "axis", "sourceFeatureId": "axis", "label": "Axis"},
    {"kind": "solid-edge", "sourceFeatureId": "guide", "bodyId": "guide-body", "label": "Guide edge",
     "anchor": {"start": {"signature": "a", "positionMillimeters": [0, 0, 0]},
                "end": {"signature": "b", "positionMillimeters": [3, 0, 4]}}},
])
def test_part27_native_extrude_direction_references_are_preserved(reference):
    workspace = new_project("Extrude direction")
    document = {"format": "aether-part", "formatVersion": 27, "features": [
        {"id": "extrude", "type": "extrude", "directionReference": reference}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    original = copy.deepcopy(workspace.part_definitions)
    raw = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(raw)
    assert reopened.part_definitions == original
    assert reopened.to_bytes()[0] == raw


@pytest.mark.parametrize("surface", ["cylinder", "cone"])
def test_part28_native_face_axis_reference_is_preserved(surface):
    workspace = new_project("Extrude face axis")
    document = {"format": "aether-part", "formatVersion": 28, "features": [
        {"id": "extrude", "type": "extrude", "directionReference": {
            "kind": "face-axis", "sourceFeatureId": "guide", "bodyId": "guide-body",
            "surfaceType": surface, "label": "Guide axis"}}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    original = copy.deepcopy(workspace.part_definitions)
    raw = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(raw)
    assert reopened.part_definitions == original
    assert reopened.to_bytes()[0] == raw


def test_part29_revolve_intersection_intent_survives_reopen():
    workspace = new_project("Revolve intersection")
    document = {"format": "aether-part", "formatVersion": 29, "features": [
        {"id": "intersection", "type": "revolve", "operation": "intersect",
         "profileFeatureId": "section", "axis": "Z", "angleDegrees": 360,
         "targetBodyId": "body", "targetBodyIds": ["body", "second"]}]}
    edit_project(workspace, "add_part", {"name": "Part", "document": document})
    reopened = AetherWorkspace.from_bytes(workspace.to_bytes()[0])
    assert reopened.part_definitions == workspace.part_definitions
