"""Saved mate poses and relation dependencies do not depend on edit order."""
import copy
import math

import pytest
from aether_animation.aether_workspace import AetherWorkspace, AetherWorkspaceError


def edit(w, method, **params):
    return w.mutate(method, params, w.revision, "test")


def make(kind="revolute", count=2):
    w = AetherWorkspace.new(1)
    edit(w, "add_part_definition", part_definition={"name": "P"})
    part = next(iter(w.part_definitions))
    for i in range(count):
        edit(w, "add_instance", instance={"name": str(i), "parent_assembly_id": w.root_assembly_id,
            "definition_kind": "part", "definition_id": part, "grounded": i == 0})
    edit(w, "add_connector", connector={"part_definition_id": part, "name": "C",
        "frame_part_local": {"origin_m": [.03, .02, .01], "primary_axis_xyz": [0, 1, 0], "secondary_axis_xyz": [0, 0, 1]}, "provenance": {"kind": "manual"}})
    connector = next(iter(w.connector_definitions))
    ids = list(w.instances)
    for b in ids[1:]:
        edit(w, "add_mate", mate={"type_id": kind, "endpoint_a": {"instance_id": ids[0], "connector_definition_id": connector}, "endpoint_b": {"instance_id": b, "connector_definition_id": connector}})
    for mate in w.projection(w.root_assembly_id)["mates"]:
        for i, dof in enumerate(mate["dofs"]):
            edit(w, "set_dof_value", dof_id=dof["id"], **({"value_rad": .2 + i * .1} if dof["kind"] == "rotation" else {"value_m": .01 + i * .01}))
    return w


def poses(w):
    result = w.solve(w.root_assembly_id)
    assert result["status"] == "solved", result
    return {v["instance_id"]: v["transform"] for v in result["instance_world_transforms"]}


@pytest.mark.parametrize("kind", ["fastened", "revolute", "prismatic", "cylindrical", "ball", "planar", "pin_slot", "parallel"])
def test_tree_can_be_grounded_at_either_endpoint_without_rewriting_rest(kind):
    w = make(kind)
    a, b = w.instances
    before = poses(w)
    # Ground the child at its solved pose. Then change the free parent's rest
    # pose: solving must recover its original placement from the child's anchor.
    edit(w, "update_instance", instance={**w.instances[b], "rest_transform": before[b], "grounded": True})
    moved = {"position_m": [1, 2, 3], "rotation_quaternion_xyzw": [math.sin(.4), 0, 0, math.cos(.4)]}
    edit(w, "update_instance", instance={**w.instances[a], "rest_transform": moved, "grounded": False})
    after = poses(w)
    for key in (a, b):
        assert after[key]["position_m"] == pytest.approx(before[key]["position_m"], abs=1e-10)
        assert abs(sum(x*y for x,y in zip(after[key]["rotation_quaternion_xyzw"], before[key]["rotation_quaternion_xyzw"]))) == pytest.approx(1)
    assert w.instances[a]["rest_transform"] == moved
    reopened = AetherWorkspace.from_bytes(w.to_bytes()[0])
    assert poses(reopened) == after


def test_conflicting_grounded_nodes_are_reported_and_matching_ones_solve():
    w = make("prismatic")
    a, b = w.instances
    right_pose = poses(w)[b]
    edit(w, "set_instance_grounded", instance_id=b, grounded=True)
    result = w.solve(w.root_assembly_id)
    assert result["status"] == "unconverged"
    assert result["diagnostics"][0]["code"] == "solve_unconverged"
    assert w.projection(w.root_assembly_id)["mates"][0]["solve_state"] == "failed"
    edit(w, "update_instance", instance={**w.instances[b], "rest_transform": right_pose})
    assert w.solve(w.root_assembly_id)["status"] == "solved"
    edit(w, "set_instance_grounded", instance_id=a, grounded=False)
    assert w.solve(w.root_assembly_id)["remaining_free_dof_count"] == 1


def test_relation_chain_is_topological_after_add_update_suppress_and_reopen():
    w = make(count=4)
    x,y,z = [m["dofs"][0]["id"] for m in w.projection(w.root_assembly_id)["mates"]]
    edit(w, "add_relation", relation={"kind":"gear", "driver_dof_id":y, "driven_dof_id":z, "ratio":-2, "offset_rad":.1, "reversed":True})
    first = next(iter(w.relations))
    edit(w, "add_relation", relation={"kind":"gear", "driver_dof_id":x, "driven_dof_id":y, "ratio":3, "offset_rad":.2})
    upstream = list(w.relations)[-1]
    def value(key):
        return next(v["value_rad"] for v in w.solve(w.root_assembly_id)["dof_values"] if v["dof_id"]==key)
    assert value(z) == pytest.approx(-1.5)
    edit(w, "set_dof_value", dof_id=x, value_rad=4*math.pi)
    assert value(z) == pytest.approx(-2*(12*math.pi+.2)+.1)
    edit(w, "update_relation", relation={**w.relations[upstream], "suppressed":True})
    assert value(z) == pytest.approx(-.3)  # y's retained authored value
    edit(w, "update_relation", relation={**w.relations[upstream], "suppressed":False, "ratio":.5})
    assert value(z) == pytest.approx(-2*(2*math.pi+.2)+.1)
    reopened = AetherWorkspace.from_bytes(w.to_bytes()[0])
    assert reopened.solve(reopened.root_assembly_id)==w.solve(w.root_assembly_id)
    before = w.to_bytes()[0]
    with pytest.raises(AetherWorkspaceError, match="cycle"):
        edit(w, "add_relation", relation={"kind":"gear", "driver_dof_id":z, "driven_dof_id":x, "ratio":1})
    assert w.to_bytes()[0]==before
    graph=copy.deepcopy(w.graph())
    graph["relations"].append({**w.relations[first], "id":"cyclic", "driver_dof_id":z,"driven_dof_id":x})
    with pytest.raises(AetherWorkspaceError, match="cycle"):
        AetherWorkspace.from_graph(graph)
