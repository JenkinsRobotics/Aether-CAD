"""A document's kind is derived from what it holds and travels in the manifest."""
import io
import json
import zipfile

from aether_animation.aether_project import edit_project, new_project, project_projection
from aether_animation.aether_workspace import AetherWorkspace
from aether_animation.workspace_drawings import drawing_entry


def manifest(workspace):
    data, _ = workspace.to_bytes()
    return json.loads(zipfile.ZipFile(io.BytesIO(data)).read("manifest.json"))


def test_kind_follows_content():
    workspace = new_project("Doc")
    assert workspace.kind == "part"  # empty documents start as a Part Studio
    edit_project(workspace, "add_part", {"name": "Part 1"})
    assert workspace.kind == "part"
    part_id = next(iter(workspace.part_definitions))
    workspace.instances["instance-1"] = {"id": "instance-1", "name": "Part 1", "definition_kind": "part",
                                         "definition_id": part_id, "parent_id": None, "transform": None,
                                         "grounded": True, "suppressed": False}
    assert workspace.kind == "mixed"
    del workspace.instances["instance-1"]
    workspace.drawings["drawing-1"] = drawing_entry("drawing-1", "Drawing 1", {"format": "aether-drawing", "formatVersion": 2})
    assert workspace.kind == "mixed"
    workspace.part_definitions.clear()
    assert workspace.kind == "drawing"


def test_manifest_and_projection_carry_kind():
    workspace = new_project("Doc")
    edit_project(workspace, "add_part", {"name": "Part 1"})
    assert manifest(workspace)["kind"] == "part"
    assert manifest(workspace)["app"] == "cad"
    reopened = AetherWorkspace.from_bytes(workspace.to_bytes()[0])
    assert project_projection(reopened)["kind"] == "part"
