"""New workspace intent must never silently disappear in an older reader."""
import pytest

from aether_animation.aether_workspace import AetherWorkspace, AetherWorkspaceError


def contacts():
    workspace = AetherWorkspace.new(1, "Contacts")
    def edit(method, **params):
        return workspace.mutate(method, params, workspace.revision, "test")
    edit("add_part_definition", part_definition={"name": "P", "source": {"kind": "authored", "label": "P"}})
    for name in ("A", "B"):
        edit("add_instance", instance={"parent_assembly_id": workspace.root_assembly_id,
             "definition_kind": "part", "definition_id": next(iter(workspace.part_definitions)),
             "name": name, "rest_transform": {"position_m": [0, 0, 0],
             "rotation_quaternion_xyzw": [0, 0, 0, 1]}})
    edit("add_contact_set", contact_set={"name": "Contact", "instance_ids": list(workspace.instances)})
    return workspace


def test_plain_files_keep_legacy_graph_and_identical_roundtrip():
    workspace = AetherWorkspace.new(1, "Plain")
    graph = workspace.graph()
    assert graph["schema_version"] == 1
    assert "contact_sets" not in graph and "contacts_enabled" not in graph
    content = workspace.to_bytes()[0]
    assert AetherWorkspace.from_bytes(content).to_bytes()[0] == content


def test_contacts_require_new_reader_even_when_disabled_or_suppressed():
    workspace = contacts()
    next(iter(workspace.contact_sets.values()))["suppressed"] = True
    assert workspace.graph()["schema_version"] == 2
    content = workspace.to_bytes()[0]
    reopened = AetherWorkspace.from_bytes(content)
    assert reopened.contact_sets == workspace.contact_sets
    assert reopened.to_bytes()[0] == content


def test_enable_all_requires_new_reader_without_named_sets():
    workspace = AetherWorkspace.new(1)
    workspace.contacts_enabled = True
    assert workspace.graph()["schema_version"] == 2
    assert AetherWorkspace.from_bytes(workspace.to_bytes()[0]).contacts_enabled is True


def test_legacy_unversioned_contact_intent_is_preserved_and_upgraded():
    original = contacts()
    graph = original.graph()
    graph["schema_version"] = 1
    reopened = AetherWorkspace.from_graph(graph)
    assert reopened.contact_sets == original.contact_sets
    assert reopened.graph()["schema_version"] == 2


def test_cam_intent_requires_new_reader():
    workspace = AetherWorkspace.new(1)
    workspace.relations["cam"] = {"id": "cam", "kind": "cam", "suppressed": True}
    assert workspace.graph()["schema_version"] == 2


@pytest.mark.parametrize("version", [True, False, "1", 1.0, 0, 4, None])
def test_invalid_graph_version_refused(version):
    graph = AetherWorkspace.new(1).graph()
    graph["schema_version"] = version
    with pytest.raises(AetherWorkspaceError, match="unsupported semantic graph version"):
        AetherWorkspace.from_graph(graph)


@pytest.mark.parametrize("enabled", [0, 1, "false", [], None])
def test_invalid_contact_flag_refused(enabled):
    graph = AetherWorkspace.new(1).graph()
    graph["contacts_enabled"] = enabled
    with pytest.raises(AetherWorkspaceError, match="expected a boolean"):
        AetherWorkspace.from_graph(graph)
