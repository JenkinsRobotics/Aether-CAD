"""Hybrid containers retain CAD-owned drawings through every archive round trip."""
import copy
import pytest
from aether_animation.aether_project import new_project, edit_project, project_projection
from aether_animation.aether_workspace import AetherWorkspace, AetherWorkspaceError


def drawing():
    return {"format": "aether-drawing", "formatVersion": 2, "documentId": "draft", "name": "Draft", "source": {"name": "Bracket"}, "sheets": [{"id": "sheet"}]}


def test_drawing_lives_in_container_and_survives_other_item_changes():
    workspace = new_project("Machine")
    assert workspace.graph()["schema_version"] == 1
    edit_project(workspace, "add_drawing", {"name": "Bracket drawing", "document": drawing()})
    key = next(iter(workspace.drawings))
    assert workspace.graph()["schema_version"] == 3
    restored = AetherWorkspace.from_bytes(workspace.to_bytes()[0])
    edit_project(restored, "add_assembly", {"name": "Subassembly"})
    assert restored.drawings == workspace.drawings
    revised = copy.deepcopy(restored.drawings[key]["document"])
    revised["sheets"].append({"id": "second"})
    edit_project(restored, "save_drawing", {"name": "Manufacturing", "drawing_id": key, "document": revised})
    final = AetherWorkspace.from_bytes(restored.to_bytes()[0])
    assert final.drawings[key]["document"]["documentId"] == key
    assert len(final.drawings[key]["document"]["sheets"]) == 2
    assert project_projection(final)["drawings"][0]["name"] == "Manufacturing"
    assert final.to_bytes() == restored.to_bytes()


@pytest.mark.parametrize("change", ["old-version", "duplicate", "identity", "future-format", "collision"])
def test_invalid_drawing_envelopes_fail_closed(change):
    workspace = new_project("Machine")
    edit_project(workspace, "add_drawing", {"name": "Drawing", "document": drawing()})
    graph = workspace.graph()
    if change == "old-version": graph["schema_version"] = 2
    if change == "duplicate": graph["drawings"].append(copy.deepcopy(graph["drawings"][0]))
    if change == "identity": graph["drawings"][0]["document"]["documentId"] = "other"
    if change == "future-format": graph["drawings"][0]["document"]["formatVersion"] = 99
    if change == "collision":
        key = graph["assemblies"][0]["id"]
        graph["drawings"][0]["id"] = key
        graph["drawings"][0]["document"]["documentId"] = key
    with pytest.raises(AetherWorkspaceError): AetherWorkspace.from_graph(graph)


@pytest.mark.parametrize("version", [3, 4, 5])
def test_newer_drawing_intent_survives_container_save_and_reopen(version):
    workspace = new_project("Machine")
    document = drawing()
    document["formatVersion"] = version
    document["sheets"][0]["annotations"] = [{
        "id": "dimension", "kind": "point-distance" if version == 5 else "radius",
        "viewId": "top", "pointsMm": [[0, 0], [20, 10]], "decimals": 2,
        "positionMm": [30, 20], "atMm": [10, 0],
    }]
    edit_project(workspace, "add_drawing", {"name": "Drawing", "document": document})
    restored = AetherWorkspace.from_bytes(workspace.to_bytes()[0])
    assert restored.drawings == workspace.drawings
    assert next(iter(restored.drawings.values()))["document"]["formatVersion"] == version
