"""Canonical relation vocabulary, independent of numerical playback dependencies."""

from enum import StrEnum

from .mates import DofKind


class RelationKind(StrEnum):
    """The four linear DOF couplings (Kinematics.md §5)."""

    GEAR = "gear"
    RACK_PINION = "rack_pinion"
    SCREW = "screw"
    LINEAR = "linear"


# Each relation kind DEFINES its (driver kind, driven kind) pairing.
RELATION_KIND_DOF_KINDS: dict[RelationKind, tuple[DofKind, DofKind]] = {
    RelationKind.GEAR: (DofKind.ROTATION, DofKind.ROTATION),
    RelationKind.RACK_PINION: (DofKind.ROTATION, DofKind.TRANSLATION),
    RelationKind.SCREW: (DofKind.ROTATION, DofKind.TRANSLATION),
    RelationKind.LINEAR: (DofKind.TRANSLATION, DofKind.TRANSLATION),
}



# The Assembly workspace's one nonlinear relation: a cam. Its driver is the cam's
# rotation; its driven DOF (a translating follower's travel or an oscillating one's
# turn) follows a table of the follower's value over one turn of the cam, which the
# CAD engine works out from the cam's profile and follower and stores on the relation.
# It is a workspace relation, not a rig `RelationKind`: rigs keep ratio couplings.
CAM_RELATION_KIND = "cam"
CAM_SAMPLES = 360


def lift_at(table: list[float] | tuple[float, ...], x: float) -> float:
    """The cam table's value at driver angle ``x`` (radians), periodic over a turn.

    A monotone cubic through the samples (Hermite, slopes limited as Fritsch and
    Carlson do), so a dwell stays flat up to a rise and nothing overshoots: the
    interpolation SolidCraft's ``lift_at`` uses. NaN for an empty table.
    """
    import math

    n = len(table)
    if n == 0 or not math.isfinite(x):
        return math.nan
    u = (x % math.tau) / math.tau * n % n
    i = int(math.floor(u))
    f = u - i
    at = lambda k: table[k % n]  # noqa: E731
    p0, p1, p2, p3 = at(i + n - 1), at(i), at(i + 1), at(i + 2)

    def slope(a: float, b: float) -> float:
        if a * b <= 0.0:
            return 0.0
        return 0.5 * math.copysign(min(abs(a + b), 6.0 * min(abs(a), abs(b))), a + b)

    m1, m2 = slope(p1 - p0, p2 - p1), slope(p2 - p1, p3 - p2)
    f2, f3 = f * f, f * f * f
    return ((2 * f3 - 3 * f2 + 1) * p1 + (f3 - 2 * f2 + f) * m1
            + (3 * f2 - 2 * f3) * p2 + (f3 - f2) * m2)
