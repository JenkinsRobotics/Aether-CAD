import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { CommandSearch } from "./CommandSearch.js";
import { EnvironmentControl } from "./EnvironmentControl.js";
import { FilesPanel } from "./FilesPanel.js";
import { FloatingToolbar, FloatingToolbarMenu } from "./FloatingToolbar.js";
import { OrientationCompass } from "./OrientationCompass.js";
import { standardWorkspacePanels } from "./StandardWorkspacePanels.js";
import { StudioAppFrame } from "./StudioAppFrame.js";
import { StudioCameraControl } from "./StudioCameraControl.js";
import { StudioModeButton } from "./StudioChrome.js";
import { StudioDocumentBar } from "./StudioDocumentBar.js";
import { StudioViewportControls } from "./StudioViewportControls.js";
import { StudioWorkspace } from "./StudioWorkspace.js";
import { WorkspaceRibbon } from "./WorkspaceRibbon.js";
const STANDARD_HEADER_PINS = ["theme", "mode", "notifications", "comments", "apps", "share"];
const STANDARD_LEFT_TRAY = ["comments", "advisor", "versions", "files", "tree-toggle"];
const STANDARD_OBJECT_TABS = [
  { id: "inspector", title: "Inspector", icon: "info" },
  { id: "properties", title: "Properties", icon: "sliders" },
  { id: "appearance", title: "Materials and appearance", icon: "palette" },
  { id: "transform", title: "Transform", icon: "move" },
  { id: "effects", title: "Effects", icon: "sparkles" }
];
const DEFAULT_PANELS = { tree: { placement: "docked" }, properties: { placement: "docked" } };
function StandardAppShell(props) {
  const { application, layout, onLayoutChange, toolbar, tree, files, objectTabs, centerTray, environment, cube } = props;
  const [ownPanels, setOwnPanels] = useState(DEFAULT_PANELS);
  const panels = props.panelState ?? ownPanels;
  const setPanels = (next) => {
    if (!props.panelState) setOwnPanels(next);
    props.onPanelStateChange?.(next);
  };
  const [cubeShown, setCubeShown] = useState(true), [cubeOpen, setCubeOpen] = useState(false);
  const treeShown = (panels.tree?.placement ?? "hidden") !== "hidden";
  const left = standardWorkspacePanels([
    { id: "tree", title: tree.title, icon: tree.icon ?? /* @__PURE__ */ jsx(AetherIcon, { name: "list-tree" }), chromeless: true, content: tree.content },
    ...props.advisor ? [{ id: "advisor", title: "AI advisor", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "brain" }), content: props.advisor }] : []
  ], { features: "tree" }, props.connection, { history: props.history, historyTabStorageKey: props.historyTabStorageKey }).filter((panel) => panel.id !== "part-manager");
  left.push({ id: "files", title: "Files", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }), content: /* @__PURE__ */ jsx(FilesPanel, { ...files }) });
  left.push({
    id: "tree-toggle",
    title: "Item tree",
    icon: /* @__PURE__ */ jsx(AetherIcon, { name: "list-tree" }),
    content: null,
    toggle: { pressed: treeShown, onToggle: () => setPanels({ ...panels, tree: { placement: treeShown ? "hidden" : "docked" } }) }
  });
  for (const panel of left) if (panel.id !== "tree") panel.inToolbar = STANDARD_LEFT_TRAY.includes(panel.id);
  const rank = (id) => {
    const i = STANDARD_LEFT_TRAY.indexOf(id);
    return i < 0 ? STANDARD_LEFT_TRAY.length : i;
  };
  left.sort((a, b) => rank(a.id) - rank(b.id));
  const right = STANDARD_OBJECT_TABS.map((tab) => ({ id: tab.id, title: tab.title, icon: /* @__PURE__ */ jsx(AetherIcon, { name: tab.icon }), content: objectTabs[tab.id] }));
  const environmentActions = [
    ...cube ? [{ id: "aether-view-cube", label: "View cube", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "view-cube" }), pressed: cubeShown }] : [],
    ...environment?.actions ?? []
  ];
  const groups = [
    { id: "tools", label: "Tools", actions: centerTray.tools },
    ...centerTray.toggles?.length ? [{ id: "toggles", label: "Panels", separatorBefore: true, actions: centerTray.toggles }] : []
  ];
  return /* @__PURE__ */ jsxs(StudioAppFrame, { className: props.className, style: { height: "100%" }, children: [
    /* @__PURE__ */ jsx(
      StudioDocumentBar,
      {
        application,
        documentName: props.documentName,
        documentState: props.documentState,
        documentMenu: props.documentMenu,
        defaultHeaderPins: [...STANDARD_HEADER_PINS],
        trailing: props.headerTrailing,
        search: /* @__PURE__ */ jsx(CommandSearch, { commands: props.commands, onSelect: props.onCommand, registerShortcut: true }),
        viewControls: /* @__PURE__ */ jsx("div", { className: "aui-studio-chrome-group", children: /* @__PURE__ */ jsx(StudioModeButton, { preset: layout, onChange: onLayoutChange }) })
      }
    ),
    /* @__PURE__ */ jsxs(
      StudioWorkspace,
      {
        preset: layout,
        pinnedPanels: ["tree"],
        panelState: panels,
        onPanelStateChange: setPanels,
        preservePanelContent: true,
        sidebarSizing: props.sidebarSizing,
        style: { flex: 1, minHeight: 0 },
        toolPosition: "top",
        toolbarSpan: layout === "docked" ? "window" : "center",
        toolbar: /* @__PURE__ */ jsx(WorkspaceRibbon, { ...toolbar, variant: layout === "docked" ? "docked" : "floating", workspaceLayout: "column", appearance: "glass", moreLabel: "Tool bar options" }),
        centerTray: /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(
            FloatingToolbar,
            {
              variant: "document",
              ariaLabel: "Center icon tray",
              groups,
              onAction: centerTray.onAction,
              trailing: centerTray.windowCommands?.length ? /* @__PURE__ */ jsx(FloatingToolbarMenu, { iconOnly: true, label: "More", items: [...centerTray.windowCommands], onSelect: centerTray.onAction, children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) }) : void 0
            }
          ),
          environmentActions.length > 0 && /* @__PURE__ */ jsx(
            EnvironmentControl,
            {
              opens: "side",
              actions: environmentActions,
              onSelect: (id) => id === "aether-view-cube" ? setCubeShown((value) => !value) : environment?.onSelect(id)
            }
          )
        ] }),
        leftPanels: left,
        rightPanels: right,
        bottom: props.bottom,
        children: [
          props.children,
          cube && cubeShown && /* @__PURE__ */ jsx(StudioViewportControls, { children: /* @__PURE__ */ jsx(StudioCameraControl, { expanded: cubeOpen, onExpandedChange: setCubeOpen, compass: /* @__PURE__ */ jsx(OrientationCompass, { orientation: cube.orientation }), children: cube.content }) })
        ]
      }
    )
  ] });
}
export {
  STANDARD_HEADER_PINS,
  STANDARD_LEFT_TRAY,
  STANDARD_OBJECT_TABS,
  StandardAppShell
};
