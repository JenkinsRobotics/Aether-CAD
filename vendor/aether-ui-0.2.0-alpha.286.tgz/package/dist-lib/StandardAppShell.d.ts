import { type ReactNode } from "react";
import { type CommandSearchCommand } from "./CommandSearch.js";
import type { DocumentConnection } from "./DocumentServices.js";
import type { DocumentBarProps } from "./DocumentBar.js";
import { type EnvironmentControlAction } from "./EnvironmentControl.js";
import { type FilesPanelProps } from "./FilesPanel.js";
import { type FloatingToolbarAction } from "./FloatingToolbar.js";
import type { MenuItem } from "./Menu.js";
import type { ViewportOrientation } from "./ViewportNavigationCube.js";
import type { LayoutPreset, WorkspacePanelState } from "./WorkspaceShell.js";
import { type WorkspaceRibbonProps } from "./WorkspaceRibbon.js";
/** The header pins every app shows, in order: light/dark, then floating ↔ docked. */
export declare const STANDARD_HEADER_PINS: readonly ["theme", "mode", "notifications", "comments", "apps", "share"];
/** Left side tray, in order (five icons). */
export declare const STANDARD_LEFT_TRAY: readonly ["comments", "advisor", "versions", "files", "tree-toggle"];
/** Right side tray: five tabs about the selected object, in order. */
export declare const STANDARD_OBJECT_TABS: readonly [{
    readonly id: "inspector";
    readonly title: "Inspector";
    readonly icon: "info";
}, {
    readonly id: "properties";
    readonly title: "Properties";
    readonly icon: "sliders";
}, {
    readonly id: "appearance";
    readonly title: "Materials and appearance";
    readonly icon: "palette";
}, {
    readonly id: "transform";
    readonly title: "Transform";
    readonly icon: "move";
}, {
    readonly id: "effects";
    readonly title: "Effects";
    readonly icon: "sparkles";
}];
export type StandardObjectTabID = typeof STANDARD_OBJECT_TABS[number]["id"];
export interface StandardAppShellProps {
    /** Header identity (app id/name, app tray, home, share, settings). */
    application: NonNullable<DocumentBarProps["application"]>;
    documentName: string;
    documentState?: ReactNode;
    /** The document's menu (new, open, import, save, export), left of its name. */
    documentMenu?: ReactNode;
    /** Header extras beside the document (e.g. draft recovery). */
    headerTrailing?: ReactNode;
    /** Every command, for the header search. */
    commands: readonly CommandSearchCommand[];
    onCommand: (id: string) => void;
    /** Floating, docked or canvas; switched from the header's mode button. */
    layout: LayoutPreset;
    onLayoutChange: (layout: LayoutPreset) => void;
    /** Tool bar: the app's workspaces, tabs and tools. Placement and look are fixed. */
    toolbar: Pick<WorkspaceRibbonProps, "workspaces" | "workspaceID" | "onWorkspaceSelect" | "tabs" | "activeTabID" | "onTabSelect" | "onCommand" | "onVariantSelect" | "moreItems">;
    /** The pinned item tree on the left. */
    tree: {
        title: string;
        icon?: ReactNode;
        content: ReactNode;
    };
    /** AI advisor panel content. */
    advisor?: ReactNode;
    /** Document connection: supplies Comments, Version control and the other standard aux panels. */
    connection?: DocumentConnection;
    history?: ReactNode;
    historyTabStorageKey?: string;
    /** Files panel: this document's contents | Drive (DriveBrowser). */
    files: Omit<FilesPanelProps, "error"> & {
        error?: string;
    };
    /** The five object tabs' contents. */
    objectTabs: Record<StandardObjectTabID, ReactNode>;
    /** Center icon tray: tools, then UI toggles (e.g. the bottom editors), then a pop-up of window commands. */
    centerTray: {
        tools: readonly FloatingToolbarAction[];
        toggles?: readonly FloatingToolbarAction[];
        windowCommands?: readonly MenuItem[];
        onAction: (id: string) => void;
    };
    /** Workspace controls in the environment stack (grid, fit, snapping, display). */
    environment?: {
        actions: readonly EnvironmentControlAction[];
        onSelect: (id: string) => void;
    };
    /** A 3D app's view cube: the full cube and the orientation its collapsed compass shows. */
    cube?: {
        orientation: ViewportOrientation;
        content: ReactNode;
    };
    /** Large editors (a BottomPanel with a timeline, a table) when open. */
    bottom?: ReactNode;
    panelState?: WorkspacePanelState;
    onPanelStateChange?: (state: WorkspacePanelState) => void;
    sidebarSizing?: {
        width: number;
        minWidth: number;
        maxWidth: number;
        minCenterWidth: number;
    };
    className?: string;
    /** The canvas, viewport or editor. */
    children: ReactNode;
}
/** The locked Aether app shell (Jonathan, 2026-11-11). An app supplies content only:
 * Header with search and the floating/docked switch; Tool bar on top; Left side tray (five
 * icons) under the item tree; Right side tray (five object tabs) under the inspector; Center
 * icon tray with the environment stack beside it; the view cube with its compass; bottom
 * editors. Order, placement and spacing are not app options. See WIDGETS.md. */
export declare function StandardAppShell(props: StandardAppShellProps): import("react").JSX.Element;
