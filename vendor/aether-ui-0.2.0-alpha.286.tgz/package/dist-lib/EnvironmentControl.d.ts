import { type ReactNode } from "react";
import { type MenuItem } from "./Menu.js";
import "./EnvironmentControl.css";
export interface EnvironmentControlAction {
    id: string;
    label: string;
    icon: ReactNode;
    pressed?: boolean;
    disabled?: boolean;
    disabledReason?: string;
    items?: readonly MenuItem[];
}
export interface EnvironmentControlProps {
    /** Product-owned snap, grid and display controls, in vertical order. */
    actions: readonly EnvironmentControlAction[];
    onSelect: (id: string) => void;
    /** "side" beside the center icon tray: the stack opens horizontally to the right, without a caption. */
    opens?: "down" | "side";
}
/** Independent vertical pill. Camera navigation belongs to StudioCameraControl. */
export declare function EnvironmentControl({ actions, onSelect, opens }: EnvironmentControlProps): import("react").JSX.Element;
