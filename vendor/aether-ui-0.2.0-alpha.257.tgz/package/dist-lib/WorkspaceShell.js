import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useRegisterWorkspaceControls } from "./workspace-controls.js";
import "./WorkspaceShellPlacement.css";
import { useInitialLayoutReady } from "./useInitialLayoutReady.js";
import "./WorkspaceSafeArea.css";
import "./WorkspaceToolbarFrame.css";
import { WorkspaceLayoutContext } from "./WorkspaceLayoutContext.js";
import { useClosingPanels, useWorkspaceInsets, WORKSPACE_PANEL_DURATION_MS } from "./WorkspaceShellMotion.js";
import { Fragment as Fragment2, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { singlePanelPerSide } from "./workspace-panel-selection.js";
import { Inspector } from "./Inspector.js";
import { CollectionHost } from "./CollectionView.js";
import { AetherIcon } from "./AetherIcon.js";
import { createPortal } from "react-dom";
import { Rail, RailButton } from "./Rail.js";
import { PanelResizeHandle } from "./PanelResizeHandle.js";
import { useSidebarSizes } from "./useSidebarSizes.js";
import { TabbedSidebar } from "./TabbedSidebar.js";
import { FloatingToolbar } from "./FloatingToolbar.js";
import { DEFAULT_WORKSPACE_CHROME, useWorkspaceChrome } from "./WorkspaceChromePreferences.js";
const PRESET_ORDER = ["floating", "docked", "canvas"];
const PRESET_GLYPH = {
  floating: "\u274F",
  docked: "\u25A5",
  canvas: "\u26F6"
};
const LEFT_PANEL_WIDTH = 232;
const RIGHT_PANEL_WIDTH = 320;
const RESTACK_DISTANCE = 110;
function nextLayoutPreset(preset) {
  return PRESET_ORDER[(PRESET_ORDER.indexOf(preset) + 1) % PRESET_ORDER.length];
}
function LayoutPresetButton({
  preset,
  onChange
}) {
  const next = nextLayoutPreset(preset);
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      className: "aui-icon-button",
      title: `Layout: ${preset} \u2014 click for ${next}`,
      "aria-label": `Layout ${preset}, switch to ${next}`,
      onClick: () => onChange(next),
      children: PRESET_GLYPH[preset]
    }
  );
}
function FloatingPanel(props) {
  const { title, x, y, width = LEFT_PANEL_WIDTH } = props;
  const drag = useRef(null);
  const pos = useRef({ x, y });
  pos.current = { x, y };
  const onPointerDown = (event) => {
    if (event.target.closest("button")) return;
    drag.current = { startX: event.clientX, startY: event.clientY, baseX: x, baseY: y };
    event.currentTarget.setPointerCapture?.(event.pointerId);
  };
  const onPointerMove = (event) => {
    if (!drag.current) return;
    props.onMove(
      drag.current.baseX + event.clientX - drag.current.startX,
      drag.current.baseY + event.clientY - drag.current.startY
    );
  };
  const onPointerUp = () => {
    if (!drag.current) return;
    drag.current = null;
    props.onDragEnd?.(pos.current.x, pos.current.y);
  };
  return /* @__PURE__ */ jsxs("div", { className: "aui-float-panel", "data-shell-side": props.shellSide, "data-closing": props.closing || void 0, "aria-hidden": props.closing || void 0, inert: props.closing || void 0, style: { left: x, top: y, width }, children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: "aui-float-panel-header",
        tabIndex: 0,
        role: "group",
        "aria-label": `Move ${title}`,
        onKeyDown: (event) => {
          const step = event.shiftKey ? 40 : 10;
          const delta = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[event.key];
          if (!delta || event.target !== event.currentTarget) return;
          event.preventDefault();
          props.onMove(x + delta[0], y + delta[1]);
        },
        onPointerDown,
        onPointerMove,
        onPointerUp,
        children: [
          /* @__PURE__ */ jsx("span", { className: "aui-float-panel-title", children: title }),
          /* @__PURE__ */ jsxs("span", { className: "aui-float-panel-actions", children: [
            props.onDock ? /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "aui-float-panel-action",
                title: "Dock panel",
                "aria-label": `Dock ${title}`,
                onClick: props.onDock,
                children: /* @__PURE__ */ jsx(AetherIcon, { name: "mode-docked" })
              }
            ) : null,
            props.onClose ? /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "aui-float-panel-action",
                title: "Close panel",
                "aria-label": `Close ${title}`,
                onClick: props.onClose,
                children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
              }
            ) : null
          ] })
        ]
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "aui-float-panel-body", children: props.children })
  ] });
}
function readPanelLayout(key, preset, fallback) {
  try {
    const saved = JSON.parse(localStorage.getItem(key) ?? "null");
    if (saved?.version !== 1 || !saved.layouts?.[preset]) return fallback;
    const result = { ...fallback };
    for (const [id, value] of Object.entries(saved.layouts[preset])) {
      const entry = value;
      if (!entry || !["docked", "floating", "hidden"].includes(entry.placement)) return fallback;
      if (entry.position && (!Number.isFinite(entry.position.x) || !Number.isFinite(entry.position.y))) return fallback;
      result[id] = entry;
    }
    return result;
  } catch {
    return fallback;
  }
}
function WorkspaceShell(props) {
  const initialLayoutReady = useInitialLayoutReady();
  const studio = props.design === "studio";
  const measureShellBottom = useCallback((node) => {
    shellBottomObserver.current?.disconnect();
    shellBottomObserver.current = null;
    const shell = node?.closest(".aui-shell");
    if (!node || !shell) return;
    const contentBottom = (element) => {
      let bottom2 = -Infinity;
      for (const child of element.children) {
        if (getComputedStyle(child).display === "contents") bottom2 = Math.max(bottom2, contentBottom(child));
        else {
          const rect = child.getBoundingClientRect();
          if (rect.height) bottom2 = Math.max(bottom2, rect.bottom);
        }
      }
      return bottom2;
    };
    const apply = () => {
      const fledge = shell.querySelector(".aui-shell-fledge--left")?.getBoundingClientRect().bottom;
      const extend = fledge === void 0 ? 0 : Math.max(0, contentBottom(node) - fledge);
      shell.style.setProperty("--aui-studio-aux-extend", `${extend}px`);
    };
    apply();
    if (typeof ResizeObserver !== "undefined") {
      shellBottomObserver.current = new ResizeObserver(apply);
      shellBottomObserver.current.observe(node);
      shellBottomObserver.current.observe(shell);
    }
  }, []);
  const shellBottomObserver = useRef(null);
  useEffect(() => () => shellBottomObserver.current?.disconnect(), []);
  const {
    preset,
    toolbar,
    frameToolbar = "auto",
    preservePanelContent = true,
    bottom,
    statusBar,
    style,
    children,
    leftPanels = [],
    rightPanels = [],
    sidebarVariant: appSidebarVariant = "rail"
  } = props;
  const sharedChrome = useWorkspaceChrome();
  const chrome = props.inheritChromePreferences === false ? DEFAULT_WORKSPACE_CHROME : sharedChrome;
  const sidebarVariant = studio ? "tabs-top" : chrome.sidebarDesign === "app" ? appSidebarVariant : chrome.sidebarDesign;
  const panelsOnOuterEdge = chrome.sidebarOpening === "app" ? props.panelsOnOuterEdge : chrome.sidebarOpening === "outside";
  const animatePanels = chrome.panelMotion === "none" ? false : props.animatePanels ?? true;
  const panelSelection = sidebarVariant === "rail" ? props.panelSelection ?? "single" : "single";
  const unifiedSidebar = panelSelection === "single";
  const sidebarTabs = sidebarVariant === "rail" ? void 0 : sidebarVariant === "tabs-top" ? "top" : "bottom";
  const bodyRef = useRef(null);
  const { sizes: sidebarSizes, update: resizeSidebar, availableWidth } = useSidebarSizes(props.storageKey, bodyRef);
  const panelHosts = useRef(/* @__PURE__ */ new Map());
  const allPanels = [...leftPanels, ...rightPanels];
  const [commandID, setCommandID] = useState(null);
  const closeCommand = useCallback(() => setCommandID(null), []);
  if (preservePanelContent && typeof document !== "undefined") {
    for (const panel of allPanels) {
      if (!panelHosts.current.has(panel.id)) {
        const host = document.createElement("div");
        host.className = "aui-shell-panel-host";
        panelHosts.current.set(panel.id, host);
      }
    }
  }
  const panelContent = (panel) => {
    const host = preservePanelContent ? panelHosts.current.get(panel.id) : void 0;
    return host ? /* @__PURE__ */ jsx("div", { className: "aui-shell-panel-slot", ref: (slot) => {
      if (slot && host.parentElement !== slot) slot.appendChild(host);
    } }) : collectionContent(panel);
  };
  const [uncontrolledPanelState, setUncontrolledPanelState] = useState(() => {
    const initial = {
      ...props.defaultPanelState ?? {}
    };
    for (const id of props.defaultOpenLeft ?? []) {
      initial[id] ??= { placement: "docked" };
    }
    for (const id of props.defaultOpenRight ?? []) {
      initial[id] ??= { placement: "docked" };
    }
    return props.storageKey ? readPanelLayout(props.storageKey, preset, initial) : initial;
  });
  const previousPreset = useRef(preset);
  const initialPanelState = useRef({
    ...Object.fromEntries([...props.defaultOpenLeft ?? [], ...props.defaultOpenRight ?? []].map((id) => [id, { placement: "docked" }])),
    ...props.defaultPanelState ?? {}
  });
  useEffect(() => {
    if (!props.storageKey || props.panelState !== void 0) return;
    if (previousPreset.current !== preset) {
      previousPreset.current = preset;
      setUncontrolledPanelState(readPanelLayout(props.storageKey, preset, initialPanelState.current));
      return;
    }
    try {
      let saved;
      try {
        saved = JSON.parse(localStorage.getItem(props.storageKey) ?? "null");
      } catch {
        saved = null;
      }
      const layouts = saved?.version === 1 ? saved.layouts ?? {} : {};
      localStorage.setItem(props.storageKey, JSON.stringify({ version: 1, layouts: { ...layouts, [preset]: uncontrolledPanelState } }));
    } catch {
    }
  }, [preset, uncontrolledPanelState, props.storageKey, props.panelState]);
  const rawPanelState = props.panelState ?? uncontrolledPanelState;
  const previousPanelState = useRef(void 0);
  const pinned = new Set(preset === "docked" || studio ? props.pinnedPanels ?? [] : []);
  const sideIDs = [leftPanels.filter((panel) => !panel.command && !panel.toggle && !pinned.has(panel.id)).map((panel) => panel.id), rightPanels.filter((panel) => !panel.command && !panel.toggle && !pinned.has(panel.id)).map((panel) => panel.id)];
  const commandKey = allPanels.filter((panel) => panel.command).map((panel) => panel.id).join("|");
  const sideKey = JSON.stringify(sideIDs);
  const panelState = useMemo(() => {
    let state = rawPanelState;
    for (const panels of [leftPanels, rightPanels]) {
      const openCommand = panels.some((panel) => panel.command && state[panel.id] && state[panel.id].placement !== "hidden");
      for (const panel of panels) if (panel.command && state[panel.id]?.placement !== "hidden") state = { ...state, [panel.id]: { placement: "hidden" } };
      if (openCommand && !panels.some((panel) => !panel.command && state[panel.id] && state[panel.id].placement !== "hidden")) {
        const first = panels.find((panel) => !panel.command);
        if (first) state = { ...state, [first.id]: { placement: "docked" } };
      }
    }
    if (unifiedSidebar) {
      for (const id of [...sideIDs.flat(), ...pinned]) {
        if (state[id]?.placement === "floating") state = { ...state, [id]: { placement: "docked" } };
      }
    }
    return panelSelection === "single" ? singlePanelPerSide(state, sideIDs, previousPanelState.current?.input, void 0, previousPanelState.current?.selection) : state;
  }, [rawPanelState, sideKey, commandKey, panelSelection, unifiedSidebar, JSON.stringify([...pinned])]);
  useEffect(() => {
    previousPanelState.current = { input: rawPanelState, selection: panelState };
    if (panelState !== rawPanelState) {
      if (props.panelState === void 0) setUncontrolledPanelState(panelState);
      props.onPanelStateChange?.(panelState);
    }
  }, [panelState, rawPanelState, props.panelState, props.onPanelStateChange]);
  const closingPanels = useClosingPanels(panelState, animatePanels, preset, [leftPanels.map((panel) => panel.id), rightPanels.map((panel) => panel.id)]);
  useEffect(() => {
    const body = bodyRef.current;
    if (!body || typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(() => {
      const next = { ...panelState };
      let changed = false;
      for (const panel of allPanels) {
        const entry = next[panel.id];
        if (entry?.placement !== "floating" || !entry.position) continue;
        const width = leftPanels.includes(panel) ? LEFT_PANEL_WIDTH : RIGHT_PANEL_WIDTH;
        const position = {
          x: Math.max(8, Math.min(entry.position.x, body.clientWidth - width - 8)),
          y: Math.max(8, Math.min(entry.position.y, body.clientHeight - 48))
        };
        if (position.x !== entry.position.x || position.y !== entry.position.y) {
          next[panel.id] = { ...entry, position };
          changed = true;
        }
      }
      if (changed) {
        if (props.panelState === void 0) setUncontrolledPanelState(next);
        props.onPanelStateChange?.(next);
      }
    });
    observer.observe(body);
    return () => observer.disconnect();
  }, [panelState, props.onPanelStateChange]);
  const [revealed, setRevealed] = useState(/* @__PURE__ */ new Set());
  useEffect(() => {
    if (!studio) return;
    const area = bodyRef.current, shell = area?.closest(".aui-shell");
    if (!area || !shell) return;
    const measure = () => area.style.setProperty("--aui-studio-footer-height", `${Math.max(0, shell.getBoundingClientRect().bottom - area.getBoundingClientRect().bottom)}px`);
    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(area);
    observer?.observe(shell);
    return () => {
      observer?.disconnect();
      area.style.removeProperty("--aui-studio-footer-height");
    };
  }, [studio]);
  const contentInsets = useWorkspaceInsets(bodyRef, true, preset, [panelState, revealed, toolbar, panelsOnOuterEdge, sidebarVariant, chrome.sidebarAttachment, chrome.tabSize, chrome.tabLabels]);
  const hideTimers = useRef(/* @__PURE__ */ new Map());
  const reveal = useCallback((edge) => {
    const timer = hideTimers.current.get(edge);
    if (timer) clearTimeout(timer);
    setRevealed((current) => {
      if (current.has(edge)) return current;
      return new Set(current).add(edge);
    });
  }, []);
  const scheduleHide = useCallback((edge) => {
    const timer = hideTimers.current.get(edge);
    if (timer) clearTimeout(timer);
    hideTimers.current.set(
      edge,
      setTimeout(() => {
        setRevealed((current) => {
          const next = new Set(current);
          next.delete(edge);
          return next;
        });
      }, 160)
    );
  }, []);
  const panelsFor = (side) => side === "left" ? leftPanels : rightPanels;
  const minimumSidebarWidth = props.sidebarSizing?.minWidth ?? 180;
  const defaultWidth = (side) => props.sidebarSizing?.width ?? (side === "left" ? LEFT_PANEL_WIDTH : RIGHT_PANEL_WIDTH);
  const maxSidebarWidth = (side) => {
    const other = side === "left" ? "right" : "left";
    const otherWidth = Math.max(minimumSidebarWidth, Math.min(props.sidebarSizing?.maxWidth ?? Infinity, sidebarSizes[other]?.width ?? defaultWidth(other)));
    return Math.max(minimumSidebarWidth, Math.min(
      props.sidebarSizing?.maxWidth ?? Infinity,
      availableWidth - otherWidth - (props.sidebarSizing?.minCenterWidth ?? 120)
    ));
  };
  const widthFor = (side) => sidebarSizes[side]?.width === void 0 ? defaultWidth(side) : Math.min(maxSidebarWidth(side), Math.max(minimumSidebarWidth, sidebarSizes[side].width));
  const presentationFor = (id) => panelState[id] ?? { placement: "hidden" };
  const renderedPresentationFor = (id) => presentationFor(id).placement === "hidden" ? closingPanels[id] ?? presentationFor(id) : presentationFor(id);
  const isClosing = (id) => !!closingPanels[id] && presentationFor(id).placement === "hidden";
  const stackProps = (side) => ({
    "data-closing": !panelsFor(side).some((panel) => presentationFor(panel.id).placement === "docked") || void 0,
    style: { "--aui-stack-width": `${widthFor(side)}px` }
  });
  const updatePanel = (id, next) => {
    const candidate = { ...panelState, [id]: next };
    const updated = panelSelection === "single" ? singlePanelPerSide(candidate, sideIDs, panelState, id) : candidate;
    if (props.panelState === void 0) setUncontrolledPanelState(updated);
    props.onPanelStateChange?.(updated);
  };
  const togglePanel = (_side, id) => {
    const toggle = allPanels.find((panel) => panel.id === id)?.toggle;
    if (toggle) {
      toggle.onToggle();
      return;
    }
    if (allPanels.find((panel) => panel.id === id)?.command) {
      setCommandID(id);
      return;
    }
    const current = presentationFor(id);
    updatePanel(
      id,
      current.placement === "hidden" ? { placement: "docked" } : { placement: "hidden" }
    );
  };
  useImperativeHandle(props.controllerRef, () => ({
    showPanel(id) {
      const panel = allPanels.find((entry) => entry.id === id);
      if (!panel) return;
      if (panel.command) {
        setCommandID(id);
        return;
      }
      const current = presentationFor(id);
      updatePanel(id, current.placement === "hidden" ? { placement: "docked" } : current);
      reveal(leftPanels.includes(panel) ? "left" : "right");
    }
  }));
  const detachPanel = (side, id) => {
    const body = bodyRef.current;
    const count = panelsFor(side).filter(
      (panel) => presentationFor(panel.id).placement === "floating"
    ).length;
    const width = widthFor(side);
    const x = side === "left" ? 64 + count * 18 : Math.max(64, (body?.clientWidth ?? 900) - 64 - width - count * 18);
    updatePanel(id, {
      placement: "floating",
      position: { x, y: 56 + count * 28 }
    });
  };
  const restackPanel = (_side, id) => {
    updatePanel(id, { placement: "docked" });
  };
  const movePanel = (side, id, x, y) => {
    const body = bodyRef.current;
    const width = widthFor(side);
    const maxX = (body?.clientWidth ?? 1200) - width - 8;
    const maxY = (body?.clientHeight ?? 700) - 48;
    const clamped = {
      x: Math.min(Math.max(x, 8), Math.max(8, maxX)),
      y: Math.min(Math.max(y, 8), Math.max(8, maxY))
    };
    updatePanel(id, { placement: "floating", position: clamped });
  };
  const maybeRestack = (side, id, x) => {
    const bodyWidth = bodyRef.current?.clientWidth ?? 1200;
    const nearHome = side === "left" ? x < RESTACK_DISTANCE : bodyWidth - (x + widthFor(side)) < RESTACK_DISTANCE;
    if (nearHome) restackPanel(side, id);
  };
  const rail = (side) => /* @__PURE__ */ jsx(Rail, { children: panelsFor(side).filter((panel) => panel.inToolbar !== false).map((panel) => /* @__PURE__ */ jsxs(Fragment2, { children: [
    panel.separatorBefore ? /* @__PURE__ */ jsx("span", { className: "aui-rail-separator", role: "separator" }) : null,
    /* @__PURE__ */ jsx(
      RailButton,
      {
        label: panel.title,
        active: panel.command ? void 0 : presentationFor(panel.id).placement !== "hidden",
        "aria-haspopup": panel.command ? "dialog" : void 0,
        onClick: () => togglePanel(side, panel.id),
        children: panel.icon
      }
    )
  ] }, panel.id)) });
  const collectionContent = (panel) => {
    if (!panel.collection) {
      const inspector = panel.contentLayout === "inspector" || panel.contentLayout !== "custom" && rightPanels.includes(panel);
      return inspector ? /* @__PURE__ */ jsx(Inspector, { children: panel.content }) : panel.content;
    }
    const side = leftPanels.includes(panel) ? "left" : "right";
    const floating = presentationFor(panel.id).placement === "floating";
    return /* @__PURE__ */ jsx(CollectionHost.Provider, { value: { title: panel.title, controls: unifiedSidebar ? [] : [
      {
        id: "panel-placement",
        label: `${floating ? "Dock" : "Float"} ${panel.title}`,
        icon: /* @__PURE__ */ jsx(AetherIcon, { name: "layout" }),
        separatorBefore: true,
        onClick: () => floating ? restackPanel(side, panel.id) : detachPanel(side, panel.id)
      },
      { id: "panel-close", label: `Close ${panel.title}`, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }), onClick: () => togglePanel(side, panel.id) }
    ] }, children: panel.content });
  };
  const stackedCard = (side, panel) => /* @__PURE__ */ jsxs("div", { className: "aui-shell-panel", "data-closing": isClosing(panel.id) || void 0, "aria-hidden": isClosing(panel.id) || void 0, inert: isClosing(panel.id) || void 0, style: { width: unifiedSidebar ? "100%" : widthFor(side) }, children: [
    unifiedSidebar || panel.chromeless || panel.collection ? null : /* @__PURE__ */ jsxs("div", { className: "aui-shell-panel-header", children: [
      /* @__PURE__ */ jsx("span", { children: panel.title }),
      /* @__PURE__ */ jsxs("span", { className: "aui-float-panel-actions", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            className: "aui-float-panel-action",
            title: "Float panel",
            "aria-label": `Float ${panel.title}`,
            onClick: () => detachPanel(side, panel.id),
            children: /* @__PURE__ */ jsx(AetherIcon, { name: "mode-floating" })
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            className: "aui-float-panel-action",
            title: "Close panel",
            "aria-label": `Close ${panel.title}`,
            onClick: () => togglePanel(side, panel.id),
            children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-shell-panel-body", children: panelContent(panel) })
  ] }, panel.id);
  const stackedIDs = (side) => {
    return panelsFor(side).filter((panel) => !panel.toggle && renderedPresentationFor(panel.id).placement === "docked").map((panel) => panel.id);
  };
  const tornLayer = (side) => {
    return panelsFor(side).filter((panel) => renderedPresentationFor(panel.id).placement === "floating").map((panel) => {
      const position = renderedPresentationFor(panel.id).position ?? { x: 64, y: 56 };
      return /* @__PURE__ */ jsx(
        FloatingPanel,
        {
          shellSide: side,
          closing: isClosing(panel.id),
          title: panel.title,
          x: position.x,
          y: position.y,
          width: widthFor(side),
          onMove: (x, y) => movePanel(side, panel.id, x, y),
          onDragEnd: (x) => maybeRestack(side, panel.id, x),
          onDock: () => restackPanel(side, panel.id),
          onClose: () => togglePanel(side, panel.id),
          children: panelContent(panel)
        },
        panel.id
      );
    });
  };
  const tabsFor = (side) => studio ? side === "left" ? "bottom" : "top" : sidebarTabs;
  const trayPosition = (side) => {
    const anchor = tabsFor(side) ?? side;
    return panelsOnOuterEdge ? { left: "right", right: "left", top: "bottom", bottom: "top" }[anchor] : anchor;
  };
  const sidebarPlacement = (side) => ({
    "data-sidebar-tabs": tabsFor(side) ?? "side",
    "data-sidebar-anchor": tabsFor(side) ?? side,
    "data-sidebar-opening": panelsOnOuterEdge ? "outside" : "inside",
    "data-tray-position": trayPosition(side),
    style: { "--aui-sidebar-expanded-width": `${widthFor(side)}px` }
  });
  const floatingStack = (side, accessories = true) => {
    const ids = stackedIDs(side);
    const panelsFirst = panelsOnOuterEdge ? side === "left" : side === "right";
    const pinnedIDs = studio ? ids.filter((id) => pinned.has(id)) : [];
    if (unifiedSidebar && studio && side === "left" && panelsFor(side).some((panel) => pinned.has(panel.id))) {
      const aux = panelsFor(side).filter((panel) => !pinned.has(panel.id));
      const auxOpen = aux.filter((panel) => !panel.toggle && !panel.command && ids.includes(panel.id));
      const buttons = aux.filter((panel) => panel.inToolbar !== false);
      return /* @__PURE__ */ jsxs("div", { className: "aui-shell-fledge aui-shell-fledge--left", "data-studio-pinned": "true", "data-auxiliary-open": auxOpen.length > 0, ...sidebarPlacement(side), children: [
        /* @__PURE__ */ jsx("section", { className: "aui-studio-aux-sidebar", "aria-label": "Aux sidebar", hidden: !auxOpen.length, children: auxOpen.map((panel) => stackedCard(side, panel)) }),
        /* @__PURE__ */ jsxs("div", { className: "aui-studio-tree-column", children: [
          pinnedIDs.length > 0 && /* @__PURE__ */ jsxs("div", { className: "aui-studio-pinned", children: [
            panelsFor(side).filter((panel) => pinnedIDs.includes(panel.id)).map((panel) => stackedCard(side, panel)),
            /* @__PURE__ */ jsx(PanelResizeHandle, { edge: "right", label: "Resize features sidebar width", value: widthFor(side), min: minimumSidebarWidth, max: maxSidebarWidth(side), onChange: (width) => resizeSidebar(side, { width }), onReset: () => resizeSidebar(side, { width: void 0 }) })
          ] }),
          buttons.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-studio-aux-toolbar", children: /* @__PURE__ */ jsx(FloatingToolbar, { ariaLabel: "Aux toolbar", variant: "document", onAction: (id) => togglePanel(side, id), groups: [{ id: "aux", label: "Aux", actions: buttons.map((panel) => ({
            id: panel.id,
            label: panel.title,
            icon: panel.icon,
            pressed: panel.command ? void 0 : panel.toggle ? panel.toggle.pressed : presentationFor(panel.id).placement !== "hidden"
          })) }] }) })
        ] })
      ] });
    }
    if (unifiedSidebar) return /* @__PURE__ */ jsxs("div", { className: `aui-shell-fledge aui-shell-fledge--${side}`, ...sidebarPlacement(side), children: [
      accessories && props.sideTop?.[side] ? /* @__PURE__ */ jsx("div", { className: "aui-shell-side-accessory aui-shell-side-accessory--top", children: props.sideTop[side] }) : null,
      tabbedSidebar(side, ids, true),
      accessories && props.sideBottom?.[side] ? /* @__PURE__ */ jsx("div", { className: "aui-shell-side-accessory aui-shell-side-accessory--bottom", children: props.sideBottom[side] }) : null
    ] });
    return /* @__PURE__ */ jsxs(
      "div",
      {
        className: `aui-shell-fledge aui-shell-fledge--${side}`,
        "data-panels-first": panelsFirst || void 0,
        children: [
          panelsFirst && ids.length > 0 ? floatingCards(side, ids) : null,
          /* @__PURE__ */ jsx("div", { className: "aui-float", children: rail(side) }),
          !panelsFirst && ids.length > 0 ? floatingCards(side, ids) : null
        ]
      }
    );
  };
  const tabbedSidebar = (side, ids, floating = false) => {
    const panels = panelsFor(side);
    const buttons = panels.filter((panel) => panel.inToolbar !== false);
    const activeTab = panels.find((panel) => !panel.toggle && !panel.command && !pinned.has(panel.id) && presentationFor(panel.id).placement !== "hidden")?.id ?? null;
    return /* @__PURE__ */ jsx(
      TabbedSidebar,
      {
        variant: studio ? "slim" : "standard",
        floating,
        heightPolicy: sidebarSizes[side]?.height ?? panels.find((panel) => panel.id === activeTab)?.floatingHeight ?? (side === "left" || studio ? "fill" : "content"),
        ariaLabel: `${side === "left" ? "Left" : "Right"} sidebar`,
        tabs: buttons.map((panel) => ({ id: panel.id, label: panel.title, icon: panel.icon, separatorBefore: panel.separatorBefore, command: !!panel.command, pressed: panel.toggle?.pressed })),
        activeTab,
        activeTabs: studio ? buttons.filter((panel) => presentationFor(panel.id).placement !== "hidden").map((panel) => panel.id) : void 0,
        onTabToggle: studio ? (id) => togglePanel(side, id) : void 0,
        tabPosition: trayPosition(side),
        anchor: tabsFor(side) ?? side,
        expanded: ids.length > 0,
        resize: {
          side,
          width: widthFor(side),
          minWidth: minimumSidebarWidth,
          maxWidth: maxSidebarWidth(side),
          onWidthChange: (width) => resizeSidebar(side, { width }),
          onHeightChange: (height) => resizeSidebar(side, { height }),
          onResetWidth: () => resizeSidebar(side, { width: void 0 }),
          onResetHeight: () => resizeSidebar(side, { height: void 0 })
        },
        attachment: props.sidebarAttachment ?? chrome.sidebarAttachment,
        animate: animatePanels,
        style: { "--aui-sidebar-expanded-width": `${widthFor(side)}px` },
        onTabChange: (id) => {
          if (id ?? activeTab) togglePanel(side, id ?? activeTab);
        },
        children: panels.filter((panel) => ids.includes(panel.id)).map((panel) => stackedCard(side, panel))
      }
    );
  };
  const floatingCards = (side, ids) => /* @__PURE__ */ jsx("div", { className: "aui-shell-flstack", ...stackProps(side), children: panelsFor(side).filter((panel) => ids.includes(panel.id)).map((panel) => /* @__PURE__ */ jsx("div", { className: "aui-float", children: stackedCard(side, panel) }, panel.id)) });
  const canvasEdge = (edge, content) => /* @__PURE__ */ jsx(
    "div",
    {
      className: `aui-shell-edge aui-shell-edge--${edge}`,
      onMouseEnter: () => reveal(edge),
      onMouseLeave: () => scheduleHide(edge),
      children: revealed.has(edge) ? content : /* @__PURE__ */ jsx("div", { className: `aui-shell-handle aui-shell-handle--${edge}` })
    }
  );
  const overlayChrome = (canvasMode) => {
    const top = toolbar ? /* @__PURE__ */ jsx("div", { className: "aui-shell-fltoolbar", "data-toolbar-frame": frameToolbar, children: frameToolbar ? /* @__PURE__ */ jsx("div", { className: "aui-float", children: toolbar }) : toolbar }) : null;
    const leftChrome = leftPanels.length ? floatingStack("left", !canvasMode) : null;
    const rightChrome = rightPanels.length ? floatingStack("right", !canvasMode) : null;
    if (!canvasMode) {
      return /* @__PURE__ */ jsxs(Fragment, { children: [
        top,
        leftChrome,
        rightChrome
      ] });
    }
    return /* @__PURE__ */ jsxs(Fragment, { children: [
      top ? canvasEdge("top", top) : null,
      leftChrome ? canvasEdge("left", leftChrome) : null,
      rightChrome ? canvasEdge("right", rightChrome) : null
    ] });
  };
  const dockedSide = (side) => {
    const panels = panelsFor(side);
    const ids = stackedIDs(side);
    const isRight = side === "right";
    const panelsFirst = panelsOnOuterEdge ? !isRight : isRight;
    const visible = preset === "docked" && panels.length > 0;
    if (unifiedSidebar) {
      const pinnedColumn = visible ? panels.filter((panel) => pinned.has(panel.id) && ids.includes(panel.id)).map((panel) => /* @__PURE__ */ jsx("div", { className: "aui-shell-pinned", style: { width: defaultWidth(side) }, children: stackedCard(side, panel) }, panel.id)) : null;
      return /* @__PURE__ */ jsxs("div", { className: `aui-shell-side${isRight ? " aui-shell-side--right" : ""}`, hidden: !visible, ...sidebarPlacement(side), children: [
        isRight ? pinnedColumn : null,
        visible ? tabbedSidebar(side, ids.filter((id) => !pinned.has(id))) : null,
        isRight ? null : pinnedColumn
      ] });
    }
    return /* @__PURE__ */ jsxs(
      "div",
      {
        className: `aui-shell-side${isRight ? " aui-shell-side--right" : ""}`,
        hidden: !visible,
        "data-panels-first": panelsFirst || void 0,
        children: [
          visible && panelsFirst && ids.length > 0 ? /* @__PURE__ */ jsx("div", { className: "aui-shell-stack", ...stackProps(side), children: panels.filter((panel) => ids.includes(panel.id)).map((panel) => stackedCard(side, panel)) }) : null,
          visible ? rail(side) : null,
          visible && !panelsFirst && ids.length > 0 ? /* @__PURE__ */ jsx("div", { className: "aui-shell-stack", ...stackProps(side), children: panels.filter((panel) => ids.includes(panel.id)).map((panel) => stackedCard(side, panel)) }) : null
        ]
      }
    );
  };
  useRegisterWorkspaceControls(bodyRef, {
    panels: allPanels.filter((panel) => !panel.command).map((panel) => ({ id: panel.id, label: panel.title, side: leftPanels.includes(panel) ? "left" : "right", placement: presentationFor(panel.id).placement })),
    show: (id) => {
      const panel = allPanels.find((panel2) => panel2.id === id);
      if (!panel) return;
      if (panel.command) {
        setCommandID(id);
        return;
      }
      updatePanel(id, { placement: "docked" });
      reveal(leftPanels.includes(panel) ? "left" : "right");
    },
    place: (id, placement) => {
      const side = leftPanels.some((panel) => panel.id === id) ? "left" : "right";
      if (placement === "floating") detachPanel(side, id);
      else updatePanel(id, { placement });
    },
    reset: () => {
      const next = Object.fromEntries(allPanels.map((panel) => [panel.id, initialPanelState.current[panel.id] ?? { placement: "hidden" }]));
      if (props.panelState === void 0) setUncontrolledPanelState(next);
      props.onPanelStateChange?.(next);
    }
  });
  return /* @__PURE__ */ jsx(WorkspaceLayoutContext.Provider, { value: preset, children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: `aui-shell${panelsOnOuterEdge ? " aui-shell--panels-outer-edge" : ""}`,
      "data-design": props.design ?? "standard",
      "data-layout-ready": initialLayoutReady,
      "data-animate-panels": animatePanels,
      "data-measure-insets": "true",
      "data-content-presentation": props.contentPresentation ?? "canvas",
      "data-layout": preset,
      "data-panel-selection": panelSelection,
      "data-sidebar-variant": sidebarVariant,
      "data-panel-relationship": preset === "docked" ? "push" : "overlay",
      style: { "--aui-shell-motion-duration": `${WORKSPACE_PANEL_DURATION_MS}ms`, ...contentInsets, ...style },
      children: [
        /* @__PURE__ */ jsxs("div", { className: "aui-shell-body", children: [
          props.toolbarSpan !== "center" && /* @__PURE__ */ jsx(
            "div",
            {
              className: "aui-shell-toolbar",
              hidden: preset !== "docked" || !toolbar,
              children: preset === "docked" ? toolbar : null
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "aui-shell-area", ref: bodyRef, children: [
            dockedSide("left"),
            /* @__PURE__ */ jsxs("div", { className: "aui-shell-main", children: [
              props.toolbarSpan === "center" && /* @__PURE__ */ jsx("div", { className: "aui-shell-toolbar", hidden: preset !== "docked" || !toolbar, children: preset === "docked" ? toolbar : null }),
              /* @__PURE__ */ jsxs("div", { className: "aui-shell-center", "data-has-bottom-dock": Boolean(props.centerBottom) || void 0, children: [
                /* @__PURE__ */ jsx("div", { className: props.centerBottom ? "aui-shell-center-canvas" : "aui-shell-center-slot", children: /* @__PURE__ */ jsx("div", { className: props.contentPresentation === "framed" ? "aui-shell-content" : "aui-shell-center-slot", children }) }),
                props.centerBottom,
                preset !== "floating" ? ["left", "right"].flatMap((side) => [
                  props.sideTop?.[side] ? /* @__PURE__ */ jsx("div", { className: `aui-shell-edge-accessory aui-shell-edge-accessory--${side} aui-shell-edge-accessory--top`, children: props.sideTop[side] }, `${side}-top`) : null,
                  props.sideBottom?.[side] ? /* @__PURE__ */ jsx("div", { className: `aui-shell-edge-accessory aui-shell-edge-accessory--${side} aui-shell-edge-accessory--bottom`, children: props.sideBottom[side] }, `${side}-bottom`) : null
                ]) : null
              ] })
            ] }),
            dockedSide("right"),
            preset !== "docked" ? overlayChrome(preset === "canvas") : null,
            tornLayer("left"),
            tornLayer("right"),
            preservePanelContent ? /* @__PURE__ */ jsx("div", { hidden: true, children: allPanels.filter((panel) => renderedPresentationFor(panel.id).placement === "hidden" || preset === "canvas" && presentationFor(panel.id).placement === "docked" && !revealed.has(leftPanels.includes(panel) ? "left" : "right")).map((panel) => /* @__PURE__ */ jsx("div", { children: panelContent(panel) }, panel.id)) }) : null,
            preservePanelContent ? allPanels.map((panel) => {
              const host = panelHosts.current.get(panel.id);
              return host ? createPortal(collectionContent(panel), host, panel.id) : null;
            }) : null
          ] }),
          bottom ? /* @__PURE__ */ jsx("div", { className: "aui-shell-bottom", ref: measureShellBottom, children: bottom }) : null
        ] }),
        statusBar,
        commandID && allPanels.find((panel) => panel.id === commandID)?.command?.(closeCommand)
      ]
    }
  ) });
}
export {
  FloatingPanel,
  LayoutPresetButton,
  WorkspaceShell,
  nextLayoutPreset
};
