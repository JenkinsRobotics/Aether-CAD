import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { StudioDesignContext } from "./StudioDesignContext.js";
import { STUDIO_TOOLBAR_DENSITIES, StudioToolBar } from "./StudioToolBar.js";
import { ToolHelp } from "./ToolHelp.js";
import { ToolTrayScroll } from "./ToolTrayScroll.js";
import { useContext, useLayoutEffect, useRef, useState } from "react";
import { WorkspaceLayoutContext } from "./WorkspaceLayoutContext.js";
import { AetherIcon } from "./AetherIcon.js";
import { Menu } from "./Menu.js";
import { Ribbon, RibbonTool } from "./Ribbon.js";
import { Tabs } from "./Tabs.js";
import { ToolMenuButton, WorkspaceSwitcher } from "./WorkspaceSwitcher.js";
import "./WorkspaceRibbon.css";
import "./IntegratedWorkspaceToolbar.css";
import { CommandSearch } from "./CommandSearch.js";
import { setWorkspaceChrome, useWorkspaceChrome } from "./WorkspaceChromePreferences.js";
const WORKSPACE_RIBBON_DENSITIES = STUDIO_TOOLBAR_DENSITIES;
function WorkspaceRibbon({
  workspaces,
  workspaceID,
  onWorkspaceSelect,
  tabs,
  compactGroups,
  compactTools = false,
  activeTabID,
  onTabSelect,
  onCommand,
  onVariantSelect,
  workspaceLayout: appWorkspaceLayout = "column",
  appearance: appAppearance = "glass",
  moreItems = [],
  moreLabel = "More tools",
  density: controlledDensity,
  defaultDensity,
  onDensityChange,
  docked,
  commandShortcuts,
  withClassicRibbon = false,
  toolRow,
  variant = "standard",
  searchCommands,
  onSearchSelect,
  searchShortcut = true,
  headerActions,
  onPlacementChange
}) {
  const integrated = variant === "integrated";
  const placed = variant === "docked" || variant === "floating";
  const [toolsHidden, setToolsHidden] = useState(false);
  const [names, setNames] = useRibbonNames(placed ? variant : null);
  const [fitRef, fit] = useFittingGroups(placed && !toolsHidden, activeTabID);
  const layout = useContext(WorkspaceLayoutContext);
  const studio = useContext(StudioDesignContext);
  const chrome = useWorkspaceChrome();
  const workspaceLayout = integrated ? "none" : chrome.workspaceSelector === "app" ? appWorkspaceLayout : chrome.workspaceSelector;
  const appearance = integrated ? "glass" : chrome.ribbonAppearance === "app" ? appAppearance : chrome.ribbonAppearance;
  const isDocked = docked ?? layout === "docked";
  const [ownDensity, setOwnDensity] = useState(defaultDensity ?? (integrated ? "standard" : "expanded"));
  const density = integrated || chrome.toolbarDensity === "app" ? controlledDensity ?? ownDensity : chrome.toolbarDensity;
  const setDensity = (next) => {
    if (!integrated && chrome.toolbarDensity !== "app") setWorkspaceChrome({ toolbarDensity: next });
    setOwnDensity(next);
    onDensityChange?.(next);
  };
  const activeTab = tabs.find((tab) => tab.id === activeTabID && !tab.disabled);
  const compact = compactGroups ?? (compactTools ? activeTab?.groups : void 0);
  const iconStrip = !integrated && density === "compact" && compact !== void 0;
  const visibleGroups = iconStrip ? compact : activeTab?.groups;
  const groupMenu = (group) => (group.menuItems ?? group.tools.flatMap(
    (tool) => (tool.variants?.length ? tool.variants : [tool]).map((entry) => ({
      id: entry.id,
      label: entry.label,
      icon: entry.icon,
      disabled: entry.disabled,
      disabledReason: entry.disabledReason
    }))
  )).map((item, index) => index === 0 ? { ...item, heading: item.heading ?? group.label } : item);
  const moreMenu = [
    ...WORKSPACE_RIBBON_DENSITIES.map((entry, index) => ({ id: `density:${entry.id}`, label: entry.label, kind: "radio", checked: density === entry.id, heading: index === 0 ? "Density" : void 0 })),
    ...moreItems.map((item, index) => index === 0 ? { ...item, separatorBefore: true, heading: item.heading ?? "Toolbar" } : item)
  ];
  const onMore = (id) => {
    if (id.startsWith("density:")) setDensity(id.slice(8));
    else onCommand(id);
  };
  const [settingsMenu, setSettingsMenu] = useState(null);
  const searchable = /* @__PURE__ */ new Map();
  if (integrated && !searchCommands) {
    const addMenu = (items, category) => {
      for (const item of items) {
        if (item.children?.length) addMenu(item.children, category);
        else searchable.set(item.id, { id: item.id, label: item.label, icon: item.icon, category, disabled: item.disabled, disabledReason: item.disabledReason });
      }
    };
    for (const tab of tabs) for (const group of tab.groups) {
      addMenu(groupMenu(group), `${tab.label} \xB7 ${group.label}`);
      for (const tool of group.tools) searchable.set(tool.id, { ...tool, category: `${tab.label} \xB7 ${group.label}` });
    }
  }
  const renderTool = (tool) => /* @__PURE__ */ jsxs("span", { className: "aui-workspace-ribbon-tool", "data-tool-id": tool.id, children: [
    /* @__PURE__ */ jsx(ToolHelp, { label: tool.label, help: tool.help, disabledReason: tool.disabled ? tool.disabledReason : void 0, children: /* @__PURE__ */ jsx(
      RibbonTool,
      {
        label: tool.label,
        icon: tool.icon,
        active: tool.active,
        "aria-pressed": tool.active,
        disabled: tool.disabled,
        title: tool.help ? void 0 : tool.disabledReason ?? tool.label,
        onClick: () => onCommand(tool.id)
      }
    ) }),
    tool.variants?.length ? (
      // The caret is named for the family, not for whichever
      // variant is showing, so its name does not move under you.
      /* @__PURE__ */ jsx(
        ToolMenuButton,
        {
          className: "aui-workspace-ribbon-variants",
          menuClassName: "aui-tool-menu",
          anchorTo: "group",
          label: `${tool.variants.find((variant2) => variant2.id === tool.id)?.label ?? tool.label} variants`,
          onSelect: (variantID) => onVariantSelect ? onVariantSelect(tool.id, variantID) : onCommand(variantID),
          items: tool.variants.map((variant2) => ({
            id: variant2.id,
            label: variant2.label,
            icon: variant2.icon,
            help: variant2.help,
            kind: "radio",
            checked: variant2.id === (tool.selectedVariantID ?? tool.id),
            disabled: variant2.disabled,
            disabledReason: variant2.disabledReason
          })),
          children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: "rotate(90deg)" }, width: 9, height: 9 })
        }
      )
    ) : null
  ] }, tool.id);
  if (placed) {
    const groups = activeTab?.groups ?? [];
    const floating = variant === "floating";
    const listed = groups.slice(fit);
    const overflowMenu = [
      ...listed.map((group, index) => ({
        id: `group:${group.id}`,
        label: group.label,
        icon: group.tools[0]?.icon,
        children: groupMenu(group),
        heading: index === 0 ? "Groups that do not fit" : void 0
      })),
      { id: "names:categories", label: "Category names", kind: "checkbox", checked: names.categories, heading: "Show", separatorBefore: listed.length > 0 },
      { id: "names:tools", label: "Tool names", kind: "checkbox", checked: names.tools },
      ...moreItems.map((item, index) => index === 0 ? { ...item, separatorBefore: true, heading: item.heading ?? "Toolbar" } : item)
    ];
    const onOverflow = (id) => {
      if (id === "names:categories") setNames({ ...names, categories: !names.categories });
      else if (id === "names:tools") setNames({ ...names, tools: !names.tools });
      else onCommand(id);
    };
    return /* @__PURE__ */ jsxs(
      "div",
      {
        className: "aui-workspace-ribbon",
        "data-variant": variant,
        "data-toolbar-menu-boundary": "",
        "data-tools-hidden": toolsHidden || void 0,
        "data-category-names": names.categories || void 0,
        "data-tool-names": names.tools || void 0,
        children: [
          workspaces.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-workspaces", children: /* @__PURE__ */ jsx(WorkspaceSwitcher, { workspaces, workspaceID, onSelect: onWorkspaceSelect, menuClassName: "aui-tool-menu" }) }),
          /* @__PURE__ */ jsx("nav", { className: "aui-workspace-ribbon-tabs", "aria-label": "Workspace tools", children: /* @__PURE__ */ jsx(Tabs, { tabs, activeID: activeTabID, onSelect: onTabSelect }) }),
          /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon-tools", role: "tabpanel", "aria-label": activeTab?.label ?? "Tools", children: [
            floating && /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "aui-workspace-ribbon-hide",
                "aria-expanded": !toolsHidden,
                "aria-label": toolsHidden ? "Show tools" : "Hide tools",
                title: toolsHidden ? "Show tools" : "Hide tools",
                onClick: () => setToolsHidden((hidden) => !hidden),
                children: /* @__PURE__ */ jsx(AetherIcon, { name: toolsHidden ? "chevron-right" : "chevron-left" })
              }
            ),
            !toolsHidden && /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx("div", { ref: fitRef, className: "aui-workspace-ribbon-fit", children: /* @__PURE__ */ jsx(Ribbon, { children: groups.map((group, index) => (
                // Groups past the fit stay laid out (hidden, inert) so their widths can be measured.
                /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon-group", "data-overflowed": index >= fit || void 0, inert: index >= fit || void 0, children: [
                  /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-buttons", children: group.tools.map(renderTool) }),
                  /* @__PURE__ */ jsxs(
                    ToolMenuButton,
                    {
                      className: "aui-workspace-ribbon-caption",
                      menuClassName: "aui-tool-menu",
                      label: `${group.label} tools`,
                      items: groupMenu(group),
                      onSelect: onCommand,
                      anchorTo: "group",
                      children: [
                        names.categories && group.label,
                        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: "rotate(90deg)" }, width: 10, height: 10 })
                      ]
                    }
                  )
                ] }, group.id)
              )) }) }),
              /* @__PURE__ */ jsx(
                ToolMenuButton,
                {
                  className: "aui-workspace-ribbon-overflow",
                  menuClassName: "aui-tool-menu",
                  label: !listed.length ? moreLabel : `${listed.length} more tool groups`,
                  items: overflowMenu,
                  onSelect: onOverflow,
                  children: /* @__PURE__ */ jsx(AetherIcon, { name: floating ? "more" : "chevron-right" })
                }
              )
            ] }),
            onPlacementChange && /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "aui-workspace-ribbon-placement",
                "aria-label": floating ? "Docked layout" : "Floating layout",
                title: floating ? "Switch to the docked layout" : "Switch to the floating layout",
                onClick: () => onPlacementChange(floating ? "docked" : "floating"),
                children: /* @__PURE__ */ jsx(AetherIcon, { name: floating ? "mode-docked" : "mode-floating" })
              }
            )
          ] })
        ]
      }
    );
  }
  const studioBar = studio && !integrated ? /* @__PURE__ */ jsx(
    StudioToolBar,
    {
      workspaces,
      workspaceID,
      onWorkspaceSelect,
      tabs,
      compactGroups,
      activeTabID,
      onTabSelect,
      commandShortcuts,
      onCommand,
      onVariantSelect,
      moreItems,
      moreLabel,
      density,
      onDensityChange: setDensity,
      toolRow
    }
  ) : null;
  if (studioBar && !withClassicRibbon) return studioBar;
  const classic = /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon", "data-variant": variant, "data-toolbar-menu-boundary": "", onContextMenu: (event) => {
    event.preventDefault();
    setSettingsMenu({ x: event.clientX, y: event.clientY });
  }, "data-docked": isDocked || void 0, "data-workspace-layout": workspaceLayout, "data-appearance": appearance, "data-density": density, "data-icon-strip": iconStrip || void 0, "data-compact-tools": compactTools || void 0, children: [
    /* @__PURE__ */ jsx(
      Menu,
      {
        open: !!settingsMenu,
        anchor: settingsMenu,
        ariaLabel: "Toolbar settings",
        applicationCommands: false,
        items: moreMenu,
        onClose: () => setSettingsMenu(null),
        onSelect: (id) => {
          setSettingsMenu(null);
          onMore(id);
        }
      }
    ),
    integrated && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "aui-integrated-toolbar-header", role: "group", "aria-label": "Workspace and command controls", children: [
      workspaces.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-integrated-toolbar-workspace", children: /* @__PURE__ */ jsx(WorkspaceSwitcher, { workspaces, workspaceID, onSelect: onWorkspaceSelect, menuClassName: "aui-tool-menu" }) }),
      /* @__PURE__ */ jsx(
        CommandSearch,
        {
          className: "aui-integrated-toolbar-search",
          commands: searchCommands ?? [...searchable.values()],
          onSelect: onSearchSelect ?? onCommand,
          registerShortcut: searchShortcut
        }
      ),
      headerActions && /* @__PURE__ */ jsx("div", { className: "aui-integrated-toolbar-actions", children: headerActions }),
      /* @__PURE__ */ jsx(ToolMenuButton, { className: "aui-integrated-toolbar-more", menuClassName: "aui-tool-menu", label: moreLabel, items: moreMenu, onSelect: onMore, children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
    ] }) }),
    !iconStrip && workspaceLayout === "column" && workspaces.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-workspaces", children: /* @__PURE__ */ jsx(WorkspaceSwitcher, { workspaces, workspaceID, onSelect: onWorkspaceSelect, menuClassName: "aui-tool-menu" }) }),
    (!iconStrip || compactTools) && /* @__PURE__ */ jsxs("nav", { className: "aui-workspace-ribbon-tabs", "aria-label": "Workspace tools", children: [
      workspaceLayout === "strip" && workspaces.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-workspaces", children: /* @__PURE__ */ jsx(
        Tabs,
        {
          tabs: workspaces.map((item) => ({ ...item, title: item.disabledReason })),
          activeID: workspaceID,
          onSelect: onWorkspaceSelect
        }
      ) }),
      /* @__PURE__ */ jsx(Tabs, { tabs, activeID: activeTabID, onSelect: onTabSelect })
    ] }),
    /* @__PURE__ */ jsx(ToolTrayScroll, { label: iconStrip ? "Compact tools" : activeTab?.label ?? "Tools", role: iconStrip ? "group" : "tabpanel", children: /* @__PURE__ */ jsxs(Ribbon, { children: [
      density === "compact" && !iconStrip && activeTab?.groups.map((group) => /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-group", "data-compact": "", children: /* @__PURE__ */ jsx(ToolMenuButton, { className: "aui-workspace-ribbon-group-button", menuClassName: "aui-tool-menu", label: `${group.label} tools`, items: groupMenu(group), onSelect: onCommand, placement: "bottom-start", children: /* @__PURE__ */ jsx("span", { className: "aui-ribbon-tool-icon", "aria-hidden": "true", children: group.tools[0]?.icon }) }) }, group.id)),
      (density !== "compact" || iconStrip) && visibleGroups?.map((group) => /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon-group", children: [
        /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-buttons", children: group.tools.map(renderTool) }),
        /* @__PURE__ */ jsxs(
          ToolMenuButton,
          {
            className: "aui-workspace-ribbon-caption",
            menuClassName: "aui-tool-menu",
            label: `${group.label} tools`,
            items: groupMenu(group),
            onSelect: onCommand,
            anchorTo: "group",
            children: [
              !iconStrip && group.label,
              /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: "rotate(90deg)" }, width: 10, height: 10 })
            ]
          }
        )
      ] }, group.id)),
      !integrated && /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-more", children: /* @__PURE__ */ jsx(ToolMenuButton, { className: "aui-workspace-ribbon-more-button", menuClassName: "aui-tool-menu", label: moreLabel, items: moreMenu, onSelect: onMore, anchorTo: "group", children: /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2022\u2022\u2022" }) }) })
    ] }) })
  ] });
  return studioBar ? /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon-pair", children: [
    classic,
    studioBar
  ] }) : classic;
}
function useFittingGroups(enabled, key) {
  const ref = useRef(null);
  const [fit, setFit] = useState(Infinity);
  useLayoutEffect(() => {
    const row = ref.current;
    if (!enabled || !row) {
      setFit(Infinity);
      return;
    }
    const groups = () => Array.from(row.querySelectorAll(".aui-workspace-ribbon-group"));
    const measure = () => {
      let used = 0, count = 0;
      for (const group of groups()) {
        used += group.offsetWidth;
        if (used > row.clientWidth + 0.5) break;
        count++;
      }
      setFit(count);
    };
    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(row);
    groups().forEach((group) => observer?.observe(group));
    return () => observer?.disconnect();
  }, [enabled, key]);
  return [ref, fit];
}
function useRibbonNames(variant) {
  const key = `aether-ui.ribbon-names.${variant}`;
  const fallback = { categories: variant === "docked", tools: variant === "docked" };
  const [names, setState] = useState(() => {
    try {
      return { ...fallback, ...JSON.parse(localStorage.getItem(key) ?? "{}") };
    } catch {
      return fallback;
    }
  });
  const setNames = (next) => {
    setState(next);
    try {
      localStorage.setItem(key, JSON.stringify(next));
    } catch {
    }
  };
  return [names, setNames];
}
export {
  WORKSPACE_RIBBON_DENSITIES,
  WorkspaceRibbon
};
