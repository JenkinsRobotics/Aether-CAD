import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect } from "react";
import { readHeaderPins, setHeaderPins } from "./header-controls.js";
import { DocumentBar } from "./DocumentBar.js";
import "./StudioAppFrame.css";
import { useStudioDesignDefaults } from "./StudioChrome.js";
import { StudioAccountControl } from "./StudioAccountControl.js";
import { AetherIcon } from "./AetherIcon.js";
function StudioDocumentBar({ documentName, documentState, onSearch, search, leading, trailing, className = "", ...props }) {
  useStudioDesignDefaults();
  const pins = JSON.stringify(props.defaultHeaderPins);
  useEffect(() => {
    if (props.application?.id !== "cad" || !pins) return;
    const key = "aether-cad.model-studio-header-v1";
    try {
      if (localStorage.getItem(key)) return;
      localStorage.setItem(key + ".previous", JSON.stringify(readHeaderPins("cad")));
      setHeaderPins("cad", JSON.parse(pins));
      localStorage.setItem(key, "1");
    } catch {
    }
  }, [props.application?.id, pins]);
  const account = props.account ?? /* @__PURE__ */ jsxs("div", { className: "aui-studio-account", children: [
    /* @__PURE__ */ jsx("div", { className: "aui-studio-account-mount", "data-aether-account": "" }),
    /* @__PURE__ */ jsx("div", { className: "aui-studio-local-account", children: /* @__PURE__ */ jsx(StudioAccountControl, { onSettings: () => props.application?.onSettings ? props.application.onSettings() : document.dispatchEvent(new window.CustomEvent("aether-open-settings", { cancelable: true })) }) })
  ] });
  return /* @__PURE__ */ jsx(
    DocumentBar,
    {
      ...props,
      variant: "transparent",
      compactControls: true,
      account,
      className: `aui-studio-document-bar ${className}`,
      trailing: /* @__PURE__ */ jsxs(Fragment, { children: [
        search ?? /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-studio-search", "aria-label": "Search commands", onClick: onSearch ?? (() => document.querySelector(".aui-studio-model-toolbar input[type=search], main input[type=search]")?.focus()), children: [
          /* @__PURE__ */ jsx(AetherIcon, { name: "search" }),
          /* @__PURE__ */ jsx("span", { children: "Search tools, features, or help\u2026" }),
          /* @__PURE__ */ jsx("kbd", { children: "\u2318 K" })
        ] }),
        trailing
      ] }),
      leading: /* @__PURE__ */ jsxs(Fragment, { children: [
        documentName && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("span", { className: "aui-studio-document-divider", "aria-hidden": "true" }),
          /* @__PURE__ */ jsx("strong", { className: "aui-studio-document-title", title: documentName, children: documentName })
        ] }),
        documentState,
        leading
      ] })
    }
  );
}
export {
  StudioDocumentBar
};
