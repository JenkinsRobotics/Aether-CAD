import { type ReactNode } from 'react';
import { type DocumentElementTab } from './DocumentTabBar.js';
import { type MenuItem } from './Menu.js';
import './DocumentTabTray.css';
/** A named group of tabs. Products persist these; the tray and browser draw them. */
export interface TabFolder {
    id: string;
    name: string;
    tabs: string[];
    collapsed: boolean;
}
export declare function assignTabFolder(folders: TabFolder[], tabID: string, folderID: string): TabFolder[];
/** What the tray and the browser both offer; one shape so they never drift. */
export interface DocumentTabControls {
    tabs: readonly DocumentElementTab[];
    label: string;
    leading?: ReactNode;
    revisionForTab?: (id: string) => {
        label: string;
        title: string;
    };
    tabActions?: (id: string) => readonly MenuItem[];
    onTabAction?: (id: string, action: string) => void;
    saveStatus?: string;
    /** Product-scoped creation actions shared by header, tray and background menu. */
    creation?: {
        label: string;
        items: MenuItem[];
        onSelect: (id: string) => void;
    };
    folders?: TabFolder[];
    onFoldersChange?: (folders: TabFolder[]) => void;
    onOrganize?: () => void;
    onManage?: () => void;
    onAdd: () => void;
    onReorder: (source: string, target: string) => void;
    onDetach: (id: string) => void;
}
export declare const documentTabAddItems: (onManage?: () => void) => MenuItem[];
/** The per-tab menu (product actions, arrange, close) and what choosing runs. */
export declare function documentTabMenu({ tabs, tabActions, onTabAction, onOrganize, onReorder, onDetach }: DocumentTabControls): {
    itemsFor: (id: string) => MenuItem[];
    choose: (id: string, action: string) => void;
};
/** Document tabs along the bottom with drag-to-reorder, drag-out to detach,
 *  folders and a per-tab menu. Products supply the tabs and lifecycle. */
export declare function DocumentTabTray(props: DocumentTabControls & {
    placement: 'bottom' | 'header';
    className?: string;
}): import("react").JSX.Element;
