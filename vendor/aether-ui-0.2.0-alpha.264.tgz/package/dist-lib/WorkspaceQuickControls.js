import { jsx, jsxs } from "react/jsx-runtime";
import { createPortal } from "react-dom";
import { useOverlayHost } from "./OverlayScope.js";
import { Children, Fragment, isValidElement, useEffect, useId, useState } from "react";
import { useWorkspaceControls } from "./workspace-controls.js";
import { AetherIcon } from "./AetherIcon.js";
import { AppLauncher } from "./AppLauncher.js";
import { AppearanceToggle, StudioModeButton, WorkspaceWindowMenu } from "./StudioChrome.js";
import { Button } from "./Button.js";
import { Dialog } from "./Dialog.js";
import { TextField } from "./TextField.js";
import { Popover } from "./Popover.js";
import { SettingsWindow } from "./SettingsWindow.js";
import { DEFAULT_HEADER_PINS, registerHeaderControls, useHeaderPins } from "./header-controls.js";
import "./WorkspaceQuickControls.css";
function controls(nodes) {
  return Children.toArray(nodes).flatMap((node) => isValidElement(node) && (node.type === Fragment || node.type === "div") ? controls(node.props.children) : [node]);
}
function controlLabel(node) {
  const props = isValidElement(node) ? node.props : {};
  return String(props["aria-label"] ?? props.label ?? props.title ?? "Workspace control");
}
function WorkspaceQuickControls({ appID, appName = appID, apps, viewControls, onShare, onSettings, account, defaultPinnedIDs = DEFAULT_HEADER_PINS, compact = false }) {
  const workspace = useWorkspaceControls(), owner = useId(), overlayHost = useOverlayHost();
  const pinned = useHeaderPins(appID, defaultPinnedIDs);
  const [pluginsOpen, setPluginsOpen] = useState(false), [settingsOpen, setSettingsOpen] = useState(false);
  const [sharing, setSharing] = useState(false), [copyStatus, setCopyStatus] = useState("");
  const [shareAnchor, setShareAnchor] = useState(null);
  const productControls = controls(viewControls), labels = productControls.map(controlLabel);
  const sharedIDs = { "Workspace layout": "layout", Comments: "comments", Reminders: "reminders", Plugins: "plugins", Notifications: "notifications", Help: "help" };
  const support = workspace ? [
    // Workspace arrangement is not an app-wide header icon (Jonathan, 2026-11-01); apps keep it with their tool bars.
    ...["comments", "reminders"].filter((id) => workspace.panels.some((panel) => panel.id === id) && !labels.includes(id === "comments" ? "Comments" : "Reminders")).map((id) => ({ id, label: id === "comments" ? "Comments" : "Reminders", icon: id === "comments" ? "comment" : "stopwatch", node: /* @__PURE__ */ jsx("button", { type: "button", className: "aui-icon-button", "aria-label": id === "comments" ? "Comments" : "Reminders", onClick: () => workspace.show(id), children: /* @__PURE__ */ jsx(AetherIcon, { name: id === "comments" ? "comment" : "stopwatch" }) }) }))
  ] : [];
  const entries = [
    { id: "theme", label: "Light / dark mode", icon: "appearance-system", node: /* @__PURE__ */ jsx(AppearanceToggle, {}) },
    { id: "share", label: "Share", icon: "link", node: /* @__PURE__ */ jsx("button", { type: "button", className: "aui-icon-button", "aria-label": "Share", title: "Share", onClick: (event) => {
      setShareAnchor(event.currentTarget);
      if (onShare) onShare();
      else {
        setCopyStatus("");
        setSharing(true);
      }
    }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "link" }) }) },
    { id: "apps", label: "App tray", icon: "apps", node: /* @__PURE__ */ jsx(AppLauncher, { apps, currentID: appID }) },
    ...productControls.map((node, index) => {
      const type = isValidElement(node) ? node.type : null;
      const props = isValidElement(node) ? node.props : {};
      const child = Children.toArray(props.children).find((child2) => isValidElement(child2) && child2.type === AetherIcon);
      const label = controlLabel(node);
      return { icon: type === StudioModeButton ? "mode-floating" : isValidElement(child) ? child.props.name : "windows", id: type === StudioModeButton ? "mode" : type === WorkspaceWindowMenu ? "tabs" : sharedIDs[label] ?? `${appID}-control-${index}`, label: type === StudioModeButton ? "Workspace mode" : type === WorkspaceWindowMenu ? "Windows and tabs" : label, node };
    }),
    ...support,
    ...!labels.includes("Plugins") && apps.length ? [{ id: "plugins", label: "Plugins", icon: "grid-2", node: /* @__PURE__ */ jsx("button", { type: "button", className: "aui-icon-button", "aria-label": "Plugins", onClick: () => setPluginsOpen(true), children: /* @__PURE__ */ jsx(AetherIcon, { name: "grid-2" }) }) }] : []
  ];
  const registration = JSON.stringify({ appID, name: appName, controls: entries.map(({ id, label, icon }) => ({ id, label, icon })), defaults: defaultPinnedIDs });
  useEffect(() => registerHeaderControls(owner, JSON.parse(registration)), [owner, registration]);
  function openSettings() {
    if (onSettings) onSettings();
    else if (document.dispatchEvent(new CustomEvent("aether-open-settings", { cancelable: true }))) setSettingsOpen(true);
  }
  const settingsButton = /* @__PURE__ */ jsx("button", { type: "button", className: "aui-icon-button", "aria-label": "Settings", title: "Settings", onClick: openSettings, children: /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }) });
  return /* @__PURE__ */ jsxs("div", { className: `aui-workspace-quick-controls${compact ? " aui-workspace-quick-controls--compact" : ""}`, children: [
    compact && settingsButton,
    /* @__PURE__ */ jsx("div", { className: "aui-quick-control-bar", role: "group", "aria-label": "User bar", children: pinned.map((id) => entries.find((entry) => entry.id === id)).filter((entry) => !!entry).map((entry) => /* @__PURE__ */ jsx("div", { className: "aui-quick-control", children: entry.node }, entry.id)) }),
    !compact && settingsButton,
    /* @__PURE__ */ jsxs(Popover, { open: sharing, anchor: shareAnchor, onClose: () => setSharing(false), ariaLabel: "Share document", placement: "bottom-end", className: "aui-quick-controls-menu", children: [
      /* @__PURE__ */ jsx("strong", { children: "Share document link" }),
      /* @__PURE__ */ jsx("p", { children: "Recipients need existing access to this document." }),
      /* @__PURE__ */ jsx(TextField, { "aria-label": "Document link", readOnly: true, value: typeof location === "undefined" ? "" : location.href, onFocus: (event) => event.currentTarget.select() }),
      /* @__PURE__ */ jsx(Button, { onClick: async () => {
        try {
          await navigator.clipboard.writeText(location.href);
          setCopyStatus("Link copied");
        } catch {
          setCopyStatus("Select and copy the link above.");
        }
      }, children: "Copy link" }),
      /* @__PURE__ */ jsx("span", { role: "status", children: copyStatus })
    ] }),
    settingsOpen && typeof document !== "undefined" && createPortal(/* @__PURE__ */ jsx(SettingsWindow, { open: settingsOpen, title: `${appName} settings`, headerAppID: appID, sections: [], activePaneID: "", onSelectPane: () => {
    }, onClose: () => setSettingsOpen(false), children: null }), overlayHost ?? document.body),
    /* @__PURE__ */ jsx(Dialog, { open: pluginsOpen, title: "Plugins", onClose: () => setPluginsOpen(false), children: /* @__PURE__ */ jsx("iframe", { title: `${appID} plugins`, src: pluginsOpen ? `/?pluginApp=${encodeURIComponent(appID)}` : void 0, style: { width: "min(1000px,80vw)", height: "70vh", border: 0 } }) }),
    /* @__PURE__ */ jsx("div", { className: "aui-application-account", children: account === void 0 ? /* @__PURE__ */ jsx("div", { "data-aether-account": "" }) : account })
  ] });
}
export {
  WorkspaceQuickControls
};
