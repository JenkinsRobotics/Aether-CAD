import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useImperativeHandle, useReducer, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { FloatingToolbar } from "./FloatingToolbar.js";
import { IconButton } from "./IconButton.js";
import {
  FREEFORM_HANDLES,
  FREEFORM_ZOOM_LIMITS,
  connectorEnds,
  deleteItems,
  fitCamera,
  gridSpacing,
  hitTest,
  isConnector,
  itemBounds,
  itemsInRect,
  moveItems,
  normalizeRect,
  panCamera,
  penItem,
  resizeRect,
  rotateCameraAt,
  screenToWorld,
  transformItems,
  unionRect,
  worldToScreen,
  zoomCameraAt
} from "./freeform-canvas-model.js";
import "./FreeformCanvas.css";
const ALL_TOOLS = ["select", "pen", "connector", "rectangle", "rounded-rectangle", "ellipse", "text", "sticky", "table", "attachment"];
const TOOL_INFO = {
  select: { label: "Select", icon: "cursor" },
  pen: { label: "Pen", icon: "scribble" },
  connector: { label: "Connector", icon: "connector" },
  rectangle: { label: "Rectangle", icon: "rectangle" },
  "rounded-rectangle": { label: "Rounded rectangle", icon: "rectangle-inset" },
  ellipse: { label: "Ellipse", icon: "circle" },
  text: { label: "Text box", icon: "text" },
  sticky: { label: "Sticky note", icon: "notes" },
  table: { label: "Table", icon: "grid-3" },
  attachment: { label: "Image or file", icon: "image" }
};
const TOOL_GROUPS = [["select", "pen", "connector"], ["rectangle", "rounded-rectangle", "ellipse"], ["text", "sticky", "table", "attachment"]];
const DEFAULT_SIZE = {
  rectangle: [160, 100],
  "rounded-rectangle": [160, 100],
  ellipse: [120, 120],
  text: [220, 32],
  sticky: [180, 180],
  table: [270, 108]
};
const NUDGE = 1, NUDGE_LARGE = 10, DRAG_THRESHOLD = 3;
const isTyping = (target) => target instanceof HTMLElement && (target.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName));
const defaultId = () => globalThis.crypto?.randomUUID?.() ?? `item-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
function TextEditor({ value, placeholder, onCommit }) {
  const [text, setText] = useState(value);
  return /* @__PURE__ */ jsx(
    "textarea",
    {
      className: "aui-freeform-text-editor",
      autoFocus: true,
      value: text,
      placeholder,
      "aria-label": placeholder,
      onFocus: (e) => e.currentTarget.select(),
      onChange: (e) => setText(e.target.value),
      onBlur: () => onCommit(text),
      onKeyDown: (e) => {
        if (e.key === "Escape" || e.key === "Enter" && (e.metaKey || e.ctrlKey)) e.currentTarget.blur();
      }
    }
  );
}
function TableEditor({ cells, onCommit }) {
  const [draft, setDraft] = useState(() => cells.map((row) => [...row]));
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: "aui-freeform-table",
      style: { gridTemplateColumns: `repeat(${cells[0]?.length ?? 1}, 1fr)` },
      onBlur: (e) => {
        if (!e.currentTarget.contains(e.relatedTarget)) onCommit(draft);
      },
      children: draft.map((row, r) => row.map((cell, c) => /* @__PURE__ */ jsx(
        "input",
        {
          className: "aui-freeform-table-cell",
          value: cell,
          autoFocus: r === 0 && c === 0,
          "aria-label": `Row ${r + 1}, column ${c + 1}`,
          onChange: (e) => setDraft((d) => d.map((rr, ri) => ri === r ? rr.map((cc, ci) => ci === c ? e.target.value : cc) : rr)),
          onKeyDown: (e) => {
            if (e.key === "Escape") e.currentTarget.blur();
          }
        },
        `${r}-${c}`
      )))
    }
  );
}
function inkOn(fill) {
  const m = fill && /^#([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(fill);
  if (!m) return void 0;
  const [r, g, b] = m.slice(1).map((h) => {
    const c = parseInt(h, 16) / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.18 ? "#1d1f24" : "#ffffff";
}
const shape = (radius) => ({ item }) => /* @__PURE__ */ jsx("div", { className: "aui-freeform-shape", style: { borderRadius: radius, background: item.fill } });
const freeformRenderers = {
  rectangle: shape(0),
  "rounded-rectangle": shape(14),
  ellipse: ({ item }) => /* @__PURE__ */ jsx("div", { className: "aui-freeform-shape", style: { borderRadius: "50%", background: item.fill } }),
  text: ({ item, editing, onCommit }) => editing ? /* @__PURE__ */ jsx(TextEditor, { value: item.text ?? "", placeholder: "Type to enter text", onCommit: (text) => onCommit({ text }) }) : /* @__PURE__ */ jsx("div", { className: "aui-freeform-text", "data-empty": !item.text || void 0, children: item.text || "Type to enter text" }),
  sticky: ({ item, editing, onCommit }) => /* @__PURE__ */ jsx("div", { className: "aui-freeform-sticky", style: { background: item.fill, color: inkOn(item.fill) }, children: editing ? /* @__PURE__ */ jsx(TextEditor, { value: item.text ?? "", placeholder: "Write a note", onCommit: (text) => onCommit({ text }) }) : /* @__PURE__ */ jsx("div", { className: "aui-freeform-text", children: item.text }) }),
  pen: ({ item }) => /* @__PURE__ */ jsx("svg", { className: "aui-freeform-pen", width: "100%", height: "100%", viewBox: `0 0 ${item.width} ${item.height}`, preserveAspectRatio: "none", overflow: "visible", "aria-hidden": true, children: /* @__PURE__ */ jsx("polyline", { points: (item.points ?? []).map((p) => `${p.x},${p.y}`).join(" ") }) }),
  image: ({ item }) => /* @__PURE__ */ jsx("img", { className: "aui-freeform-image", src: item.src, alt: item.name ?? "", draggable: false }),
  attachment: ({ item }) => /* @__PURE__ */ jsxs("div", { className: "aui-freeform-attachment", children: [
    /* @__PURE__ */ jsx(AetherIcon, { name: "file-generic", "aria-hidden": true }),
    /* @__PURE__ */ jsx("span", { children: item.name ?? "Attachment" })
  ] }),
  table: ({ item, editing, onCommit }) => editing ? /* @__PURE__ */ jsx(TableEditor, { cells: item.cells ?? [[""]], onCommit: (cells) => onCommit({ cells }) }) : /* @__PURE__ */ jsx("div", { className: "aui-freeform-table", style: { gridTemplateColumns: `repeat(${item.cells?.[0]?.length ?? 1}, 1fr)` }, children: (item.cells ?? [[""]]).flatMap((row, r) => row.map((cell, c) => /* @__PURE__ */ jsx("div", { className: "aui-freeform-table-cell", children: cell }, `${r}-${c}`))) })
};
const EDITABLE = /* @__PURE__ */ new Set(["text", "sticky", "table"]);
function FreeformCanvas(props) {
  const { items, onChange, camera, onCameraChange, selection, onSelectionChange, onUndo, onRedo, onAttachFiles, controllerRef, className } = props;
  const limits = props.zoomLimits ?? FREEFORM_ZOOM_LIMITS;
  const createId = props.createId ?? defaultId;
  const renderers = props.renderers ? { ...freeformRenderers, ...props.renderers } : freeformRenderers;
  const [ownTool, setOwnTool] = useState("select");
  const tool = props.tool ?? ownTool;
  const setTool = (next) => {
    if (props.tool === void 0) setOwnTool(next);
    props.onToolChange?.(next);
  };
  const hostTool = props.hostTools?.includes(tool) ?? false;
  const [editing, setEditing] = useState(null);
  const [ownGrid, setOwnGrid] = useState(props.defaultShowGrid ?? true);
  const [ownConnectors, setOwnConnectors] = useState(props.defaultShowConnectors ?? true);
  const showGrid = props.showGrid ?? ownGrid, showConnectors = props.showConnectors ?? ownConnectors;
  const setShowGrid = (update) => {
    const next = update(showGrid);
    setOwnGrid(next);
    props.onShowGridChange?.(next);
  };
  const setShowConnectors = (update) => {
    const next = update(showConnectors);
    setOwnConnectors(next);
    props.onShowConnectorsChange?.(next);
  };
  const [spaceHeld, setSpaceHeld] = useState(false);
  const [, redraw] = useReducer((n) => n + 1, 0);
  const viewport = useRef(null);
  const fileInput = useRef(null);
  const gesture = useRef(null);
  const latest = useRef({ camera, onCameraChange, limits, rotatable: props.rotatable });
  latest.current = { camera, onCameraChange, limits, rotatable: props.rotatable };
  const selected = new Set(selection);
  const visible = (item) => showConnectors || !isConnector(item);
  const tools = (props.tools ?? ALL_TOOLS).filter((t) => t !== "attachment" || onAttachFiles);
  const size = () => {
    const r = viewport.current?.getBoundingClientRect();
    return { width: r?.width || 800, height: r?.height || 600 };
  };
  const clearArea = () => {
    const s = size(), css = viewport.current ? getComputedStyle(viewport.current) : null;
    const px = (name) => css && parseFloat(css.getPropertyValue(name)) || 0;
    const top = px("--aui-workspace-inset-top"), left = px("--aui-workspace-inset-left"), right = px("--aui-workspace-inset-right");
    const bottom = Math.max(px("--aui-workspace-inset-bottom"), px("--aui-studio-tools-clearance"));
    const width = s.width - left - right, height = s.height - top - bottom;
    return width > 120 && height > 120 ? { left, top, width, height } : { left: 0, top: 0, ...s };
  };
  const local = (e) => {
    const r = viewport.current.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const toWorld = (e) => screenToWorld(camera, local(e));
  const tolerance = 6 / camera.zoom;
  const fit = (ids) => {
    const chosen = ids ? items.filter((i) => ids.includes(i.id)) : items;
    const rects = chosen.map((i) => itemBounds(items, i)).filter((b) => Boolean(b));
    if (!ids && props.contentBounds) rects.push(props.contentBounds);
    const bounds = unionRect(rects);
    if (!bounds) return;
    const area = clearArea(), fitted = fitCamera(bounds, area, 48, limits, 1, camera.rotation ?? 0);
    onCameraChange({ ...fitted, x: fitted.x + area.left, y: fitted.y + area.top });
  };
  const zoomTo = (zoom, screen) => {
    const s = size();
    onCameraChange(zoomCameraAt(camera, screen ?? { x: s.width / 2, y: s.height / 2 }, zoom, limits));
  };
  const rotateTo = (rotation2, screen) => {
    const s = size();
    onCameraChange(rotateCameraAt(camera, screen ?? { x: s.width / 2, y: s.height / 2 }, rotation2));
  };
  useImperativeHandle(controllerRef, () => ({ panBy: (dx, dy) => onCameraChange(panCamera(camera, dx, dy)), zoomTo, fit, rotateTo }));
  useEffect(() => {
    const el = viewport.current;
    if (!el) return;
    const wheel = (e) => {
      if (isTyping(e.target)) return;
      e.preventDefault();
      const { camera: c, onCameraChange: change, limits: l, rotatable } = latest.current;
      const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 400 : 1;
      const r = el.getBoundingClientRect();
      const next = rotatable && e.altKey ? rotateCameraAt(c, { x: e.clientX - r.left, y: e.clientY - r.top }, (c.rotation ?? 0) + (e.deltaY || e.deltaX) * unit * Math.PI / 720) : e.ctrlKey || e.metaKey ? zoomCameraAt(c, { x: e.clientX - r.left, y: e.clientY - r.top }, c.zoom * Math.exp(-e.deltaY * unit * 25e-4), l) : panCamera(c, -e.deltaX * unit, -e.deltaY * unit);
      latest.current.camera = next;
      change(next);
    };
    el.addEventListener("wheel", wheel, { passive: false });
    return () => el.removeEventListener("wheel", wheel);
  }, []);
  const commitEdit = (id, patch) => {
    setEditing(null);
    const item = items.find((i) => i.id === id);
    if (!item) return;
    if (item.kind === "text" && "text" in patch && !patch.text?.trim()) {
      onChange(deleteItems(items, /* @__PURE__ */ new Set([id])), { type: "delete", ids: [id] });
      onSelectionChange([]);
    } else if (Object.entries(patch).some(([k, v]) => JSON.stringify(item[k]) !== JSON.stringify(v))) {
      onChange(items.map((i) => i.id === id ? { ...i, ...patch } : i), { type: "edit", ids: [id] });
    }
    viewport.current?.focus();
  };
  const create = (item) => {
    onChange([...items, item], { type: "create", ids: [item.id] });
    onSelectionChange([item.id]);
    setTool("select");
    if (EDITABLE.has(item.kind)) setEditing(item.id);
  };
  const pointerDown = (e) => {
    if (isTyping(e.target) || e.target.closest(".aui-freeform-hud")) return;
    if (e.button !== 0 && e.button !== 1) return;
    if (editing) {
      e.preventDefault();
      viewport.current?.focus();
      return;
    }
    const world = toWorld(e), id = e.pointerId;
    const handle = e.target.closest("[data-freeform-handle]")?.dataset.freeformHandle;
    if (tool === "zoom" && e.button === 0 && !spaceHeld) {
      e.stopPropagation();
      zoomTo(camera.zoom * (e.altKey ? 0.5 : 2), local(e));
      return;
    }
    const panning = e.button === 1 || spaceHeld || tool === "hand" && e.button === 0;
    if (!panning && (hostTool || props.layer && tool === "select" && !handle && !hitTest(items, world, tolerance, visible))) {
      if (selection.length && !e.shiftKey) onSelectionChange([]);
      return;
    }
    e.stopPropagation();
    viewport.current?.focus();
    let next = null;
    if (panning) next = { kind: "pan", pointerId: id, start: local(e), camera };
    else if (handle && selectionBounds) next = { kind: "resize", pointerId: id, handle, start: world, current: world, bounds: selectionBounds, ids: selected };
    else if (tool === "pen") next = { kind: "pen", pointerId: id, points: [world] };
    else if (tool === "connector") {
      const from = hitTest(items, world, tolerance, (i) => !isConnector(i));
      if (from) next = { kind: "connect", pointerId: id, from, current: world };
    } else if (tool in DEFAULT_SIZE) next = { kind: "create", pointerId: id, tool, start: world, current: world };
    else {
      const hit = hitTest(items, world, tolerance, visible);
      if (hit) {
        const ids = e.shiftKey || e.metaKey ? selected.has(hit) ? selection.filter((s) => s !== hit) : [...selection, hit] : selected.has(hit) ? [...selection] : [hit];
        if (ids.join() !== selection.join()) onSelectionChange(ids);
        next = { kind: "move", pointerId: id, start: world, current: world, ids: new Set(ids), screenStart: local(e), moved: false };
      } else {
        const base = e.shiftKey || e.metaKey ? selection : [];
        if (!base.length && selection.length) onSelectionChange([]);
        next = { kind: "marquee", pointerId: id, start: world, current: world, base };
      }
    }
    if (!next) return;
    e.preventDefault();
    gesture.current = next;
    try {
      e.currentTarget.setPointerCapture?.(id);
    } catch {
    }
    redraw();
  };
  const pointerMove = (e) => {
    const g2 = gesture.current;
    if (!g2 || g2.pointerId !== e.pointerId) return;
    const world = toWorld(e);
    if (g2.kind === "pan") {
      const p = local(e);
      onCameraChange({ ...g2.camera, x: g2.camera.x + p.x - g2.start.x, y: g2.camera.y + p.y - g2.start.y });
      return;
    }
    if (g2.kind === "pen") g2.points.push(world);
    else if (g2.kind === "move") {
      const p = local(e);
      g2.current = world;
      g2.moved ||= Math.hypot(p.x - g2.screenStart.x, p.y - g2.screenStart.y) > DRAG_THRESHOLD;
    } else if (g2.kind === "marquee") {
      g2.current = world;
      onSelectionChange([.../* @__PURE__ */ new Set([...g2.base, ...itemsInRect(items, normalizeRect(g2.start, world), visible)])]);
    } else g2.current = world;
    redraw();
  };
  const pointerUp = (e) => {
    const g2 = gesture.current;
    if (!g2 || g2.pointerId !== e.pointerId) return;
    gesture.current = null;
    redraw();
    if (g2.kind === "move" && g2.moved) onChange(moveItems(items, g2.ids, g2.current.x - g2.start.x, g2.current.y - g2.start.y), { type: "move", ids: [...g2.ids] });
    else if (g2.kind === "resize") {
      const to = resizeRect(g2.bounds, g2.handle, g2.current.x - g2.start.x, g2.current.y - g2.start.y);
      onChange(transformItems(items, g2.ids, g2.bounds, to), { type: "resize", ids: [...g2.ids] });
    } else if (g2.kind === "pen" && g2.points.length > 1) {
      const item = penItem(createId(), g2.points);
      onChange([...items, item], { type: "create", ids: [item.id] });
    } else if (g2.kind === "connect") {
      const to = hitTest(items, g2.current, tolerance, (i) => !isConnector(i));
      if (to && to !== g2.from) create({ id: createId(), kind: "connector", x: 0, y: 0, width: 0, height: 0, from: g2.from, to });
    } else if (g2.kind === "create") create(createItem(g2.tool, g2.start, g2.current));
  };
  const createItem = (kind, a, b) => {
    const [w, h] = DEFAULT_SIZE[kind] ?? [160, 100];
    const dragged = Math.hypot(b.x - a.x, b.y - a.y) * camera.zoom > DRAG_THRESHOLD * 2;
    const rect = dragged ? normalizeRect(a, b) : { x: a.x - (kind === "text" ? 0 : w / 2), y: a.y - (kind === "text" ? h / 2 : h / 2), width: w, height: h };
    const item = { id: createId(), kind, ...rect };
    if (kind === "table") item.cells = [["", "", ""], ["", "", ""], ["", "", ""]];
    if (kind === "text" || kind === "sticky") item.text = "";
    return item;
  };
  const keyDown = (e) => {
    if (e.defaultPrevented || isTyping(e.target) || e.target.closest?.(".aui-freeform-hud")) return;
    const mod = e.metaKey || e.ctrlKey, key = e.key.toLowerCase();
    if (key === " ") {
      e.preventDefault();
      if (!spaceHeld) setSpaceHeld(true);
      return;
    }
    if (mod && key === "z") {
      e.preventDefault();
      (e.shiftKey ? onRedo : onUndo)?.();
      return;
    }
    if (mod && key === "y") {
      e.preventDefault();
      onRedo?.();
      return;
    }
    if (mod && key === "a") {
      e.preventDefault();
      onSelectionChange(items.filter(visible).map((i) => i.id));
      return;
    }
    if (e.key === "Escape") {
      if (tool !== "select") setTool("select");
      else if (selection.length) onSelectionChange([]);
      return;
    }
    if ((e.key === "Delete" || e.key === "Backspace") && selection.length) {
      e.preventDefault();
      onChange(deleteItems(items, selected), { type: "delete", ids: [...selection] });
      onSelectionChange([]);
      return;
    }
    if (e.key === "Enter" && selection.length === 1 && EDITABLE.has(items.find((i) => i.id === selection[0])?.kind ?? "")) {
      e.preventDefault();
      setEditing(selection[0]);
      return;
    }
    if (e.key === "1" && e.shiftKey) {
      e.preventDefault();
      fit();
      return;
    }
    const arrows = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    if (arrows[e.key] && selection.length) {
      e.preventDefault();
      const step = e.shiftKey ? NUDGE_LARGE : NUDGE, [dx, dy] = arrows[e.key];
      onChange(moveItems(items, selected, dx * step, dy * step), { type: "nudge", ids: [...selection] });
    }
  };
  const doubleClick = (e) => {
    if (e.defaultPrevented || isTyping(e.target) || e.target.closest(".aui-freeform-hud") || tool !== "select") return;
    const world = toWorld(e), hit = hitTest(items, world, tolerance, visible);
    const item = hit ? items.find((i) => i.id === hit) : void 0;
    if (item && EDITABLE.has(item.kind)) {
      onSelectionChange([item.id]);
      setEditing(item.id);
    } else if (!hit && !props.layer) create(createItem("text", world, world));
  };
  const drop = (e) => {
    if (!onAttachFiles || !e.dataTransfer.files.length) return;
    e.preventDefault();
    onAttachFiles([...e.dataTransfer.files], toWorld(e));
  };
  const g = gesture.current;
  let shown = items;
  if (g?.kind === "move" && g.moved) shown = moveItems(items, g.ids, g.current.x - g.start.x, g.current.y - g.start.y);
  if (g?.kind === "resize") shown = transformItems(items, g.ids, g.bounds, resizeRect(g.bounds, g.handle, g.current.x - g.start.x, g.current.y - g.start.y));
  const selectedBoxes = shown.filter((i) => selected.has(i.id) && !isConnector(i));
  const selectionBounds = unionRect(items.filter((i) => selected.has(i.id) && !isConnector(i)));
  const shownBounds = unionRect(selectedBoxes);
  const spacing = gridSpacing(camera.zoom);
  const rotation = camera.rotation ?? 0, turned = rotation ? `rotate(${rotation}rad)` : void 0;
  const style = { "--aui-freeform-grid": showGrid ? `${spacing}px` : void 0, backgroundPosition: `${camera.x}px ${camera.y}px` };
  const screenRect = (r) => {
    const p = worldToScreen(camera, r);
    return { left: p.x, top: p.y, width: r.width * camera.zoom, height: r.height * camera.zoom, transform: turned, transformOrigin: turned && "0 0" };
  };
  const gridAnchor = () => {
    const cell = screenToWorld({ ...camera, zoom: 1 }, { x: 0, y: 0 });
    return worldToScreen({ ...camera, zoom: 1 }, { x: Math.round(cell.x / spacing) * spacing, y: Math.round(cell.y / spacing) * spacing });
  };
  const connectors = showConnectors ? shown.filter(isConnector) : [];
  const preview = g?.kind === "create" ? normalizeRect(g.start, g.current) : null;
  const marquee = g?.kind === "marquee" ? normalizeRect(g.start, g.current) : null;
  const connectFrom = g?.kind === "connect" ? items.find((i) => i.id === g.from) : void 0;
  const groups = TOOL_GROUPS.map((group, index) => ({
    id: `tools-${index}`,
    label: index === 0 ? "Modes" : index === 1 ? "Shapes" : "Insert",
    separatorBefore: index > 0,
    actions: group.filter((t) => tools.includes(t)).map((t) => ({ id: t, label: TOOL_INFO[t].label, icon: /* @__PURE__ */ jsx(AetherIcon, { name: TOOL_INFO[t].icon, "aria-hidden": true }), pressed: t === "attachment" ? void 0 : tool === t }))
  })).filter((group) => group.actions.length);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      ref: viewport,
      className: ["aui-freeform", className].filter(Boolean).join(" "),
      style,
      tabIndex: 0,
      role: "application",
      "aria-label": props["aria-label"] ?? "Freeform canvas",
      "aria-roledescription": "canvas",
      "data-tool": tool,
      "data-panning": spaceHeld || g?.kind === "pan" || void 0,
      "data-grid": showGrid && !rotation || void 0,
      onPointerDownCapture: pointerDown,
      onPointerMove: pointerMove,
      onPointerUp: pointerUp,
      onPointerCancel: () => {
        gesture.current = null;
        redraw();
      },
      onKeyDown: keyDown,
      onKeyUp: (e) => {
        if (e.key === " ") setSpaceHeld(false);
      },
      onBlur: () => setSpaceHeld(false),
      onDoubleClick: doubleClick,
      onDragOver: (e) => {
        if (onAttachFiles && e.dataTransfer.types.includes("Files")) e.preventDefault();
      },
      onDrop: drop,
      children: [
        showGrid && rotation !== 0 && ((at) => /* @__PURE__ */ jsx("div", { className: "aui-freeform-turned-grid", "aria-hidden": true, style: { left: at.x, top: at.y, transform: turned }, children: /* @__PURE__ */ jsx("div", {}) }))(gridAnchor()),
        /* @__PURE__ */ jsxs("div", { className: "aui-freeform-world", style: { transform: `translate(${camera.x}px, ${camera.y}px) ${turned ?? ""} scale(${camera.zoom})` }, children: [
          connectors.length > 0 && /* @__PURE__ */ jsxs("svg", { className: "aui-freeform-connectors", "aria-hidden": true, children: [
            connectors.map((c) => {
              const ends = connectorEnds(shown, c);
              return ends && /* @__PURE__ */ jsx("line", { "data-selected": selected.has(c.id) || void 0, x1: ends[0].x, y1: ends[0].y, x2: ends[1].x, y2: ends[1].y }, c.id);
            }),
            connectFrom && g?.kind === "connect" && /* @__PURE__ */ jsx("line", { "data-preview": true, x1: connectFrom.x + connectFrom.width / 2, y1: connectFrom.y + connectFrom.height / 2, x2: g.current.x, y2: g.current.y })
          ] }),
          props.layer && /* @__PURE__ */ jsx("div", { className: "aui-freeform-layer", children: props.layer }),
          shown.filter((i) => !isConnector(i)).map((item) => {
            const render = renderers[item.kind];
            return /* @__PURE__ */ jsx(
              "div",
              {
                className: "aui-freeform-item",
                "data-kind": item.kind,
                "data-editing": editing === item.id || void 0,
                style: { left: item.x, top: item.y, width: item.width, height: item.height },
                children: render ? render({ item, selected: selected.has(item.id), editing: editing === item.id, onCommit: (patch) => commitEdit(item.id, patch) }) : /* @__PURE__ */ jsx("div", { className: "aui-freeform-unknown" })
              },
              item.id
            );
          }),
          g?.kind === "pen" && /* @__PURE__ */ jsx("svg", { className: "aui-freeform-connectors aui-freeform-pen", "aria-hidden": true, children: /* @__PURE__ */ jsx("polyline", { points: g.points.map((p) => `${p.x},${p.y}`).join(" ") }) })
        ] }),
        shown.filter((i) => selected.has(i.id) && !isConnector(i) && selectedBoxes.length > 1).map((i) => /* @__PURE__ */ jsx("div", { className: "aui-freeform-outline", style: screenRect(i) }, i.id)),
        shownBounds && editing === null && /* @__PURE__ */ jsx("div", { className: "aui-freeform-selection", style: screenRect(shownBounds), children: FREEFORM_HANDLES.map((h) => /* @__PURE__ */ jsx("span", { className: "aui-freeform-handle", "data-freeform-handle": h, "aria-hidden": true }, h)) }),
        preview && /* @__PURE__ */ jsx("div", { className: "aui-freeform-preview", "data-kind": g?.kind === "create" ? g.tool : void 0, style: screenRect(preview) }),
        marquee && /* @__PURE__ */ jsx("div", { className: "aui-freeform-marquee", style: screenRect(marquee) }),
        groups.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-freeform-hud aui-freeform-toolbar", children: /* @__PURE__ */ jsx(FloatingToolbar, { ariaLabel: "Canvas tools", groups, onAction: (id) => id === "attachment" ? fileInput.current?.click() : setTool(id) }) }),
        onAttachFiles && /* @__PURE__ */ jsx("input", { ref: fileInput, type: "file", multiple: true, hidden: true, onChange: (e) => {
          const files = [...e.target.files ?? []];
          e.target.value = "";
          if (files.length) {
            const s = size();
            onAttachFiles(files, screenToWorld(camera, { x: s.width / 2, y: s.height / 2 }));
          }
        } }),
        props.hud !== false && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("div", { className: "aui-freeform-hud aui-freeform-zoom", role: "group", "aria-label": "Zoom", children: [
            /* @__PURE__ */ jsx(IconButton, { label: "Zoom out", size: "small", onClick: () => zoomTo(camera.zoom / 1.25), disabled: camera.zoom <= limits.min, children: /* @__PURE__ */ jsx(AetherIcon, { name: "minus", "aria-hidden": true }) }),
            /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-freeform-zoom-value", title: "Reset to 100%", "aria-label": `Zoom ${Math.round(camera.zoom * 100)}%, reset to 100%`, onClick: () => zoomTo(1), children: [
              Math.round(camera.zoom * 100),
              "%"
            ] }),
            /* @__PURE__ */ jsx(IconButton, { label: "Zoom in", size: "small", onClick: () => zoomTo(camera.zoom * 1.25), disabled: camera.zoom >= limits.max, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus", "aria-hidden": true }) }),
            /* @__PURE__ */ jsx(IconButton, { label: "Fit to content", size: "small", onClick: () => fit(), disabled: !items.length, children: /* @__PURE__ */ jsx(AetherIcon, { name: "fit", "aria-hidden": true }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "aui-freeform-hud aui-freeform-view", role: "group", "aria-label": "View", children: [
            /* @__PURE__ */ jsx(IconButton, { label: "Show connectors", size: "small", "aria-pressed": showConnectors, onClick: () => setShowConnectors((v) => !v), children: /* @__PURE__ */ jsx(AetherIcon, { name: "connector", "aria-hidden": true }) }),
            /* @__PURE__ */ jsx(IconButton, { label: "Show grid", size: "small", "aria-pressed": showGrid, onClick: () => setShowGrid((v) => !v), children: /* @__PURE__ */ jsx(AetherIcon, { name: "grid-dots", "aria-hidden": true }) })
          ] })
        ] })
      ]
    }
  );
}
export {
  FreeformCanvas,
  freeformRenderers,
  inkOn
};
