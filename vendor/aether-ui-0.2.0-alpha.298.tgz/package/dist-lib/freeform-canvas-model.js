const FREEFORM_ZOOM_LIMITS = { min: 0.1, max: 8 };
const FREEFORM_HANDLES = ["nw", "n", "ne", "e", "se", "s", "sw", "w"];
const clampZoom = (zoom, limits = FREEFORM_ZOOM_LIMITS) => Math.min(limits.max, Math.max(limits.min, zoom));
const turn = (p, angle) => {
  if (!angle) return p;
  const c = Math.cos(angle), s = Math.sin(angle);
  return { x: p.x * c - p.y * s, y: p.x * s + p.y * c };
};
const worldToScreen = (camera, p) => {
  const r = turn({ x: p.x * camera.zoom, y: p.y * camera.zoom }, camera.rotation ?? 0);
  return { x: r.x + camera.x, y: r.y + camera.y };
};
const screenToWorld = (camera, p) => {
  const r = turn({ x: p.x - camera.x, y: p.y - camera.y }, -(camera.rotation ?? 0));
  return { x: r.x / camera.zoom, y: r.y / camera.zoom };
};
const panCamera = (camera, dx, dy) => ({ ...camera, x: camera.x + dx, y: camera.y + dy });
const holding = (camera, anchor, screen) => {
  const at = worldToScreen({ ...camera, x: 0, y: 0 }, anchor);
  return { ...camera, x: screen.x - at.x, y: screen.y - at.y };
};
function zoomCameraAt(camera, screen, zoom, limits = FREEFORM_ZOOM_LIMITS) {
  return holding({ ...camera, zoom: clampZoom(zoom, limits) }, screenToWorld(camera, screen), screen);
}
function rotateCameraAt(camera, screen, rotation) {
  const wrapped = Math.atan2(Math.sin(rotation), Math.cos(rotation)), { rotation: _old, ...flat } = camera;
  return holding(Math.abs(wrapped) < 1e-9 ? flat : { ...flat, rotation: wrapped }, screenToWorld(camera, screen), screen);
}
function fitCamera(bounds, viewport, padding = 48, limits = FREEFORM_ZOOM_LIMITS, maxZoom = 1, rotation = 0) {
  const c = Math.abs(Math.cos(rotation)), s = Math.abs(Math.sin(rotation)), width = bounds.width * c + bounds.height * s, height = bounds.width * s + bounds.height * c;
  const fit = Math.min((viewport.width - padding * 2) / Math.max(width, 1), (viewport.height - padding * 2) / Math.max(height, 1));
  const zoom = clampZoom(Math.min(fit, maxZoom), limits);
  return holding({ zoom, x: 0, y: 0, ...rotation ? { rotation } : {} }, { x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height / 2 }, { x: viewport.width / 2, y: viewport.height / 2 });
}
function gridSpacing(zoom, base = 24, minimum = 12) {
  let spacing = base * zoom;
  while (spacing < minimum) spacing *= 2;
  return spacing;
}
const normalizeRect = (a, b) => ({ x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), width: Math.abs(a.x - b.x), height: Math.abs(a.y - b.y) });
const rectsIntersect = (a, b) => a.x <= b.x + b.width && b.x <= a.x + a.width && a.y <= b.y + b.height && b.y <= a.y + a.height;
function unionRect(rects) {
  if (!rects.length) return null;
  const left = Math.min(...rects.map((r) => r.x)), top = Math.min(...rects.map((r) => r.y));
  const right = Math.max(...rects.map((r) => r.x + r.width)), bottom = Math.max(...rects.map((r) => r.y + r.height));
  return { x: left, y: top, width: right - left, height: bottom - top };
}
const center = (r) => ({ x: r.x + r.width / 2, y: r.y + r.height / 2 });
function edgePoint(r, toward) {
  const c = center(r), dx = toward.x - c.x, dy = toward.y - c.y;
  if (!dx && !dy) return c;
  const scale = Math.min(dx ? r.width / 2 / Math.abs(dx) : Infinity, dy ? r.height / 2 / Math.abs(dy) : Infinity, 1);
  return { x: c.x + dx * scale, y: c.y + dy * scale };
}
function connectorEnds(items, connector) {
  const from = items.find((i) => i.id === connector.from), to = items.find((i) => i.id === connector.to);
  if (!from || !to) return null;
  return [edgePoint(from, center(to)), edgePoint(to, center(from))];
}
const isConnector = (item) => item.kind === "connector";
function itemBounds(items, item) {
  if (!isConnector(item)) return item;
  const ends = connectorEnds(items, item);
  return ends && normalizeRect(ends[0], ends[1]);
}
function distanceToSegment(p, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, length = dx * dx + dy * dy;
  const t = length ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / length)) : 0;
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
}
function itemContains(items, item, p, tolerance = 0) {
  if (isConnector(item)) {
    const ends = connectorEnds(items, item);
    return Boolean(ends && distanceToSegment(p, ends[0], ends[1]) <= Math.max(tolerance, 4));
  }
  if (item.kind === "pen" && item.points?.length) {
    const local = { x: p.x - item.x, y: p.y - item.y }, pts = item.points, reach = Math.max(tolerance, 4);
    if (pts.length === 1) return Math.hypot(local.x - pts[0].x, local.y - pts[0].y) <= reach;
    for (let i = 1; i < pts.length; i++) if (distanceToSegment(local, pts[i - 1], pts[i]) <= reach) return true;
    return false;
  }
  if (item.kind === "ellipse") {
    const rx = item.width / 2 + tolerance, ry = item.height / 2 + tolerance, c = center(item);
    return rx > 0 && ry > 0 && ((p.x - c.x) / rx) ** 2 + ((p.y - c.y) / ry) ** 2 <= 1;
  }
  return p.x >= item.x - tolerance && p.x <= item.x + item.width + tolerance && p.y >= item.y - tolerance && p.y <= item.y + item.height + tolerance;
}
function hitTest(items, p, tolerance = 0, include = () => true) {
  for (let i = items.length - 1; i >= 0; i--) if (include(items[i]) && itemContains(items, items[i], p, tolerance)) return items[i].id;
  return null;
}
function itemsInRect(items, rect, include = () => true) {
  return items.filter((item) => {
    const b = include(item) && itemBounds(items, item);
    return b ? rectsIntersect(b, rect) : false;
  }).map((i) => i.id);
}
function resizeRect(rect, handle, dx, dy, minimum = 8) {
  let left = rect.x, top = rect.y, right = rect.x + rect.width, bottom = rect.y + rect.height;
  if (handle.includes("w")) left = Math.min(left + dx, right - minimum);
  if (handle.includes("e")) right = Math.max(right + dx, left + minimum);
  if (handle.includes("n")) top = Math.min(top + dy, bottom - minimum);
  if (handle.includes("s")) bottom = Math.max(bottom + dy, top + minimum);
  return { x: left, y: top, width: right - left, height: bottom - top };
}
function transformItems(items, ids, from, to) {
  const sx = to.width / Math.max(from.width, 1e-9), sy = to.height / Math.max(from.height, 1e-9);
  return items.map((item) => {
    if (!ids.has(item.id) || isConnector(item)) return item;
    const next = { ...item, x: to.x + (item.x - from.x) * sx, y: to.y + (item.y - from.y) * sy, width: item.width * sx, height: item.height * sy };
    if (item.points) next.points = item.points.map((p) => ({ x: p.x * sx, y: p.y * sy }));
    return next;
  });
}
const moveItems = (items, ids, dx, dy) => items.map((item) => ids.has(item.id) && !isConnector(item) ? { ...item, x: item.x + dx, y: item.y + dy } : item);
function deleteItems(items, ids) {
  const kept = items.filter((item) => !ids.has(item.id));
  const present = new Set(kept.map((i) => i.id));
  return kept.filter((item) => !isConnector(item) || present.has(item.from ?? "") && present.has(item.to ?? ""));
}
function penItem(id, stroke) {
  const xs = stroke.map((p) => p.x), ys = stroke.map((p) => p.y);
  const x = Math.min(...xs), y = Math.min(...ys);
  return { id, kind: "pen", x, y, width: Math.max(Math.max(...xs) - x, 1), height: Math.max(Math.max(...ys) - y, 1), points: stroke.map((p) => ({ x: p.x - x, y: p.y - y })) };
}
export {
  FREEFORM_HANDLES,
  FREEFORM_ZOOM_LIMITS,
  clampZoom,
  connectorEnds,
  deleteItems,
  fitCamera,
  gridSpacing,
  hitTest,
  isConnector,
  itemBounds,
  itemContains,
  itemsInRect,
  moveItems,
  normalizeRect,
  panCamera,
  penItem,
  rectsIntersect,
  resizeRect,
  rotateCameraAt,
  screenToWorld,
  transformItems,
  unionRect,
  worldToScreen,
  zoomCameraAt
};
