import type { CubeVector } from "./viewport-cube-geometry.js";
/** Orthographic camera space: larger Z is nearer the viewer. Clip each facet
 * to the portion in front of an axis segment (or a constant-depth label).
 * Masks therefore remove only occluded pixels, not entire axes by direction. */
export declare function cubeAxisOccluders(facets: readonly (readonly CubeVector[])[], start: CubeVector, end?: CubeVector): CubeVector[][];
