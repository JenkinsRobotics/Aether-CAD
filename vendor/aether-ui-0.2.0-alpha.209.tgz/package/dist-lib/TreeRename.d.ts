/** A rename owns its draft and focuses before paint; no delayed select can erase typing. */
export declare function TreeRename({ label, onCommit, onCancel }: {
    label: string;
    onCommit: (value: string) => void;
    onCancel: () => void;
}): import("react").JSX.Element;
