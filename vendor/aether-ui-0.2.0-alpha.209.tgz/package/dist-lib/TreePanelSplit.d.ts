import { type ReactNode } from "react";
import "./TreePanelSplit.css";
export interface TreePanelSplitProps {
    primary: ReactNode;
    secondary: ReactNode;
    primaryLabel: string;
    secondaryLabel: string;
    /** Fraction of available height assigned to the first collection. */
    defaultRatio?: number;
    storageKey?: string;
    /** Sections that can collapse to their heading, docked as a tab at the
     * bottom. `defaultCollapsed` starts them closed; the choice is remembered. */
    collapsible?: ReadonlyArray<"primary" | "secondary">;
    defaultCollapsed?: ReadonlyArray<"primary" | "secondary">;
}
/** Two independently scrolling collections sharing one card and a movable divider. */
export declare function TreePanelSplit({ primary, secondary, primaryLabel, secondaryLabel, defaultRatio, storageKey, collapsible, defaultCollapsed }: TreePanelSplitProps): import("react").JSX.Element;
