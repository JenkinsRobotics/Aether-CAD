import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
import { useDocumentBrowserContext } from "./document-browser-context.js";
import { assignTabFolder, documentTabAddItems } from "./DocumentTabTray.js";
import "./DocumentTabBrowser.css";
const VIEW_KEY = "aether-ui.tab-browser.view";
const readView = () => {
  try {
    return localStorage.getItem(VIEW_KEY) === "gallery" ? "gallery" : "list";
  } catch {
    return "list";
  }
};
function DocumentTabBrowser(props) {
  const { tabs, folders = [], onFoldersChange, onOrganize, onManage, onAdd, onReorder, saveStatus, revisionForTab, title = "Files", rootLabel, actions } = props;
  const [view, setView] = useState(readView);
  const [folderID, setFolderID] = useState(null);
  const [dragging, setDragging] = useState(null);
  const folder = folders.find((item) => item.id === folderID) ?? null;
  const filed = new Set(folders.flatMap((item) => item.tabs));
  const shown = folder ? tabs.filter((tab) => folder.tabs.includes(tab.id)) : tabs.filter((tab) => !filed.has(tab.id));
  const chooseView = (next) => {
    setView(next);
    try {
      localStorage.setItem(VIEW_KEY, next);
    } catch {
    }
  };
  const menu = useDocumentBrowserContext(props, { view, folderID, rootLabel, setView: chooseView, setFolder: setFolderID });
  const dropOn = (target) => {
    const source = dragging;
    setDragging(null);
    if (!source) return;
    if (target.folder !== void 0) onFoldersChange?.(assignTabFolder(folders, source, target.folder));
    else if (target.tab && target.tab !== source) onReorder(source, target.tab);
  };
  const dropProps = (target) => ({
    onDragOver: (event) => {
      if (dragging) event.preventDefault();
    },
    onDrop: (event) => {
      event.preventDefault();
      dropOn(target);
    }
  });
  const detail = (tab) => [tab.detail, revisionForTab?.(tab.id).label].filter(Boolean).join(" \xB7 ");
  return /* @__PURE__ */ jsxs("section", { className: "aui-tab-browser", "data-view": view, "aria-label": title, onContextMenu: (event) => menu.open(event, { kind: "background" }), children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-tab-browser-head", children: [
      /* @__PURE__ */ jsx("h2", { children: title }),
      /* @__PURE__ */ jsx(
        MenuButton,
        {
          className: "aui-tab-browser-add",
          label: "Create or open a design",
          items: documentTabAddItems(onManage),
          onSelect: (id) => {
            if (id === "create") onAdd();
            else if (id === "manage") onManage?.();
          },
          children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" })
        }
      ),
      onOrganize && /* @__PURE__ */ jsx(IconButton, { label: "Organize tabs", title: "Folder manager", onClick: onOrganize, children: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }) }),
      onManage && /* @__PURE__ */ jsx(IconButton, { label: "Manage files", title: "Manage and import files", onClick: onManage, children: /* @__PURE__ */ jsx(AetherIcon, { name: "part-manager" }) }),
      actions,
      /* @__PURE__ */ jsxs("span", { className: "aui-tab-browser-views", role: "group", "aria-label": "View", children: [
        /* @__PURE__ */ jsx(IconButton, { label: "List view", "aria-pressed": view === "list", onClick: () => chooseView("list"), children: /* @__PURE__ */ jsx(AetherIcon, { name: "list" }) }),
        /* @__PURE__ */ jsx(IconButton, { label: "Gallery view", "aria-pressed": view === "gallery", onClick: () => chooseView("gallery"), children: /* @__PURE__ */ jsx(AetherIcon, { name: "grid-2" }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("nav", { className: "aui-tab-browser-path", "aria-label": "Folder path", children: [
      /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Back to ${rootLabel}`, disabled: !folder, ...dropProps({ folder: "" }), onClick: () => setFolderID(null), children: /* @__PURE__ */ jsx(AetherIcon, { name: "home" }) }),
      /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right", "aria-hidden": "true" }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: !folder, ...dropProps({ folder: "" }), onClick: () => setFolderID(null), children: rootLabel }),
      folder && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right", "aria-hidden": "true" }),
        /* @__PURE__ */ jsx("span", { "aria-current": "page", children: folder.name || "Untitled folder" })
      ] }),
      saveStatus && /* @__PURE__ */ jsx("small", { className: "aui-tab-browser-status", children: saveStatus })
    ] }),
    /* @__PURE__ */ jsxs("ul", { className: "aui-tab-browser-items", children: [
      !folder && folders.map((item) => /* @__PURE__ */ jsx("li", { "data-tab-folder": item.id, ...dropProps({ folder: item.id }), onContextMenu: (event) => menu.open(event, { kind: "folder", id: item.id }), children: /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-tab-browser-row", onClick: () => setFolderID(item.id), children: [
        /* @__PURE__ */ jsx("span", { className: "aui-tab-browser-thumb", "data-kind": "folder", children: /* @__PURE__ */ jsx(AetherIcon, { name: "file-folder" }) }),
        /* @__PURE__ */ jsxs("span", { className: "aui-tab-browser-text", children: [
          /* @__PURE__ */ jsx("strong", { children: item.name || "Untitled folder" }),
          /* @__PURE__ */ jsxs("small", { children: [
            item.tabs.filter((id) => tabs.some((tab) => tab.id === id)).length,
            " items"
          ] })
        ] })
      ] }) }, item.id)),
      shown.map((tab) => /* @__PURE__ */ jsxs(
        "li",
        {
          "data-document-tab-id": tab.id,
          "data-current": tab.current || void 0,
          draggable: true,
          onDragStart: (event) => {
            setDragging(tab.id);
            event.dataTransfer.effectAllowed = "move";
          },
          onDragEnd: () => setDragging(null),
          ...dropProps({ tab: tab.id }),
          onContextMenu: (event) => menu.open(event, { kind: "tab", id: tab.id }),
          children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                className: "aui-tab-browser-row",
                "aria-current": tab.current ? "page" : void 0,
                disabled: tab.disabled,
                title: revisionForTab?.(tab.id).title ?? tab.label,
                onClick: () => tab.onSelect?.(),
                children: [
                  /* @__PURE__ */ jsx("span", { className: "aui-tab-browser-thumb", children: tab.thumbnail ? /* @__PURE__ */ jsx("img", { src: tab.thumbnail, alt: "" }) : tab.icon }),
                  /* @__PURE__ */ jsxs("span", { className: "aui-tab-browser-text", children: [
                    /* @__PURE__ */ jsx("strong", { children: tab.label }),
                    /* @__PURE__ */ jsx("small", { children: detail(tab) })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsx(MenuButton, { className: "aui-tab-browser-menu", label: `Options for ${tab.label}`, placement: "bottom-end", items: menu.tabItems(tab.id), onSelect: (action) => menu.selectTab(tab.id, action), children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
          ]
        },
        tab.id
      )),
      !shown.length && !(folders.length && !folder) && /* @__PURE__ */ jsx("li", { className: "aui-tab-browser-empty", children: folder ? "This folder is empty. Drag items here to file them." : "No documents yet." })
    ] }),
    menu.overlays
  ] });
}
export {
  DocumentTabBrowser
};
