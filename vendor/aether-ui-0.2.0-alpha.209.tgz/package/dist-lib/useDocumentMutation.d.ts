import type { DocumentConnection } from "./DocumentServices.js";
/** Presentation-level explicit retry. The transport is still supplied by the host.
 * A retry never flushes, reads newer guards or rebuilds arguments from edited fields. */
export declare function useDocumentMutation(connection: DocumentConnection, recovered: (action: string, result: unknown) => Promise<void>, replaySafe?: boolean): {
    uncertain: boolean;
    retrying: boolean;
    canRetry: boolean;
    send<T = unknown>(action: string, data: Record<string, unknown>): Promise<T>;
    retry(): Promise<void>;
};
