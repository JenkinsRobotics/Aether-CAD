import type { DocumentConnection } from "./DocumentServices.js";
import type { WorkspacePanel } from "./WorkspaceShell.js";
/** The suite's document rail. Products supply content, never their own order or glyphs. */
export declare const STANDARD_WORKSPACE_PANELS: readonly [{
    readonly id: "features";
    readonly title: "Features and parts";
    readonly icon: "features-parts";
}, {
    readonly id: "versions";
    readonly title: "Version control";
    readonly icon: "version-control";
}, {
    readonly id: "create-version";
    readonly title: "Create version";
    readonly icon: "version-create";
}, {
    readonly id: "comments";
    readonly title: "Comments";
    readonly icon: "comment";
}, {
    readonly id: "notes";
    readonly title: "Document notes";
    readonly icon: "notes";
}, {
    readonly id: "reminders";
    readonly title: "Reminders";
    readonly icon: "stopwatch";
}, {
    readonly id: "advisor";
    readonly title: "AI advisor";
    readonly icon: "advisor";
}, {
    readonly id: "tasks";
    readonly title: "Action items";
    readonly icon: "tasks";
}, {
    readonly id: "part-manager";
    readonly title: "Part manager";
    readonly icon: "part-manager";
}];
export type StandardWorkspacePanelID = typeof STANDARD_WORKSPACE_PANELS[number]["id"];
export type StandardWorkspacePanelBindings = Partial<Record<StandardWorkspacePanelID, string>>;
/** Preserve product IDs (saved layout, selection and commands) while standardizing
 * presentation. Extra product panels sit before the final Part manager entry.
 * Unconnected services have an explicit unavailable state, never fake data/actions. */
export declare function standardWorkspacePanels(panels: readonly WorkspacePanel[], bindings?: StandardWorkspacePanelBindings, connection?: DocumentConnection): WorkspacePanel[];
