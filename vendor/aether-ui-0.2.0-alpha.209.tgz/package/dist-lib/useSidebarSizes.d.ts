import { type RefObject } from "react";
type Side = "left" | "right";
type Size = {
    width?: number;
    height?: number;
};
/** User overrides only; no stored value means the standard automatic sizing. */
export declare function useSidebarSizes(storageKey?: string, area?: RefObject<HTMLDivElement | null>): {
    sizes: Partial<Record<Side, Size>>;
    update: (side: Side, patch: Size) => void;
    availableWidth: number;
};
export {};
