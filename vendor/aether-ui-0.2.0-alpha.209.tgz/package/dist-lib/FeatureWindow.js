import { createFeatureWindowAccessories } from "./FeatureWindowAccessories.js";
function openFeatureWindow(options) {
  const compact = options.variant === "compact";
  const lifetime = new (document.defaultView?.AbortController ?? AbortController)();
  const panel = document.createElement("aside");
  panel.className = `aui-float-panel aui-feature-window ${options.className}`;
  if (options.variant === "spacious") panel.classList.add("aui-feature-window--spacious");
  if (compact) panel.classList.add("aui-feature-window--compact");
  else if (options.variant !== "spacious") panel.classList.add("aui-feature-window--standard");
  const header = document.createElement(compact ? "header" : "div");
  header.className = "aui-float-panel-header";
  const title = document.createElement("span");
  title.className = "aui-float-panel-title";
  title.textContent = options.title;
  title.title = options.title;
  if (options.headerIcon) {
    options.headerIcon.classList.add("aui-feature-header-icon");
    options.headerIcon.setAttribute("aria-hidden", "true");
    header.append(options.headerIcon);
  }
  header.append(title);
  const actions = document.createElement("span");
  actions.className = "aui-float-panel-actions";
  const accept = document.createElement("button");
  accept.type = "button";
  accept.className = compact ? "aui-button aui-button--primary" : "aui-feature-accept";
  accept.textContent = compact ? options.acceptLabel : "\u2713";
  accept.setAttribute("aria-label", options.acceptLabel);
  accept.dataset.featureAction = "accept";
  const discard = document.createElement("button");
  discard.type = "button";
  discard.className = compact ? "aui-button aui-button--flat" : "aui-feature-discard";
  discard.textContent = compact ? options.discardLabel : "\u2715";
  discard.setAttribute("aria-label", options.discardLabel);
  discard.dataset.featureAction = "discard";
  if (compact) {
    actions.className = "aui-feature-commit-actions";
    actions.append(discard, accept);
  } else {
    actions.append(accept, discard);
    header.append(actions);
  }
  panel.append(header);
  const body = document.createElement("div");
  body.className = "aui-float-panel-body";
  panel.append(body);
  if (compact) panel.append(actions);
  const accessories = createFeatureWindowAccessories(options);
  panel.append(accessories.element);
  const status = document.createElement("p");
  status.setAttribute("role", "status");
  let panelX = 0, panelY = 0;
  header.addEventListener("pointerdown", (e) => {
    if (e.target.closest("button")) return;
    const startX = e.clientX - panelX, startY = e.clientY - panelY;
    header.setPointerCapture(e.pointerId);
    const move = (ev) => {
      panelX = ev.clientX - startX;
      panelY = ev.clientY - startY;
      panel.style.transform = `translate(${panelX}px, ${panelY}px)`;
      place();
    };
    const up = () => {
      header.removeEventListener("pointermove", move);
      header.removeEventListener("pointerup", up);
    };
    header.addEventListener("pointermove", move);
    header.addEventListener("pointerup", up);
  });
  accept.onclick = () => void options.onAccept();
  discard.onclick = () => void options.onDiscard();
  panel.addEventListener("keydown", (e) => {
    const target = e.target;
    if (e.key !== "Enter" || target?.tagName === "TEXTAREA") return;
    if (target?.closest("button, a, input[type=checkbox], input[type=radio]")) return;
    if (target?.closest?.("form")) return;
    e.preventDefault();
    if (!accept.disabled) void options.onAccept();
  });
  const close = () => {
    lifetime.abort();
    panel.remove();
    notices.remove();
  };
  const notices = document.createElement("div");
  notices.className = "aui-feature-notices";
  const error = document.createElement("p");
  error.className = "aui-feature-error";
  error.hidden = true;
  error.setAttribute("role", "alert");
  const notice = document.createElement("p");
  notice.className = "aui-feature-notice";
  notice.hidden = true;
  notice.setAttribute("role", "status");
  notice.setAttribute("aria-live", "polite");
  notices.append(error, notice);
  document.body.append(notices);
  const place = () => {
    if (error.hidden && notice.hidden) return;
    const rect = panel.getBoundingClientRect();
    notices.style.left = `${rect.left}px`;
    notices.style.width = `${rect.width}px`;
    const above = rect.top - notices.offsetHeight - 6;
    notices.style.top = `${above >= 8 ? above : rect.bottom + 6}px`;
  };
  window.addEventListener("resize", place, { signal: lifetime.signal });
  const setError = (message) => {
    error.textContent = message ?? "";
    error.hidden = !message;
    panel.classList.toggle("invalid", Boolean(message));
    accept.disabled = Boolean(message);
    if (message) place();
  };
  const setNotice = (message) => {
    notice.textContent = message ?? "";
    notice.hidden = !message;
    if (message) place();
  };
  const entitiesBox = (caption = "Entities") => {
    const element = document.createElement("div");
    element.className = "aui-feature-entities";
    element.setAttribute("aria-label", caption);
    const label = document.createElement("span");
    label.className = "aui-feature-entities-caption";
    label.textContent = caption;
    element.append(label);
    const list = document.createElement("div");
    element.append(list);
    body.append(element);
    body.append(status);
    return {
      element,
      render(rows) {
        list.replaceChildren();
        for (const { label: text, onRemove } of rows) {
          const row2 = document.createElement("div");
          row2.className = "aui-feature-entity";
          const name = document.createElement("span");
          name.textContent = text;
          const remove = document.createElement("button");
          remove.type = "button";
          remove.textContent = "\xD7";
          remove.setAttribute("aria-label", `Remove ${text}`);
          remove.onclick = onRemove;
          row2.append(name, remove);
          list.append(row2);
        }
      }
    };
  };
  const row = (label, ...controls) => {
    const element = document.createElement("div");
    element.className = "aui-feature-row";
    const caption = document.createElement("span");
    caption.textContent = label;
    for (const control of controls) {
      if (control.matches("input, select, textarea") && !control.hasAttribute("aria-label")) control.setAttribute("aria-label", label);
    }
    element.append(caption, ...controls);
    body.append(element);
    body.append(status);
    return element;
  };
  const tabs = (labels, activeIndex = 0) => {
    const element = document.createElement("div");
    element.className = "aui-feature-tabs";
    labels.forEach((text, index) => {
      const tab = document.createElement("button");
      tab.type = "button";
      tab.textContent = text;
      tab.className = index === activeIndex ? "active" : "";
      tab.onclick = () => {
        for (const sibling of element.children) sibling.classList.remove("active");
        tab.classList.add("active");
      };
      element.append(tab);
    });
    body.append(element);
    body.append(status);
    return element;
  };
  const picker = (options2, config = {}) => {
    let current = config.value ?? options2[0] ?? "";
    const element = document.createElement("span");
    element.className = "aui-feature-picker";
    const trigger = document.createElement("button");
    trigger.type = "button";
    trigger.className = "aui-feature-picker-trigger";
    trigger.setAttribute("aria-haspopup", "listbox");
    trigger.setAttribute("aria-expanded", "false");
    if (config.ariaLabel) trigger.setAttribute("aria-label", config.ariaLabel);
    const label = document.createElement("span");
    const chevron = document.createElement("span");
    chevron.className = "aui-feature-picker-chevron";
    chevron.textContent = "\u25BE";
    trigger.append(label, chevron);
    const menu = document.createElement("div");
    menu.className = "aui-feature-picker-menu";
    menu.setAttribute("role", "listbox");
    menu.hidden = true;
    const paint = () => {
      label.textContent = current;
      for (const child of menu.children) {
        const option = child;
        option.setAttribute("aria-selected", String(option.dataset.value === current));
      }
    };
    const close2 = () => {
      menu.hidden = true;
      trigger.setAttribute("aria-expanded", "false");
    };
    for (const option of options2) {
      const item = document.createElement("button");
      item.type = "button";
      item.setAttribute("role", "option");
      item.dataset.value = option;
      item.textContent = option;
      item.onclick = () => {
        current = option;
        paint();
        close2();
        config.onChange?.(option);
      };
      menu.append(item);
    }
    trigger.onclick = () => {
      const opening = menu.hidden;
      menu.hidden = !opening;
      trigger.setAttribute("aria-expanded", String(opening));
    };
    document.addEventListener("pointerdown", (event) => {
      if (!element.contains(event.target)) close2();
    }, { signal: lifetime.signal });
    element.addEventListener("keydown", (event) => {
      if (event.key === "Escape") close2();
    });
    element.append(trigger, menu);
    paint();
    return {
      element,
      value: () => current,
      setValue: (value) => {
        current = value;
        paint();
      }
    };
  };
  const subsection = (label, config = {}) => {
    const kind = config.kind ?? "checkbox";
    const element = document.createElement("div");
    element.className = "aui-feature-subsection";
    const header2 = document.createElement("div");
    header2.className = "aui-feature-subsection-header";
    const nested = document.createElement("div");
    nested.className = "aui-feature-subsection-body";
    let open = config.open ?? kind === "disclosure";
    const apply = () => {
      nested.hidden = !open;
      element.classList.toggle("open", open);
    };
    if (kind === "checkbox") {
      const box = document.createElement("input");
      box.type = "checkbox";
      box.checked = open;
      box.setAttribute("aria-label", label);
      const caption = document.createElement("span");
      caption.textContent = label;
      box.onchange = () => {
        open = box.checked;
        apply();
        config.onToggle?.(open);
      };
      header2.append(caption, box);
    } else {
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.className = "aui-feature-disclosure";
      const caption = document.createElement("span");
      caption.textContent = label;
      const chevron = document.createElement("span");
      chevron.className = "aui-feature-chevron";
      chevron.textContent = open ? "\u25BE" : "\u25B8";
      toggle.append(chevron, caption);
      toggle.onclick = () => {
        open = !open;
        chevron.textContent = open ? "\u25BE" : "\u25B8";
        apply();
        config.onToggle?.(open);
      };
      header2.append(toggle);
    }
    apply();
    element.append(header2, nested);
    body.append(element);
    body.append(status);
    return {
      element,
      body: nested,
      setOpen: (next) => {
        open = next;
        apply();
      },
      isOpen: () => open
    };
  };
  const actionIcon = accessories.actionIcon;
  options.viewport.append(panel);
  body.append(status);
  return { panel, accept, discard, body, status, close, setError, setNotice, entitiesBox, row, tabs, picker, subsection, actionIcon, setHelpActive: accessories.setHelpActive };
}
export {
  openFeatureWindow
};
