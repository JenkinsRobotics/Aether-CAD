import { type ReactNode } from "react";
import type { VersionControlEntry } from "./VersionControl.js";
/** A saved image belongs to its entry. Never substitute the live model for an
 * older version that has no snapshot. */
export declare function VersionBranchRow({ entry, active, icon, label, onSelect, menu }: {
    entry: VersionControlEntry;
    active: boolean;
    icon: string;
    label: string;
    onSelect: () => void;
    menu: ReactNode;
}): import("react").JSX.Element;
