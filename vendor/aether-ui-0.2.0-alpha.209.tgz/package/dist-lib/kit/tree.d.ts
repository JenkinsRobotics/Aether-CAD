import { type TreeNode, type TreeState } from "./state.js";
export interface TreeViewProps {
    model: TreeState;
    onChange: (next: TreeState) => void;
    /** Called when a leaf is activated (single selection), e.g. to select the part. */
    onActivate?: (node: TreeNode) => void;
    ariaLabel?: string;
}
export declare function TreeView({ model, onChange, onActivate, ariaLabel }: TreeViewProps): import("react").JSX.Element;
/** A `PanelAction` pair used under trees ("New Folder" · "Group"). */
export declare const TreeFooter: ({ onAdd, onFolder, addLabel }: {
    onAdd?: () => void;
    onFolder?: () => void;
    addLabel?: string;
}) => import("react").JSX.Element;
