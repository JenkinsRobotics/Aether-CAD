/**
 * The Aether Animation Mockup widget kit — Design.swift, Widgets.swift,
 * PanelWidgets.swift, NodeWidgets.swift (inputs) and App.swift chrome, ported
 * one struct to one component. Names, props and measurements follow the Swift
 * source so the two can be compared side by side; styling lives in widgets.css
 * under the `aui-kit-` prefix.
 */
import { type CSSProperties, type ReactNode } from "react";
import { type StageLabelMode } from "./state.js";
/** The UI.* colour tokens as CSS values, for `tint` props. */
export declare const AD: {
    readonly accent: "var(--aether-color-accent)";
    readonly accent2: "var(--aether-color-part)";
    readonly warn: "var(--aether-color-warn)";
    readonly danger: "var(--aether-color-error)";
    readonly ok: "var(--aether-color-ok)";
    readonly text: "var(--aether-color-text)";
    readonly text2: "var(--aether-color-text-dim)";
    readonly text3: "var(--aether-color-text-faint)";
    readonly panel: "var(--aether-color-bg-panel)";
    readonly panelHi: "var(--aether-color-bg-control)";
    readonly purple: "var(--aether-color-joint)";
    readonly pink: "var(--aether-color-error)";
    readonly teal: "var(--aether-color-part)";
    readonly blue: "var(--aether-color-accent)";
};
export declare const tintStyle: (tint?: string, extra?: CSSProperties) => CSSProperties;
/** Pill button used in toolbars / palettes. */
export declare function Pill({ icon, label, active, tint, onClick }: {
    icon?: string;
    label: string;
    active?: boolean;
    tint?: string;
    onClick?: () => void;
}): import("react").JSX.Element;
/** A titled panel container. */
export declare function Panel({ title, systemImage, accessory, children, className, style }: {
    title?: string;
    systemImage?: string;
    accessory?: ReactNode;
    children: ReactNode;
    className?: string;
    style?: CSSProperties;
}): import("react").JSX.Element;
/** A tree/list row (Onshape-style). `controls` adds visibility + lock toggles. */
export declare function Row({ icon, label, detail, indent, tint, selected, badge, controls, onClick }: {
    icon: string;
    label: string;
    detail?: string;
    indent?: number;
    tint?: string;
    selected?: boolean;
    badge?: string;
    controls?: boolean;
    onClick?: () => void;
}): import("react").JSX.Element;
/** Small labeled field for inspectors. */
export declare function Field({ label, value, unit }: {
    label: string;
    value: string;
    unit?: string;
}): import("react").JSX.Element;
/** Status badge — text in a tinted capsule. */
export declare const Badge: ({ text, tint }: {
    text: string;
    tint?: string;
}) => import("react").JSX.Element;
/** KPI / metric card — label, big value, caption. */
export declare const MetricCard: ({ title, value, caption, tint }: {
    title: string;
    value: string;
    caption?: string;
    tint?: string;
}) => import("react").JSX.Element;
/** Plain range input, styled once for every slider in the kit. */
export declare function Range({ value, onChange, min, max, step, ariaLabel, tint, gradient, style }: {
    value: number;
    onChange: (v: number) => void;
    min?: number;
    max?: number;
    step?: number;
    ariaLabel: string;
    tint?: string;
    /** Paints the whole track with these stops instead of a fill-to-value (the native UIDevMaterialSlider: hue, roughness, metallic ramps). */ gradient?: string[];
    style?: CSSProperties;
}): import("react").JSX.Element;
/** Labeled slider row — label + slider + monospaced readout. */
export declare function LabeledSlider({ label, value, onChange, min, max, unit, tint, readout }: {
    label: string;
    value: number;
    onChange: (v: number) => void;
    min?: number;
    max?: number;
    unit?: string; /** Track colour (CodexUI pose sliders tint per channel). */
    tint?: string; /** Replaces the numeric readout, e.g. "+22°". */
    readout?: string;
}): import("react").JSX.Element;
/** Segmented icon control — theme-styled, single select. */
export declare function SegmentedIcons({ items, selection, onChange }: {
    items: readonly {
        icon: string;
        help: string;
    }[];
    selection: number;
    onChange: (i: number) => void;
}): import("react").JSX.Element;
/** Icon tool cluster — vertical/horizontal group of labeled tool buttons. */
export declare function ToolCluster({ tools, axis, solid }: {
    /** `tint` colours the active state per tool (CodexUI's selection rail: Cue/Trigger warn, Monitor/Hardware ok, Stop danger). */
    tools: readonly {
        icon: string;
        label: string;
        tint?: string;
    }[];
    axis?: "vertical" | "horizontal"; /** Fill the active tool with its tint and white glyph, CodexUI-style. */
    solid?: boolean;
}): import("react").JSX.Element;
/** Inline notification / toast banner. */
export declare const Toast: ({ icon, message, tint }: {
    icon?: string;
    message: string;
    tint?: string;
}) => import("react").JSX.Element;
/** Info callout box — icon + title + message. */
export declare const Callout: ({ icon, title, message, tint }: {
    icon?: string;
    title: string;
    message: string;
    tint?: string;
}) => import("react").JSX.Element;
/** macOS-style switch. */
export declare function Switch({ checked, onChange, label, size }: {
    checked: boolean;
    onChange: (v: boolean) => void;
    label: string;
    size?: "mini" | "small";
}): import("react").JSX.Element;
/** Labeled toggle row. */
export declare const ToggleRow: ({ label, isOn, onChange }: {
    label: string;
    isOn: boolean;
    onChange: (v: boolean) => void;
}) => import("react").JSX.Element;
/** A `Toggle(label)` with the label on the left, as SwiftUI lays it out in a panel. */
export declare const ToggleLine: ({ label, isOn, onChange, size }: {
    label: string;
    isOn: boolean;
    onChange: (v: boolean) => void;
    size?: "mini" | "small";
}) => import("react").JSX.Element;
/** Determinate progress bar. */
export declare const ProgressBar: ({ value, tint }: {
    value: number;
    tint?: string;
}) => import("react").JSX.Element;
/** Boxed numeric property field — label + value + unit in a bordered box. */
export declare const PropertyField: ({ label, value, unit }: {
    label: string;
    value: string;
    unit?: string;
}) => import("react").JSX.Element;
/** Icon command button with an active state. */
export declare const CommandButton: ({ icon, active, onClick, label }: {
    icon: string;
    active?: boolean;
    onClick?: () => void;
    label?: string;
}) => import("react").JSX.Element;
/** Rich non-blocking notification — icon, title, message, action + timestamp, dismiss. */
export declare function NotificationCard({ icon, title, message, action, timestamp, tint, onDismiss }: {
    icon?: string;
    title: string;
    message: string;
    action?: string;
    timestamp?: string;
    tint?: string;
    onDismiss?: () => void;
}): import("react").JSX.Element;
/** Modal dialog card — header, content, and Cancel/Confirm actions. */
export declare function DialogCard({ title, subtitle, icon, confirmLabel, onCancel, onConfirm, children }: {
    title: string;
    subtitle?: string;
    icon?: string;
    confirmLabel?: string;
    onCancel?: () => void;
    onConfirm?: () => void;
    children: ReactNode;
}): import("react").JSX.Element;
/** Closable document tab strip with an active underline. */
export declare function DocumentTabs({ tabs, selection, onChange }: {
    tabs: readonly string[];
    selection: number;
    onChange: (i: number) => void;
}): import("react").JSX.Element;
/** Segmented value chip strip — quick-pick options (e.g. FPS, units). */
export declare const ChipPicker: ({ options, selection, onChange }: {
    options: readonly string[];
    selection: string;
    onChange: (v: string) => void;
}) => import("react").JSX.Element;
export declare const Spinner: ({ size }: {
    size?: number;
}) => import("react").JSX.Element;
/** Busy card for long operations (STEP import). */
export declare function ProgressCard({ title, detail, progress, countText }: {
    title: string;
    detail?: string;
    progress?: number | null;
    countText?: string;
}): import("react").JSX.Element;
/** Panel with an icon badge, subtitle, and overflow menu. */
export declare function PanelCard({ title, subtitle, icon, tint, onMenu, children, className, style, contentOnly }: {
    title: string;
    subtitle?: string;
    icon?: string;
    tint?: string;
    onMenu?: () => void;
    children: ReactNode;
    className?: string;
    style?: CSSProperties;
    contentOnly?: boolean;
}): import("react").JSX.Element;
/** List row with solid-accent selection, optional indent, trailing detail and status dot. */
export declare function ListRow({ icon, title, detail, level, selected, statusColor, onClick }: {
    icon: string;
    title: string;
    detail?: string;
    level?: number;
    selected?: boolean;
    statusColor?: string;
    onClick?: () => void;
}): import("react").JSX.Element;
/** Small footer action button used under panel lists ("+ Clip", duplicate…). */
export declare const PanelAction: ({ icon, label, onClick }: {
    icon?: string;
    label?: string;
    onClick?: () => void;
}) => import("react").JSX.Element;
/** One canonical row for every file-tree / browser panel (Fusion-browser layout). */
export declare function TreeRow({ depth, icon, title, count, detail, expandable, expanded, selected, muted, bold, visible, onToggleVisible, onToggleExpand, onTap, trailing, dragHandleProps }: {
    depth?: number;
    icon: string;
    title: string;
    count?: number;
    detail?: string;
    expandable?: boolean;
    expanded?: boolean;
    selected?: boolean;
    muted?: boolean;
    bold?: boolean;
    visible?: boolean;
    onToggleVisible?: () => void;
    onToggleExpand?: () => void;
    onTap?: () => void;
    trailing?: ReactNode;
    dragHandleProps?: Record<string, unknown>;
}): import("react").JSX.Element;
/** Search / filter input. */
export declare function SearchField({ placeholder, text, onChange }: {
    placeholder?: string;
    text: string;
    onChange: (v: string) => void;
}): import("react").JSX.Element;
/** Numeric field with −/+ steppers. */
export declare function StepperField({ label, value, onChange, step, unit }: {
    label: string;
    value: number;
    onChange: (v: number) => void;
    step?: number;
    unit?: string;
}): import("react").JSX.Element;
/** Simple segmented text tabs for inspectors (Properties · Appearance · Output). */
export declare const InspectorTabs: ({ tabs, selection, onChange }: {
    tabs: readonly (string | {
        label: string;
        icon: string;
    })[];
    selection: number;
    onChange: (i: number) => void;
}) => import("react").JSX.Element;
/** A `Picker(.segmented)` — text or icon segments. */
export declare function Segmented<T extends string>({ options, value, onChange, ariaLabel, size }: {
    options: readonly {
        id: T;
        label?: string;
        icon?: string;
    }[];
    value: T;
    onChange: (v: T) => void;
    ariaLabel: string;
    size?: "mini" | "small" | "regular";
}): import("react").JSX.Element;
export interface StageDef {
    id: string;
    name: string;
    icon: string;
}
/** One pipeline tab in the top bar. */
export declare const StageChip: ({ stage, active, compact, showLabel, onClick }: {
    stage: StageDef;
    active: boolean;
    compact?: boolean; /** Overrides the label rule (CodexUI's label modes). */
    showLabel?: boolean;
    onClick?: () => void;
}) => import("react").JSX.Element;
/** The 24pt footer strip. */
export declare function StatusBar({ workspace, model, engine, themeName, kernel }: {
    workspace: string;
    model?: {
        name: string;
        triangles: number;
    } | null;
    engine?: string;
    themeName?: string;
    kernel?: string;
}): import("react").JSX.Element;
export interface SystemOutput {
    icon: string;
    name: string;
    detail: string;
    status: string;
    tint: string;
    statusTint: string;
}
/** The Live popover — outputs and media the show is bound to. */
export declare function SystemStatusView({ outputs, media }: {
    outputs?: readonly SystemOutput[];
    media?: readonly {
        name: string;
        icon: string;
    }[];
}): import("react").JSX.Element;
/** 28×24 icon button from the home header / file cluster. */
export declare const HeaderIcon: ({ icon, label, onClick, active, tint }: {
    icon: string;
    label: string;
    onClick?: () => void;
    active?: boolean;
    tint?: string;
}) => import("react").JSX.Element;
/** Section caption: 9.5pt semibold, tracked, text3. */
export declare const Caption: ({ children, style }: {
    children: ReactNode;
    style?: CSSProperties;
}) => import("react").JSX.Element;
export declare const Divider: ({ vertical, height, style }: {
    vertical?: boolean;
    height?: number;
    style?: CSSProperties;
}) => import("react").JSX.Element;
/** Shapes from the kit. */
export declare const Diamond: ({ size, fill, className, style }: {
    size?: number;
    fill?: string;
    className?: string;
    style?: CSSProperties;
}) => import("react").JSX.Element;
export declare const Triangle: ({ size, fill }: {
    size?: number;
    fill?: string;
}) => import("react").JSX.Element;
/** Accessible name plumbing for labelled controls. */
export declare const useLabelId: () => string;
/** The centred workspace navigator: authoring stages, a divider, then the utilities (WorkspaceStageTabs.swift). */
export declare function WorkspaceStageTabs({ stages, activeID, onSelect, compact, labelMode, utilityStartID }: {
    stages: readonly StageDef[];
    activeID: string;
    onSelect?: (id: string) => void;
    compact?: boolean;
    labelMode?: StageLabelMode; /** The first utility stage; a hairline sits before it. */
    utilityStartID?: string;
}): import("react").JSX.Element;
/** The guided-tour bar over the workspace: stage icon, progress, purpose, previous / Next / close (CodexUIShell.swift). */
export declare function WalkthroughCard({ icon, progress, purpose, onPrevious, onNext, onClose }: {
    icon: string;
    progress: string;
    purpose: string;
    onPrevious?: () => void;
    onNext?: () => void;
    onClose?: () => void;
}): import("react").JSX.Element;
/** Dashed file target with a foot line (AssetsPrototype "Load 3D Assembly"). */
export declare function DropZone({ icon, title, detail, footLeft, footRight, onPick }: {
    icon?: string;
    title?: string;
    detail?: string;
    footLeft?: ReactNode;
    footRight?: ReactNode;
    onPick?: () => void;
}): import("react").JSX.Element;
/** A mate connector slot: caption, target glyph, the picked entity, and a swap affordance (RigPrototype). */
export declare const ConnectorField: ({ label, value, onSwap }: {
    label: string;
    value: string;
    onSwap?: () => void;
}) => import("react").JSX.Element;
export interface ContextAction {
    id: string;
    label: string;
    icon: string;
    danger?: boolean;
}
/** The selection-adaptive actions card beside the selection rail (SpatialSelectionToolsSpecimen). */
export declare function ContextActionsCard({ icon, title, kind, actions, activeID, onSelect, width }: {
    icon?: string;
    title: string;
    kind: string;
    actions: readonly ContextAction[];
    activeID?: string;
    onSelect?: (id: string) => void;
    width?: number;
}): import("react").JSX.Element;
/** One device with its transport, checked when it answers (SpatialContextStackSpecimen, HardwarePrototype). */
export declare const DeviceStatusRow: ({ name, route, ok }: {
    name: string;
    route: string;
    ok?: boolean;
}) => import("react").JSX.Element;
export interface SafetyRow {
    label: string;
    value: string;
    tint?: string;
}
/** The authoritative device-layer safety panel body: shield status, enforced limits, the E-Stop (HardwarePrototype). */
export declare function SafetyStatus({ healthy, title, detail, rows, onStop, stopLabel }: {
    healthy?: boolean;
    title?: string;
    detail?: string;
    rows: readonly SafetyRow[];
    onStop?: () => void;
    stopLabel?: string;
}): import("react").JSX.Element;
/** A live-value capsule: the channel's position within its range (HardwarePrototype channel map). */
export declare const LiveBar: ({ fraction, tint, width }: {
    fraction: number;
    tint?: string;
    width?: number;
}) => import("react").JSX.Element;
/** A stat chip: uppercase key over a monospaced value (the old Assets `importStat`). */
export declare const StatChip: ({ label, value, tint }: {
    label: string;
    value: string;
    tint?: string;
}) => import("react").JSX.Element;
/** A project tile: tinted gradient thumb, name, kind, meta (the old Home RECENT grid). */
export declare const ProjectCard: ({ name, kind, meta, tint, icon, onClick }: {
    name: string;
    kind: string;
    meta: string;
    tint?: string;
    icon?: string;
    onClick?: () => void;
}) => import("react").JSX.Element;
/** A device's identity: tinted circle badge, name, transport/port (the old Hardware controller inspector head). */
export declare const DeviceIdentity: ({ icon, name, detail, tint }: {
    icon?: string;
    name: string;
    detail: string;
    tint?: string;
}) => import("react").JSX.Element;
/** The servo range bar: the mapped span within the pulse range, marker ticks, µs labels (the old `calibBar`). */
export declare function CalibrationRangeBar({ start, end, minLabel, maxLabel, tint }: {
    start?: number;
    end?: number;
    minLabel?: string;
    maxLabel?: string;
    tint?: string;
}): import("react").JSX.Element;
/** MouseControlDiagram.swift — the navigation settings' code-drawn mouse legend: L / wheel / R with the profile's orbit, pan, zoom and special mappings. */
export declare function MouseControlDiagram({ profile, orbit, pan, zoom, special, style }: {
    profile: string;
    orbit: string;
    pan: string;
    zoom: string;
    special: string;
    style?: CSSProperties;
}): import("react").JSX.Element;
