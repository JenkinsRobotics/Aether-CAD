/**
 * Viewport-side widgets: the mock stage (Design.swift ViewportMock +
 * PerspectiveGrid), EmptyStage, RadialMenu and CenterTray (Layout.swift),
 * AxisGizmo, ViewCube (ViewCube.swift, same projection math), MoveGizmo,
 * MaterialSphere / VisualizationIcon (Visualization.swift) and the two grids
 * the Design/Show canvases draw.
 */
import { type CSSProperties, type ReactNode } from "react";
/** Shapr3D-style perspective ground grid — lines converge toward the horizon. */
export declare function PerspectiveGrid({ className }: {
    className?: string;
}): import("react").JSX.Element;
/** Faint square construction grid (DesignGrid / the Show + Hardware graph paper). */
export declare const DotGrid: ({ step, opacity }: {
    step?: number;
    opacity?: number;
}) => import("react").JSX.Element;
/** A stylized 3D-viewport placeholder (gradient stage + faux part + triad). */
export declare function ViewportMock({ showGizmo, selected, onTapPart, onTapCanvas, children, className }: {
    showGizmo?: boolean;
    selected?: boolean;
    onTapPart?: () => void;
    onTapCanvas?: () => void;
    children?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
/** The empty-viewport prompt with its import call to action. */
export declare const EmptyStage: ({ status, importAction, importLabel }: {
    status: string;
    importAction?: () => void;
    importLabel?: string;
}) => import("react").JSX.Element;
/** Six-item radial menu on double-click (208pt ring, 76pt radius). */
export declare function RadialMenu({ onDismiss, onPick }: {
    onDismiss: () => void;
    onPick?: (label: string) => void;
}): import("react").JSX.Element;
export interface TrayItem {
    icon: string;
    label: string;
    popover?: ReactNode;
    onSelect?: () => void;
}
/** 70×50 items in a translucent tray; items with a popover open it. */
export declare function CenterTray({ items, active }: {
    items: readonly TrayItem[];
    active?: string;
}): import("react").JSX.Element;
/** Viewport axis orientation gizmo (X/Y/Z indicator). */
export declare function AxisGizmo({ size }: {
    size?: number;
}): import("react").JSX.Element;
export type ViewCubeFace = "front" | "back" | "right" | "left" | "top" | "bottom";
type V3 = [number, number, number];
/** Screen basis for an orthographic view along `direction` (origin → camera). */
export declare function cubeBasis(direction: V3): {
    right: V3;
    up: V3;
};
export declare const cubeDirection: (yaw: number, pitch: number) => V3;
/** Camera-facing faces only, back-to-front so painting order is correct. */
export declare function cubeFaces(size: number, direction: V3): {
    face: ViewCubeFace;
    points: {
        x: number;
        y: number;
    }[];
    depth: number;
}[];
/** Orientation cube — projected faces, hover highlight, click to look at a face. */
export declare function ViewCube({ yaw, pitch, size, onSelect }: {
    yaw: number;
    pitch: number;
    size?: number;
    onSelect?: (yaw: number, pitch: number) => void;
}): import("react").JSX.Element;
/** Move controls shown after double-clicking a body — directional arrows + a Copy affordance. */
export declare function MoveGizmo({ onNudge, onDismiss }: {
    onNudge?: (dx: number, dy: number) => void;
    onDismiss?: () => void;
}): import("react").JSX.Element;
/** Sphere preview with the Shapr3D diagonal band. */
export declare function MaterialSphere({ color, glossy, size, checkered }: {
    color: [number, number, number];
    glossy: boolean;
    size?: number;
    checkered?: boolean;
}): import("react").JSX.Element;
/** The rainbow Visualization button from the reference. */
export declare const VisualizationIcon: ({ size }: {
    size?: number;
}) => import("react").JSX.Element;
export declare const checkerStyle: (tint?: string, extra?: CSSProperties) => CSSProperties;
/**
 * The CodexUI stage: a schematic animatronic over a converging grid, a mode
 * pill with the selection, a mini view cube, and the camera chrome capsule.
 * `showsStage` adds the proscenium frame and light beams the Show workspace used.
 */
export declare function RobotViewport({ mode, selected, showsStage, hud, onToggleHud, display, className, style, children }: {
    mode?: string;
    selected?: string;
    showsStage?: boolean; /** Present = the gauge button is offered; true = pressed. */
    hud?: boolean;
    onToggleHud?: () => void;
    display?: string;
    className?: string;
    style?: CSSProperties;
    children?: ReactNode;
}): import("react").JSX.Element;
export {};
