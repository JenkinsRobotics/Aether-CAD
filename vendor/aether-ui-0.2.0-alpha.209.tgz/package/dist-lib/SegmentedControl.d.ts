import type { ReactNode } from "react";
export interface SegmentedControlOption {
    id: string;
    label: ReactNode;
    icon?: ReactNode;
    disabled?: boolean;
}
export interface SegmentedControlProps {
    options: readonly SegmentedControlOption[];
    value?: string;
    defaultValue?: string;
    onChange?: (id: string) => void;
    ariaLabel: string;
    disabled?: boolean;
    className?: string;
}
export declare function SegmentedControl({ options, value, defaultValue, onChange, ariaLabel, disabled, className }: SegmentedControlProps): import("react").JSX.Element;
