import { historyBranchKey, historyReferenceKey } from "./DocumentServices.js";
function documentHistoryGraph(history, commitsFor) {
  const snapshots = new Map(
    history.revisions.map((save) => [save.revision, save])
  );
  const lanes = [
    "Main",
    ...new Set(
      [
        ...history.branches.map(historyBranchKey),
        ...history.versions.map(
          (version) => historyReferenceKey(version.branch ? version : snapshots.get(version.revision) ?? {})
        )
      ].filter((name) => name !== "Main")
    )
  ];
  const rows = [];
  const first = Math.min(...snapshots.keys());
  const add = (id, kind, name, revision, branch, message = "", created, branchID) => {
    const save = snapshots.get(revision);
    rows.push({
      id,
      kind,
      name,
      revision,
      branch,
      branchID,
      message,
      author: save?.author ?? "",
      saved: created ?? save?.saved ?? 0,
      lane: lanes.indexOf(branchID ?? branch),
      parents: [],
      primaryParents: []
    });
  };
  const versionRevisions = new Set(history.versions.map((version) => version.revision));
  const uncommitted = (head) => {
    let edits = 0, revision = head, since = null;
    const seen = /* @__PURE__ */ new Set();
    while (revision != null && !seen.has(revision)) {
      seen.add(revision);
      if (versionRevisions.has(revision)) {
        since = history.versions.find((version) => version.revision === revision)?.name ?? null;
        const content = snapshots.get(head)?.blob_hash;
        if (content && content === snapshots.get(revision)?.blob_hash) edits = 0;
        break;
      }
      const save = snapshots.get(revision);
      if (save && save.event !== "create") edits++;
      revision = save?.parent_revision;
    }
    return { edits, since };
  };
  for (const branch of history.branches) {
    if (commitsFor !== void 0) {
      const { edits, since } = uncommitted(branch.head_revision);
      if (!edits) continue;
      add(
        `workspace:${historyBranchKey(branch)}`,
        "workspace",
        historyBranchKey(branch) === commitsFor ? "Uncommitted changes" : branch.name,
        branch.head_revision,
        branch.name,
        `${edits} ${edits === 1 ? "edit" : "edits"} since ${since ?? "the document was created"}`,
        void 0,
        branch.id
      );
      continue;
    }
    add(
      `workspace:${historyBranchKey(branch)}`,
      "workspace",
      branch.name,
      branch.head_revision,
      branch.name,
      branch.message,
      void 0,
      branch.id
    );
  }
  for (const version of history.versions) {
    add(
      `version:${version.name}`,
      "version",
      version.name,
      version.revision,
      version.branch ?? snapshots.get(version.revision)?.branch ?? "Main",
      version.message,
      version.created,
      version.branch_id ?? snapshots.get(version.revision)?.branch_id
    );
    Object.assign(rows[rows.length - 1], { status: version.status ?? "version", origin: version.origin ?? "user", statusUpdated: version.status_updated ?? 0, statusNote: version.status_note ?? "" });
  }
  for (const save of history.revisions) {
    if (save.parent_revision == null && (save.event === "create" || save.revision === first))
      add(
        `start:${save.revision}`,
        "start",
        "Start",
        save.revision,
        save.branch,
        "",
        void 0,
        save.branch_id
      );
  }
  const order = { workspace: 0, version: 1, start: 2 };
  rows.sort(
    (a, b) => b.revision - a.revision || order[a.kind] - order[b.kind] || b.saved - a.saved || a.id.localeCompare(b.id)
  );
  const milestones = /* @__PURE__ */ new Map();
  for (const row of rows)
    milestones.set(row.revision, [
      ...milestones.get(row.revision) ?? [],
      row
    ]);
  const nearest = (revision, merges = true, viaMerge = false) => {
    const queue = revision == null ? [] : [[revision, viaMerge]], seen = /* @__PURE__ */ new Set(), found = /* @__PURE__ */ new Set();
    while (queue.length) {
      const [id, merged] = queue.pop();
      if (seen.has(`${id}:${merged}`)) continue;
      seen.add(`${id}:${merged}`);
      const same = milestones.get(id) ?? [];
      const milestone = same.find((item) => item.kind !== "workspace") ?? (merged ? same[0] : void 0);
      if (milestone) {
        found.add(milestone.id);
        continue;
      }
      const save = snapshots.get(id);
      if (save?.parent_revision != null) queue.push([save.parent_revision, merged]);
      if (merges && save?.merge_parent_revision != null) queue.push([save.merge_parent_revision, true]);
    }
    return [...found];
  };
  for (const row of rows) {
    if (row.kind === "start") continue;
    const same = milestones.get(row.revision) ?? [];
    const next = row.kind === "workspace" ? same.find((item) => item.kind !== "workspace") : same.filter((item) => item.kind !== "workspace").find((_, index, list) => list[index - 1]?.id === row.id);
    if (next) row.parents = row.primaryParents = [next.id];
    else {
      const save = snapshots.get(row.revision);
      row.primaryParents = nearest(save?.parent_revision, false);
      row.parents = [
        .../* @__PURE__ */ new Set([
          ...nearest(save?.parent_revision),
          ...nearest(save?.merge_parent_revision, true, true)
        ])
      ];
    }
  }
  return rows;
}
export {
  documentHistoryGraph
};
