import type { WorkspaceControls } from './workspace-controls.js';
export declare function WorkspaceLayoutControl({ controls }: {
    controls: WorkspaceControls;
}): import("react").JSX.Element;
