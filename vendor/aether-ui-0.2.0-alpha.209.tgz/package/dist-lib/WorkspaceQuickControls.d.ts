import { type ReactNode } from "react";
import { type LaunchableApp } from "./AppLauncher.js";
import "./WorkspaceQuickControls.css";
export declare function WorkspaceQuickControls({ appID, appName, apps, viewControls, onShare, onSettings, account, defaultPinnedIDs, compact }: {
    appID: string;
    appName?: string;
    apps: readonly LaunchableApp[];
    viewControls?: ReactNode;
    onShare?: () => void;
    onSettings?: () => void;
    account?: ReactNode;
    defaultPinnedIDs?: readonly string[];
    compact?: boolean;
}): import("react").JSX.Element;
