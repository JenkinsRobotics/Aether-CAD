import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import "./ConceptWidgets.css";
import { AdvisorWelcome } from "./AdvisorWelcome.js";
import "./AdvisorPanel.css";
import "./StudioAgent.css";
function AssistantPanel({ title, heading, welcome, onRate, detail, status = "Prototype", appearance = "default", messages, suggestions = [], showModes = true, density = "compact", layout = "card", toolbar, headerActions, context, composerActions, renderComposerActions, notice, busy = false, disabled = false, onStop, onSubmit }) {
  const [mode, setMode] = useState("chat");
  const [draft, setDraft] = useState("");
  const promptId = useId();
  const sending = useRef(false);
  const submission = useRef(0);
  const wasBusy = useRef(busy);
  const [submitting, setSubmitting] = useState(false);
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  useEffect(() => {
    if (wasBusy.current && !busy) {
      submission.current++;
      sending.current = false;
      setSubmitting(false);
    }
    wasBusy.current = busy;
  }, [busy]);
  const inputRef = useRef(null);
  const [ratings, setRatings] = useState({});
  const bodyRef = useRef(null);
  useEffect(() => {
    const body = bodyRef.current;
    if (body) body.scrollTop = messages.length ? body.scrollHeight : 0;
  }, [messages]);
  const submit = async (event) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text || busy || disabled || sending.current) return;
    const request = ++submission.current;
    sending.current = true;
    setSubmitting(true);
    try {
      const result = onSubmit?.(text);
      const accepted = result && typeof result === "object" && "then" in result ? await result : result;
      if (accepted !== false && mounted.current && request === submission.current) setDraft((current) => current.trim() === text ? "" : current);
    } finally {
      if (request === submission.current) {
        sending.current = false;
        if (mounted.current) setSubmitting(false);
      }
    }
  };
  if (layout === "agent") return /* @__PURE__ */ jsxs("section", { className: `aui-agent-chat${appearance === "studio" ? " aui-agent-chat--studio" : ""}`, "aria-label": title, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-agent-chat__header", children: [
      /* @__PURE__ */ jsx("h3", { children: heading ?? title }),
      /* @__PURE__ */ jsx("span", { className: "aui-agent-chat__beta", children: "Pre-alpha" }),
      headerActions && /* @__PURE__ */ jsx("div", { className: "aui-agent-chat__header-actions", children: headerActions })
    ] }),
    (detail || toolbar) && /* @__PURE__ */ jsxs("div", { className: "aui-agent-chat__toolbar", children: [
      /* @__PURE__ */ jsx("span", { title: detail, children: detail }),
      toolbar
    ] }),
    /* @__PURE__ */ jsx("div", { ref: bodyRef, className: "aui-agent-chat__conversation", role: "log", "aria-label": "Conversation", "aria-live": "polite", children: messages.length ? messages.map((message) => /* @__PURE__ */ jsxs("div", { className: `aui-assistant-panel__message aui-agent-chat__message aui-agent-chat__message--${message.role}`, children: [
      message.text,
      message.role === "assistant" && message.text && /* @__PURE__ */ jsx("div", { className: "aui-advisor-rating", role: "group", "aria-label": "Rate this response", title: "Your rating stays with this conversation", children: [1, 2, 3, 4, 5].map((value) => /* @__PURE__ */ jsx(
        IconButton,
        {
          label: `Rate ${value} of 5`,
          disabled: busy,
          "aria-pressed": (message.rating ?? ratings[message.id]) === value,
          "data-filled": value <= (message.rating ?? ratings[message.id] ?? 0),
          onClick: () => {
            setRatings((current) => ({ ...current, [message.id]: value }));
            onRate?.(message.id, value);
          },
          children: /* @__PURE__ */ jsx(AetherIcon, { name: "star" })
        },
        value
      )) })
    ] }, message.id)) : /* @__PURE__ */ jsxs("div", { className: "aui-agent-chat__welcome", children: [
      welcome ?? /* @__PURE__ */ jsx(AdvisorWelcome, { hasContext: !!context }),
      !!suggestions.length && /* @__PURE__ */ jsxs("div", { className: "aui-agent-chat__samples", children: [
        /* @__PURE__ */ jsx("h4", { children: "Sample questions" }),
        suggestions.map((suggestion) => /* @__PURE__ */ jsx("button", { type: "button", onClick: () => {
          setDraft(suggestion);
          inputRef.current?.focus();
        }, children: suggestion }, suggestion))
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "aui-agent-chat__bottom", children: [
      notice && /* @__PURE__ */ jsx("div", { className: "aui-agent-chat__notice", role: "status", children: notice }),
      /* @__PURE__ */ jsx("label", { className: "aui-agent-chat__prompt-label", htmlFor: promptId, children: "Prompt" }),
      /* @__PURE__ */ jsxs("form", { className: "aui-agent-chat__composer", onSubmit: submit, children: [
        context && /* @__PURE__ */ jsx("div", { className: "aui-agent-chat__context", children: context }),
        /* @__PURE__ */ jsx(
          "textarea",
          {
            id: promptId,
            ref: inputRef,
            disabled,
            "aria-label": `Ask ${title}`,
            placeholder: messages.length ? "Ask for follow-up changes" : "Ask anything\u2026",
            rows: 3,
            value: draft,
            onChange: (event) => setDraft(event.target.value),
            onKeyDown: (event) => {
              if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
                event.preventDefault();
                event.currentTarget.form?.requestSubmit();
              }
            }
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "aui-agent-chat__controls", children: [
          composerActions,
          renderComposerActions?.((text) => setDraft((value) => `${value}${value && !value.endsWith(" ") ? " " : ""}${text}`)),
          busy ? /* @__PURE__ */ jsx(IconButton, { type: "button", label: "Stop response", onClick: onStop, children: /* @__PURE__ */ jsx(AetherIcon, { name: "stop" }) }) : /* @__PURE__ */ jsx(IconButton, { type: "submit", label: "Send", disabled: disabled || submitting || !draft.trim(), children: /* @__PURE__ */ jsx(AetherIcon, { name: "arrow-up" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "aui-agent-chat__status", children: status }),
      /* @__PURE__ */ jsx("p", { className: "aui-agent-chat__disclaimer", children: "AI can make mistakes. Review its work." })
    ] })
  ] });
  return /* @__PURE__ */ jsxs("section", { className: "aui-assistant-panel", "data-density": density, style: showModes ? void 0 : { gridTemplateRows: "auto minmax(110px, 1fr) auto" }, "aria-label": title, children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "aether" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: title }),
        /* @__PURE__ */ jsx("span", { children: detail })
      ] }),
      /* @__PURE__ */ jsx("small", { children: status })
    ] }),
    showModes && /* @__PURE__ */ jsx("div", { className: "aui-assistant-panel__modes", children: [["voice", "animate"], ["chat", "comment"], ["docs", "document"], ["ideas", "lighting"]].map(([id, icon]) => /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `${id} mode`, "aria-pressed": mode === id, onClick: () => setMode(id), children: /* @__PURE__ */ jsx(AetherIcon, { name: icon }) }, id)) }),
    /* @__PURE__ */ jsxs("div", { className: "aui-assistant-panel__body", children: [
      messages.map((message) => /* @__PURE__ */ jsx("div", { className: `aui-assistant-panel__message aui-assistant-panel__message--${message.role}`, children: message.text }, message.id)),
      suggestions.length ? /* @__PURE__ */ jsx("div", { className: "aui-assistant-panel__suggestions", children: suggestions.map((suggestion) => /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setDraft(suggestion), children: suggestion }, suggestion)) }) : null
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
      /* @__PURE__ */ jsx("input", { "aria-label": `Ask ${title}`, placeholder: `Ask ${title}\u2026`, value: draft, onChange: (event) => setDraft(event.target.value) }),
      /* @__PURE__ */ jsx(IconButton, { type: "submit", label: "Send", children: /* @__PURE__ */ jsx(AetherIcon, { name: "export" }) })
    ] })
  ] });
}
export {
  AssistantPanel
};
