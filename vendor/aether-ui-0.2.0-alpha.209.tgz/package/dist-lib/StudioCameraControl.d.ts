import { type ReactNode } from "react";
import "./StudioAppFrame.css";
import "./StudioCameraControl.css";
/** One expanding camera surface; products supply their real navigation. */
export declare function StudioCameraControl({ projection, children }: {
    projection?: string;
    children: ReactNode;
}): import("react").JSX.Element;
