import { jsx, jsxs } from "react/jsx-runtime";
import { parseReviewTags } from "./review-tags.js";
import { commentImage } from "./comment-images.js";
import { useEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
import "./StudioReview.css";
function ReviewComposer({ task, value, onChange, onSubmit, busy, selectedName, reply, onCancelReply, context, members = [], versions = [], initialImages = [], initialRevision, resetKey, onCapture, initialTags = [], initialMentions = [], initialReference = false, referenceLabel = "Reference selected part" }) {
  const input = useRef(null), files = useRef(null);
  const [images, setImages] = useState([]), [reference, setReference] = useState(false), [revision, setRevision] = useState(initialRevision), [error, setError] = useState("");
  const [tags, setTags] = useState(initialTags), [mentions, setMentions] = useState(initialMentions), [tagsOpen, setTagsOpen] = useState(false);
  const [tagText, setTagText] = useState(initialTags.join(", "));
  const [loading, setLoading] = useState(false);
  const submitting = useRef(false);
  const generation = useRef(0);
  useEffect(() => {
    generation.current++;
    setImages(initialImages);
    setRevision(initialRevision);
    setReference(initialReference);
    setTags(initialTags);
    setTagText(initialTags.join(", "));
    setMentions(initialMentions);
    setLoading(false);
    setError("");
    return () => {
      generation.current++;
    };
  }, [resetKey]);
  async function addImages(list) {
    if (!list || busy || loading || images.length >= 3) return;
    const started = generation.current;
    setError("");
    setLoading(true);
    try {
      const added = [];
      for (const file of Array.from(list).slice(0, 3 - images.length)) {
        added.push(await commentImage(file));
      }
      if (started === generation.current) setImages((current) => [...current, ...added].slice(0, 3));
    } catch (e) {
      if (started === generation.current) setError(e.message);
    } finally {
      if (started === generation.current) setLoading(false);
    }
  }
  function action(id) {
    if (id === "tags") setTagsOpen((v) => !v);
    else if (id === "image") files.current?.click();
    else if (id === "reference") setReference((v) => !v);
    else if (id.startsWith("revision:")) setRevision(Number(id.slice(9)));
    else if (id === "screenshot" && onCapture && !loading && images.length < 3) {
      const started = generation.current;
      setError("");
      setLoading(true);
      void onCapture().then((image) => {
        if (started === generation.current) setImages((current) => [...current, image].slice(0, 3));
      }).catch((e) => {
        if (started === generation.current) setError(e.message);
      }).finally(() => {
        if (started === generation.current) setLoading(false);
      });
    } else if (id.startsWith("mention:")) {
      const member = members.find((person) => person.id === id.slice(8));
      if (member) {
        setMentions((ids) => [.../* @__PURE__ */ new Set([...ids, member.id])]);
        onChange(`${value}${value && !value.endsWith(" ") ? " " : ""}@${member.name} `);
      }
      input.current?.focus();
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "ps-review-compose-wrap", children: [
    reply && /* @__PURE__ */ jsxs("div", { className: "ps-review-replying", children: [
      reply === "Editing comment" ? reply : `Replying to ${reply}`,
      /* @__PURE__ */ jsx(IconButton, { label: "Cancel reply", size: "small", onClick: onCancelReply, children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
    ] }),
    error && /* @__PURE__ */ jsx("small", { role: "alert", children: error }),
    /* @__PURE__ */ jsxs("form", { className: "ps-review-composer aui-agent-chat__composer", "aria-label": task ? "Task composer" : "Comment composer", onSubmit: async (e) => {
      e.preventDefault();
      if (busy || loading || submitting.current || !value.trim()) return;
      submitting.current = true;
      const started = generation.current;
      try {
        if (await onSubmit(images, reference, revision, { tags, mentions }) && started === generation.current) {
          setImages([]);
          setReference(false);
          setRevision(void 0);
          setTags([]);
          setTagText("");
          setTagsOpen(false);
          setMentions([]);
        }
      } catch (error2) {
        if (started === generation.current) setError(error2.message);
      } finally {
        submitting.current = false;
      }
    }, children: [
      context,
      tagsOpen && /* @__PURE__ */ jsxs("label", { className: "ps-review-draft-tags", children: [
        "Tags",
        /* @__PURE__ */ jsx("input", { "aria-label": "Review item tags", value: tagText, placeholder: "Design, Clearance", onChange: (e) => {
          setTagText(e.target.value);
          setTags(parseReviewTags(e.target.value));
        } })
      ] }),
      !!tags.length && /* @__PURE__ */ jsx("div", { className: "ps-review-item-tags", children: tags.map((tag) => /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => {
        const next = tags.filter((value2) => value2 !== tag);
        setTags(next);
        setTagText(next.join(", "));
      }, "aria-label": `Remove tag: ${tag}`, children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "tag" }),
        tag,
        /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
      ] }, tag)) }),
      !!images.length && /* @__PURE__ */ jsx("div", { className: "ps-review-attachments", children: images.map((image, i) => /* @__PURE__ */ jsxs("span", { children: [
        /* @__PURE__ */ jsx("img", { src: image.data_url, alt: image.name }),
        /* @__PURE__ */ jsx(IconButton, { size: "small", label: `Remove ${image.name}`, onClick: () => setImages((v) => v.filter((_, n) => n !== i)), children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
      ] }, `${image.name}-${i}`)) }),
      reference && /* @__PURE__ */ jsxs("button", { type: "button", className: "ps-review-context-chip", onClick: () => setReference(false), children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "cube" }),
        selectedName ?? "Whole model",
        /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
      ] }),
      revision != null && /* @__PURE__ */ jsxs("button", { type: "button", className: "ps-review-context-chip", onClick: () => setRevision(void 0), children: [
        versions.find((item) => item.id === revision)?.label ?? `Saved state ${revision}`,
        /* @__PURE__ */ jsx(AetherIcon, { name: "close" })
      ] }),
      /* @__PURE__ */ jsx(
        "textarea",
        {
          ref: input,
          maxLength: task ? 1e3 : 1e4,
          rows: 2,
          "aria-label": task ? "New task" : "Write a comment",
          placeholder: task ? "Add a task for this design\u2026" : "Add a comment or ask a question\u2026",
          value,
          onChange: (e) => onChange(e.target.value),
          disabled: busy,
          onKeyDown: (e) => {
            if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault();
              e.currentTarget.form?.requestSubmit();
            }
          }
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "ps-review-composer-actions", children: [
        /* @__PURE__ */ jsx("input", { ref: files, type: "file", hidden: true, multiple: true, accept: "image/png,image/jpeg,image/webp", "aria-label": "Attach review images", onChange: (e) => {
          void addImages(e.target.files);
          e.target.value = "";
        } }),
        /* @__PURE__ */ jsx(MenuButton, { className: "ps-review-add", label: "Add to draft", placement: "top-start", disabled: busy, items: [
          { id: "tags", label: "Edit tags", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "tag" }) },
          { id: "image", label: "Attach images", disabled: loading || images.length >= 3, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "image" }) },
          { id: "reference", label: reference ? "Remove model reference" : referenceLabel, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "cube" }) },
          ...versions.map((item) => ({ id: `revision:${item.id}`, label: `Reference ${item.label}`, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "history" }) })),
          ...onCapture ? [{ id: "screenshot", label: "Attach screenshot", disabled: loading || images.length >= 3, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "screenshot" }) }] : []
        ], onSelect: action, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }),
        /* @__PURE__ */ jsx(MenuButton, { className: "ps-review-more", label: "Mention a member", disabled: busy || !members.length, placement: "top-start", items: members.map((member) => ({ id: `mention:${member.id}`, label: member.name })), onSelect: action, children: /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: "@" }) }),
        /* @__PURE__ */ jsx(IconButton, { size: "small", label: referenceLabel, "aria-pressed": reference, disabled: busy, onClick: () => action("reference"), children: /* @__PURE__ */ jsx(AetherIcon, { name: "cube" }) }),
        /* @__PURE__ */ jsx(IconButton, { size: "small", label: "Attach images", disabled: busy || loading || images.length >= 3, onClick: () => action("image"), children: /* @__PURE__ */ jsx(AetherIcon, { name: "image" }) }),
        /* @__PURE__ */ jsxs("span", { className: "ps-review-compose-kind", children: [
          /* @__PURE__ */ jsx(AetherIcon, { name: task ? "tasks" : "pencil" }),
          task ? "Task" : "Comment"
        ] }),
        /* @__PURE__ */ jsx(IconButton, { className: "ps-review-send", type: "submit", label: task ? "Add task" : reply ? "Send reply" : "Send comment", disabled: busy || loading || !value.trim(), children: /* @__PURE__ */ jsx(AetherIcon, { name: "arrow-up" }) })
      ] })
    ] })
  ] });
}
export {
  ReviewComposer
};
