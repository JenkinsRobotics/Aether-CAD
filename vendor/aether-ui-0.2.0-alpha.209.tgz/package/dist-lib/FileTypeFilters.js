import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { FileIcon } from "./FileIcon.js";
import { AetherIcon } from "./AetherIcon.js";
import { Menu } from "./Menu.js";
import { useRef, useState } from "react";
import { FILE_TYPES } from "./file-types.js";
import "./FileTypeFilters.css";
function FileTypeFilters({ value, onChange, types = FILE_TYPES, quickIDs = ["part", "assembly", "show", "pdf"] }) {
  const [open, setOpen] = useState(false);
  const trigger = useRef(null);
  const quick = quickIDs.flatMap((id) => types.filter((type) => type.id === id));
  const more = types.filter((type) => !quickIDs.includes(type.id));
  const selectedMore = more.find((type) => type.id === value);
  return /* @__PURE__ */ jsxs("div", { className: "aui-file-type-filters", role: "group", "aria-label": "Filter files by type", children: [
    /* @__PURE__ */ jsx("button", { type: "button", "aria-pressed": value === "all", onClick: () => onChange("all"), children: "All" }),
    quick.map((type) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-pressed": value === type.id, onClick: () => onChange(type.id), children: [
      /* @__PURE__ */ jsx(FileIcon, { type, size: 16 }),
      type.plural
    ] }, type.id)),
    more.length > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          ref: trigger,
          "aria-label": "More file types",
          "aria-haspopup": "menu",
          "aria-expanded": open,
          "data-selected": !!selectedMore || void 0,
          onClick: () => setOpen(!open),
          children: [
            selectedMore ? /* @__PURE__ */ jsx(FileIcon, { type: selectedMore, size: 16 }) : /* @__PURE__ */ jsx(AetherIcon, { name: "filter" }),
            selectedMore?.plural ?? "More",
            /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" })
          ]
        }
      ),
      /* @__PURE__ */ jsx(
        Menu,
        {
          open,
          anchor: trigger.current,
          ariaLabel: "More file types",
          className: "aui-file-type-menu",
          items: more.map((type) => ({ id: type.id, label: type.plural, icon: /* @__PURE__ */ jsx(FileIcon, { type, size: 16 }), kind: "radio", checked: value === type.id })),
          onSelect: onChange,
          onClose: () => setOpen(false)
        }
      )
    ] })
  ] });
}
export {
  FileTypeFilters
};
