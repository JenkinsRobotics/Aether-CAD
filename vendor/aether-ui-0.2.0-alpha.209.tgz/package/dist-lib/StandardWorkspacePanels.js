import { jsx } from "react/jsx-runtime";
import { AetherIcon } from "./AetherIcon.js";
import { DocumentCreateDialog } from "./DocumentCreateDialog.js";
import { DocumentVersionPanel } from "./DocumentVersionPanel.js";
import { DocumentReviewPanel } from "./DocumentReviewPanel.js";
import { DocumentCollaborationPanel } from "./DocumentCollaborationPanel.js";
import { DocumentFileManager } from "./DocumentFileManager.js";
import { EmptyState } from "./EmptyState.js";
const STANDARD_WORKSPACE_PANELS = [
  { id: "features", title: "Features and parts", icon: "features-parts" },
  { id: "versions", title: "Version control", icon: "version-control" },
  { id: "create-version", title: "Create version", icon: "version-create" },
  { id: "comments", title: "Comments", icon: "comment" },
  { id: "notes", title: "Document notes", icon: "notes" },
  { id: "reminders", title: "Reminders", icon: "stopwatch" },
  { id: "advisor", title: "AI advisor", icon: "advisor" },
  { id: "tasks", title: "Action items", icon: "tasks" },
  { id: "part-manager", title: "Part manager", icon: "part-manager" }
];
function standardWorkspacePanels(panels, bindings = {}, connection) {
  const used = /* @__PURE__ */ new Set();
  const standard = STANDARD_WORKSPACE_PANELS.map((definition) => {
    const id = bindings[definition.id] ?? definition.id;
    if (used.has(id)) throw new Error(`Two standard workspace panels are bound to ${id}.`);
    used.add(id);
    const panel = panels.find((panel2) => panel2.id === id);
    return {
      ...panel,
      id,
      title: definition.title,
      icon: /* @__PURE__ */ jsx(AetherIcon, { name: definition.icon }),
      ...definition.id === "part-manager" ? { separatorBefore: true } : {},
      ...definition.id === "create-version" ? { command: (onClose) => /* @__PURE__ */ jsx(DocumentCreateDialog, { connection, onClose }) } : {},
      content: definition.id === "create-version" ? null : connection && definition.id === "versions" ? /* @__PURE__ */ jsx(DocumentVersionPanel, { connection }) : connection && (definition.id === "comments" || definition.id === "tasks") ? /* @__PURE__ */ jsx(DocumentReviewPanel, { connection, initialTab: definition.id }) : connection && ["notes", "reminders"].includes(definition.id) ? /* @__PURE__ */ jsx(DocumentCollaborationPanel, { connection, kind: definition.id }) : connection && definition.id === "part-manager" && !panel?.content ? /* @__PURE__ */ jsx(DocumentFileManager, { connection }) : panel?.content ?? /* @__PURE__ */ jsx(
        EmptyState,
        {
          compact: true,
          title: definition.title,
          icon: /* @__PURE__ */ jsx(AetherIcon, { name: definition.icon }),
          description: `${definition.title} is not connected in this workspace yet.`
        }
      )
    };
  });
  const extras = panels.filter((panel) => !used.has(panel.id));
  return [...standard.slice(0, -1), ...extras, standard[standard.length - 1]];
}
export {
  STANDARD_WORKSPACE_PANELS,
  standardWorkspacePanels
};
