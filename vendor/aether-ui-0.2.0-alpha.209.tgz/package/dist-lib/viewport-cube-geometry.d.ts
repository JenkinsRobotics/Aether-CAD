/** One renderer-independent beveled cube for corner and world-space navigation.
 * This is UI artwork/hit geometry, never a product modeling kernel. */
export type CubeVector = readonly [number, number, number];
export type ViewportUpAxis = "y" | "z";
/** One camera frame for the mesh, face targets and corner-anchored XYZ axes.
 * Extra lens margin keeps endpoint lettering in bounds throughout a full orbit. */
export declare const viewportCubeProjection: {
    readonly center: 54;
    readonly scale: 21;
    readonly size: 108;
};
export declare const viewportCubeAxisOrigin: CubeVector;
export declare const viewportCubeAxes: {
    id: "x" | "y" | "z";
    end: CubeVector;
}[];
/** Proper rotation about X: preserve X and handedness when choosing Z-up. */
export declare function viewportVectorForUpAxis([x, y, z]: CubeVector, upAxis: ViewportUpAxis): CubeVector;
export type CubeFaceView = "front" | "back" | "right" | "left" | "top" | "bottom";
export interface ViewportCubeRegion {
    id: string;
    label: string;
    kind: "face" | "edge" | "corner";
    view?: CubeFaceView;
    normal: CubeVector;
    vertices: readonly CubeVector[];
    right?: CubeVector;
    up?: CubeVector;
}
export declare const viewportCubeRegions: readonly ViewportCubeRegion[];
export declare function viewportCubeRegionsForUpAxis(upAxis: ViewportUpAxis): readonly ViewportCubeRegion[];
/** Both renderers obtain their neutral colors from the same suite tokens. */
export declare const viewportCubeColorTokens: {
    readonly face: "--aether-color-bg-control-hover";
    readonly edge: "--aether-color-bg-hover";
    readonly corner: "--aether-color-border-control";
    readonly outline: "--aether-color-text-dim";
    readonly label: "--aether-color-text";
    readonly hover: "--aether-color-accent";
};
