/** The suite-standard floating feature window (Onshape-anatomy):
 * standard header = icon/title + green ✓ accept + red ✕ discard; compact keeps
 * icon/title above a shared body and bottom Cancel/Apply. Headers drag. Body takes an
 * entities box, inline parameter rows, and a status line. Every feature
 * editor (plane, extrude, mirror, mates…) mounts through this one module. */
import { type FeatureWindowHelp } from "./FeatureWindowAccessories.js";
export interface FeatureWindowOptions {
    viewport: HTMLElement;
    className: string;
    title: string;
    /** Presentation only; every variant uses the same body builders and validation. */
    variant?: "standard" | "spacious" | "compact";
    /** Optional shared artwork node, displayed beside the title. */
    headerIcon?: HTMLElement;
    acceptLabel: string;
    discardLabel: string;
    onAccept: () => void | Promise<void>;
    onDiscard: () => void | Promise<void>;
    /** Legacy help metadata. No content is rendered inside the accessory row. */
    help?: FeatureWindowHelp;
    /** Initial icon state; the Help toggle never expands the editor. */
    helpActive?: boolean;
    onHelpToggle?: (active: boolean) => void;
}
export interface FeatureWindow {
    panel: HTMLElement;
    /** The commit and discard buttons, in every variant (also `[data-feature-action]`). */
    accept: HTMLButtonElement;
    discard: HTMLButtonElement;
    body: HTMLElement;
    status: HTMLElement;
    close: () => void;
    /** Put the window in the error state (red title + message) or clear it.
     *  Accept is disabled while an error is showing. */
    setError: (message: string | null) => void;
    /** A transient status (preview progress, hints) shown beside the window, never reflowing it. */
    setNotice: (message: string | null) => void;
    /** Captioned bordered selection list; render() replaces its rows. */
    entitiesBox: (caption?: string) => {
        element: HTMLElement;
        render: (rows: {
            label: string;
            onRemove: () => void;
        }[]) => void;
    };
    /** Inline row: label left, controls right (Onshape parameter row). */
    row: (label: string, ...controls: HTMLElement[]) => HTMLElement;
    /** Segmented tab row (e.g. Solid/Surface/Thin, New/Add/Remove/Intersect). */
    tabs: (labels: string[], activeIndex?: number) => HTMLElement;
    /** A dropdown anchored to its field: the popup opens directly beneath,
     *  matching the field width. Native <select> popups overlay the control
     *  (macOS centres the current value on the cursor), which reads as
     *  misaligned inside a feature window. */
    picker: (options: readonly string[], config?: {
        value?: string;
        ariaLabel?: string;
        onChange?: (value: string) => void;
    }) => FeaturePicker;
    /** A sub-setting block: its children indent beneath a toggle, the way
     *  Onshape nests options that only apply when the parent is on. */
    subsection: (label: string, options?: {
        kind?: "checkbox" | "disclosure";
        open?: boolean;
        onToggle?: (open: boolean) => void;
    }) => FeatureSubsection;
    /** Add an icon toggle before Help. Callback receives its new on/off state. */
    actionIcon: (iconSvg: string, title: string, onToggle: (active: boolean) => void, active?: boolean) => HTMLElement;
    /** Synchronize app-owned Help mode without firing onHelpToggle. */
    setHelpActive: (active: boolean) => void;
}
export interface FeaturePicker {
    /** Place this in a row or the body; it carries the popup with it. */
    element: HTMLElement;
    value: () => string;
    setValue: (value: string) => void;
}
export interface FeatureSubsection {
    element: HTMLElement;
    /** Container for the nested rows. */
    body: HTMLElement;
    setOpen: (open: boolean) => void;
    isOpen: () => boolean;
}
export declare function openFeatureWindow(options: FeatureWindowOptions): FeatureWindow;
