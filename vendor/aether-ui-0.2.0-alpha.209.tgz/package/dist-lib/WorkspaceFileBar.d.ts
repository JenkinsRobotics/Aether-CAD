import { type ReactNode } from 'react';
import { type DocumentTabsProps } from './DocumentTabs.js';
import { type DocumentFileManagerProps } from './DocumentFileManager.js';
import './DocumentTabBar.css';
import './WorkspaceFileBar.css';
export interface WorkspaceFileBarProps extends DocumentTabsProps {
    manager: DocumentFileManagerProps;
    onAdd: () => void;
    addLabel?: string;
    trailing?: ReactNode;
    /** Product file menu, placed with the contents/library controls on the right. */
    fileActions?: ReactNode;
}
/** Shared bottom document strip. Products retain save, create and navigation semantics. */
export declare function WorkspaceFileBar({ manager, onAdd, addLabel, trailing, fileActions, ...tabs }: WorkspaceFileBarProps): import("react").JSX.Element;
