import type { MenuItem } from './Menu.js';
import type { CollectionControl } from './CollectionView.js';
import type { CollectionFilterOption } from './CollectionFilter.js';
/** Panel commands reuse the same controls as its header. */
export declare function treePanelContextItems(controls: readonly CollectionControl[], options: {
    filterOptions?: readonly CollectionFilterOption[];
    category: string;
    query: string;
    expand: boolean;
    collapse: boolean;
    extra: readonly MenuItem[];
}): MenuItem[];
