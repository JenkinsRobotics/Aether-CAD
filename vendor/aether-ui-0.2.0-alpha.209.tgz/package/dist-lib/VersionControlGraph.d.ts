import { type ReactNode } from "react";
import type { VersionControlEntry } from "./VersionControl.js";
/** Draw the host's actual ancestry beside measured rows. Card expansion and
 * container resizing change positions only; time sorting never creates edges. */
export declare function VersionControlGraph({ entries, visible, selected, children, linear }: {
    entries: readonly VersionControlEntry[];
    visible: readonly VersionControlEntry[];
    selected: string | null;
    children: ReactNode;
    linear?: boolean;
}): import("react").JSX.Element;
