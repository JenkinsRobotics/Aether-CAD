/**
 * The viewport look, read from the theme as numbers a renderer can use.
 *
 * A theme's `viewport-*` tokens describe the stage: its gradient, grid, part
 * shading, sketch strokes and selection. A viewport theme
 * (core/assets/themes/viewports) overrides only those, independently of the
 * interface theme. Every product's 3D view reads the same tokens through this
 * module, so one choice restyles every stage.
 *
 * Presentation only: it reads CSS custom properties and returns numbers. It
 * knows nothing about any renderer, and nothing about the host.
 */
export interface RGBA {
    r: number;
    g: number;
    b: number;
    a: number;
}
/** Parses the CSS colour forms a theme manifest may use: #rgb, #rrggbb, #rrggbbaa, rgb()/rgba(). */
export declare function parseCSSColor(value: string): RGBA | null;
/** A colour as a renderer hex number, with the alpha the token carried. */
export interface ViewportColor {
    hex: number;
    alpha: number;
}
export interface ViewportPalette {
    /** The stage gradient, and the single colour a solid background should use (their midpoint). */
    backgroundTop?: ViewportColor;
    backgroundBottom?: ViewportColor;
    background?: ViewportColor;
    grid?: ViewportColor;
    gridAxis?: ViewportColor;
    part?: ViewportColor;
    partShade?: ViewportColor;
    partEdge?: ViewportColor;
    cavity?: ViewportColor;
    sketch?: ViewportColor;
    sketchConstrained?: ViewportColor;
    construction?: ViewportColor;
    selection?: ViewportColor;
    hover?: ViewportColor;
}
/** Builds the palette from already-read token text, so the arithmetic is testable without a DOM. */
export declare function viewportPalette(tokens: Record<string, string>): ViewportPalette;
/**
 * The palette the page's theme currently resolves to. Returns an empty palette
 * where there is no document, so a renderer keeps its own defaults rather than
 * painting the scene black.
 */
export declare function readViewportPalette(element?: Element): ViewportPalette;
