import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { parseNumberExpression } from "./number-expression.js";
function clamp(value, min, max) {
  return Math.min(max ?? Number.POSITIVE_INFINITY, Math.max(min ?? Number.NEGATIVE_INFINITY, value));
}
function formatValue(value, precision) {
  if (value === null || value === void 0 || !Number.isFinite(value)) return "";
  return precision === void 0 ? String(value) : value.toFixed(precision);
}
function NumberField({
  value,
  defaultValue,
  min,
  max,
  step = 1,
  precision,
  unit,
  mixed = false,
  invalid: invalidProp = false,
  scrubLabel,
  onValueChange,
  onCommit,
  onCancel,
  className,
  disabled,
  readOnly,
  placeholder,
  onKeyDown,
  ...inputProps
}) {
  const inputRef = useRef(null);
  const committedRef = useRef(value ?? defaultValue ?? null);
  const [invalidDraft, setInvalidDraft] = useState(false);
  useEffect(() => {
    if (value === void 0 || !inputRef.current) return;
    committedRef.current = value;
    inputRef.current.value = formatValue(value, precision);
    setInvalidDraft(false);
  }, [precision, value]);
  const parseDraft = () => {
    const parsed = parseNumberExpression(inputRef.current?.value ?? "");
    if (parsed === null || parsed < (min ?? -Infinity) || parsed > (max ?? Infinity)) {
      return null;
    }
    return parsed;
  };
  const writeValue = (next, commit) => {
    const bounded = clamp(next, min, max);
    if (inputRef.current) inputRef.current.value = formatValue(bounded, precision);
    setInvalidDraft(false);
    onValueChange?.(bounded);
    if (commit) {
      committedRef.current = bounded;
      onCommit?.(bounded);
    }
  };
  const commitDraft = () => {
    const next = parseDraft();
    if (next === null) {
      setInvalidDraft(true);
      onValueChange?.(null);
      return;
    }
    writeValue(next, true);
  };
  const cancelDraft = () => {
    if (inputRef.current) {
      inputRef.current.value = formatValue(committedRef.current, precision);
      inputRef.current.select();
    }
    setInvalidDraft(false);
    onValueChange?.(committedRef.current);
    onCancel?.(committedRef.current);
  };
  const stepBy = (direction, event) => {
    const current = parseDraft() ?? committedRef.current ?? 0;
    const multiplier = event.shiftKey ? 10 : event.altKey ? 0.1 : 1;
    writeValue(current + direction * step * multiplier, true);
  };
  const beginScrub = (event) => {
    if (disabled || readOnly) return;
    event.preventDefault();
    const startX = event.clientX;
    const startValue = parseDraft() ?? committedRef.current ?? 0;
    let latest = startValue;
    const onMove = (moveEvent) => {
      latest = clamp(startValue + (moveEvent.clientX - startX) * step, min, max);
      writeValue(latest, false);
    };
    const onUp = () => {
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerup", onUp);
      writeValue(latest, true);
      inputRef.current?.focus();
    };
    document.addEventListener("pointermove", onMove);
    document.addEventListener("pointerup", onUp, { once: true });
  };
  const classes = ["aui-number-field"];
  if (invalidProp || invalidDraft) classes.push("aui-number-field--invalid");
  if (mixed) classes.push("aui-number-field--mixed");
  if (className) classes.push(className);
  return /* @__PURE__ */ jsxs("span", { className: "aui-number-field-wrap", children: [
    scrubLabel ? /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        className: "aui-number-field-scrub",
        "aria-label": `Adjust ${scrubLabel}`,
        title: `Drag to adjust ${scrubLabel}`,
        disabled: disabled || readOnly,
        onPointerDown: beginScrub,
        children: "\u2194"
      }
    ) : null,
    /* @__PURE__ */ jsx(
      "input",
      {
        ...inputProps,
        ref: inputRef,
        type: "text",
        inputMode: "decimal",
        className: classes.join(" "),
        defaultValue: mixed ? "" : formatValue(value ?? defaultValue, precision),
        placeholder: mixed ? "Mixed" : placeholder,
        disabled,
        readOnly,
        "aria-invalid": invalidProp || invalidDraft || void 0,
        onInput: () => {
          const parsed = parseDraft();
          setInvalidDraft(false);
          onValueChange?.(parsed);
        },
        onBlur: commitDraft,
        onKeyDown: (event) => {
          onKeyDown?.(event);
          if (event.defaultPrevented) return;
          if (event.key === "Enter") {
            event.preventDefault();
            commitDraft();
          } else if (event.key === "Escape") {
            event.preventDefault();
            cancelDraft();
          } else if (event.key === "ArrowUp" || event.key === "ArrowDown") {
            event.preventDefault();
            stepBy(event.key === "ArrowUp" ? 1 : -1, event);
          }
        }
      }
    ),
    unit ? /* @__PURE__ */ jsx("span", { className: "aui-number-field-unit", "aria-hidden": true, children: unit }) : null
  ] });
}
export {
  NumberField
};
