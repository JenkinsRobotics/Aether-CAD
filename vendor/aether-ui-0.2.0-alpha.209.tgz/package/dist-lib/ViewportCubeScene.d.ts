import type { ViewportUpAxis } from "./viewport-cube-geometry.js";
import type { ViewportOrientation } from "./ViewportNavigationCube.js";
/** Isolated, on-demand renderer: no second animation loop or product engine. */
export declare function ViewportCubeScene({ orientation, upAxis, highlight, onReady }: {
    orientation: ViewportOrientation;
    upAxis: ViewportUpAxis;
    highlight: string | null;
    onReady: (ready: boolean) => void;
}): import("react").JSX.Element;
