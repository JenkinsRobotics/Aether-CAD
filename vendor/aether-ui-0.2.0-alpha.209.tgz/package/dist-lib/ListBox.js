import { jsx, jsxs } from "react/jsx-runtime";
import { createElement } from "react";
import { Menu } from "./Menu.js";
import { CollectionView } from "./CollectionView.js";
import { CollectionFilter } from "./CollectionFilter.js";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState
} from "react";
const GROUP_HEIGHT = 25;
const TYPEAHEAD_RESET_MS = 700;
function ListBoxRows({
  items,
  selectedIDs,
  onSelect,
  ariaLabel,
  selectionMode = "single",
  onActivate,
  onContextMenu,
  onFocusItem,
  onAction,
  emptyState,
  loading = false,
  loadingState,
  error,
  virtualizeThreshold = 100,
  height = 240,
  rowHeight = 34,
  overscan = 4,
  className,
  style
}) {
  const [focusedID, setFocusedID] = useState(null);
  const [scrollTop, setScrollTop] = useState(0);
  const anchorRef = useRef(null);
  const rowRefs = useRef(/* @__PURE__ */ new Map());
  const scrollerRef = useRef(null);
  const typeaheadRef = useRef("");
  const typeaheadTimerRef = useRef(null);
  const enabledItems = useMemo(
    () => items.filter((item) => !item.disabled),
    [items]
  );
  const visualRows = useMemo(() => {
    const rows = [];
    let top = 0;
    let lastGroup;
    items.forEach((item, itemIndex) => {
      if (item.group && item.group !== lastGroup) {
        rows.push({
          kind: "group",
          label: item.group,
          top,
          height: GROUP_HEIGHT
        });
        top += GROUP_HEIGHT;
      }
      lastGroup = item.group;
      rows.push({ kind: "item", item, itemIndex, top, height: rowHeight });
      top += rowHeight;
    });
    return rows;
  }, [items, rowHeight]);
  const totalHeight = visualRows.length ? visualRows[visualRows.length - 1].top + visualRows[visualRows.length - 1].height : 0;
  const virtualized = items.length >= virtualizeThreshold;
  const visibleRows = useMemo(() => {
    if (!virtualized) return visualRows;
    const buffer = overscan * rowHeight;
    const start = Math.max(0, scrollTop - buffer);
    const end = scrollTop + height + buffer;
    return visualRows.filter(
      (row) => row.top + row.height >= start && row.top <= end
    );
  }, [height, overscan, rowHeight, scrollTop, virtualized, visualRows]);
  useEffect(
    () => () => {
      if (typeaheadTimerRef.current) clearTimeout(typeaheadTimerRef.current);
    },
    []
  );
  useEffect(() => {
    if (focusedID && !items.some((item) => item.id === focusedID && !item.disabled)) {
      setFocusedID(null);
    }
  }, [focusedID, items]);
  const applySelect = useCallback(
    (item, event) => {
      if (item.disabled || selectionMode === "none" || !onSelect) return;
      if (selectionMode === "multiple" && event.shiftKey && anchorRef.current) {
        const from = items.findIndex((entry) => entry.id === anchorRef.current);
        const to = items.findIndex((entry) => entry.id === item.id);
        if (from >= 0 && to >= 0) {
          const [start, end] = from < to ? [from, to] : [to, from];
          onSelect(
            items.slice(start, end + 1).filter((entry) => !entry.disabled).map((entry) => entry.id),
            "range"
          );
          return;
        }
      }
      anchorRef.current = item.id;
      onSelect(
        [item.id],
        selectionMode === "multiple" && (event.metaKey || event.ctrlKey) ? "toggle" : "single"
      );
    },
    [items, onSelect, selectionMode]
  );
  const focusItem = useCallback(
    (item) => {
      if (!item) return;
      setFocusedID(item.id);
      const element = rowRefs.current.get(item.id);
      if (element) {
        element.focus();
        return;
      }
      if (!virtualized) return;
      const row = visualRows.find(
        (entry) => entry.kind === "item" && entry.item.id === item.id
      );
      if (!row) return;
      scrollerRef.current?.scrollTo({
        top: Math.max(0, row.top - (height - row.height) / 2)
      });
      requestAnimationFrame(() => rowRefs.current.get(item.id)?.focus());
    },
    [height, virtualized, visualRows]
  );
  const handleTypeahead = useCallback(
    (key, currentID) => {
      typeaheadRef.current += key.toLocaleLowerCase();
      if (typeaheadTimerRef.current) clearTimeout(typeaheadTimerRef.current);
      typeaheadTimerRef.current = setTimeout(() => {
        typeaheadRef.current = "";
      }, TYPEAHEAD_RESET_MS);
      const currentIndex = enabledItems.findIndex((item) => item.id === currentID);
      const ordered = [
        ...enabledItems.slice(currentIndex + 1),
        ...enabledItems.slice(0, currentIndex + 1)
      ];
      const query = typeaheadRef.current;
      const match = ordered.find(
        (item) => item.label.toLocaleLowerCase().startsWith(query)
      );
      focusItem(match);
    },
    [enabledItems, focusItem]
  );
  const onKeyDown = useCallback(
    (event, item) => {
      const index = enabledItems.findIndex((entry) => entry.id === item.id);
      if (event.key === "ContextMenu" || event.key === "F10" && event.shiftKey) {
        const rect = event.currentTarget.getBoundingClientRect();
        onContextMenu?.(item.id, rect.left + 10, rect.bottom);
        event.preventDefault();
        return;
      }
      switch (event.key) {
        case "ArrowDown":
          focusItem(enabledItems[index + 1] ?? enabledItems[0]);
          break;
        case "ArrowUp":
          focusItem(enabledItems[index - 1] ?? enabledItems[enabledItems.length - 1]);
          break;
        case "Home":
          focusItem(enabledItems[0]);
          break;
        case "End":
          focusItem(enabledItems[enabledItems.length - 1]);
          break;
        case "Enter":
          if (selectionMode === "none" && item.actions?.length) {
            const rect = event.currentTarget.getBoundingClientRect();
            onContextMenu?.(item.id, rect.left, rect.bottom);
          } else if (selectedIDs.has(item.id) && onActivate) onActivate(item.id);
          else applySelect(item, event);
          break;
        case " ":
          applySelect(item, event);
          break;
        default:
          if (event.key.length === 1 && !event.metaKey && !event.ctrlKey && !event.altKey) {
            handleTypeahead(event.key, item.id);
            event.preventDefault();
          }
          return;
      }
      event.preventDefault();
    },
    [applySelect, enabledItems, focusItem, handleTypeahead, onActivate, onContextMenu, selectedIDs, selectionMode]
  );
  const renderRow = (row) => {
    const virtualStyle = virtualized ? { position: "absolute", top: row.top, left: 0, right: 0, height: row.height } : void 0;
    if (row.kind === "group") {
      return /* @__PURE__ */ jsx(
        "div",
        {
          className: "aui-listbox-group",
          role: "presentation",
          style: virtualStyle,
          children: row.label
        },
        `group-${row.label}-${row.top}`
      );
    }
    const { item } = row;
    const selected = selectedIDs.has(item.id);
    const classes2 = ["aui-listbox-option"];
    if (selected) classes2.push("aui-listbox-option--selected");
    if (item.dimmed) classes2.push("aui-listbox-option--dimmed");
    return /* @__PURE__ */ jsxs(
      "div",
      {
        ref: (element) => {
          if (element) rowRefs.current.set(item.id, element);
          else rowRefs.current.delete(item.id);
        },
        className: classes2.join(" "),
        role: selectionMode === "none" ? "listitem" : "option",
        "aria-selected": selectionMode === "none" ? void 0 : selected,
        "aria-disabled": item.disabled || void 0,
        tabIndex: selectionMode === "none" ? !item.disabled && item.actions?.length ? 0 : -1 : !item.disabled && (focusedID === item.id || focusedID === null && enabledItems[0]?.id === item.id) ? 0 : -1,
        style: virtualStyle,
        onFocus: () => {
          onFocusItem?.(item.id);
          if (selectionMode !== "none") setFocusedID(item.id);
        },
        onClick: (event) => {
          if (selectionMode !== "none") applySelect(item, event);
        },
        onDoubleClick: () => !item.disabled && onActivate?.(item.id),
        onContextMenu: (event) => {
          if (!onContextMenu || item.disabled) return;
          event.preventDefault();
          onContextMenu(item.id, event.clientX, event.clientY);
        },
        onKeyDown: (event) => onKeyDown(event, item),
        children: [
          /* @__PURE__ */ jsx("span", { className: "aui-listbox-icon", "aria-hidden": "true", children: item.icon }),
          /* @__PURE__ */ jsxs("span", { className: "aui-listbox-copy", children: [
            /* @__PURE__ */ jsx("span", { className: "aui-listbox-label", children: item.label }),
            item.description ? /* @__PURE__ */ jsx("span", { className: "aui-listbox-description", children: item.description }) : null
          ] }),
          item.badge ? /* @__PURE__ */ jsx("span", { className: "aui-listbox-badge", children: item.badge }) : null,
          item.accessory != null && /* @__PURE__ */ jsx("span", { className: "aui-listbox-accessory", children: item.accessory }),
          item.actions?.some((a) => a.pinned) ? /* @__PURE__ */ jsx("span", { className: "aui-listbox-actions", children: item.actions.filter((a) => a.pinned).map((action) => /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              "aria-label": action.label,
              title: action.label,
              tabIndex: selectionMode === "none" ? 0 : -1,
              disabled: item.disabled,
              onClick: (event) => {
                event.stopPropagation();
                onAction?.(item.id, action.id);
              },
              children: action.icon
            },
            action.id
          )) }) : null
        ]
      },
      item.id
    );
  };
  const classes = ["aui-listbox", className].filter(Boolean).join(" ");
  const handleScroll = (event) => {
    if (virtualized) setScrollTop(event.currentTarget.scrollTop);
  };
  if (loading || error || items.length === 0) {
    return /* @__PURE__ */ jsx(
      "div",
      {
        className: classes,
        role: selectionMode === "none" ? "list" : "listbox",
        "aria-label": ariaLabel,
        "aria-busy": loading || void 0,
        "aria-multiselectable": selectionMode === "multiple" || void 0,
        style,
        children: /* @__PURE__ */ jsx("div", { className: "aui-listbox-state", role: error ? "alert" : "status", children: error ?? (loading ? loadingState ?? "Loading\u2026" : emptyState ?? "No items") })
      }
    );
  }
  return /* @__PURE__ */ jsx(
    "div",
    {
      ref: scrollerRef,
      className: classes,
      role: selectionMode === "none" ? "list" : "listbox",
      "aria-label": ariaLabel,
      "aria-multiselectable": selectionMode === "multiple" || void 0,
      style: {
        ...style,
        ...virtualized ? { height, overflowY: "auto" } : null
      },
      onScroll: handleScroll,
      children: /* @__PURE__ */ jsx(
        "div",
        {
          className: virtualized ? "aui-listbox-window" : void 0,
          style: virtualized ? { height: totalHeight } : void 0,
          children: visibleRows.map(renderRow)
        }
      )
    }
  );
}
function ListBox(props) {
  const [query, setQuery] = useState(""), [category, setCategory] = useState("all");
  const effectiveQuery = props.onFilterChange ? props.filter ?? "" : query;
  const text = (effectiveQuery || props.filter || "").trim().toLocaleLowerCase();
  const items = props.items.filter((item) => (category === "all" || (item.category ?? item.group) === category) && (!text || `${item.label} ${item.description ?? ""} ${item.badge ?? ""}`.toLocaleLowerCase().includes(text)));
  const options = props.filterOptions ?? [...new Set(props.items.map((i) => i.category ?? i.group).filter(Boolean))].map((id) => ({ id, label: id }));
  const [menu, setMenu] = useState(null);
  const [actionTarget, setActionTarget] = useState(null);
  const active = props.items.find((i) => props.selectedIDs.has(i.id)) ?? props.items.find((i) => i.id === actionTarget);
  const actions = (id) => props.items.find((i) => i.id === id)?.actions ?? [];
  const rowControls = active?.actions?.map((a) => ({
    ...a,
    disabled: active.disabled || a.disabled,
    onClick: () => props.onAction?.(active.id, a.id)
  })) ?? [];
  return /* @__PURE__ */ jsxs(
    CollectionView,
    {
      title: props.title ?? props.ariaLabel,
      className: "aui-list-collection",
      controlsLabel: `${props.ariaLabel} controls`,
      controls: [...props.controls ?? [], ...rowControls],
      filter: props.showFilter === false ? void 0 : /* @__PURE__ */ jsx(
        CollectionFilter,
        {
          query: effectiveQuery,
          onQueryChange: props.onFilterChange ?? setQuery,
          options,
          value: category,
          onChange: setCategory,
          ariaLabel: `Search ${props.ariaLabel}`
        }
      ),
      children: [
        /* @__PURE__ */ jsx("div", { className: "aui-collection-list", children: /* @__PURE__ */ createElement(
          ListBoxRows,
          {
            ...props,
            key: `${category}/${text}`,
            items,
            onFocusItem: setActionTarget,
            onContextMenu: (id, x, y) => {
              if (props.onContextMenu) props.onContextMenu(id, x, y);
              else if (actions(id).length) setMenu({ id, x, y });
            },
            rowHeight: props.rowHeight ?? (props.items.some((i) => i.description) ? 40 : 24)
          }
        ) }),
        menu && /* @__PURE__ */ jsx(
          Menu,
          {
            className: "aui-collection-popup",
            open: true,
            anchor: menu,
            ariaLabel: `${props.ariaLabel} item options`,
            items: actions(menu.id),
            onSelect: (id) => {
              props.onAction?.(menu.id, id);
              setMenu(null);
            },
            onClose: () => setMenu(null)
          }
        )
      ]
    }
  );
}
export {
  ListBox,
  ListBoxRows
};
