/** Measurements during mount are initialization, not an animated user resize.
 * Allow the initial layout/ResizeObserver cycle to settle before enabling motion. */
export declare function useInitialLayoutReady(): boolean;
