import type { VersionControlEntry } from "./VersionControl.js";
/** Retain the branch's first-parent ancestry across its fork. Merged source
 * work remains on its own branch, just as it does in the full graph. */
export declare function versionBranchIDs(entries: readonly VersionControlEntry[], branch: string): Set<string>;
