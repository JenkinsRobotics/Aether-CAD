import { jsx, jsxs } from "react/jsx-runtime";
import { createContext, useContext, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
const SidebarContext = createContext(null);
function SidebarToggle({ children, className } = {}) {
  const context = useContext(SidebarContext);
  if (!context) return null;
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      className: ["aui-sidebar-toggle", className].filter(Boolean).join(" "),
      "aria-expanded": !context.collapsed,
      "aria-label": context.collapsed ? `Expand ${context.ariaLabel}` : `Collapse ${context.ariaLabel}`,
      title: context.collapsed ? "Expand sidebar" : "Collapse sidebar",
      onClick: context.toggle,
      children: children ?? /* @__PURE__ */ jsx(AetherIcon, { name: "sidebar" })
    }
  );
}
function CollapsibleSidebar({ id, ariaLabel, className, children, footer, toggle = "default", defaultCollapsed = false }) {
  const storageKey = `aether-sidebar-${id}`;
  const [collapsed, setCollapsed] = useState(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      return saved ? saved === "collapsed" : defaultCollapsed;
    } catch {
      return defaultCollapsed;
    }
  });
  const toggleCollapsed = () => {
    const next = !collapsed;
    setCollapsed(next);
    try {
      localStorage.setItem(storageKey, next ? "collapsed" : "expanded");
    } catch {
    }
  };
  return /* @__PURE__ */ jsx(SidebarContext.Provider, { value: { collapsed, toggle: toggleCollapsed, ariaLabel }, children: /* @__PURE__ */ jsxs(
    "aside",
    {
      className: `aui-sidebar${collapsed ? " aui-sidebar--collapsed" : ""}${className ? ` ${className}` : ""}`,
      "aria-label": ariaLabel,
      children: [
        toggle === "default" ? /* @__PURE__ */ jsx(SidebarToggle, {}) : null,
        /* @__PURE__ */ jsx("div", { className: "aui-sidebar-body", children }),
        footer ? /* @__PURE__ */ jsx("div", { className: "aui-sidebar-footer", children: footer }) : null
      ]
    }
  ) });
}
function SidebarLabel({ children }) {
  return /* @__PURE__ */ jsx("span", { className: "aui-sidebar-label", children });
}
export {
  CollapsibleSidebar,
  SidebarLabel,
  SidebarToggle
};
