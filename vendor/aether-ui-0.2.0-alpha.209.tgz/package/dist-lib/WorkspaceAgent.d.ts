import { type ReactNode } from 'react';
import { type AssistantMessage } from './AssistantPanel.js';
import type { AgentService, AgentInteraction, AgentAccessService, AgentEditorSharing } from './AgentServices.js';
export interface WorkspaceAgentProps {
    service: AgentService;
    app: string;
    contextText: string;
    detail?: string;
    messages: readonly AssistantMessage[];
    onMessages: (messages: AssistantMessage[]) => void;
    toolbar?: ReactNode;
    context?: ReactNode;
    composerActions?: ReactNode;
    notice?: string;
    onLocalSubmit?: (text: string) => void;
    interaction?: AgentInteraction;
    access?: AgentAccessService;
    sharing?: AgentEditorSharing;
}
/** Shared agent UI. The host transport and product context are supplied by its owner. */
export declare function WorkspaceAgent({ service, app, contextText, detail, messages, onMessages, toolbar, context, composerActions, notice, onLocalSubmit, interaction, access, sharing }: WorkspaceAgentProps): import("react").JSX.Element;
