import type { ReactElement, ReactNode } from "react";
import { type OverlayPlacement } from "./overlay-position.js";
export interface TooltipProps {
    children: ReactElement<{
        "aria-describedby"?: string;
    }>;
    content: ReactNode;
    shortcut?: ReactNode;
    disabledReason?: ReactNode;
    delayMilliseconds?: number;
    placement?: OverlayPlacement;
}
/** Accessible delayed pointer help. Keyboard focus reveals immediately and the
 * trigger receives aria-describedby while the tooltip is present. */
export declare function Tooltip({ children, content, shortcut, disabledReason, delayMilliseconds, placement, }: TooltipProps): import("react").JSX.Element;
