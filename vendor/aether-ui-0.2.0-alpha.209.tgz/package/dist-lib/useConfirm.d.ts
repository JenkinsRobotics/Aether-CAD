export interface ConfirmRequest {
    title: string;
    message: string;
    action: string;
}
/** Ask before a consequential action, or for a short text, in an Aether dialog,
 *  never the browser's native confirm/prompt. Render `dialog` once.
 *  `confirm` resolves true on the action; `prompt` resolves the trimmed text or null. */
export declare function useConfirm(): readonly [(value: ConfirmRequest) => Promise<boolean>, import("react").JSX.Element, (value: ConfirmRequest & {
    value: string;
}) => Promise<string | null>];
