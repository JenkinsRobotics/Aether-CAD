import { type RefObject } from 'react';
export type ControlPlacement = 'docked' | 'floating' | 'hidden';
export interface WorkspaceControls {
    panels: readonly {
        id: string;
        label: string;
        side: 'left' | 'right';
        placement: ControlPlacement;
    }[];
    show: (id: string) => void;
    place: (id: string, placement: ControlPlacement) => void;
    reset: () => void;
}
/** Registers presentation capabilities only; the shell remains the state owner. */
export declare function useRegisterWorkspaceControls(element: RefObject<HTMLElement | null>, controls: WorkspaceControls): void;
export declare function useWorkspaceControls(): WorkspaceControls | undefined;
