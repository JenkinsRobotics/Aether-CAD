import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Avatar } from "./Avatar.js";
import { Button } from "./Button.js";
import { Checkbox } from "./Checkbox.js";
import { IconButton } from "./IconButton.js";
import { MenuButton } from "./Menu.js";
import { SearchField } from "./SearchField.js";
import { SegmentedControl } from "./SegmentedControl.js";
import { SelectField } from "./SelectField.js";
import { VersionControlGraph } from "./VersionControlGraph.js";
import { VersionBranchRow } from "./VersionBranchRow.js";
import { versionBranchIDs } from "./version-branch-entries.js";
import "./VersionControl.css";
import "./VersionBranchTimeline.css";
const kinds = {
  workspace: { icon: "workspace", label: "Workspace" },
  branch: { icon: "version-control", label: "Branch" },
  version: { icon: "version", label: "Version" },
  merge: { icon: "version-merge", label: "Merge" },
  review: { icon: "triangle", label: "Release candidate" },
  release: { icon: "triangle-filled", label: "Release" },
  deprecated: { icon: "obsoletion", label: "Contains obsoletion" },
  start: { icon: "workspace", label: "Start" },
  change: { icon: "change", label: "Change" },
  automatic: { icon: "auto-version", label: "Automatic version" }
};
function VersionControl({ entries, activeBranch, selected, onSelect, onCreate, onCompare, onRestore, onMerge, footer, notice, createKinds, branchOptions, onOpenBranch, entryActions, onEntryAction }) {
  const [tab, setTab] = useState("all"), [query, setQuery] = useState("");
  const [sort, setSort] = useState("newest"), [filters, setFilters] = useState(false);
  const [branch, setBranch] = useState(activeBranch ?? "all"), [deprecated, setDeprecated] = useState(true);
  const [changes, setChanges] = useState(null);
  const previousCount = useRef(entries.length);
  useEffect(() => {
    setBranch(activeBranch ?? "all");
    setTab("all");
    setChanges(null);
  }, [activeBranch]);
  useEffect(() => {
    if (previousCount.current > 0 && entries.length > previousCount.current) {
      setTab("all");
      setQuery("");
      if (branch !== "all" && entries[0]?.kind === "branch") setBranch(entries[0].branch);
    }
    previousCount.current = entries.length;
  }, [entries.length]);
  const branches = [...new Set(entries.map((entry) => entry.branch))];
  const checkout = Boolean(onOpenBranch);
  const branchView = branch !== "all" && !checkout;
  const branchIDs = branchView ? versionBranchIDs(entries, branch) : null;
  const chooseBranch = (value) => {
    if (onOpenBranch) {
      onOpenBranch(value);
      return;
    }
    setBranch(value);
    setTab("all");
    setChanges(null);
    onSelect(null);
  };
  const visible = entries.filter((entry) => (tab === "all" || (tab === "branches" ? ["workspace", "branch"].includes(entry.kind) : ["release", "review"].includes(entry.kind))) && (!branchIDs || branchIDs.has(entry.id)) && (deprecated || entry.kind !== "deprecated") && `${entry.name} ${entry.description} ${entry.author} ${entry.branch} ${entry.changes.join(" ")}`.toLowerCase().includes(query.trim().toLowerCase())).sort((a, b) => sort === "oldest" ? a.saved - b.saved : b.saved - a.saved);
  const requestCreate = (kind) => {
    const source = entries.find((entry) => entry.id === selected) ?? (branchView ? entries.filter((entry) => entry.branch === branch).sort((a, b) => b.saved - a.saved)[0] : entries.find((entry) => entry.current));
    onCreate?.(kind, source?.id);
  };
  const options = [{ id: "version", label: "Create version", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "version" }) }, { id: "branch", label: "Create branch", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "version-control" }) }, { id: "release", label: "Create release", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "triangle-filled" }) }];
  return /* @__PURE__ */ jsxs("section", { className: "aui-version-control", "data-branch-view": branchView, "aria-label": "Version control", children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-vc-heading", children: [
      !branchView && /* @__PURE__ */ jsx(AetherIcon, { name: "version-control" }),
      /* @__PURE__ */ jsx("h2", { children: branchView ? "Versions" : "Version control" }),
      /* @__PURE__ */ jsx("span", { className: "aui-vc-heading-spacer" }),
      /* @__PURE__ */ jsx(IconButton, { label: "Version filters", size: "small", "aria-pressed": filters, onClick: () => setFilters((value) => !value), children: /* @__PURE__ */ jsx(AetherIcon, { name: "filter" }) }),
      /* @__PURE__ */ jsx(MenuButton, { className: "aui-vc-more", label: "Version control options", items: [{ id: "reset", label: "Clear filters", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "filter" }) }, { id: "oldest", label: sort === "oldest" ? "Newest first" : "Oldest first", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "arrow-down" }) }], onSelect: (id) => {
        if (id === "reset") {
          setTab("all");
          setQuery("");
          setDeprecated(true);
        } else setSort((value) => value === "oldest" ? "newest" : "oldest");
      }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
    ] }),
    /* @__PURE__ */ jsx(SearchField, { ariaLabel: "Search versions", placeholder: "Search versions\u2026", value: query, onQueryChange: setQuery }),
    /* @__PURE__ */ jsxs("div", { className: "aui-vc-actions", role: "toolbar", "aria-label": "Version actions", children: [
      /* @__PURE__ */ jsxs("div", { className: "aui-vc-create", children: [
        /* @__PURE__ */ jsxs(Button, { primary: true, "aria-label": "Create version", title: "Create version", disabled: !onCreate, onClick: () => requestCreate("version"), children: [
          /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }),
          /* @__PURE__ */ jsx("span", { children: "Create version" })
        ] }),
        /* @__PURE__ */ jsx(MenuButton, { label: "Create version options", disabled: !onCreate, items: options.filter((item) => !createKinds || createKinds.includes(item.id)), onSelect: (id) => requestCreate(id), children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" }) })
      ] }),
      /* @__PURE__ */ jsxs(Button, { className: "aui-vc-secondary", "aria-label": "Create branch", title: "Create branch", disabled: !onCreate, onClick: () => requestCreate("branch"), children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "version-control" }),
        /* @__PURE__ */ jsx("span", { children: "Branch" })
      ] }),
      /* @__PURE__ */ jsxs(Button, { className: "aui-vc-secondary", "aria-label": "Merge branches", title: onMerge ? "Merge branches" : "Merge requires a connected document", disabled: !onMerge, onClick: onMerge, children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "version-merge" }),
        /* @__PURE__ */ jsx("span", { children: "Merge" })
      ] }),
      /* @__PURE__ */ jsxs(MenuButton, { className: "aui-vc-branch-picker", label: "Choose version branch", items: onOpenBranch && branchOptions ? branchOptions.map((option) => ({ id: option.id, label: option.name, kind: "radio", checked: option.name === activeBranch, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "version-control" }) })) : [{ id: "all", label: "All branches \xB7 Full graph" }, ...branches.map((value) => ({ id: value, label: value, icon: /* @__PURE__ */ jsx(AetherIcon, { name: "version-control" }) }))], onSelect: chooseBranch, children: [
        /* @__PURE__ */ jsx("span", { children: checkout ? activeBranch ?? "Main" : branchView ? branch : "All branches" }),
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" })
      ] })
    ] }),
    filters && /* @__PURE__ */ jsxs("div", { className: "aui-vc-filters", children: [
      /* @__PURE__ */ jsx("div", { className: "aui-vc-view-controls", children: /* @__PURE__ */ jsx(SegmentedControl, { ariaLabel: "Version categories", value: tab, onChange: setTab, options: [{ id: "all", label: "All versions" }, { id: "branches", label: "Branches" }, { id: "releases", label: "Releases" }] }) }),
      /* @__PURE__ */ jsx(SelectField, { "aria-label": "Version sort", value: sort, onChange: (e) => setSort(e.target.value), options: [{ value: "newest", label: "Newest first" }, { value: "oldest", label: "Oldest first" }] }),
      /* @__PURE__ */ jsx(Checkbox, { label: "Show deprecated", checked: deprecated, onChange: (e) => setDeprecated(e.target.checked) })
    ] }),
    notice && /* @__PURE__ */ jsx("div", { className: "aui-vc-notice", role: "status", children: notice }),
    /* @__PURE__ */ jsxs("div", { className: "aui-vc-list", children: [
      /* @__PURE__ */ jsx(VersionControlGraph, { entries, visible, selected, linear: branchView, children: visible.map((entry) => {
        const active = entry.id === selected, kind = kinds[entry.kind];
        const entryMenu = /* @__PURE__ */ jsx(MenuButton, { className: "aui-vc-more", label: `Version actions: ${entry.name}`, items: [{ id: "changes", label: "Show changes", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "change" }) }, { id: "compare", label: "Compare", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "compare" }), disabled: !onCompare }, { id: "restore", label: "Restore", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "restore" }), disabled: !onRestore }, ...(entryActions?.(entry.id) ?? []).map((item, index) => index ? item : { ...item, separatorBefore: true })], onSelect: (id) => {
          onSelect(entry.id);
          if (id === "changes") setChanges(entry.id);
          else if (id === "compare") onCompare?.(entry.id);
          else if (id === "restore") onRestore?.(entry.id);
          else onEntryAction?.(entry.id, id);
        }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) });
        return /* @__PURE__ */ jsxs("article", { role: "listitem", className: "aui-vc-entry", "data-entry-id": entry.id, "data-kind": entry.kind, "data-selected": active, children: [
          branchView ? /* @__PURE__ */ jsx(VersionBranchRow, { entry, active, icon: kind.icon, label: entry.kind === "deprecated" ? "Obsolete" : kind.label, menu: entryMenu, onSelect: () => {
            onSelect(active ? null : entry.id);
            setChanges(null);
          } }) : /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "aui-vc-entry-head", onClick: (event) => {
            if (!event.target.closest("button, input, select, a")) {
              onSelect(active ? null : entry.id);
              setChanges(null);
            }
          }, children: [
            /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-vc-select", "aria-label": `Select ${entry.name}`, title: active ? "Click again to collapse and view the graph" : "Select version details", "aria-expanded": active, "aria-pressed": active, onClick: () => {
              onSelect(active ? null : entry.id);
              setChanges(null);
            }, children: [
              /* @__PURE__ */ jsx("span", { className: "aui-vc-kind", children: /* @__PURE__ */ jsx(AetherIcon, { name: kind.icon }) }),
              entry.snapshot && /* @__PURE__ */ jsx("span", { className: "aui-vc-row-snapshot", children: /* @__PURE__ */ jsx("img", { src: entry.snapshot, alt: `Snapshot of ${entry.name}` }) }),
              /* @__PURE__ */ jsxs("span", { className: "aui-vc-entry-name", children: [
                /* @__PURE__ */ jsx("strong", { title: entry.name, children: entry.name }),
                /* @__PURE__ */ jsx("small", { title: entry.description, children: entry.description })
              ] })
            ] }),
            !active && /* @__PURE__ */ jsxs("span", { className: "aui-vc-entry-person", title: `${entry.author} \xB7 ${new Date(entry.saved * 1e3).toLocaleString()}`, children: [
              /* @__PURE__ */ jsx(Avatar, { name: entry.author, size: "small" }),
              /* @__PURE__ */ jsx("time", { dateTime: new Date(entry.saved * 1e3).toISOString(), children: new Date(entry.saved * 1e3).toLocaleDateString([], { month: "short", day: "numeric" }) })
            ] }),
            /* @__PURE__ */ jsx("span", { className: "aui-vc-badge", children: entry.current ? "Current" : kind.label }),
            entryMenu
          ] }) }),
          active && (!branchView || changes === entry.id) && /* @__PURE__ */ jsxs("div", { className: "aui-vc-details", children: [
            /* @__PURE__ */ jsxs("div", { className: "aui-vc-author", children: [
              /* @__PURE__ */ jsx(Avatar, { name: entry.author, size: "small" }),
              /* @__PURE__ */ jsx("span", { children: entry.author }),
              /* @__PURE__ */ jsx("time", { dateTime: new Date(entry.saved * 1e3).toISOString(), children: new Date(entry.saved * 1e3).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) })
            ] }),
            changes !== entry.id && /* @__PURE__ */ jsxs("div", { className: "aui-vc-change-preview", children: [
              (entry.preview || entry.snapshot) && /* @__PURE__ */ jsx("div", { className: "aui-vc-thumbnail", children: entry.preview ?? /* @__PURE__ */ jsx("img", { src: entry.snapshot, alt: "" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("strong", { children: "Changes in this version" }),
                entry.changes.length ? /* @__PURE__ */ jsx("ul", { children: (changes === entry.id ? entry.changes : entry.changes.slice(0, 3)).map((change, index) => /* @__PURE__ */ jsx("li", { children: change }, index)) }) : /* @__PURE__ */ jsx("p", { children: "Initial document state." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "aui-vc-entry-actions", children: [
              /* @__PURE__ */ jsxs(Button, { primary: true, "aria-label": `${changes === entry.id ? "Hide" : "Show"} changes (${entry.changes.length})`, title: `${changes === entry.id ? "Hide" : "Show"} changes (${entry.changes.length})`, "aria-expanded": changes === entry.id, onClick: () => setChanges((value) => value === entry.id ? null : entry.id), children: [
                /* @__PURE__ */ jsx(AetherIcon, { name: "change" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  changes === entry.id ? "Hide" : "Changes",
                  " (",
                  entry.changes.length,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxs(Button, { "aria-label": `Compare ${entry.name}`, title: `Compare ${entry.name}`, disabled: !onCompare, onClick: () => onCompare?.(entry.id), children: [
                /* @__PURE__ */ jsx(AetherIcon, { name: "compare" }),
                /* @__PURE__ */ jsx("span", { children: "Compare" })
              ] }),
              /* @__PURE__ */ jsxs(Button, { "aria-label": `Restore ${entry.name}`, title: onRestore ? "Restore version" : "Restore requires a saved document snapshot", disabled: !onRestore, onClick: () => onRestore?.(entry.id), children: [
                /* @__PURE__ */ jsx(AetherIcon, { name: "restore" }),
                /* @__PURE__ */ jsx("span", { children: "Restore" })
              ] })
            ] }),
            changes === entry.id && /* @__PURE__ */ jsxs("div", { className: "aui-vc-change-list", "aria-label": `Changes for ${entry.name}`, children: [
              /* @__PURE__ */ jsxs("strong", { children: [
                entry.changes.length,
                " changes \xB7 ",
                entry.branch
              ] }),
              /* @__PURE__ */ jsx("ol", { children: entry.changes.map((change, index) => /* @__PURE__ */ jsxs("li", { children: [
                /* @__PURE__ */ jsx(AetherIcon, { name: "check" }),
                change
              ] }, index)) })
            ] })
          ] })
        ] }, entry.id);
      }) }),
      !visible.length && /* @__PURE__ */ jsx("p", { className: "aui-vc-empty", children: "No matching versions." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aui-vc-legend", role: "list", "aria-label": "Version types", children: ["workspace", "version", "change", "review", "release", "deprecated", "automatic", "branch", "merge"].map((id) => {
      const kind = kinds[id];
      return /* @__PURE__ */ jsxs("span", { role: "listitem", "data-kind": id, title: kind.label, children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: kind.icon }),
        /* @__PURE__ */ jsx("span", { children: kind.label })
      ] }, id);
    }) }),
    footer && /* @__PURE__ */ jsx("footer", { className: "aui-vc-footer", children: footer })
  ] });
}
export {
  VersionControl
};
