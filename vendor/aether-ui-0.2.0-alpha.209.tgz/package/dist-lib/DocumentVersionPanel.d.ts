import { type DocumentConnection } from "./DocumentServices.js";
import "./DocumentVersionPanel.css";
/** Shared Onshape-style milestone history. Autosaves are recovery snapshots,
 * never commits; naming a version is an explicit, flushed editor action. */
export declare function DocumentVersionPanel({ connection, createOnly, onCreated, onCancel, branchSource, branchOnly, }: {
    connection: DocumentConnection;
    createOnly?: boolean;
    onCreated?: () => void;
    onCancel?: () => void;
    branchSource?: number;
    branchOnly?: boolean;
}): import("react").JSX.Element;
