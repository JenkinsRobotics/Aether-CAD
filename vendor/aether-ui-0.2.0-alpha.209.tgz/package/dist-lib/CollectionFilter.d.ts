import { type ReactNode, type RefObject } from 'react';
export interface CollectionFilterOption {
    id: string;
    label: string;
    icon?: ReactNode;
}
export interface CollectionFilterProps {
    query: string;
    onQueryChange: (query: string) => void;
    options?: readonly CollectionFilterOption[];
    value?: string;
    onChange?: (id: string) => void;
    ariaLabel: string;
    inputRef?: RefObject<HTMLInputElement | null>;
    inputID?: string;
    /** Rows the filter is showing; omitted means no count is announced. */
    resultCount?: number;
}
export declare function CollectionFilter({ query, onQueryChange, options, value, onChange, ariaLabel, inputRef, inputID, resultCount }: CollectionFilterProps): import("react").JSX.Element;
