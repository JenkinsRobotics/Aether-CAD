import { type ReactNode } from "react";
import { type DocumentBarProps } from "./DocumentBar.js";
import "./StudioAppFrame.css";
export interface StudioDocumentBarProps extends DocumentBarProps {
    documentName?: string;
    /** Real branch/version and connection state supplied by the owning product. */
    documentState?: ReactNode;
    onSearch?: () => void;
}
/** Transparent document identity on the left; configurable utilities/account on the right. */
export declare function StudioDocumentBar({ documentName, documentState, onSearch, leading, trailing, className, ...props }: StudioDocumentBarProps): import("react").JSX.Element;
