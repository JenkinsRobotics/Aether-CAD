import { jsx } from "react/jsx-runtime";
import { flushSync } from "react-dom";
import { createRoot } from "react-dom/client";
import { openFeatureWindow } from "./FeatureWindow.js";
import { ToolIcon, toolIconNames } from "./ToolIcon.js";
function openCompactFeatureWindow(options) {
  const name = toolIconNames.includes(options.icon) ? options.icon : "properties";
  const header = document.createElement("span");
  const win = openFeatureWindow({
    ...options,
    variant: "compact",
    headerIcon: header,
    title: options.title.replace(/\s+\d+$/, ""),
    acceptLabel: options.acceptLabel ?? "Apply",
    discardLabel: options.discardLabel ?? "Cancel"
  });
  const root = createRoot(header);
  flushSync(() => root.render(/* @__PURE__ */ jsx(ToolIcon, { name })));
  const close = win.close;
  win.close = () => {
    root.unmount();
    close();
  };
  return win;
}
export {
  openCompactFeatureWindow
};
