import { type ReactNode } from "react";
import { type MenuItem } from "./Menu.js";
import "./VersionControl.css";
import "./VersionBranchTimeline.css";
export type VersionControlKind = "workspace" | "branch" | "version" | "merge" | "review" | "release" | "deprecated" | "start" | "change" | "automatic";
export interface VersionControlEntry {
    id: string;
    name: string;
    description: string;
    kind: VersionControlKind;
    branch: string;
    /** Stable graph lane and actual ancestry, supplied by the document host. */
    lane: number;
    parents: readonly string[];
    primaryParents: readonly string[];
    author: string;
    saved: number;
    current?: boolean;
    changes: readonly string[];
    preview?: ReactNode;
    /** Host-supplied version label; storage revision IDs are not version numbers. */
    versionLabel?: string;
    /** Image captured for this entry, independent of the current viewport. */
    snapshot?: string;
}
export interface VersionControlProps {
    entries: readonly VersionControlEntry[];
    /** Follow a checked-out branch; null opens the complete graph. */
    activeBranch?: string | null;
    selected: string | null;
    onSelect: (id: string | null) => void;
    createKinds?: readonly ("version" | "branch" | "release")[];
    onCreate?: (kind: "version" | "branch" | "release", sourceID?: string) => void;
    onCompare?: (id: string) => void;
    onRestore?: (id: string) => void;
    onMerge?: () => void;
    footer?: ReactNode;
    notice?: ReactNode;
    /** Commit-list hosts: every document branch, so the picker checks one out
     *  (like git) instead of filtering the graph. */
    branchOptions?: readonly {
        id: string;
        name: string;
    }[];
    onOpenBranch?: (id: string) => void;
    /** Further actions for one entry (rename, remove, release…), shown in its own menu. */
    entryActions?: (id: string) => MenuItem[];
    onEntryAction?: (entryID: string, actionID: string) => void;
}
/** A content-only version-control variant. Hosts own records and operations;
 * this view only searches, filters and presents them. The original
 * DocumentVersionPanel and graph remain independent reference designs. */
export declare function VersionControl({ entries, activeBranch, selected, onSelect, onCreate, onCompare, onRestore, onMerge, footer, notice, createKinds, branchOptions, onOpenBranch, entryActions, onEntryAction }: VersionControlProps): import("react").JSX.Element;
