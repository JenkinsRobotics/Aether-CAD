import type { LayoutPreset } from "./WorkspaceShell.js";
/** Shared chrome follows its hosting workspace unless explicitly customized. */
export declare const WorkspaceLayoutContext: import("react").Context<LayoutPreset | null>;
