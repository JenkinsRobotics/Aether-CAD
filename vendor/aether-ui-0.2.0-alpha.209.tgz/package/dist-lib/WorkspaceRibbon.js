import { jsx, jsxs } from "react/jsx-runtime";
import { StudioDesignContext } from "./StudioDesignContext.js";
import { STUDIO_TOOLBAR_DENSITIES, StudioToolBar } from "./StudioToolBar.js";
import { ToolHelp } from "./ToolHelp.js";
import { ToolTrayScroll } from "./ToolTrayScroll.js";
import { useContext, useState } from "react";
import { WorkspaceLayoutContext } from "./WorkspaceLayoutContext.js";
import { AetherIcon } from "./AetherIcon.js";
import { Menu } from "./Menu.js";
import { Ribbon, RibbonTool } from "./Ribbon.js";
import { Tabs } from "./Tabs.js";
import { ToolMenuButton, WorkspaceSwitcher } from "./WorkspaceSwitcher.js";
import "./WorkspaceRibbon.css";
import { setWorkspaceChrome, useWorkspaceChrome } from "./WorkspaceChromePreferences.js";
const WORKSPACE_RIBBON_DENSITIES = STUDIO_TOOLBAR_DENSITIES;
function WorkspaceRibbon({
  workspaces,
  workspaceID,
  onWorkspaceSelect,
  tabs,
  compactGroups,
  compactTools = false,
  activeTabID,
  onTabSelect,
  onCommand,
  onVariantSelect,
  workspaceLayout: appWorkspaceLayout = "column",
  appearance: appAppearance = "glass",
  moreItems = [],
  moreLabel = "More tools",
  density: controlledDensity,
  defaultDensity = "expanded",
  onDensityChange,
  docked,
  commandShortcuts,
  withClassicRibbon = false,
  toolRow
}) {
  const layout = useContext(WorkspaceLayoutContext);
  const studio = useContext(StudioDesignContext);
  const chrome = useWorkspaceChrome();
  const workspaceLayout = chrome.workspaceSelector === "app" ? appWorkspaceLayout : chrome.workspaceSelector;
  const appearance = chrome.ribbonAppearance === "app" ? appAppearance : chrome.ribbonAppearance;
  const isDocked = docked ?? layout === "docked";
  const [ownDensity, setOwnDensity] = useState(defaultDensity);
  const density = chrome.toolbarDensity === "app" ? controlledDensity ?? ownDensity : chrome.toolbarDensity;
  const setDensity = (next) => {
    if (chrome.toolbarDensity !== "app") setWorkspaceChrome({ toolbarDensity: next });
    setOwnDensity(next);
    onDensityChange?.(next);
  };
  const activeTab = tabs.find((tab) => tab.id === activeTabID && !tab.disabled);
  const compact = compactGroups ?? (compactTools ? activeTab?.groups : void 0);
  const iconStrip = density === "compact" && compact !== void 0;
  const visibleGroups = iconStrip ? compact : activeTab?.groups;
  const groupMenu = (group) => (group.menuItems ?? group.tools.flatMap(
    (tool) => (tool.variants?.length ? tool.variants : [tool]).map((entry) => ({
      id: entry.id,
      label: entry.label,
      icon: entry.icon,
      disabled: entry.disabled,
      disabledReason: entry.disabledReason
    }))
  )).map((item, index) => index === 0 ? { ...item, heading: item.heading ?? group.label } : item);
  const moreMenu = [
    ...WORKSPACE_RIBBON_DENSITIES.map((entry, index) => ({ id: `density:${entry.id}`, label: entry.label, kind: "radio", checked: density === entry.id, heading: index === 0 ? "Density" : void 0 })),
    ...moreItems.map((item, index) => index === 0 ? { ...item, separatorBefore: true, heading: item.heading ?? "Toolbar" } : item)
  ];
  const onMore = (id) => {
    if (id.startsWith("density:")) setDensity(id.slice(8));
    else onCommand(id);
  };
  const [settingsMenu, setSettingsMenu] = useState(null);
  const studioBar = studio ? /* @__PURE__ */ jsx(
    StudioToolBar,
    {
      workspaces,
      workspaceID,
      onWorkspaceSelect,
      tabs,
      compactGroups,
      activeTabID,
      onTabSelect,
      commandShortcuts,
      onCommand,
      onVariantSelect,
      moreItems,
      moreLabel,
      density,
      onDensityChange: setDensity,
      toolRow
    }
  ) : null;
  if (studioBar && !withClassicRibbon) return studioBar;
  const classic = /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon", "data-toolbar-menu-boundary": "", onContextMenu: (event) => {
    event.preventDefault();
    setSettingsMenu({ x: event.clientX, y: event.clientY });
  }, "data-docked": isDocked || void 0, "data-workspace-layout": workspaceLayout, "data-appearance": appearance, "data-density": density, "data-icon-strip": iconStrip || void 0, "data-compact-tools": compactTools || void 0, children: [
    /* @__PURE__ */ jsx(
      Menu,
      {
        open: !!settingsMenu,
        anchor: settingsMenu,
        ariaLabel: "Toolbar settings",
        applicationCommands: false,
        items: moreMenu,
        onClose: () => setSettingsMenu(null),
        onSelect: (id) => {
          setSettingsMenu(null);
          onMore(id);
        }
      }
    ),
    !iconStrip && workspaceLayout === "column" && workspaces.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-workspaces", children: /* @__PURE__ */ jsx(WorkspaceSwitcher, { workspaces, workspaceID, onSelect: onWorkspaceSelect, menuClassName: "aui-tool-menu" }) }),
    (!iconStrip || compactTools) && /* @__PURE__ */ jsxs("nav", { className: "aui-workspace-ribbon-tabs", "aria-label": "Workspace tools", children: [
      workspaceLayout === "strip" && workspaces.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-workspaces", children: /* @__PURE__ */ jsx(
        Tabs,
        {
          tabs: workspaces.map((item) => ({ ...item, title: item.disabledReason })),
          activeID: workspaceID,
          onSelect: onWorkspaceSelect
        }
      ) }),
      /* @__PURE__ */ jsx(Tabs, { tabs, activeID: activeTabID, onSelect: onTabSelect })
    ] }),
    /* @__PURE__ */ jsx(ToolTrayScroll, { label: iconStrip ? "Compact tools" : activeTab?.label ?? "Tools", role: iconStrip ? "group" : "tabpanel", children: /* @__PURE__ */ jsxs(Ribbon, { children: [
      density === "compact" && !iconStrip && activeTab?.groups.map((group) => /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-group", "data-compact": "", children: /* @__PURE__ */ jsx(ToolMenuButton, { className: "aui-workspace-ribbon-group-button", menuClassName: "aui-tool-menu", label: `${group.label} tools`, items: groupMenu(group), onSelect: onCommand, placement: "bottom-start", children: /* @__PURE__ */ jsx("span", { className: "aui-ribbon-tool-icon", "aria-hidden": "true", children: group.tools[0]?.icon }) }) }, group.id)),
      (density !== "compact" || iconStrip) && visibleGroups?.map((group) => /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon-group", children: [
        /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-buttons", children: group.tools.map((tool) => /* @__PURE__ */ jsxs("span", { className: "aui-workspace-ribbon-tool", "data-tool-id": tool.id, children: [
          /* @__PURE__ */ jsx(ToolHelp, { label: tool.label, help: tool.help, disabledReason: tool.disabled ? tool.disabledReason : void 0, children: /* @__PURE__ */ jsx(
            RibbonTool,
            {
              label: tool.label,
              icon: tool.icon,
              active: tool.active,
              "aria-pressed": tool.active,
              disabled: tool.disabled,
              title: tool.help ? void 0 : tool.disabledReason ?? tool.label,
              onClick: () => onCommand(tool.id)
            }
          ) }),
          tool.variants?.length ? (
            // The caret is named for the family, not for whichever
            // variant is showing, so its name does not move under you.
            /* @__PURE__ */ jsx(
              ToolMenuButton,
              {
                className: "aui-workspace-ribbon-variants",
                menuClassName: "aui-tool-menu",
                anchorTo: "group",
                label: `${tool.variants.find((variant) => variant.id === tool.id)?.label ?? tool.label} variants`,
                onSelect: (variantID) => onVariantSelect ? onVariantSelect(tool.id, variantID) : onCommand(variantID),
                items: tool.variants.map((variant) => ({
                  id: variant.id,
                  label: variant.label,
                  icon: variant.icon,
                  help: variant.help,
                  kind: "radio",
                  checked: variant.id === (tool.selectedVariantID ?? tool.id),
                  disabled: variant.disabled,
                  disabledReason: variant.disabledReason
                })),
                children: /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: "rotate(90deg)" }, width: 9, height: 9 })
              }
            )
          ) : null
        ] }, tool.id)) }),
        /* @__PURE__ */ jsxs(
          ToolMenuButton,
          {
            className: "aui-workspace-ribbon-caption",
            menuClassName: "aui-tool-menu",
            label: `${group.label} tools`,
            items: groupMenu(group),
            onSelect: onCommand,
            anchorTo: "group",
            children: [
              !iconStrip && group.label,
              /* @__PURE__ */ jsx(AetherIcon, { name: "chevron", style: { transform: "rotate(90deg)" }, width: 10, height: 10 })
            ]
          }
        )
      ] }, group.id)),
      /* @__PURE__ */ jsx("div", { className: "aui-workspace-ribbon-more", children: /* @__PURE__ */ jsx(ToolMenuButton, { className: "aui-workspace-ribbon-more-button", menuClassName: "aui-tool-menu", label: moreLabel, items: moreMenu, onSelect: onMore, anchorTo: "group", children: /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2022\u2022\u2022" }) }) })
    ] }) })
  ] });
  return studioBar ? /* @__PURE__ */ jsxs("div", { className: "aui-workspace-ribbon-pair", children: [
    classic,
    studioBar
  ] }) : classic;
}
export {
  WORKSPACE_RIBBON_DENSITIES,
  WorkspaceRibbon
};
