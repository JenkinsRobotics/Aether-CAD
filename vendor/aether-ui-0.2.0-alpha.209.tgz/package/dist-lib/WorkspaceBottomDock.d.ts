import { type ReactNode } from "react";
import { type SidebarTab } from "./TabbedSidebar.js";
import "./WorkspaceBottomDock.css";
export interface WorkspaceBottomDockProps {
    tabs: readonly SidebarTab[];
    activeTab: string | null;
    /** Independent open panels; when provided, an empty list collapses the dock. */
    activeTabs?: readonly string[];
    onTabToggle?: (id: string) => void;
    onTabChange: (id: string | null) => void;
    children: ReactNode;
    ariaLabel?: string;
    /** Fraction of the workspace width, excluding outer margins; defaults to 60%. */
    widthFraction?: number;
    storageKey?: string;
    defaultHeight?: number;
    /** Preferred content height, excluding the icon tray. */
    height?: number;
    minHeight?: number;
    onHeightChange?: (height: number) => void;
}
/** A bottom-centered card whose floating anchor is independent of sidebars.
 * Docked mode reserves canvas space. The last panel stays mounted while collapsed. */
export declare function WorkspaceBottomDock({ tabs, activeTab: selectedTab, activeTabs, onTabToggle, onTabChange, children, ariaLabel, widthFraction, height, minHeight, onHeightChange, storageKey, defaultHeight }: WorkspaceBottomDockProps): import("react").JSX.Element;
