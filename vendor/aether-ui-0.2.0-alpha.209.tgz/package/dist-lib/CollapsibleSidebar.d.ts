import { type ReactNode } from "react";
/** Optional content makes a brand or another shared control the collapse target. */
export declare function SidebarToggle({ children, className }?: {
    children?: ReactNode;
    className?: string;
}): import("react").JSX.Element | null;
export declare function CollapsibleSidebar({ id, ariaLabel, className, children, footer, toggle, defaultCollapsed }: {
    /** Initial state until the person toggles it (their choice is remembered). */
    defaultCollapsed?: boolean;
    /** Stable per-sidebar key; the collapse preference persists per device. */
    id: string;
    ariaLabel: string;
    className?: string;
    children: ReactNode;
    footer?: ReactNode;
    /** "custom": the app renders <SidebarToggle /> inside its own layout. */
    toggle?: "default" | "custom";
}): import("react").JSX.Element;
/** Text that hides when the owning sidebar collapses to its icon rail. */
export declare function SidebarLabel({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
