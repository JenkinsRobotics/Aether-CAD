import type { WorkspacePanelState } from "./WorkspaceShell.js";
/** One active panel per rail; preserve hidden editors and their coordinates. */
export declare function singlePanelPerSide(state: WorkspacePanelState, sides: readonly (readonly string[])[], previous?: WorkspacePanelState, preferredID?: string, previousSelection?: Readonly<Record<string, Readonly<import("./WorkspaceShell.js").WorkspacePanelPresentation>>> | undefined): WorkspacePanelState;
