/** Retained metadata for callers; the accessory row never renders help content. */
export interface FeatureWindowHelp {
    summary: string;
    steps?: readonly string[];
}
/** Shared icon-control row. Toggling an accessory never changes the editor's
 * structure, opens content, moves focus, or submits/discards the feature. */
export declare function createFeatureWindowAccessories(options: {
    title: string;
    help?: FeatureWindowHelp;
    helpActive?: boolean;
    onHelpToggle?: (active: boolean) => void;
}): {
    element: HTMLDivElement;
    /** Synchronize app-owned state without firing the user-toggle callback. */
    setHelpActive: (active: boolean) => void;
    actionIcon(iconSvg: string, title: string, onToggle: (active: boolean) => void, active?: boolean): HTMLButtonElement;
};
