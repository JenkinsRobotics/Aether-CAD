import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { AppMark } from "./AppMark.js";
import { AppWordmark, resolveAppWordmark } from "./AppWordmark.js";
import { AppLauncher } from "./AppLauncher.js";
import { CollapsibleSidebar, SidebarLabel, SidebarToggle } from "./CollapsibleSidebar.js";
import { AppearanceToggle } from "./StudioChrome.js";
import { ThemeMenu } from "./ThemeMenu.js";
import "./ApplicationSidebar.css";
function SidebarRow({ item }) {
  const icon = typeof item.icon === "string" ? /* @__PURE__ */ jsx(AetherIcon, { name: item.icon }) : item.icon;
  const body = /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("span", { className: "aui-application-sidebar-icon", "aria-hidden": "true", children: icon }),
    /* @__PURE__ */ jsx(SidebarLabel, { children: item.label }),
    item.badge !== void 0 && /* @__PURE__ */ jsx("span", { className: "aui-application-sidebar-badge", children: item.badge })
  ] });
  const shared = { onContextMenu: item.onContextMenu, className: "aui-application-sidebar-row", title: item.label, "aria-label": item.label, "aria-current": item.current ? "page" : void 0 };
  return item.href && !item.disabled ? /* @__PURE__ */ jsx("a", { ...shared, href: item.href, onClick: item.onSelect, children: body }) : /* @__PURE__ */ jsx("button", { ...shared, type: "button", disabled: item.disabled, onClick: item.onSelect, children: body });
}
function SidebarNavigation({ sections, ariaLabel, captions = false }) {
  return /* @__PURE__ */ jsx("div", { className: "aui-application-sidebar-navigation", children: sections.map((section) => /* @__PURE__ */ jsxs("nav", { className: "aui-application-sidebar-section", "aria-label": section.title ?? ariaLabel, children: [
    section.title && captions ? /* @__PURE__ */ jsx("div", { className: "aui-application-sidebar-caption", children: section.title }) : null,
    section.title && !captions ? /* @__PURE__ */ jsx(SidebarGroup, { title: section.title, children: section.items.map((item) => /* @__PURE__ */ jsx(SidebarRow, { item }, item.id)) }) : section.items.map((item) => /* @__PURE__ */ jsx(SidebarRow, { item }, item.id))
  ] }, section.id)) });
}
function ApplicationSidebar({ id, name, app, icon, homeUrl, brand = true, action, sections, settings, apps, currentApp, children, footerTools, footer, className, userLabel = "My workspace", toggleInContent = false, selection = "solid", defaultCollapsed, variant = "standard" }) {
  const settingsItem = settings ? {
    id: "settings",
    label: "Settings",
    icon: "settings",
    onSelect: () => document.dispatchEvent(new CustomEvent("aether-open-settings", { cancelable: true })),
    ...settings === true ? {} : settings
  } : null;
  const identity = app ?? resolveAppWordmark(name);
  const brandContent = identity ? /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("span", { className: "aui-application-sidebar-mark", "aria-hidden": "true", children: /* @__PURE__ */ jsx(AppMark, { app: identity, size: variant === "standard" ? 32 : 40 }) }),
    /* @__PURE__ */ jsx(SidebarLabel, { children: /* @__PURE__ */ jsx(AppWordmark, { app: identity, size: variant === "standard" ? 32 : 40, appearance: variant === "studio" ? "dark" : "auto", decorative: true }) })
  ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
    icon,
    /* @__PURE__ */ jsx(SidebarLabel, { children: /* @__PURE__ */ jsx("strong", { children: name }) })
  ] });
  const brandToggle = variant !== "standard" && !toggleInContent;
  return /* @__PURE__ */ jsxs(
    CollapsibleSidebar,
    {
      id,
      ariaLabel: `${name} sidebar`,
      className: `aui-application-sidebar${variant !== "standard" ? ` aui-application-sidebar--${variant}` : ""}${selection === "tint" ? " aui-application-sidebar--tint" : ""}${className ? ` ${className}` : ""}`,
      toggle: "custom",
      defaultCollapsed,
      footer: footer ?? /* @__PURE__ */ jsxs(Fragment, { children: [
        footerTools && /* @__PURE__ */ jsx("div", { className: "aui-application-sidebar-tools", children: footerTools }),
        (settingsItem || apps) && /* @__PURE__ */ jsxs("div", { className: "aui-application-sidebar-settings", children: [
          settingsItem && /* @__PURE__ */ jsx(SidebarRow, { item: settingsItem }),
          apps && /* @__PURE__ */ jsx(AppLauncher, { apps, currentID: currentApp, label: "Apps", className: "aui-application-sidebar-row", placement: "top-start" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "aui-application-sidebar-profile", "data-aether-account": "", "data-aether-account-layout": "sidebar", children: /* @__PURE__ */ jsxs("div", { className: "aui-application-sidebar-fallback", children: [
          /* @__PURE__ */ jsx(SidebarLabel, { children: "Local preview" }),
          /* @__PURE__ */ jsx(ThemeMenu, {}),
          /* @__PURE__ */ jsx(AppearanceToggle, {})
        ] }) })
      ] }),
      children: [
        /* @__PURE__ */ jsxs("div", { className: `aui-application-sidebar-brand${identity ? " aui-application-sidebar-brand--wordmark" : ""}${brand ? "" : " aui-application-sidebar-brand--toggle-only"}`, children: [
          brand && (brandToggle ? /* @__PURE__ */ jsx(SidebarToggle, { className: "aui-application-sidebar-brand-toggle", children: brandContent }) : /* @__PURE__ */ jsx("a", { href: homeUrl, "aria-label": `${name} home`, title: name, children: brandContent })),
          brandToggle && !brand && /* @__PURE__ */ jsx(SidebarToggle, {})
        ] }),
        action && /* @__PURE__ */ jsx("div", { className: "aui-application-sidebar-action", children: action }),
        variant === "standard" && !toggleInContent && /* @__PURE__ */ jsxs("div", { className: "aui-application-sidebar-user", children: [
          /* @__PURE__ */ jsx(SidebarLabel, { children: userLabel }),
          /* @__PURE__ */ jsx(SidebarToggle, {})
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "aui-application-sidebar-content", children: [
          sections && /* @__PURE__ */ jsx(SidebarNavigation, { sections, ariaLabel: name, captions: variant === "captioned" }),
          children
        ] })
      ]
    }
  );
}
function SidebarGroup({ title, children, storageKey }) {
  const [expanded, setExpanded] = useState(() => {
    try {
      return !storageKey || localStorage.getItem(storageKey) !== "false";
    } catch {
      return true;
    }
  });
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-application-sidebar-disclosure", "aria-label": `${expanded ? "Hide" : "Show"} ${title}`, "aria-expanded": expanded, onClick: () => {
      setExpanded(!expanded);
      try {
        if (storageKey) localStorage.setItem(storageKey, String(!expanded));
      } catch {
      }
    }, children: [
      /* @__PURE__ */ jsx(SidebarLabel, { children: title }),
      /* @__PURE__ */ jsx(AetherIcon, { name: expanded ? "chevron-down" : "chevron-up" })
    ] }),
    expanded && children
  ] });
}
function WorkspaceIcon({ name }) {
  return /* @__PURE__ */ jsx("span", { className: "aui-workspace-monogram", children: name.split(/\s+/).filter(Boolean).slice(0, 2).map((word) => word[0]).join("").toUpperCase() });
}
export {
  ApplicationSidebar,
  SidebarGroup,
  SidebarNavigation,
  SidebarRow,
  WorkspaceIcon
};
