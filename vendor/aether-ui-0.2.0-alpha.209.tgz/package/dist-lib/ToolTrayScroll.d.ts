import { type ReactNode } from 'react';
/** One bounded viewport for every ribbon density, with explicit overflow controls. */
export declare function ToolTrayScroll({ children, label, role }: {
    children: ReactNode;
    label: string;
    role: 'group' | 'tabpanel';
}): import("react").JSX.Element;
