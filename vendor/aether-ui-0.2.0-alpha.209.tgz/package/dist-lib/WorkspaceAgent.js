import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { AssistantPanel } from "./AssistantPanel.js";
import { Button } from "./Button.js";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { Dialog } from "./Dialog.js";
import { Menu } from "./Menu.js";
import { AgentConnectionsDialog } from "./AgentConnectionsDialog.js";
import { AgentVoiceInput } from "./AgentVoiceInput.js";
import { AgentTurn } from "./AgentTurn.js";
function WorkspaceAgent({ service, app, contextText, detail, messages, onMessages, toolbar, context, composerActions, notice, onLocalSubmit, interaction, access, sharing }) {
  const [connectionsOpen, setConnectionsOpen] = useState(false), [toolsOpen, setToolsOpen] = useState(false);
  const [style, setStyle] = useState("Normal"), [styleAnchor, setStyleAnchor] = useState(null);
  const [disabledTools, setDisabledTools] = useState([]), [conversation, setConversation] = useState(0);
  const [attachments, setAttachments] = useState([]), [reading, setReading] = useState(false);
  const files = useRef(null), fileGeneration = useRef(0);
  const [plugins, setPlugins] = useState([]), [provider, setProvider] = useState("");
  const [models, setModels] = useState([]), [model, setModel] = useState("");
  const [loadingModels, setLoadingModels] = useState(false), [loadingCatalog, setLoadingCatalog] = useState(true);
  const catalogGeneration = useRef(0);
  const [error, setError] = useState(""), [job, setJob] = useState(null), [starting, setStarting] = useState(false);
  const callbacks = useRef({ onMessages, messages, interaction });
  callbacks.current = { onMessages, messages, interaction };
  const [activity, setActivity] = useState([]);
  const active = useRef(null);
  const alive = useRef(true);
  const generation = useRef(0);
  const ready = plugins.filter((p) => p.enabled && p.runtimeReady && p.account.connected);
  async function refresh() {
    const hostGeneration = catalogGeneration.current;
    try {
      const result = await service.call("catalog");
      if (alive.current && catalogGeneration.current === hostGeneration) {
        setPlugins(result.plugins);
        setProvider((current) => result.plugins.some((p) => p.id === current && p.enabled && p.runtimeReady && p.account.connected) ? current : result.plugins.find((p) => p.enabled && p.runtimeReady && p.account.connected)?.id || "");
      }
    } catch (e) {
      if (alive.current && catalogGeneration.current === hostGeneration) {
        setPlugins([]);
        setProvider("");
        setError(e.message);
      }
    } finally {
      if (alive.current && catalogGeneration.current === hostGeneration) setLoadingCatalog(false);
    }
  }
  useEffect(() => {
    alive.current = true;
    catalogGeneration.current++;
    setLoadingCatalog(true);
    setPlugins([]);
    setProvider("");
    void refresh();
    const focus = () => void refresh();
    window.addEventListener("focus", focus);
    const leaving = () => {
      const previous = active.current;
      generation.current++;
      previous?.turn.stop();
      active.current = null;
      setJob(null);
      setStarting(false);
      if (previous) void previous.service.call("cancel", { id: previous.id }).catch(() => {
      });
    };
    window.addEventListener("pagehide", leaving);
    return () => {
      alive.current = false;
      catalogGeneration.current++;
      generation.current++;
      active.current?.turn.stop();
      window.removeEventListener("focus", focus);
      window.removeEventListener("pagehide", leaving);
      if (active.current) void service.call("cancel", { id: active.current.id }).catch(() => {
      });
    };
  }, [service]);
  useEffect(() => {
    setModels([]);
    setModel("");
    setLoadingModels(Boolean(provider));
    if (!provider) return;
    let disposed = false, id = "", timer;
    const poll = async () => {
      try {
        const result = await service.call("job", { id });
        if (disposed) return;
        if (result.state === "running") timer = setTimeout(() => void poll(), 700);
        else {
          setLoadingModels(false);
          if (result.state === "completed") setModels(result.models);
          else if (result.error) setError(result.error);
        }
      } catch (e) {
        if (!disposed) {
          setLoadingModels(false);
          setError(e.message);
        }
      }
    };
    void service.call("models", { provider }).then((result) => {
      id = result.id;
      if (disposed) void service.call("cancel", { id }).catch(() => {
      });
      else void poll();
    }).catch((e) => {
      if (!disposed) {
        setLoadingModels(false);
        setError(e.message);
      }
    });
    return () => {
      disposed = true;
      clearTimeout(timer);
      if (id) void service.call("cancel", { id }).catch(() => {
      });
    };
  }, [provider, service]);
  const scope = useRef({ app, key: interaction?.contextKey, service });
  useLayoutEffect(() => {
    const changed = scope.current.app !== app || scope.current.key !== interaction?.contextKey || scope.current.service !== service;
    scope.current = { app, key: interaction?.contextKey, service };
    generation.current++;
    fileGeneration.current++;
    setStarting(false);
    setReading(false);
    setAttachments([]);
    setActivity([]);
    setError("");
    if (changed) {
      setConversation((value) => value + 1);
      callbacks.current.onMessages([]);
    }
    const previous = active.current;
    if (previous) {
      previous.turn.stop();
      active.current = null;
      setJob(null);
      void previous.service.call("cancel", { id: previous.id }).catch(() => {
      });
    }
  }, [app, interaction?.contextKey, service]);
  async function submit(text) {
    if (starting || active.current) return false;
    if (!provider) {
      if (onLocalSubmit) {
        onLocalSubmit(text);
        return true;
      }
      setConnectionsOpen(true);
      return false;
    }
    const requestGeneration = ++generation.current;
    const content = text + attachments.map((file) => `

Attached text file: ${file.name}
${file.text}`).join("");
    const base = [...callbacks.current.messages, { id: crypto.randomUUID(), role: "user", text: content }];
    setStarting(true);
    setError("");
    setActivity([]);
    const requestedInteraction = interaction ? { ...interaction, tools: interaction.tools.filter((tool) => !disabledTools.includes(tool.name)) } : void 0;
    try {
      const result = await service.call("chat", { app, provider, model, context: contextText + (style === "Normal" ? "" : `
Response style: ${style.toLowerCase()}. Keep tool evidence accurate.`), messages: base.map((m) => ({ role: m.role, content: m.text })), ...requestedInteraction ? { tools: requestedInteraction.tools } : {} });
      if (!alive.current || generation.current !== requestGeneration) {
        void service.call("cancel", { id: result.id }).catch(() => {
        });
        return false;
      }
      const current = {
        id: result.id,
        assistant: crypto.randomUUID(),
        base,
        contextKey: requestedInteraction?.contextKey,
        service,
        turn: new AgentTurn({
          id: result.id,
          service,
          interaction: requestedInteraction,
          isCurrent: () => alive.current && active.current === current && callbacks.current.interaction?.contextKey === current.contextKey,
          onJob: (value) => {
            if (!alive.current || active.current !== current) return;
            setJob(value);
            if (value.text) callbacks.current.onMessages([...base, { id: current.assistant, role: "assistant", text: value.text }]);
          },
          onActions: (value) => {
            if (alive.current && active.current === current) setActivity(value);
          },
          onEnd: (error2) => {
            if (!alive.current || active.current !== current) return;
            active.current = null;
            setJob(null);
            if (error2) {
              setError(error2);
              void service.call("cancel", { id: current.id }).catch(() => {
              });
            }
          }
        })
      };
      callbacks.current.onMessages(base);
      setAttachments([]);
      active.current = current;
      setJob(result);
      current.turn.start();
      return true;
    } catch (e) {
      if (alive.current && generation.current === requestGeneration) setError(e.message);
      return false;
    } finally {
      if (alive.current && generation.current === requestGeneration) setStarting(false);
    }
  }
  function stop() {
    const stoppedGeneration = ++generation.current, stopped = active.current;
    stopped?.turn.stop();
    active.current = null;
    setJob(null);
    setStarting(false);
    if (stopped) void stopped.service.call("cancel", { id: stopped.id }).catch((e) => {
      if (alive.current && generation.current === stoppedGeneration) setError(e.message);
    });
  }
  function newChat() {
    stop();
    fileGeneration.current++;
    setReading(false);
    setAttachments([]);
    setActivity([]);
    setError("");
    setConversation((value) => value + 1);
    callbacks.current.onMessages([]);
  }
  async function attach(selected) {
    if (!selected?.length) return;
    const request = ++fileGeneration.current;
    setReading(true);
    setError("");
    try {
      const incoming = Array.from(selected);
      if (incoming.length + attachments.length > 3) throw Error("Attach up to 3 text files.");
      if (incoming.some((file) => file.size > 16e3 || !/\.(txt|md|csv|json|yaml|yml)$/i.test(file.name))) throw Error("Use text, Markdown, CSV, JSON or YAML files up to 16 KB each.");
      const read = await Promise.all(incoming.map(async (file) => ({ name: file.name, text: await file.text() })));
      if (read.some((file) => file.text.includes("\0"))) throw Error("Attachments must contain readable text.");
      if (alive.current && request === fileGeneration.current) setAttachments((value) => [...value, ...read]);
    } catch (e) {
      if (alive.current && request === fileGeneration.current) setError(e.message);
    } finally {
      if (alive.current && request === fileGeneration.current) setReading(false);
    }
  }
  const running = starting || job?.state === "running";
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      AssistantPanel,
      {
        title: "Aether Agent",
        heading: "AI chat",
        layout: "agent",
        appearance: "studio",
        welcome: /* @__PURE__ */ jsxs("div", { className: "aui-agent-welcome", children: [
          /* @__PURE__ */ jsx(AetherIcon, { name: "comment" }),
          /* @__PURE__ */ jsx("h3", { children: app === "cad" ? "Explore your model" : "Explore your workspace" }),
          /* @__PURE__ */ jsx("p", { children: "Keep your ideas beside the workspace." }),
          /* @__PURE__ */ jsx("small", { children: provider ? "Ask the agent to inspect, build or revise your work using the enabled tools." : "Connect an AI provider to inspect, build or revise your work." })
        ] }),
        suggestions: app === "cad" ? ["Summarize this scene", "Inspect the selected part", "How do I edit this model?"] : ["Summarize this workspace", "Inspect my selection", "Help me plan the next step"],
        headerActions: /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(IconButton, { size: "small", label: "Agent connections", onClick: () => setConnectionsOpen(true), children: /* @__PURE__ */ jsx(AetherIcon, { name: "settings" }) }),
          /* @__PURE__ */ jsx(IconButton, { size: "small", label: "New chat", onClick: newChat, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) })
        ] }),
        onRate: (id, rating) => onMessages(messages.map((message) => message.id === id ? { ...message, rating } : message)),
        messages,
        busy: running,
        disabled: loadingCatalog || loadingModels || reading,
        onStop: stop,
        status: /* @__PURE__ */ jsxs("div", { className: "aui-agent-connection-status", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            provider ? `${ready.find((p) => p.id === provider)?.name || "Agent"} \xB7 ${running ? "Working\u2026" : "Connected"}` : "No AI provider connected",
            sharing && ["shared", "working"].includes(sharing.state) ? " \xB7 Editor shared" : ""
          ] }),
          /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setConnectionsOpen(true), children: provider ? "Connections" : "Connect agent" })
        ] }),
        notice: error || (loadingModels ? "Loading available models\u2026" : reading ? "Reading attachments\u2026" : notice),
        toolbar,
        context: /* @__PURE__ */ jsxs(Fragment, { children: [
          context || detail && /* @__PURE__ */ jsxs("span", { className: "aui-agent-context", children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "cube" }),
            detail
          ] }),
          attachments.length > 0 && /* @__PURE__ */ jsx("div", { className: "aui-agent-composer-context", children: attachments.map((file, index) => /* @__PURE__ */ jsxs("span", { className: "aui-agent-composer-chip", children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "document" }),
            /* @__PURE__ */ jsx("span", { children: file.name }),
            /* @__PURE__ */ jsx(IconButton, { label: `Remove ${file.name}`, disabled: running, onClick: () => setAttachments((value) => value.filter((_, i) => i !== index)), children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
          ] }, index)) }),
          activity.length > 0 && /* @__PURE__ */ jsxs("details", { "aria-label": "Agent actions", open: running, children: [
            /* @__PURE__ */ jsxs("summary", { children: [
              "Actions \xB7 ",
              activity.length
            ] }),
            /* @__PURE__ */ jsx("ol", { children: activity.map((item) => /* @__PURE__ */ jsxs("li", { children: [
              item.name.replace(/^aether_/, "").replaceAll("_", " "),
              " \xB7 ",
              item.state,
              item.image && /* @__PURE__ */ jsx("img", { alt: "Preview sent to agent", src: `data:${item.image.mimeType};base64,${item.image.data}`, style: { display: "block", width: 160, maxHeight: 160, objectFit: "contain", background: "#fff" } })
            ] }, item.id)) })
          ] })
        ] }),
        onSubmit: submit,
        renderComposerActions: (append) => /* @__PURE__ */ jsxs(Fragment, { children: [
          composerActions,
          /* @__PURE__ */ jsx("button", { type: "button", className: "aui-agent-composer-add", "aria-label": "Attach text files", disabled: running || reading, onClick: () => files.current?.click(), children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) }),
          /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-agent-composer-pill", onClick: () => setToolsOpen(true), children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "sliders" }),
            "Tools"
          ] }),
          /* @__PURE__ */ jsxs("button", { type: "button", className: "aui-agent-composer-pill", "aria-label": "Response style", disabled: running, onClick: (event) => setStyleAnchor(event.currentTarget), children: [
            /* @__PURE__ */ jsx(AetherIcon, { name: "pencil" }),
            style
          ] }),
          /* @__PURE__ */ jsx(AgentVoiceInput, { disabled: running || reading, onText: append, onError: setError })
        ] })
      },
      conversation
    ),
    /* @__PURE__ */ jsx("input", { ref: files, type: "file", accept: ".txt,.md,.csv,.json,.yaml,.yml", multiple: true, hidden: true, onChange: (event) => {
      void attach(event.target.files);
      event.target.value = "";
    } }),
    /* @__PURE__ */ jsx(Menu, { open: !!styleAnchor, anchor: styleAnchor, ariaLabel: "Response style", applicationCommands: false, placement: "top-start", onClose: () => setStyleAnchor(null), items: ["Normal", "Concise", "Detailed"].map((label) => ({ id: label, label, kind: "radio", checked: style === label })), onSelect: (id) => {
      setStyle(id);
      setStyleAnchor(null);
    } }),
    /* @__PURE__ */ jsxs(Dialog, { open: toolsOpen, title: "Agent tools", onClose: () => setToolsOpen(false), actions: /* @__PURE__ */ jsx(Button, { onClick: () => setToolsOpen(false), children: "Done" }), children: [
      /* @__PURE__ */ jsx("p", { children: "Enabled tools are available to this chat. Changes apply to the next message. External MCP access is managed separately in Connections." }),
      /* @__PURE__ */ jsx("div", { className: "aui-agent-tool-list", children: interaction?.tools.map((tool) => /* @__PURE__ */ jsxs("label", { children: [
        /* @__PURE__ */ jsx("input", { type: "checkbox", checked: !disabledTools.includes(tool.name), disabled: running, onChange: (event) => setDisabledTools((value) => event.target.checked ? value.filter((name) => name !== tool.name) : [...value, tool.name]) }),
        /* @__PURE__ */ jsxs("span", { children: [
          tool.name.replace(/^aether_/, "").replaceAll("_", " "),
          /* @__PURE__ */ jsx("small", { children: tool.description })
        ] })
      ] }, tool.name)) }),
      !interaction?.tools.length && /* @__PURE__ */ jsx("p", { children: "This workspace has no editor tools available." }),
      /* @__PURE__ */ jsx(Button, { onClick: () => {
        setToolsOpen(false);
        setConnectionsOpen(true);
      }, children: "Agent connections" })
    ] }),
    /* @__PURE__ */ jsx(AgentConnectionsDialog, { open: connectionsOpen, onClose: () => setConnectionsOpen(false), app, service, access, sharing, plugins, onChanged: () => void refresh(), provider, onProvider: setProvider, models, model, onModel: setModel, busy: running })
  ] });
}
export {
  WorkspaceAgent
};
