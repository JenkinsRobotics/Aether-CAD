import { type ViewportUpAxis, type CubeVector, type CubeFaceView } from "./viewport-cube-geometry.js";
import "./ViewportNavigationCube.css";
import { type MenuItem } from "./Menu.js";
export type ViewportOrientation = readonly [
    x: number,
    y: number,
    z: number,
    w: number
];
export type StandardViewportView = CubeFaceView;
export interface ViewportNavigationCubeProps {
    orientation: ViewportOrientation;
    upAxis?: ViewportUpAxis;
    id?: string;
    className?: string;
    /** Studio uses a quiet surface, corner controls and direct cube navigation. */
    appearance?: "standard" | "studio";
    onSelectView: (view: StandardViewportView) => void;
    onSelectDirection?: (direction: CubeVector) => void;
    onFit: () => void;
    homeMenuItems?: readonly MenuItem[];
    onHomeMenuSelect?: (id: string) => void;
    onNudge: (horizontalSteps: number, verticalSteps: number) => void;
    onRoll: (quarterTurns: number) => void;
}
/** Retained as the renderer-independent quaternion projection helper used by
 * camera presentation stores. */
export declare function viewportCubeTransform(orientation: ViewportOrientation): string;
/** Shared suite ViewCube, visually aligned with the native Studio projection.
 * Applications retain camera behavior and pass typed intent callbacks. */
export declare function ViewportNavigationCube({ orientation, upAxis, id, className, appearance, onSelectView, onSelectDirection, onFit, homeMenuItems, onHomeMenuSelect, onNudge, onRoll, }: ViewportNavigationCubeProps): import("react").JSX.Element;
