import { type ReactNode } from "react";
export type ToolIconPack = "classic" | "graphite-ribbon";
export type ToolIconPalette = "auto" | "light" | "dark";
export declare function activeToolIconPack(): ToolIconPack;
export declare function setToolIconPack(pack: ToolIconPack): void;
export declare function useGlobalToolIconPack(): ToolIconPack;
/** Scope an illustrated tool pack to a ribbon, workspace or app. No global mutation. */
export declare function ToolIconTheme({ pack, palette, children }: {
    pack: ToolIconPack;
    palette?: ToolIconPalette;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useToolIconTheme(): {
    pack: ToolIconPack;
    palette: ToolIconPalette;
};
