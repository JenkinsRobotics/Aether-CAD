/** Separate clicks from navigation gestures without intercepting OrbitControls. */
export declare function bindViewportPointerActions(canvas: HTMLCanvasElement, actions: {
    pick: (event: PointerEvent) => void;
    menu: (x: number, y: number) => void;
}): () => void;
