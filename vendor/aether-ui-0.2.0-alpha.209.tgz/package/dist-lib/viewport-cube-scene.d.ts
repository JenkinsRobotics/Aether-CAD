import * as THREE from "three";
import { viewportCubeColorTokens, type ViewportUpAxis } from "./viewport-cube-geometry.js";
export type CubeScenePalette = Record<keyof typeof viewportCubeColorTokens | "x" | "y" | "z", string>;
/** A genuine depth-buffered scene. The orthographic lens matches the shared
 * face projection, so DOM keyboard/pointer targets align with mesh facets. */
export declare class ViewportCubeScene {
    private palette;
    readonly scene: THREE.Scene;
    readonly camera: THREE.OrthographicCamera;
    readonly faces: Map<string, THREE.Mesh<THREE.BufferGeometry<THREE.NormalBufferAttributes, THREE.BufferGeometryEventMap>, THREE.MeshBasicMaterial, THREE.Object3DEventMap>>;
    private idleColors;
    constructor(upAxis: ViewportUpAxis, palette: CubeScenePalette);
    setOrientation(orientation: readonly [number, number, number, number]): void;
    setHighlight(id: string | null): void;
    dispose(): void;
}
export declare function readCubeScenePalette(host: HTMLElement): CubeScenePalette;
export declare function createCubeRenderer(size?: number): THREE.WebGLRenderer;
