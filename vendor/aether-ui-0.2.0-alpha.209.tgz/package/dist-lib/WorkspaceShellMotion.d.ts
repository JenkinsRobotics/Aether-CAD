import { type CSSProperties, type RefObject } from "react";
import type { LayoutPreset, WorkspacePanelState } from "./WorkspaceShell.js";
import "./WorkspaceShellMotion.css";
export declare const WORKSPACE_PANEL_DURATION_MS = 240;
/** Retain closing panels for their exit transition, including their portal hosts.
 * Authoritative visibility changes immediately; retained chrome is inert. */
export declare function useClosingPanels(state: WorkspacePanelState, enabled: boolean, preset: LayoutPreset, sides: readonly (readonly string[])[]): {
    [x: string]: Readonly<import("./WorkspaceShell.js").WorkspacePanelPresentation>;
};
/** Measure the actual chrome, not a toolbar-height estimate. Insets are relative
 * to the shell area; docked panels already participate in document flow. */
export declare function useWorkspaceInsets(areaRef: RefObject<HTMLDivElement | null>, enabled: boolean, preset: LayoutPreset, revision: readonly unknown[]): CSSProperties;
