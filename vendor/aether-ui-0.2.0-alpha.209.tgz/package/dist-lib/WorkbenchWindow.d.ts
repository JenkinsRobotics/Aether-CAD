import { type ReactNode } from "react";
import "./WorkbenchWindow.css";
export interface WorkbenchWindowProps {
    title: string;
    subtitle?: string;
    sidebar: ReactNode;
    sidebarTitle?: string;
    sidebarActions?: ReactNode;
    sidebarFooter?: ReactNode;
    toolbar?: ReactNode;
    statusBar?: ReactNode;
    /** Presentation overlays only; the owner supplies real diagnostic values. */
    canvasOverlay?: ReactNode;
    canvasFooter?: ReactNode;
    children: ReactNode;
    sidebarCollapsed?: boolean;
    defaultSidebarCollapsed?: boolean;
    onSidebarCollapsedChange?: (collapsed: boolean) => void;
    sidebarWidth?: number;
    defaultSidebarWidth?: number;
    onSidebarWidthChange?: (width: number) => void;
    className?: string;
}
/** Codex Bench's split-window anatomy, without its renderer or benchmark logic.
 * Compose file lists/trees, toolbar, canvas and status from the owning product.
 * The hidden sidebar remains mounted, preserving drafts and selection.
 */
export declare function WorkbenchWindow({ title, subtitle, sidebar, sidebarTitle, sidebarActions, sidebarFooter, toolbar, statusBar, canvasOverlay, canvasFooter, children, sidebarCollapsed, defaultSidebarCollapsed, onSidebarCollapsedChange, sidebarWidth, defaultSidebarWidth, onSidebarWidthChange, className, }: WorkbenchWindowProps): import("react").JSX.Element;
