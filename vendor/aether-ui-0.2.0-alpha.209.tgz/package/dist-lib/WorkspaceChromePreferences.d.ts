export declare const CHROME_PREFERENCES_KEY = "aether.workspace-chrome.v1";
declare const options: {
    readonly sidebarOpening: readonly ["app", "inside", "outside"];
    readonly sidebarAttachment: readonly ["auto", "attached", "detached"];
    readonly sidebarDesign: readonly ["app", "rail", "tabs-top", "tabs-bottom"];
    readonly tabSize: readonly ["auto", "compact", "touch"];
    readonly tabLabels: readonly ["icons", "labels"];
    readonly toolbarDensity: readonly ["app", "compact", "standard", "expanded"];
    readonly ribbonAppearance: readonly ["app", "glass", "panel"];
    readonly workspaceSelector: readonly ["app", "column", "strip"];
    readonly toolPopup: readonly ["app", "list", "grid"];
    readonly panelMotion: readonly ["auto", "none"];
};
export type WorkspaceChromePreferences = {
    [K in keyof typeof options]: (typeof options)[K][number];
};
export type SidebarAttachment = WorkspaceChromePreferences["sidebarAttachment"];
export declare const DEFAULT_WORKSPACE_CHROME: Readonly<WorkspaceChromePreferences>;
export declare function readWorkspaceChrome(raw: string | null): WorkspaceChromePreferences;
export declare function setWorkspaceChrome(patch: Partial<WorkspaceChromePreferences>): void;
export declare function useWorkspaceChrome(): WorkspaceChromePreferences;
/** Legacy automatic callers also receive the primary combined card. */
export declare function resolveSidebarAttachment(choice: SidebarAttachment): "attached" | "detached";
export {};
