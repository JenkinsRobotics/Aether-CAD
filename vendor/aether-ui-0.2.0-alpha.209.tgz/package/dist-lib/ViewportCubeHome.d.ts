import { type MenuItem } from "./Menu.js";
export declare function ViewportCubeHome({ onHome, items, onSelect }: {
    onHome: () => void;
    items?: readonly MenuItem[];
    onSelect?: (id: string) => void;
}): import("react").JSX.Element;
