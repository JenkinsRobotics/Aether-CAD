import type { CSSProperties, ReactNode } from "react";
export interface TreeNode {
    id: string;
    label: string;
    /** Product-defined type used by the shared collection picker. */
    category?: string;
    /** Additional type keywords included in text filtering. */
    searchText?: string;
    icon?: ReactNode;
    /** Counts or other short metadata. Use status icons for state. */
    badge?: string;
    status?: readonly {
        id: string;
        label: string;
        icon: ReactNode;
    }[];
    /** Row cannot be focused, selected, renamed, or dragged. */
    disabled?: boolean;
    /** Protect fixed reference/collection rows from drag gestures. */
    draggable?: boolean;
    /** Ordered leaves split their whole row into before/after drop targets. */
    dropMode?: "hierarchy" | "reorder";
    /** Visually de-emphasized (for example suppressed/hidden entities). */
    dimmed?: boolean;
    /** Extra class on the row element for application-specific presentation. */
    className?: string;
    /** Row presentation variant. "divider" renders a slim draggable rule
     * (feature-history rollback lines) instead of a normal row. */
    variant?: "divider";
    /** Semantic row tone; "error" marks failing entities. */
    tone?: "error";
    /** Hover-revealed trailing actions; clicks never change selection; `pinned` keeps one visible without hover. */
    actions?: readonly {
        id: string;
        label: string;
        icon: ReactNode;
        pinned?: boolean;
        state?: boolean;
    }[];
    children?: readonly TreeNode[];
    /** Shows a live child status row while an expanded branch resolves. */
    childrenLoading?: boolean;
    /** Shows a recoverable child error row while the branch is expanded. */
    childrenError?: ReactNode;
}
export type TreeMovePosition = "before" | "inside" | "after";
export interface TreeProps {
    nodes: readonly TreeNode[];
    selectedIDs: ReadonlySet<string>;
    onSelect: (ids: readonly string[], mode: "single" | "toggle" | "range") => void;
    ariaLabel?: string;
    /** Double-click, or Enter on an already-selected row. */
    onActivate?: (id: string) => void;
    onContextMenu?: (id: string, x: number, y: number) => void;
    onAction?: (nodeID: string, actionID: string) => void;
    /** Controlled expansion; omit for internal state. */
    expandedIDs?: ReadonlySet<string>;
    onToggle?: (id: string, expanded: boolean) => void;
    defaultCollapsedIDs?: readonly string[];
    /** Reveal ancestors of the controlled selection without forgetting their collapsed state. */
    revealSelection?: boolean;
    /** Case-insensitive filter that keeps matching rows and ancestors. */
    filter?: string;
    emptyState?: ReactNode;
    /** Controlled rename. The application decides when a row enters this mode. */
    renamingID?: string | null;
    onRename?: (id: string, label: string) => void;
    onCancelRename?: (id: string) => void;
    /** Native drag signal; the application remains owner of hierarchy mutation. */
    onMove?: (sourceID: string, targetID: string, position: TreeMovePosition) => void;
    canMove?: (sourceID: string, targetID: string, position: TreeMovePosition) => boolean;
    onRetryChildren?: (id: string) => void;
    /** Visible rows at or above this count use fixed-row windowing. */
    virtualizeThreshold?: number;
    height?: number;
    rowHeight?: number;
    /** Inset before root rows; descendants add the normal hierarchy indentation. */
    rootInset?: number;
    overscan?: number;
    className?: string;
    style?: CSSProperties;
}
/** The definitive hierarchical collection for all Aether products. */
export declare function Tree({ nodes, selectedIDs, onSelect, ariaLabel, onActivate, onContextMenu, onAction, expandedIDs, onToggle, defaultCollapsedIDs, revealSelection, filter, emptyState, renamingID, onRename, onCancelRename, onMove, canMove, onRetryChildren, virtualizeThreshold, height, rowHeight, rootInset, overscan, className, style, }: TreeProps): import("react").JSX.Element;
