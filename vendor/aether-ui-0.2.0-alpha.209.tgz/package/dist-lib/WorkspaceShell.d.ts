import "./WorkspaceShellPlacement.css";
import "./WorkspaceSafeArea.css";
import "./WorkspaceToolbarFrame.css";
import type { CSSProperties, ReactNode, Ref } from "react";
import type { PanelPlacement } from "./PanelPlacementMenu.js";
import { type SidebarAttachment } from "./WorkspaceChromePreferences.js";
/**
 * The app-window chrome, ported from the Swift `StudioWorkspaceScaffold`:
 * three layout presets — DOCKED (sidebars in flow), FLOATING (chrome
 * floats over the canvas), CANVAS (chrome hidden; edge hot-zones reveal
 * it on hover) — with per-side panel stacks toggled from icon rails and
 * tear-off floating panels that drag anywhere and restack near their
 * home edge. Spec lives in WIDGETS.md ("WorkspaceShell").
 */
export type LayoutPreset = "docked" | "floating" | "canvas";
export interface WorkspacePanel {
    /** Floating combined card height; defaults to fill on the left, content on the right. */
    floatingHeight?: "fill" | "content" | number;
    id: string;
    title: string;
    icon: ReactNode;
    content: ReactNode;
    /** Right-side property panels use the shared inspector. Custom canvases/browsers may opt out. */
    contentLayout?: "inspector" | "custom";
    /** Command entries open an overlay without changing sidebar selection or size. */
    command?: (onClose: () => void) => ReactNode;
    /** A workspace visibility toggle keeps the selected auxiliary editor intact. */
    toggle?: {
        pressed: boolean;
        onToggle: () => void;
    };
    /** Docked presentation renders no title/float/close header; the panel content owns its heading. Rail toggle still closes it. */
    chromeless?: boolean;
    /** A collection owns its header and receives docking commands in its footer menu. */
    collection?: boolean;
    /** Draw a divider above this panel's rail button, to group the rail. */
    separatorBefore?: boolean;
    /** false: the panel still opens from other commands but has no toolbar/rail button (a user display choice). */
    inToolbar?: boolean;
}
export declare function nextLayoutPreset(preset: LayoutPreset): LayoutPreset;
/** The studio layout button: cycles Floating → Docked → Canvas. */
export declare function LayoutPresetButton({ preset, onChange, }: {
    preset: LayoutPreset;
    onChange: (preset: LayoutPreset) => void;
}): import("react").JSX.Element;
export interface FloatingPanelProps {
    shellSide?: "left" | "right";
    closing?: boolean;
    title: string;
    x: number;
    y: number;
    width?: number;
    onMove: (x: number, y: number) => void;
    onDragEnd?: (x: number, y: number) => void;
    onDock?: () => void;
    onClose?: () => void;
    children: ReactNode;
}
/** A draggable floating panel (drag by header). Also used standalone for
 *  short-lived tools that must stay visible above the workspace. */
export declare function FloatingPanel(props: FloatingPanelProps): import("react").JSX.Element;
export interface WorkspaceShellHandle {
    /** Reveal a panel without toggling it closed or remounting its editor. */
    showPanel: (id: string) => void;
}
export interface WorkspaceShellProps {
    /** Approved Model Studio frame; the standard variant remains available for existing specimens. */
    design?: "standard" | "studio";
    controllerRef?: Ref<WorkspaceShellHandle>;
    /** Shared default: animate opening/closing while retaining editor hosts. Set false for immediate transitions. */
    animatePanels?: boolean;
    /** @deprecated Safe areas are now always measured and applied by the shell. */
    measureContentInsets?: boolean;
    preset: LayoutPreset;
    /** Put panel cards at the window edge and icon rails beside the workspace in all layouts. */
    panelsOnOuterEdge?: boolean;
    /** Defaults true: preserve panel DOM, drafts and editor bindings across layout/visibility changes. */
    preservePanelContent?: boolean;
    /** One active panel per side by default. Explicitly opt into stacked panels. */
    panelSelection?: "single" | "multiple";
    /** Additive full-height sidebar variant, with horizontal top/bottom tabs.
     * All standard sidebars share one frame; multiple-panel rails retain tear-off windows. */
    sidebarVariant?: "rail" | "tabs-top" | "tabs-bottom";
    sidebarAttachment?: SidebarAttachment;
    /** Gallery specimens may pin their local design for side-by-side comparisons. */
    inheritChromePreferences?: boolean;
    /** Versioned device-local layouts, remembered independently per preset. */
    storageKey?: string;
    /** Usually a <Ribbon>; docked above the canvas or floating top-center. */
    toolbar?: ReactNode;
    /** Docked toolbar spans the window by default; center keeps sidebars full-height. */
    toolbarSpan?: "window" | "center";
    /** Optional shared app-layout bounds. Existing workspace defaults are retained when omitted. */
    sidebarSizing?: {
        width: number;
        minWidth: number;
        maxWidth: number;
        minCenterWidth: number;
    };
    /** Panels that keep their own column beside the canvas (Onshape's feature
     *  list): exempt from one-panel-per-side, so the rail's other panels open
     *  in a column between the rail and these instead of replacing them.
     *  Docked layout only. */
    pinnedPanels?: readonly string[];
    /** Widgets that belong to a side's column, above and below its sidebar
     *  (CAD: the view cube on top, the selection filter at the bottom). In
     *  the floating layout they stack in that column; docked, the sidebar owns
     *  the full-height column, and in canvas the column is hidden, so they sit
     *  at that edge of the canvas. */
    sideTop?: {
        left?: ReactNode;
        right?: ReactNode;
    };
    sideBottom?: {
        left?: ReactNode;
        right?: ReactNode;
    };
    /** Auto (default) recognizes shared toolbars that already own their frame. */
    frameToolbar?: boolean | "auto";
    leftPanels?: readonly WorkspacePanel[];
    rightPanels?: readonly WorkspacePanel[];
    defaultOpenLeft?: readonly string[];
    defaultOpenRight?: readonly string[];
    /** Controlled stable-ID panel presentation. Omit for shell-owned state. */
    panelState?: WorkspacePanelState;
    /** Additional initial state used only when `panelState` is uncontrolled. */
    defaultPanelState?: WorkspacePanelState;
    /** Emits a complete state snapshot after any visibility or position change. */
    onPanelStateChange?: (state: WorkspacePanelState) => void;
    /** Bottom editor strip under the canvas (dope sheet, curves, log). */
    bottom?: ReactNode;
    /** A shared bottom dock inside the center column; follows this shell’s preset. */
    centerBottom?: ReactNode;
    statusBar?: ReactNode;
    style?: CSSProperties;
    /** Framed documents clear surrounding chrome. Continuous canvases extend
     * behind floating chrome; use the measured inset variables for their HUDs. */
    contentPresentation?: "framed" | "canvas";
    /** The center canvas/viewport. */
    children: ReactNode;
}
export interface WorkspaceFloatingPosition {
    x: number;
    y: number;
}
export interface WorkspacePanelPresentation {
    placement: PanelPlacement;
    position?: Readonly<WorkspaceFloatingPosition>;
}
export type WorkspacePanelState = Readonly<Record<string, Readonly<WorkspacePanelPresentation>>>;
export declare function WorkspaceShell(props: WorkspaceShellProps): import("react").JSX.Element;
