import type { CSSProperties } from "react";
export interface ViewportCanvasProps {
    /**
     * Mounts the imperative renderer exactly once with the live canvas and
     * returns its teardown. React NEVER re-renders through this element —
     * the viewport is a persistent Three.js/WebGPU object (see the UI
     * framework decision record).
     */
    onMount: (canvas: HTMLCanvasElement) => () => void;
    style?: CSSProperties;
    className?: string;
}
export declare function ViewportCanvas({ onMount, style, className }: ViewportCanvasProps): import("react").JSX.Element;
