import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ViewportCubeScene } from "./ViewportCubeScene.js";
import { useId, useState } from "react";
import { cubeAxisOccluders } from "./viewport-cube-occlusion.js";
import arrow0 from "@aether/assets/icons/navigation/roll-left.svg?raw";
import arrow1 from "@aether/assets/icons/navigation/roll-right.svg?raw";
import arrow2 from "@aether/assets/icons/navigation/up.svg?raw";
import arrow3 from "@aether/assets/icons/navigation/left.svg?raw";
import arrow4 from "@aether/assets/icons/navigation/right.svg?raw";
import arrow5 from "@aether/assets/icons/navigation/down.svg?raw";
import { viewportCubeRegionsForUpAxis, viewportCubeColorTokens, viewportCubeProjection, viewportCubeAxisOrigin, viewportCubeAxes } from "./viewport-cube-geometry.js";
import "./ViewportNavigationCube.css";
import { ViewportCubeHome } from "./ViewportCubeHome.js";
import { MenuButton } from "./Menu.js";
import { AetherIcon } from "./AetherIcon.js";
function normalizedOrientation([x, y, z, w]) {
  const length = Math.hypot(x, y, z, w) || 1;
  return [x / length, y / length, z / length, w / length];
}
function rotateIntoCamera(vector, orientation) {
  const [sourceX, sourceY, sourceZ, sourceW] = normalizedOrientation(orientation);
  const x = -sourceX;
  const y = -sourceY;
  const z = -sourceZ;
  const [vx, vy, vz] = vector;
  const dot = x * vx + y * vy + z * vz;
  const crossX = y * vz - z * vy;
  const crossY = z * vx - x * vz;
  const crossZ = x * vy - y * vx;
  const scalar = sourceW * sourceW - x * x - y * y - z * z;
  return [
    2 * dot * x + scalar * vx + 2 * sourceW * crossX,
    2 * dot * y + scalar * vy + 2 * sourceW * crossY,
    2 * dot * z + scalar * vz + 2 * sourceW * crossZ
  ];
}
function viewportCubeTransform(orientation) {
  let [x, y, z, w] = normalizedOrientation(orientation);
  x = -x;
  y = -y;
  z = -z;
  const xx = x * x;
  const yy = y * y;
  const zz = z * z;
  const xy = x * y;
  const xz = x * z;
  const yz = y * z;
  const wx = w * x;
  const wy = w * y;
  const wz = w * z;
  const matrix = [
    1 - 2 * (yy + zz),
    2 * (xy + wz),
    2 * (xz - wy),
    0,
    2 * (xy - wz),
    1 - 2 * (xx + zz),
    2 * (yz + wx),
    0,
    2 * (xz + wy),
    2 * (yz - wx),
    1 - 2 * (xx + yy),
    0,
    0,
    0,
    0,
    1
  ];
  return `matrix3d(${matrix.join(",")})`;
}
const project = ([x, y]) => [viewportCubeProjection.center + x * viewportCubeProjection.scale, viewportCubeProjection.center - y * viewportCubeProjection.scale];
function centroid(points) {
  const [x, y] = points.reduce(
    ([sumX, sumY], [pointX, pointY]) => [sumX + pointX, sumY + pointY],
    [0, 0]
  );
  return [Number((x / points.length).toFixed(6)), Number((y / points.length).toFixed(6))];
}
function ViewportNavigationCube({
  orientation,
  upAxis = "y",
  id,
  className,
  appearance = "standard",
  onSelectView,
  onSelectDirection,
  onFit,
  homeMenuItems,
  onHomeMenuSelect,
  onNudge,
  onRoll
}) {
  const [sceneReady, setSceneReady] = useState(false);
  const [highlight, setHighlight] = useState(null);
  const maskPrefix = useId().replaceAll(":", "");
  const classes = ["aui-viewport-cube"];
  if (appearance === "studio") classes.push("aui-viewport-cube--studio");
  if (className) classes.push(className);
  if (sceneReady) classes.push("aui-viewport-cube--3d");
  const projections = viewportCubeRegionsForUpAxis(upAxis).map((face) => {
    const normal = rotateIntoCamera(face.normal, orientation);
    const vertices = face.vertices.map((vertex) => rotateIntoCamera(vertex, orientation));
    return {
      ...face,
      cameraVertices: vertices,
      facing: normal[2],
      depth: vertices.reduce((sum, vertex) => sum + vertex[2], 0) / vertices.length,
      points: vertices.map(project)
    };
  }).filter((face) => face.facing > 1e-9).sort((first, second) => first.depth - second.depth);
  const axisOrigin = rotateIntoCamera(viewportCubeAxisOrigin, orientation);
  const axes = viewportCubeAxes.map((axis) => ({ ...axis, end: rotateIntoCamera(axis.end, orientation) }));
  const [axisX, axisY] = project(axisOrigin);
  const facets = projections.map((face) => face.cameraVertices);
  const depthMasks = [
    ...axes.map((axis) => ({ id: `${maskPrefix}-${axis.id}-line`, polygons: cubeAxisOccluders(facets, axisOrigin, axis.end) })),
    { id: `${maskPrefix}-origin`, polygons: cubeAxisOccluders(facets, axisOrigin) }
  ];
  return /* @__PURE__ */ jsxs("div", { id, className: classes.join(" "), "aria-label": "Viewport navigation", children: [
    appearance !== "studio" && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("button", { className: "aui-viewport-cube-roll aui-viewport-cube-roll--left", type: "button", title: "Roll view counterclockwise", "aria-label": "Roll view counterclockwise", onClick: () => onRoll(-1), children: /* @__PURE__ */ jsx(NavigationArrow, { name: "roll-left" }) }),
      /* @__PURE__ */ jsx("button", { className: "aui-viewport-cube-roll aui-viewport-cube-roll--right", type: "button", title: "Roll view clockwise", "aria-label": "Roll view clockwise", onClick: () => onRoll(1), children: /* @__PURE__ */ jsx(NavigationArrow, { name: "roll-right" }) }),
      /* @__PURE__ */ jsx("button", { className: "aui-viewport-cube-nudge aui-viewport-cube-nudge--up", type: "button", title: "Nudge view up 15 degrees", "aria-label": "Nudge view up 15 degrees", onClick: () => onNudge(0, 1), children: /* @__PURE__ */ jsx(NavigationArrow, { name: "up" }) }),
      /* @__PURE__ */ jsx("button", { className: "aui-viewport-cube-nudge aui-viewport-cube-nudge--left", type: "button", title: "Nudge view left 15 degrees", "aria-label": "Nudge view left 15 degrees", onClick: () => onNudge(-1, 0), children: /* @__PURE__ */ jsx(NavigationArrow, { name: "left" }) })
    ] }),
    /* @__PURE__ */ jsx(ViewportCubeScene, { orientation, upAxis, highlight, onReady: setSceneReady }),
    /* @__PURE__ */ jsxs("svg", { className: "aui-viewport-cube-stage", viewBox: `0 0 ${viewportCubeProjection.size} ${viewportCubeProjection.size}`, role: "img", "aria-label": "Camera ViewCube", children: [
      /* @__PURE__ */ jsx("defs", { children: depthMasks.map((mask) => /* @__PURE__ */ jsxs("mask", { id: mask.id, maskUnits: "userSpaceOnUse", x: "-100", y: "-100", width: "300", height: "300", style: { maskType: "luminance" }, children: [
        /* @__PURE__ */ jsx("rect", { x: "-100", y: "-100", width: "300", height: "300", fill: "white" }),
        mask.polygons.map((polygon, index) => /* @__PURE__ */ jsx("polygon", { fill: "black", points: polygon.map((vertex) => project(vertex).join(",")).join(" ") }, index))
      ] }, mask.id)) }),
      projections.map((face) => {
        const [labelX, labelY] = centroid(face.points);
        const right = rotateIntoCamera(face.right ?? [1, 0, 0], orientation);
        const up = rotateIntoCamera(face.up ?? [0, 1, 0], orientation);
        const labelTransform = `matrix(${right[0]} ${-right[1] || 0} ${-up[0] || 0} ${up[1]} ${labelX} ${labelY})`;
        const activate = () => face.view ? onSelectView(face.view) : onSelectDirection?.(face.normal);
        const interactive = !!face.view || !!onSelectDirection;
        return /* @__PURE__ */ jsxs(
          "g",
          {
            className: `aui-viewport-cube-face aui-viewport-cube-face--${face.kind}`,
            "data-view": face.view,
            "data-cube-region": face.id,
            role: interactive ? "button" : void 0,
            tabIndex: interactive ? 0 : void 0,
            "aria-label": `${face.label} view`,
            onPointerEnter: () => setHighlight(face.id),
            onPointerLeave: () => setHighlight(null),
            onFocus: () => setHighlight(face.id),
            onBlur: () => setHighlight(null),
            onClick: activate,
            onKeyDown: (event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                event.stopPropagation();
                activate();
              }
            },
            children: [
              /* @__PURE__ */ jsx("polygon", { style: { fill: `var(${viewportCubeColorTokens[face.kind]})` }, points: face.points.map(([x, y]) => `${x},${y}`).join(" ") }),
              face.view ? /* @__PURE__ */ jsx("text", { x: 0, y: 0, transform: labelTransform, children: face.label.toUpperCase() }) : null
            ]
          },
          face.id
        );
      }),
      /* @__PURE__ */ jsxs("g", { className: "aui-viewport-cube-axes", "aria-hidden": "true", pointerEvents: "none", children: [
        axes.map((axis) => {
          const [endX, endY] = project(axis.end);
          const dx = endX - axisX, dy = endY - axisY, length = Math.hypot(dx, dy);
          const labelX = endX + (length > 0.1 ? dx / length * 5 : -5);
          const labelY = endY + (length > 0.1 ? dy / length * 5 : 5);
          return /* @__PURE__ */ jsxs("g", { className: `aui-viewport-cube-axis-${axis.id}`, children: [
            /* @__PURE__ */ jsx("line", { className: "aui-viewport-cube-axis-hidden", x1: axisX, y1: axisY, x2: endX, y2: endY }),
            /* @__PURE__ */ jsx("line", { mask: `url(#${maskPrefix}-${axis.id}-line)`, x1: axisX, y1: axisY, x2: endX, y2: endY }),
            /* @__PURE__ */ jsx("text", { x: labelX, y: labelY, children: axis.id.toUpperCase() })
          ] }, axis.id);
        }),
        /* @__PURE__ */ jsx("circle", { mask: `url(#${maskPrefix}-origin)`, cx: axisX, cy: axisY, r: "1.5" })
      ] })
    ] }),
    appearance !== "studio" && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("button", { className: "aui-viewport-cube-nudge aui-viewport-cube-nudge--right", type: "button", title: "Nudge view right 15 degrees", "aria-label": "Nudge view right 15 degrees", onClick: () => onNudge(1, 0), children: /* @__PURE__ */ jsx(NavigationArrow, { name: "right" }) }),
      /* @__PURE__ */ jsx("button", { className: "aui-viewport-cube-nudge aui-viewport-cube-nudge--down", type: "button", title: "Nudge view down 15 degrees", "aria-label": "Nudge view down 15 degrees", onClick: () => onNudge(0, -1), children: /* @__PURE__ */ jsx(NavigationArrow, { name: "down" }) })
    ] }),
    /* @__PURE__ */ jsx(ViewportCubeHome, { onHome: onFit, items: appearance === "studio" ? void 0 : homeMenuItems, onSelect: onHomeMenuSelect }),
    appearance === "studio" && homeMenuItems?.length && onHomeMenuSelect ? /* @__PURE__ */ jsxs(MenuButton, { className: "aui-viewport-cube-options", label: "Camera settings", items: homeMenuItems, onSelect: onHomeMenuSelect, children: [
      /* @__PURE__ */ jsx(AetherIcon, { name: "cube" }),
      /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down" })
    ] }) : null
  ] });
}
const arrows = { "roll-left": arrow0, "roll-right": arrow1, "up": arrow2, "left": arrow3, "right": arrow4, "down": arrow5 };
function NavigationArrow({ name }) {
  const source = arrows[name];
  return /* @__PURE__ */ jsx("svg", { "aria-hidden": "true", viewBox: name.startsWith("roll") ? "0 0 44 28" : "0 0 24 24", dangerouslySetInnerHTML: { __html: source.replace(/<svg[^>]*>|<\/svg>/g, "") } });
}
export {
  ViewportNavigationCube,
  viewportCubeTransform
};
