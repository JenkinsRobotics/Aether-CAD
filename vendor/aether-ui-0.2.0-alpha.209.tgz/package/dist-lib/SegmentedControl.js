import { jsx, jsxs } from "react/jsx-runtime";
import { useRef, useState } from "react";
function SegmentedControl({ options, value, defaultValue, onChange, ariaLabel, disabled = false, className }) {
  const [internal, setInternal] = useState(defaultValue ?? options.find((item) => !item.disabled)?.id ?? "");
  const selected = value ?? internal;
  const refs = useRef(/* @__PURE__ */ new Map());
  const select = (id) => {
    if (value === void 0) setInternal(id);
    onChange?.(id);
  };
  const move = (event, id) => {
    const enabled = options.filter((item) => !disabled && !item.disabled);
    const current = enabled.findIndex((item) => item.id === id);
    let next = current;
    if (event.key === "ArrowRight" || event.key === "ArrowDown") next = (current + 1) % enabled.length;
    else if (event.key === "ArrowLeft" || event.key === "ArrowUp") next = (current - 1 + enabled.length) % enabled.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = enabled.length - 1;
    else return;
    event.preventDefault();
    const option = enabled[next];
    if (!option) return;
    select(option.id);
    refs.current.get(option.id)?.focus();
  };
  return /* @__PURE__ */ jsx("div", { className: ["aui-segmented-control", className].filter(Boolean).join(" "), role: "radiogroup", "aria-label": ariaLabel, "aria-disabled": disabled || void 0, children: options.map((option) => /* @__PURE__ */ jsxs(
    "button",
    {
      ref: (element) => {
        if (element) refs.current.set(option.id, element);
        else refs.current.delete(option.id);
      },
      type: "button",
      role: "radio",
      "aria-checked": selected === option.id,
      tabIndex: selected === option.id ? 0 : -1,
      disabled: disabled || option.disabled,
      onClick: () => select(option.id),
      onKeyDown: (event) => move(event, option.id),
      children: [
        option.icon ? /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: option.icon }) : null,
        /* @__PURE__ */ jsx("span", { children: option.label })
      ]
    },
    option.id
  )) });
}
export {
  SegmentedControl
};
