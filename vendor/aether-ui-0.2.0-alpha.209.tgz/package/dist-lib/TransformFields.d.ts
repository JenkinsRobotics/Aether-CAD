import './TransformFields.css';
export interface TransformFieldsProps {
    label: string;
    values: readonly number[];
    unit?: string;
    disabled?: boolean;
    min?: number;
    max?: number;
    step?: number;
    locked?: readonly boolean[];
    onCommit: (axis: number, value: number) => void;
    onToggleLock?: (axis: number) => void;
}
/** Unframed vector editor. Units, constraints and edit transactions belong to the caller. */
export declare function TransformFields({ label, values, unit, disabled, min, max, step, locked, onCommit, onToggleLock }: TransformFieldsProps): import("react").JSX.Element;
