import { jsx, jsxs } from "react/jsx-runtime";
import { createContext, useContext, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { IconButton } from "./IconButton.js";
import { Menu } from "./Menu.js";
import "./CollectionView.css";
const CollectionHost = createContext({});
function CollectionActions({ controls = [], primaryControls, label = "Item controls" }) {
  const host = useContext(CollectionHost), [open, setOpen] = useState(false), anchor = useRef(null);
  const unique = (items) => items.filter((item, i) => items.findIndex((other) => other.id === item.id) === i);
  const own = unique([...primaryControls ?? [], ...controls]);
  const preferred = primaryControls ?? [
    own.find((c) => /folder/i.test(c.id)),
    own.find((c) => /settings/i.test(c.id)),
    own.find((c) => !/folder/i.test(c.id) && /^(new|add|create)/i.test(c.id))
  ].filter((c) => Boolean(c));
  const primary = unique(preferred).slice(0, 2);
  const commands = unique([...own, ...host.controls ?? []]).filter((c) => !primary.some((p) => p.id === c.id));
  if (!primary.length && !commands.length) return null;
  return /* @__PURE__ */ jsxs("div", { className: "aui-collection-actions", role: "group", "aria-label": label, ref: anchor, children: [
    primary.map((control) => /* @__PURE__ */ jsx(
      IconButton,
      {
        label: control.label,
        disabled: control.disabled,
        onClick: control.onClick,
        children: control.icon
      },
      control.id
    )),
    commands.length > 0 && /* @__PURE__ */ jsx(
      IconButton,
      {
        label: `More ${label}`,
        "aria-haspopup": "menu",
        "aria-expanded": open,
        onClick: () => setOpen(!open),
        children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" })
      }
    ),
    open && commands.length > 0 && /* @__PURE__ */ jsx(
      Menu,
      {
        className: "aui-collection-popup",
        open: true,
        anchor: anchor.current,
        placement: "bottom-end",
        ariaLabel: label,
        items: commands.map((c) => ({ id: c.id, label: c.label, icon: c.icon, disabled: c.disabled, shortcut: c.shortcut, separatorBefore: c.separatorBefore })),
        onSelect: (id) => {
          commands.find((c) => c.id === id)?.onClick();
          setOpen(false);
        },
        onClose: () => setOpen(false)
      }
    )
  ] });
}
function CollectionView({ title, headerActions, filter, children, footer, controls, primaryControls, controlsLabel, className = "", id, onKeyDown, onContextMenu }) {
  const host = useContext(CollectionHost);
  const [context, setContext] = useState(null);
  const commands = [...primaryControls ?? [], ...controls ?? [], ...host.controls ?? []].filter((control, index, all) => all.findIndex((item) => item.id === control.id) === index);
  return /* @__PURE__ */ jsxs("div", { id, className: `aui-collection ${className}`, onKeyDown, onContextMenu: (event) => {
    if (onContextMenu) {
      onContextMenu(event);
      return;
    }
    if (event.target.closest('input, textarea, [contenteditable="true"], [role="menu"], [role="treeitem"], [role="option"], [role="row"], [role="listitem"], li')) return;
    event.preventDefault();
    event.stopPropagation();
    if (commands.length) setContext({ x: event.clientX, y: event.clientY });
  }, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-collection-heading", children: [
      /* @__PURE__ */ jsx("strong", { children: title ?? host.title ?? "Items" }),
      /* @__PURE__ */ jsxs("span", { className: "aui-collection-heading-actions", children: [
        headerActions,
        /* @__PURE__ */ jsx(CollectionActions, { controls, primaryControls, label: controlsLabel })
      ] })
    ] }),
    filter && /* @__PURE__ */ jsx("div", { className: "aui-collection-search", children: filter }),
    children,
    footer,
    context && /* @__PURE__ */ jsx(
      Menu,
      {
        open: true,
        anchor: context,
        ariaLabel: `${title ?? host.title ?? "Collection"} actions`,
        items: commands,
        onClose: () => setContext(null),
        onSelect: (id2) => {
          commands.find((command) => command.id === id2 && !command.disabled)?.onClick();
          setContext(null);
        }
      }
    )
  ] });
}
export {
  CollectionActions,
  CollectionHost,
  CollectionView
};
