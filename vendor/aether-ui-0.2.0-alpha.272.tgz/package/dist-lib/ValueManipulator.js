import { mountTransformManipulator } from "./TransformManipulator.js";
import "./ValueManipulator.css";
const svgNS = "http://www.w3.org/2000/svg";
function orbitRibbon(orbit) {
  const speed = Math.hypot(orbit.pointAt(orbit.angle + 1).x - orbit.pointAt(orbit.angle - 1).x, orbit.pointAt(orbit.angle + 1).y - orbit.pointAt(orbit.angle - 1).y) / 2;
  const span = Math.min(55, 24 / Math.max(speed, 0.4));
  const points = Array.from({ length: 25 }, (_, i) => orbit.pointAt(orbit.angle - span + i * span / 12));
  const first = points[0], last = points[points.length - 1];
  const normal = (i) => {
    const a = points[Math.max(0, i - 1)], b = points[Math.min(points.length - 1, i + 1)];
    const size = Math.max(Math.hypot(b.x - a.x, b.y - a.y), 1e-6);
    return { x: -(b.y - a.y) / size, y: (b.x - a.x) / size };
  };
  const side = (i, width) => {
    const n = normal(i), p = points[i];
    return { x: p.x + n.x * width, y: p.y + n.y * width };
  };
  const shaft = Array.from({ length: 17 }, (_, i) => i + 4);
  return [first, side(4, 6), ...shaft.map((i) => side(i, 2)), side(20, 6), last, side(20, -6), ...shaft.reverse().map((i) => side(i, -2)), side(4, -6)];
}
function mountValueManipulator(container, options) {
  const element = document.createElement("div");
  element.className = "aui-value-manipulator";
  const guides = document.createElementNS(svgNS, "svg");
  guides.classList.add("aui-manipulator-guides");
  guides.setAttribute("aria-hidden", "true");
  const orbits = document.createElementNS(svgNS, "svg");
  orbits.classList.add("aui-manipulator-orbits");
  element.append(guides, orbits);
  const gizmo = mountTransformManipulator(element, options);
  const readout = document.createElement("input");
  readout.className = "aui-manipulator-readout";
  readout.inputMode = "decimal";
  readout.hidden = true;
  readout.setAttribute("aria-label", options.readoutLabel ?? "Value");
  readout.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    event.stopPropagation();
    options.onCommit?.(readout.value);
    readout.blur();
  });
  readout.addEventListener("blur", () => options.onCommit?.(readout.value));
  element.append(readout);
  container.append(element);
  const guideLines = [];
  const entries = /* @__PURE__ */ new Map();
  let current = [];
  let drag = null;
  const handleFor = (id) => {
    const orbit = current.find((o) => o.id === id);
    return orbit && { id: orbit.id, kind: "rotation", label: orbit.label, x: 0, y: 0, angle: orbit.angle };
  };
  const finish = (cancelled) => {
    if (!drag) return;
    const previous = drag;
    drag = null;
    previous.hit.parentElement?.removeAttribute("data-dragging");
    if (previous.hit.hasPointerCapture?.(previous.pointer)) previous.hit.releasePointerCapture(previous.pointer);
    options.onEnd(previous.handle, cancelled);
  };
  const escape = (event) => {
    if (!drag || event.key !== "Escape") return;
    event.preventDefault();
    event.stopPropagation();
    finish(true);
  };
  const blur = () => finish(true);
  window.addEventListener("keydown", escape, true);
  window.addEventListener("blur", blur);
  const path = (points) => points.map((p) => `${p.x},${p.y}`).join(" ");
  const update = (state) => {
    gizmo.update(state.handles ?? [], { disabled: state.disabled });
    const lines = state.guides ?? [];
    while (guideLines.length < lines.length) {
      const line = document.createElementNS(svgNS, "polyline");
      line.classList.add("aui-manipulator-guide");
      guides.append(line);
      guideLines.push(line);
    }
    guideLines.forEach((line, i) => {
      if (i < lines.length) {
        line.setAttribute("points", path(lines[i]));
        line.style.display = "";
      } else line.style.display = "none";
    });
    current = state.orbits ?? [];
    if (drag && !current.some((o) => o.id === drag.handle.id)) finish(true);
    for (const orbit of current) {
      let entry = entries.get(orbit.id);
      if (!entry) {
        const group = document.createElementNS(svgNS, "g");
        const guide = document.createElementNS(svgNS, "polyline");
        guide.classList.add("aui-manipulator-orbit-guide");
        const arrow = document.createElementNS(svgNS, "polygon");
        arrow.classList.add("aui-manipulator-orbit-arrow");
        const hit = document.createElementNS(svgNS, "polyline");
        hit.classList.add("aui-manipulator-orbit-hit");
        hit.setAttribute("role", "button");
        hit.setAttribute("tabindex", "0");
        hit.dataset.transformHandle = orbit.id;
        hit.addEventListener("pointerdown", (event) => {
          if (event.button !== 0 || drag || state.disabled) return;
          const handle = handleFor(orbit.id);
          if (!handle) return;
          event.preventDefault();
          event.stopPropagation();
          if (options.onStart(handle, event) === false) return;
          drag = { handle, pointer: event.pointerId, hit };
          group.dataset.dragging = "true";
          hit.focus({ preventScroll: true });
          hit.setPointerCapture(event.pointerId);
        });
        hit.addEventListener("pointermove", (event) => {
          if (drag?.hit !== hit || drag.pointer !== event.pointerId) return;
          event.stopPropagation();
          options.onMove(drag.handle, event);
        });
        hit.addEventListener("pointerup", (event) => {
          if (drag?.hit !== hit || drag.pointer !== event.pointerId) return;
          event.stopPropagation();
          finish(false);
        });
        hit.addEventListener("pointercancel", () => finish(true));
        hit.addEventListener("lostpointercapture", () => finish(true));
        hit.addEventListener("keydown", (event) => {
          const handle = handleFor(orbit.id);
          if (handle) options.onKey?.(handle, event);
        });
        group.append(guide, arrow, hit);
        orbits.append(group);
        entry = { group, guide, arrow, hit };
        entries.set(orbit.id, entry);
      }
      entry.hit.setAttribute("aria-label", orbit.label);
      const line = path(orbit.points);
      entry.guide.setAttribute("points", line);
      entry.hit.setAttribute("points", line);
      entry.arrow.setAttribute("points", path(orbitRibbon(orbit)));
      entry.group.style.display = "";
    }
    for (const [id, entry] of entries) if (!current.some((o) => o.id === id)) entry.group.style.display = "none";
    const pill = state.readout;
    readout.hidden = !pill;
    if (pill) {
      readout.style.transform = `translate(${pill.x}px,${pill.y}px)`;
      if (document.activeElement !== readout && readout.value !== pill.text) readout.value = pill.text;
    }
    readout.disabled = Boolean(state.disabled);
  };
  return {
    element,
    readout,
    update,
    cancel: () => {
      finish(true);
      gizmo.cancel();
    },
    dispose() {
      finish(true);
      gizmo.dispose();
      window.removeEventListener("keydown", escape, true);
      window.removeEventListener("blur", blur);
      element.remove();
    }
  };
}
export {
  mountValueManipulator,
  orbitRibbon
};
