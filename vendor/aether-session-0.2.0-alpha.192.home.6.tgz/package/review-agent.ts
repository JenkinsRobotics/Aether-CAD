import type { AgentInteraction, AgentTool } from '@aether/ui/AgentServices';
import type { DocumentConnection, DocumentCollaboration } from '@aether/ui/DocumentServices';
const tool=(name:string,description:string,properties:Record<string,unknown>,required:string[]=[]):AgentTool=>({name,description,inputSchema:{type:'object',properties,required,additionalProperties:false}});
export const reviewAgentTools:AgentTool[]=[
 tool('aether_review_read','Read comments, tasks, cards and member IDs for the current Studio document. Read before writing.',{}),
 tool('aether_review_mutate','Create, edit, resolve or delete a comment, task or task card through Studio. Uses the same permissions as the signed-in user. Supply the revision returned by read; never invent author IDs.',{
  collection:{type:'string',enum:['comments','tasks','reminders','cards']},operation:{type:'string',enum:['add','update','delete']},item:{type:'string'},expected_revision:{type:'integer',minimum:0},value:{type:'object',description:'text; tags (strings); mentions (member IDs); reference_name; revision; parent for replies; resolved for root comments; status, due (YYYY-MM-DD), assignee and card for tasks. Author cannot be supplied.'},
 },['collection','operation','expected_revision','value']),
];
/** Transport adapter: document identity and authorization remain with the host.
 * The caller supplies a live accessor so a tool cannot write a replaced document.
 */
export function withReviewAgent(base:AgentInteraction, getConnection:()=>DocumentConnection|null):AgentInteraction {
 const connection=getConnection(),key=connection?.key;
 if(!connection)return base;
 return {...base,contextKey:`${base.contextKey}:review:${key}`,tools:[...base.tools,...reviewAgentTools],async execute(call,signal){
  if(!call.name.startsWith('aether_review_'))return base.execute(call,signal);
  const current=()=>{const active=getConnection();if(signal.aborted||!active||active.key!==key)throw Error('The review document changed or the request was cancelled.');return active;};
  const args=call.arguments;
  if(call.name==='aether_review_read'){
   if(Object.keys(args).length)throw Error('Review read takes no arguments.');
   const result=await current().call<DocumentCollaboration>('collaboration');current();
   // Images remain in Studio; avoid putting large image bodies in provider tool JSON.
   return JSON.parse(JSON.stringify(result,(key,value)=>key==='data_url'?undefined:value));
  }
  if(call.name!=='aether_review_mutate'||Object.keys(args).some(key=>!['collection','operation','item','expected_revision','value'].includes(key))||!['comments','tasks','reminders','cards'].includes(String(args.collection))||!['add','update','delete'].includes(String(args.operation))||!Number.isInteger(args.expected_revision)||Number(args.expected_revision)<0||!args.value||typeof args.value!=='object'||Array.isArray(args.value))throw Error('Invalid review mutation.');
  const value=args.value as Record<string,unknown>;
  if(['author','id','created','updated'].some(key=>key in value))throw Error('Review author and identity are assigned by Studio.');
  const result=await current().call<DocumentCollaboration>('collaboration_mutate',{...args,value:{...value,...(args.operation==='add'?{source:'ai'}:{})},operation_id:`review-${crypto.randomUUID()}`});
  return JSON.parse(JSON.stringify({revision:result.revision,collection:args.collection,items:(result as unknown as Record<string,unknown>)[String(args.collection)]},(key,value)=>key==='data_url'?undefined:value));
 }};
}
