import React, { useLayoutEffect, useState } from 'react';
import { Button } from '@aether/ui';
import type { AgentInteraction, AgentEditorSharing } from '@aether/ui/AgentServices';
import { LiveEditorConnection, studioEditorTransport } from './live-editor';

/** Explicit local opt-in. Leaving this panel or document ends sharing. */
export function useLiveEditorAccess({ app, documentID, interaction }: {
  app: 'cad' | 'map'; documentID: string | null; interaction: AgentInteraction;
}): AgentEditorSharing {
  const current = React.useRef(interaction); current.current = interaction;
  const [state, setState] = useState('off'), [message, setMessage] = useState('');
  const [connection] = useState(() => new LiveEditorConnection(studioEditorTransport, () => current.current,
    (next, text) => { setState(next); setMessage(text); }));
  useLayoutEffect(() => {
    connection.stop();
    const stop = () => connection.stop(); window.addEventListener('pagehide', stop);
    return () => { connection.stop(); window.removeEventListener('pagehide', stop); };
  }, [connection, app, documentID, interaction.contextKey]);
  return {available:!!documentID,state,message,start:()=>{if(documentID)void connection.start(app,documentID);},stop:()=>connection.stop()};
}

/** Legacy presentation; new workspaces put this same controller in Connections. */
export function LiveEditorAccess(props: {app:'cad'|'map';documentID:string|null;interaction:AgentInteraction}) {
  const access=useLiveEditorAccess(props);
  if(!access.available)return null;
  const enabled=['shared','working','connecting'].includes(access.state);
  return <div className="aui-live-editor-access" aria-label="External agent access"><Button onClick={enabled?access.stop:access.start}>{enabled?'Stop sharing editor':'Share this editor'}</Button><p role="status">{access.message||'Let connected agents use this editor’s tools and undo. Requires Studio content-edit access.'}</p></div>;
}
