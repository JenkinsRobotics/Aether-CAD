import {isLocalDocument,documentURL} from './home/runtime';
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  AutosaveSession,
  recoveryKey,
  sessionOwner,
  SaveError,
  type SaveState,
} from "./autosave";
import {
  decodeDocument,
  documentRequest,
  encodeDocument,
  type HostedDocument,
} from "./documents";

import { prepareSaveRecovery, SaveRecoveryController, downloadRecovery } from "./save-recovery";

/** Always-on host history for text documents. Formats stay in the product. */
export function useHostedDocument(options: {
  app: string;
  identity: string;
  text: string | null;
  name: string;
  onLoad: (text: string, file: HostedDocument | null) => void;
  onSaved?: (file: HostedDocument) => void;
}) {
  const current = useRef(options);
  current.current = options;
  const hosted =
    typeof location !== "undefined" &&
    (isLocalDocument() || location.pathname.startsWith(`/${options.app}/`));
  const [ready, setReady] = useState(!hosted),
    [file, setFile] = useState<HostedDocument | null>(null),
    [state, setState] = useState<SaveState>({ phase: "saved", durable: true });
  const [guard, setGuard] = useState<SaveRecoveryController<HostedDocument | null> | null>(null);
  const copyName = useRef<string | null>(null);
  const session = useRef<AutosaveSession<HostedDocument | null> | null>(null);
  const activeIdentity = useRef<string | null>(null);
  const opening = useRef<Promise<void>>(Promise.resolve());
  useEffect(() => {
    if (!hosted) return;
    let disposed = false;
    let controller: SaveRecoveryController<HostedDocument | null> | null = null;
    setReady(false);
    setFile(null);
    setGuard(null);
    const initial = current.current,
      query = new URLSearchParams(location.search),
      id = query.get("document"),
      branch = query.get("branch") ?? "Main";
    opening.current = (async () => {
      if (!id && initial.text === null) {
        if (!disposed) setReady(true);
        return;
      }
      const owner = await sessionOwner(false);
      const stored = id
        ? await documentRequest<HostedDocument>(initial.app, "read", {
            id,
            branch,
          })
        : null;
      if (disposed) return;
      const initialText = stored
        ? decodeDocument(stored.data_base64!)
        : initial.text!;
      const docKey = id ?? query.get("draft") ?? crypto.randomUUID();
      if (!id) {
        query.set("draft", docKey);
        history.replaceState(null, "", `${location.pathname}?${query}`);
      }
      const keyFor = (base: HostedDocument | null) =>
        recoveryKey(initial.app, owner, `${base?.id ?? docKey}:${branch}`);
      const key = keyFor(stored),
        selection = prepareSaveRecovery<HostedDocument | null>(key, initialText),
        recovery = selection.record;
      // Parse before creating a save queue; malformed documents cannot replace valid files.
      initial.onLoad(recovery?.text ?? initialText, stored);
      const queue = new AutosaveSession<HostedDocument | null>({
        key, persistentRecovery: true,
        base: stored ? {id:stored.id,name:stored.name,revision:stored.revision,writable:stored.writable,branch:stored.branch,branch_id:stored.branch_id} : null,
        text: initialText,
        keyForBase: keyFor,
        save: async (text, base) => {
          if (await sessionOwner(false) !== owner) throw new SaveError("Sign in with the account that opened this document.", 401);
          if (base?.writable === false)
            throw new SaveError(
              "This document is read only. Download a copy to keep edits.",
              403,
            );
          return await documentRequest<HostedDocument>(
            initial.app,
            base ? "save" : "create",
            base
              ? {
                  id: base.id,
                  branch,
                  expected_revision: base.revision,
                  data_base64: encodeDocument(text),
                }
              : {
                  name: copyName.current ?? current.current.name,
                  kind: "file",
                  scope: "personal",
                  data_base64: encodeDocument(text),
                },
          );
        },
      });
      session.current = queue;
      activeIdentity.current = initial.identity;
      queue.subscribe((next) => {
        if (disposed) return;
        setState(next);
        setFile(queue.base);
        if (queue.base) {
          const q = new URLSearchParams(location.search);
          q.set("document", queue.base.id);
          q.delete("draft");
          q.delete("new");
          history.replaceState(null, "", `${location.pathname}?${q}`);
          current.current.onSaved?.(queue.base);
        }
      });
      if (recovery) {
        queue.recover(recovery, stored?.revision !== recovery.base?.revision);
        if (stored?.writable !== false && (stored || !recovery.blocked || [401, 403].includes(recovery.blockedStatus ?? 0)))
          queue.reconcile(stored, initialText, stored?.revision === recovery.base?.revision);
      }
      if (stored?.writable === false) queue.block('This document is read only. Save a copy to keep edits.', 403);
      controller = new SaveRecoveryController({ session: queue, selection,
        sameBase: (a, b) => a?.id === b?.id && a?.revision === b?.revision,
        revision: base => base?.revision,
        verify: async () => {
          if (await sessionOwner(false) !== owner) throw new SaveError('Sign in with the account that opened this document.', 401);
          const base = queue.base;
          if (!base) {
            if (queue.state.phase === 'conflict' && ![401, 403].includes(queue.state.status ?? 0))
              throw new Error('The first save could not be confirmed. Keep your recovery copy and check My files before creating another.');
            return { base: null, text: initialText };
          }
          const fresh = await documentRequest<HostedDocument>(initial.app, 'read', { id: base.id, branch });
          if (!fresh.writable) throw new SaveError('This document is read only. Save a copy to keep edits.', 403);
          return { base: fresh, text: decodeDocument(fresh.data_base64!) };
        },
        download: text => downloadRecovery(text, current.current.name),
        copy: async () => {
          if (await sessionOwner(false) !== owner) throw new SaveError('Sign in with the account that opened this document.', 401);
          try { await queue.flush(); } catch { /* Copy also resolves a conflict. */ }
          copyName.current = current.current.name.replace(/(\.[^.]+)$/, ' copy$1');
          queue.copyTo(null); queue.write(queue.text, true);
          await queue.flush(); if (queue.dirty) await queue.flush();
          if (queue.dirty) throw new Error('The copy still has unsaved changes.');
          if (queue.base) location.assign(documentURL(queue.base.id));
        },
      });
      setGuard(controller);
      if (!stored) queue.write(recovery?.text ?? initialText, true);
      setReady(true);
    })().catch((e) => {
      if (!disposed)
        setState({
          phase: "offline",
          durable: false,
          message: (e as Error).message,
          status: (e as SaveError).status,
        });
      throw e;
    });
    void opening.current.catch(() => {});
    return () => {
      disposed = true;
      controller?.dispose();
      session.current?.dispose();
      session.current = null;
      activeIdentity.current = null;
    };
  }, [hosted, options.app, options.identity]);
  useLayoutEffect(() => {
    if (
      ready &&
      activeIdentity.current === options.identity &&
      options.text !== null
    )
      session.current?.write(options.text);
  }, [ready, options.text, options.identity]);
  const flush = async () => {
    if (!hosted)
      throw new Error(
        "Open this app through Aether Studio to save document history.",
      );
    await opening.current;
    const queue = session.current;
    if (!queue || activeIdentity.current !== current.current.identity)
      throw new Error("Open a document first.");
    if (current.current.text !== null)
      queue.write(current.current.text, !queue.base);
    await queue.flush();
    if (queue.dirty) await queue.flush();
    if (queue.dirty) throw new Error("The document still has unsaved changes.");
  };
  const saveCopy = async () => {
    if (!guard) throw new Error('Open a document in Studio first.');
    await guard.options.copy();
  };
  return { ready, file, state, flush, saveCopy, guard };
}
