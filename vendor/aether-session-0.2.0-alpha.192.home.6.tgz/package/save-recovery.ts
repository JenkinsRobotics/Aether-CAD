import { AutosaveSession, readRecovery, SaveError, type RecoveryRecord, type SaveState } from './autosave';
import { listRecoveryBackups, removeRecoveryBackup, type RecoveryBackup } from './autosave-recovery';

export interface VerifiedDocument<Base> { base: Base; text: string }
export interface RecoverySelection<Base> {
  record: RecoveryRecord<Base> | null;
  candidates: RecoveryBackup<Base>[];
  adopted: RecoveryBackup<Base>[];
}
/** Call after an authorized read. Recovery never uses timestamps to choose a winner. */
export function prepareSaveRecovery<Base>(key: string, confirmedText: string): RecoverySelection<Base> {
  const backups = listRecoveryBackups<Base>(key);
  const selected = new URLSearchParams(location.search).get('recovery');
  const requested = backups.find(b => b.id === selected);
  const record = requested?.record ?? readRecovery<Base>(key);
  const candidates = backups.filter(b => {
    if (b.record.text !== confirmedText) return true;
    removeRecoveryBackup(key, b.id, b); return false;
  });
  return {
    record: record?.text === confirmedText ? null : record,
    candidates: record ? [] : candidates,
    adopted: record ? backups.filter(b => b.record.text === record.text) : [],
  };
}

/** Product adapters supply canonical bytes and revision comparison. This controller
 * only verifies saving; it never silently replaces a live editor or rebases edits. */
export class SaveRecoveryController<Base> {
  private checking: Promise<void> | null = null;
  private disposed = false;
  private listeners = new Set<() => void>();
  private unsubscribe: () => void;
  private error = '';
  private candidates: RecoveryBackup<Base>[];
  private adopted: RecoveryBackup<Base>[];
  private announced = '';
  constructor(readonly options: {
    session: AutosaveSession<Base>;
    selection: RecoverySelection<Base>;
    verify: () => Promise<VerifiedDocument<Base>>;
    sameBase: (a: Base, b: Base) => boolean;
    revision: (base: Base) => number | string | undefined;
    download: (text: string) => void | Promise<void>;
    copy: () => Promise<void>;
  }) {
    this.candidates = options.selection.candidates;
    this.adopted = options.selection.adopted;
    this.unsubscribe = options.session.subscribe(state => {
      if (state.phase === 'saved') {
        this.adopted = this.adopted.filter(b => {
          if (b.record.text !== options.session.text) return true;
          removeRecoveryBackup(b.key, b.id, b); return false;
        });
        const revision = String(options.revision(options.session.base) ?? '');
        if (revision && revision !== this.announced) {
          this.announced = revision;
          try { localStorage.setItem(`aether.saved.v1:${options.session.recoveryScope}`, revision); } catch { /* Focus checks too. */ }
        }
      }
      this.emit();
    });
    window.addEventListener('focus', this.focus);
    window.addEventListener('online', this.focus);
    document.addEventListener('visibilitychange', this.focus);
    window.addEventListener('storage', this.storage);
  }
  get session() { return this.options.session; }
  get state(): SaveState { return this.error ? { ...this.session.state, phase: 'offline', message: this.error } : this.session.state; }
  get recoveries() { return this.candidates.map(b => ({ id: b.id, updated: b.updated, revision: this.options.revision(b.record.base) })); }
  subscribe = (listener: () => void) => { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; };
  private emit() { if (!this.disposed) this.listeners.forEach(f => f()); }
  private focus = () => { if (document.visibilityState !== 'hidden') void this.check(); };
  private storage = (e: StorageEvent) => { if (e.key === `aether.saved.v1:${this.session.recoveryScope}`) void this.check(); };
  check = async () => {
    if (this.disposed || this.session.saving) return;
    if (this.checking) return this.checking;
    const before = this.session.base, beforeText = this.session.text;
    this.checking = (async () => {
      try {
        const next = await this.options.verify();
        if (this.disposed || this.session.saving || this.session.base !== before || this.session.text !== beforeText) return;
        this.candidates = this.candidates.filter(backup => {
          if (backup.record.text !== next.text) return true;
          removeRecoveryBackup(backup.key, backup.id, backup); return false;
        });
        const same = this.options.sameBase(before, next.base);
        // A clean stale tab must reopen too: advancing just its revision would
        // let its old geometry overwrite newer content on the next edit.
        if (!same && next.text !== this.session.text) {
          this.session.block('A newer version was saved elsewhere. Reopen the saved version, or save your edits as a separate copy.', 409);
          return;
        }
        this.error = '';
        this.session.reconcile(next.base, next.text, same);
      } catch (error) {
        if (this.disposed) return;
        const e = error as SaveError;
        if (e.status === 401 || e.status === 403 || e.status === 404) this.session.block(e.message, e.status);
        else { this.error = e.message; this.emit(); }
      } finally { this.checking = null; }
    })();
    return this.checking;
  };
  private action = async (run: () => void | Promise<void>) => {
    try { this.error = ''; await run(); }
    catch (error) { this.error = (error as Error).message; }
    this.emit();
  };
  retry = () => this.action(async () => { await this.check(); if (this.session.dirty) await this.session.flush(); });
  copy = () => this.action(this.options.copy);
  download = () => this.action(() => this.options.download(this.session.text));
  signIn = () => { window.open(`/?next=${encodeURIComponent(location.pathname + location.search)}`, '_blank', 'noopener'); };
  openSaved = () => { const url = new URL(location.href); url.searchParams.delete('recovery'); window.open(url.href, '_blank', 'noopener'); };
  recover = (id: string) => {
    if (!this.candidates.some(b => b.id === id)) return;
    // Separate tab leaves any in-flight editing untouched. The new tab verifies
    // account and document access before reading this explicitly chosen slot.
    const url = new URL(location.href); url.searchParams.set('recovery', id);
    window.open(url.href, '_blank', 'noopener');
  };
  keepSaved = () => { this.candidates = []; this.emit(); };
  dispose() {
    this.disposed = true; this.unsubscribe(); this.listeners.clear();
    window.removeEventListener('focus', this.focus); window.removeEventListener('online', this.focus);
    document.removeEventListener('visibilitychange', this.focus); window.removeEventListener('storage', this.storage);
  }
}
export function downloadRecovery(text: string | Uint8Array, name: string) {
  const blob = new Blob([typeof text === 'string' ? text : new Uint8Array(text)], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob), link = document.createElement('a');
  link.href = url; link.download = name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
