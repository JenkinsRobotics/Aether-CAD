import type { RecoveryRecord } from './autosave';

const PREFIX = 'aether.recovery.backup.v1:';
export interface RecoveryBackup<Base> {
  id: string;
  key: string;
  updated: number;
  record: RecoveryRecord<Base>;
}
const address = (key: string, id: string) => `${PREFIX}${encodeURIComponent(key)}:${id}`;

/** Separate slots prevent an older or duplicated tab from replacing another draft. */
export function storeRecoveryBackup<Base>(backup: RecoveryBackup<Base>): boolean {
  try {
    const value = JSON.stringify(backup), key = address(backup.key, backup.id);
    localStorage.setItem(key, value);
    return localStorage.getItem(key) === value;
  } catch { return false; }
}

/** Call only after a fresh authorized read of the account/document in key. */
export function listRecoveryBackups<Base>(key: string): RecoveryBackup<Base>[] {
  const result: RecoveryBackup<Base>[] = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const name = localStorage.key(i);
      if (!name?.startsWith(`${PREFIX}${encodeURIComponent(key)}:`)) continue;
      try {
        const value = JSON.parse(localStorage.getItem(name) ?? 'null');
        if (value?.key === key && typeof value.id === 'string' && name === address(key, value.id) &&
            Number.isFinite(value.updated) && typeof value.record?.text === 'string' && 'base' in value.record)
          result.push(value);
      } catch { /* One damaged entry must not hide other drafts. */ }
    }
  } catch { /* Recovery storage can be unavailable. */ }
  return result.sort((a, b) => b.updated - a.updated);
}

/** A confirmation in one tab never deletes work subsequently changed in another. */
export function removeRecoveryBackup<Base>(key: string, id: string, expected?: RecoveryBackup<Base>): void {
  try {
    const name = address(key, id);
    if (expected && localStorage.getItem(name) !== JSON.stringify(expected)) return;
    localStorage.removeItem(name);
  } catch { /* Retaining a redundant backup is safe. */ }
}
