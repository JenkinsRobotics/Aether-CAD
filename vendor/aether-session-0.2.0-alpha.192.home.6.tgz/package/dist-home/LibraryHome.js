import { jsx, jsxs } from "react/jsx-runtime";
import { FOLDER_REQUIRED } from "../local-documents";
import "@aether/session/library/studio.css";
import "./library-embedded.css";
import { FileObjectPreview } from "./FileObjectPreview.js";
import { LibrarySettings } from "./LibrarySettings.js";
import { readLibraryPreferences, writeLibraryPreferences } from "./library-preferences.js";
import { Inspector } from "@aether/ui";
import { FileDetails } from "@aether/ui/file-details";
import "@aether/session/library/FileDetailsInspector.css";
import "./LibraryFileControls.css";
import { ListToolMenu as ToolMenu } from "@aether/ui";
import { CreateMenu } from "./CreateMenu.js";
import { DocumentHistory } from "./DocumentHistory.js";
import { NewFileDialog } from "@aether/ui";
import { NewDesignDialog } from "@aether/ui/new-design";
import { useEffect, useRef, useState } from "react";
import { ApplicationListHeading, ApplicationListControls, Breadcrumbs, WorkspaceIcon, FileIcon, fileTypeFor, ApplicationFileTable, ApplicationSidebar, ApplicationHomeFrame, AetherIcon, Button, IconButton, Menu, TextField } from "@aether/ui";
import { createHomeStorage } from "./storage.js";
import { useLibraryListing } from "./use-library-listing.js";
import { ApplicationWelcome } from "@aether/ui";
import { ApplicationArtwork, ApplicationHeroArtwork } from "@aether/session/library/ApplicationArtwork";
import "@aether/session/library/library.css";
const titles = {
  home: "Home",
  personal: "My files",
  recent: "Recently opened",
  workspace: "Workspace",
  organization: "Workspaces",
  shared: "Shared",
  trash: "Recycle bin"
};
const DETAILS_KEY = (app) => `aether-library-details-${app}`;
function readDetailsPreference(app) {
  try {
    return localStorage.getItem(DETAILS_KEY(app)) === "open";
  } catch {
    return false;
  }
}
function writeDetailsPreference(app, open) {
  try {
    localStorage.setItem(DETAILS_KEY(app), open ? "open" : "closed");
  } catch {
  }
}
function ApplicationHome({ definition: cfg, storage: suppliedStorage }) {
  const app = cfg.appIcon;
  const [storage] = useState(() => suppliedStorage ?? createHomeStorage(app));
  const api = storage.request;
  const workspaceLabel = storage.hosted ? "Studio" : "On this device";
  const DESIGN_KINDS = cfg.design?.kinds ?? [];
  const DESIGN_UNIT_OPTIONS = cfg.design?.units ?? [];
  const [selectedIds, setSelectedIds] = useState(/* @__PURE__ */ new Set());
  const [directory, setDirectory] = useState(null);
  const [organizationID, setOrganizationID] = useState(null);
  const [workspaceID, setWorkspaceID] = useState(null);
  const [directoryError, setDirectoryError] = useState("");
  useEffect(() => {
    let live = true;
    void storage.directory().then((context) => {
      if (!live) return;
      setDirectory(context);
      setWorkspaceID(context.workspaces.find((item) => item.organization === "default" && item.is_default)?.id ?? context.workspaces[0]?.id ?? null);
    }).catch((error2) => {
      if (live) setDirectoryError(error2.message);
    });
    return () => {
      live = false;
    };
  }, []);
  const activeWorkspace = directory?.workspaces.find((item) => item.id === workspaceID);
  const workspace = activeWorkspace?.name ?? workspaceLabel;
  const activeOrganization = directory?.organizations.find((item) => item.id === (organizationID ?? activeWorkspace?.organization));
  useEffect(() => {
    document.title = cfg.brand;
  }, [cfg.brand]);
  useEffect(() => {
    if (!storage.hosted) return;
    const link = document.createElement("link");
    link.rel = "manifest";
    link.href = `/${cfg.appIcon}/manifest.webmanifest`;
    document.head.append(link);
    const deferInstall = (event) => event.preventDefault();
    window.addEventListener("beforeinstallprompt", deferInstall);
    return () => {
      link.remove();
      window.removeEventListener("beforeinstallprompt", deferInstall);
    };
  }, [storage.hosted, cfg.appIcon]);
  const [preferences, setPreferences] = useState(() => readLibraryPreferences(app));
  const [settingsOpen, setSettingsOpen] = useState(false);
  const updatePreferences = (value) => {
    try {
      writeLibraryPreferences(app, value);
      setPreferences(value);
      setDesignUnits(value.lengthUnit);
    } catch {
      setError("Your browser could not save these preferences.");
    }
  };
  const typeOf = (file) => file.kind === "folder" ? "folder" : cfg.types.find((type) => type.test.test(file.name.toLowerCase()))?.id ?? "import";
  const embedded = window.parent !== window && new URLSearchParams(location.search).get("embedded") === "1";
  useEffect(() => {
    if (!embedded) return;
    const escape = (event) => {
      if (event.key === "Escape" && !event.defaultPrevented && !document.querySelector('[role="dialog"], [role="menu"]')) window.parent.postMessage({ type: "aether-cad-close-library" }, location.origin);
    };
    window.addEventListener("keydown", escape);
    return () => window.removeEventListener("keydown", escape);
  }, [embedded]);
  const [view, setView] = useState(() => embedded ? "personal" : storage.hosted ? readLibraryPreferences(app).startPage : "home");
  const [apps, setApps] = useState([]);
  useEffect(() => {
    if (!storage.hosted) return;
    void api("/api/status").then(
      (status) => {
        setApps(
          (status.apps ?? []).filter((entry) => entry.enabled !== false).map((entry) => ({
            id: entry.id,
            name: entry.name,
            description: entry.description,
            url: entry.url,
            comingSoon: entry.coming_soon
          }))
        );
      },
      () => void 0
    );
  }, []);
  const [folders, setFolders] = useState([]);
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState("");
  const [grid, setGrid] = useState(() => readLibraryPreferences(app).view === "grid");
  const [typeFilter, setTypeFilter] = useState("all");
  const [nameFilter, setNameFilter] = useState("");
  const [menu, setMenu] = useState(null);
  const [showDetails, setShowDetails] = useState(() => readDetailsPreference(app));
  const [sortKey, setSortKey] = useState("opened");
  const [sortAsc, setSortAsc] = useState(false);
  const parent = folders.at(-1)?.id ?? null;
  useEffect(() => setSelectedIds(/* @__PURE__ */ new Set()), [view, parent]);
  const { files, loading, error: listingError, reload: list } = useLibraryListing({ request: api, app, view, parent, query, location: activeWorkspace ? { organization: activeWorkspace.organization, workspace: activeWorkspace.id } : null });
  const filterText = nameFilter.trim().toLowerCase();
  const compareShown = (a, b) => {
    const result = sortKey === "name" ? a.name.localeCompare(b.name) : sortKey === "owner" ? a.owner.localeCompare(b.owner) || a.name.localeCompare(b.name) : a.modified - b.modified;
    return sortAsc ? result : -result;
  };
  const shown = files.filter((file) => {
    const type = typeOf(file);
    if (typeFilter !== "all" && !(type === typeFilter || type === "import" && typeFilter === cfg.types[0].id)) return false;
    if (filterText && !file.name.toLowerCase().includes(filterText) && !file.owner.toLowerCase().includes(filterText)) return false;
    return true;
  }).sort(compareShown);
  const childWorkspaces = view === "organization" ? (directory?.workspaces ?? []).filter((w) => w.organization === activeOrganization?.id && w.name.toLowerCase().includes(filterText)).sort((a, b) => Number(!!b.is_default) - Number(!!a.is_default) || a.name.localeCompare(b.name)) : [];
  const tableRows = [
    ...childWorkspaces.map((entry) => ({ id: `workspace:${entry.id}`, name: entry.name, icon: /* @__PURE__ */ jsx(WorkspaceIcon, { name: entry.name }), location: "Workspace", date: "\u2014", owner: directory?.organizations.find((o) => o.id === entry.organization)?.name ?? "Organization", file: void 0, entry })),
    ...shown.map((file) => ({ id: file.id, name: file.name, icon: /* @__PURE__ */ jsx(FileObjectPreview, { file, app, preview: cfg.preview, request: api, enabled: preferences.objectPreviews }), location: file.workspace ? directory?.workspaces.find((w) => w.id === file.workspace)?.name ?? "Workspace" : "My files", date: new Date(file.modified * 1e3).toLocaleDateString(), owner: file.owner, file, entry: void 0 }))
  ];
  const startCreate = (choice) => {
    if (view === "organization") return;
    if (choice === "design") setChoosingDesign(true);
    else if (choice !== "folder" && choice !== "import") newDocument(choice);
    else if (choice === "import") input.current?.click();
    else {
      setName("");
      setDialog(choice);
    }
  };
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [creatingKind, setCreatingKind] = useState(null);
  const [choosingDesign, setChoosingDesign] = useState(false);
  const [designUnits, setDesignUnits] = useState(() => readLibraryPreferences(app).lengthUnit);
  const createdSelection = useRef(null);
  const [notice, setNotice] = useState("");
  const [connecting, setConnecting] = useState(false);
  const [server, setServer] = useState("");
  const [dialog, setDialog] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [name, setName] = useState("");
  const input = useRef(null);
  const showIntro = view === "home";
  useEffect(() => {
    const createdID = createdSelection.current;
    setSelected((current) => files.find((file) => file.id === createdID) ?? files.find((file) => file.id === current?.id) ?? null);
    if (!loading && !listingError) createdSelection.current = null;
  }, [files, loading, listingError]);
  const run = async (fn) => {
    setBusy(true);
    setError("");
    try {
      await fn();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const navigate = (next) => {
    setView(next);
    if (next !== "organization") setOrganizationID(null);
    setFolders([]);
    setQuery("");
    setNameFilter("");
    setTypeFilter("all");
    setSelected(null);
    setError("");
    setNotice("");
  };
  const visitFolder = (path) => {
    setFolders(path);
    setQuery("");
    setNameFilter("");
    setTypeFilter("all");
    setSelected(null);
    setError("");
  };
  const open = (file) => {
    if (file.kind === "folder") {
      setView(file.scope === "workspace" ? "workspace" : "personal");
      if (file.workspace) setWorkspaceID(file.workspace);
      visitFolder([...folders, file]);
      return;
    }
    if (embedded) {
      window.parent.postMessage({ type: "aether-cad-open-file", id: file.id }, location.origin);
      return;
    }
    location.assign(storage.openURL(cfg.appUrl, file.id));
  };
  const scope = !storage.hosted ? "personal" : view === "workspace" ? "workspace" : view === "home" ? preferences.destination : "personal";
  const destination = () => {
    if (view === "organization") throw new Error("Open a workspace to create files.");
    if (scope === "workspace" && !activeWorkspace) throw new Error("Choose an available organization workspace first.");
    return { scope, parent, ...scope === "workspace" ? { organization: activeWorkspace.organization, workspace: activeWorkspace.id } : { organization: folders.at(-1)?.organization ?? "default", workspace: null } };
  };
  const upload = async (file) => {
    if (!cfg.uploadPattern.test(file.name))
      throw new Error(
        cfg.uploadHint
      );
    if (file.size > 6 * 1024 * 1024)
      throw new Error("Choose a file up to 6 MB.");
    const bytes = new Uint8Array(await file.arrayBuffer());
    let binary = "";
    for (let i = 0; i < bytes.length; i += 32768)
      binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
    const created = await api("/api/library/create", {
      app,
      name: file.name,
      ...destination(),
      data_base64: btoa(binary)
    });
    await refreshCreated(created, "Uploaded");
  };
  const refreshCreated = async (created, action = "Created", extra = "") => {
    const where = folders.at(-1)?.name ?? (scope === "workspace" ? workspace : "My files");
    setNotice(`${action} ${created.name} in ${where}. Your current view is unchanged. Open it when you are ready.${extra}`);
    createdSelection.current = created.id;
    await list();
  };
  const edit = async () => {
    if (dialog === "folder") {
      const created = await api("/api/library/create", {
        app,
        name,
        kind: "folder",
        ...destination()
      });
      setDialog(null);
      await refreshCreated(created);
      return;
    } else if (selected)
      await api("/api/library/rename", {
        app,
        id: selected.id,
        name,
        expected_revision: selected.revision
      });
    setDialog(null);
    await list();
  };
  const share = () => run(async () => {
    if (!selected) return;
    await api("/api/library/share", {
      app,
      id: selected.id,
      scope: selected.scope === "personal" ? "workspace" : "personal",
      expected_revision: selected.revision
    });
    await list();
  });
  const download = () => run(async () => {
    if (!selected) return;
    const file = await api("/api/library/read", {
      app,
      id: selected.id
    });
    const bytes = Uint8Array.from(
      atob(file.data_base64),
      (c) => c.charCodeAt(0)
    );
    const url = URL.createObjectURL(new Blob([bytes]));
    const a = document.createElement("a");
    a.href = url;
    a.download = file.name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  });
  const newDocument = (kind) => setCreatingKind(kind);
  return /* @__PURE__ */ jsx("div", { style: { display: "contents" }, onContextMenu: (event) => {
    const target = event.target;
    if (target.closest('input,textarea,[contenteditable="true"],[role="dialog"],[role="menu"]')) return;
    event.preventDefault();
    event.stopPropagation();
    setMenu({ x: event.clientX, y: event.clientY });
  }, children: /* @__PURE__ */ jsxs(ApplicationHomeFrame, { design: embedded ? "standard" : "studio", className: `studio library-root${embedded ? " library-embedded" : ""}`, layout: "sidebar", children: [
    /* @__PURE__ */ jsx(LibrarySettings, { design: cfg.design, hosted: storage.hosted, open: settingsOpen, name: cfg.brand, workspace, preferences, onChange: updatePreferences, onClose: () => setSettingsOpen(false) }),
    choosingDesign && /* @__PURE__ */ jsx(
      NewDesignDialog,
      {
        kinds: DESIGN_KINDS,
        defaultKindID: preferences.designKind,
        learnMoreHref: "https://github.com/aether-studio",
        units: {
          label: "Unit System",
          value: designUnits,
          onChange: setDesignUnits,
          options: DESIGN_UNIT_OPTIONS
        },
        onClose: () => setChoosingDesign(false),
        onCreate: (kind) => {
          setChoosingDesign(false);
          newDocument(kind);
        }
      }
    ),
    creatingKind && /* @__PURE__ */ jsx(
      NewFileDialog,
      {
        title: `New ${cfg.design ? DESIGN_KINDS.find((kind) => kind.id === creatingKind)?.title ?? creatingKind : creatingKind}`,
        directory: folders.at(-1)?.name ?? (scope === "workspace" ? workspace : "My files"),
        onClose: () => setCreatingKind(null),
        onCreate: async (name2) => {
          const created = await cfg.create(creatingKind, name2, { storage, destination: destination(), preferences: { ...preferences, lengthUnit: designUnits } });
          await refreshCreated(created);
        }
      }
    ),
    /* @__PURE__ */ jsx(
      "input",
      {
        ref: input,
        type: "file",
        hidden: true,
        accept: cfg.accept,
        onChange: (e) => {
          const file = e.target.files?.[0];
          if (file) void run(() => upload(file));
          e.target.value = "";
        }
      }
    ),
    !embedded && /* @__PURE__ */ jsx(
      ApplicationSidebar,
      {
        variant: "captioned",
        id: `${app}-library`,
        name: cfg.brand,
        app,
        settings: { onSelect: () => setSettingsOpen(true) },
        apps,
        currentApp: app,
        action: /* @__PURE__ */ jsx(CreateMenu, { disabled: busy || view === "organization", onChoose: startCreate, items: cfg.menu }),
        sections: [
          { id: "library", title: "Library", items: (storage.hosted ? ["home", "personal", "shared", "trash"] : ["home", "personal"]).map((id) => ({
            id,
            label: titles[id],
            current: view === id,
            onSelect: () => navigate(id),
            icon: id === "home" ? "home" : id === "shared" ? "link" : id === "trash" ? "delete" : "folder"
          })) },
          ...cfg.navigation?.filter((item) => !item.requiresStudio || storage.hosted).length ? [{ id: "product", title: cfg.brand, items: cfg.navigation.filter((item) => !item.requiresStudio || storage.hosted).map((item) => ({ id: item.id, label: item.label, icon: item.icon, onSelect: () => location.assign(item.href) })) }] : [],
          ...(directory?.organizations ?? []).map((organization) => ({
            id: organization.id,
            title: organization.name,
            items: [{ id: `organization:${organization.id}`, label: "Workspaces", icon: "folder", current: view === "organization" && activeOrganization?.id === organization.id, onSelect: () => {
              setOrganizationID(organization.id);
              navigate("organization");
            } }, ...(directory?.workspaces ?? []).filter((item) => item.organization === organization.id).sort((a, b) => Number(!!b.is_default) - Number(!!a.is_default) || a.name.localeCompare(b.name)).map((item) => ({
              id: item.id,
              label: item.name,
              current: view === "workspace" && workspaceID === item.id,
              onSelect: () => {
                setWorkspaceID(item.id);
                navigate("workspace");
              },
              icon: /* @__PURE__ */ jsx(WorkspaceIcon, { name: item.name })
            }))]
          }))
        ]
      }
    ),
    /* @__PURE__ */ jsxs(
      "main",
      {
        className: "library-main",
        onContextMenu: (e) => {
          e.preventDefault();
          e.stopPropagation();
          setMenu({ x: e.clientX, y: e.clientY });
        },
        children: [
          embedded && /* @__PURE__ */ jsxs("div", { className: "library-embedded-toolbar", children: [
            /* @__PURE__ */ jsxs("div", { role: "group", "aria-label": "File location", children: [
              /* @__PURE__ */ jsx(Button, { "aria-pressed": view === "personal", onClick: () => navigate("personal"), children: "My files" }),
              /* @__PURE__ */ jsx(Button, { "aria-pressed": view === "workspace", onClick: () => navigate("workspace"), children: workspace })
            ] }),
            /* @__PURE__ */ jsx(CreateMenu, { disabled: busy || view === "organization", onChoose: startCreate, items: cfg.menu })
          ] }),
          menu && /* @__PURE__ */ jsx(
            Menu,
            {
              open: true,
              ariaLabel: "Library actions",
              anchor: { x: menu.x, y: menu.y },
              onClose: () => setMenu(null),
              onSelect: (id) => {
                const target = menu.file;
                if (id === "open-workspace" && menu.workspace) {
                  setWorkspaceID(menu.workspace.id);
                  navigate("workspace");
                }
                setMenu(null);
                if (id === "open" && target) open(target);
                else if (id === "details" && target) {
                  setSelected(target);
                  setShowDetails(true);
                  writeDetailsPreference(app, true);
                } else if (id === "rename" && target) {
                  setName(target.name);
                  setDialog("rename");
                } else if (id === "download" && target) void download();
                else if (id === "duplicate" && target) void run(async () => {
                  await api("/api/library/copy", { app, id: target.id });
                  await list();
                });
                else if (id === "share" && target) void share();
                else if (id === "history" && target) setShowHistory(true);
                else if (id === "refresh") void list();
                else if (id === "list" || id === "grid") setGrid(id === "grid");
                else if (id.startsWith("new-"))
                  startCreate(id.slice(4));
              },
              items: menu.workspace ? [{ id: "open-workspace", label: "Open workspace", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "folder" }) }] : menu.file ? [
                { id: "open", label: "Open", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "open", width: 15, height: 15 }) },
                { id: "details", label: "Details", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "document", width: 15, height: 15 }) },
                { id: "rename", label: "Rename", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "pencil" }), disabled: !menu.file.writable, separatorBefore: true },
                { id: "download", label: "Download", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "import" }), disabled: busy || menu.file.kind !== "file" },
                { id: "duplicate", label: "Duplicate", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "copy" }), disabled: busy || menu.file.kind !== "file" },
                { id: "share", label: menu.file.scope === "workspace" ? "Make private" : "Share", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "link" }), disabled: !storage.hosted || busy || !menu.file.writable || menu.file.kind !== "file" },
                { id: "history", label: "History & collaboration", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "history" }), disabled: !storage.hosted || menu.file.kind !== "file" }
              ] : [
                {
                  id: "add",
                  label: "Add New",
                  disabled: view === "organization",
                  icon: /* @__PURE__ */ jsx(AetherIcon, { name: "plus", width: 15, height: 15 }),
                  children: [["folder", "Folder", "folder"], ...cfg.menu.filter(([id]) => id !== "folder")].map(([id, label, icon]) => ({
                    id: "new-" + id,
                    label,
                    icon: /* @__PURE__ */ jsx(AetherIcon, { name: icon, width: 15, height: 15 })
                  }))
                },
                { id: "details", label: "Details", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "document", width: 15, height: 15 }), disabled: !selected },
                { id: "new-import", label: "Files upload", disabled: view === "organization", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "import" }), separatorBefore: true },
                { id: "view", label: "View", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "layout" }), children: [{ id: "list", label: "List", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "items" }), checked: !grid }, { id: "grid", label: "Gallery", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "layout" }), checked: grid }] },
                { id: "refresh", label: "Refresh", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "refresh" }), separatorBefore: true }
              ]
            }
          ),
          error && /* @__PURE__ */ jsx("div", { className: "message error", role: "alert", children: error }),
          showIntro && preferences.showUpdates && /* @__PURE__ */ jsx("div", { style: { marginBottom: 32 }, children: cfg.welcome ?? /* @__PURE__ */ jsx(ApplicationWelcome, { id: `${app}-welcome`, updates: cfg.updates ?? [], name: cfg.brand, description: cfg.heroLead, artwork: /* @__PURE__ */ jsx(ApplicationArtwork, { app }), wideArtwork: /* @__PURE__ */ jsx(ApplicationHeroArtwork, { app }) }) }),
          showIntro && /* @__PURE__ */ jsxs("section", { className: "library-start", "aria-label": "Get started", children: [
            /* @__PURE__ */ jsx("h2", { children: "Get started" }),
            /* @__PURE__ */ jsx("div", { className: "library-start-cards", children: cfg.start.map((card) => /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                disabled: busy || !card.action || !!card.requiresStudio && !storage.hosted,
                title: card.requiresStudio && !storage.hosted ? "Connect to Aether Studio to manage network players." : card.tooltip,
                onClick: () => {
                  if (card.action === "new-doc") newDocument(card.kind);
                  else if (card.action === "dialog") startCreate(card.kind);
                  else if (card.action === "import") input.current?.click();
                  else if (card.action === "navigate" && card.href) location.assign(card.href);
                },
                children: [
                  /* @__PURE__ */ jsx(FileIcon, { icon: card.icon, size: 34 }),
                  /* @__PURE__ */ jsxs("span", { children: [
                    /* @__PURE__ */ jsx("strong", { children: card.title }),
                    /* @__PURE__ */ jsx("small", { children: card.tagline })
                  ] })
                ]
              },
              card.kind
            )) })
          ] }),
          !storage.hosted && /* @__PURE__ */ jsxs("div", { className: "library-note", children: [
            /* @__PURE__ */ jsx(Button, { onClick: () => void run(async () => {
              await storage.chooseFolder?.();
              await list();
            }), children: "Choose local folder" }),
            " ",
            /* @__PURE__ */ jsx(Button, { onClick: () => setConnecting(true), children: "Connect to Studio" }),
            /* @__PURE__ */ jsxs("p", { children: [
              "Local files stay in the folder you choose. Use Documents/Aether/",
              cfg.brand.replace("Aether ", ""),
              " or another folder. Studio sharing and revision services require a server connection."
            ] })
          ] }),
          notice && /* @__PURE__ */ jsxs("p", { className: "library-notice", role: "status", children: [
            notice,
            /* @__PURE__ */ jsx(IconButton, { label: "Dismiss notification", onClick: () => setNotice(""), children: /* @__PURE__ */ jsx(AetherIcon, { name: "close" }) })
          ] }),
          /* @__PURE__ */ jsx(ApplicationListHeading, { children: view === "home" ? "Recently opened" : view === "organization" ? activeOrganization?.name ?? "Workspaces" : view === "workspace" ? workspace : titles[view] }),
          (view === "personal" || view === "workspace" || view === "organization" || folders.length > 0) && /* @__PURE__ */ jsx(Breadcrumbs, { items: [
            ...view === "workspace" || view === "organization" ? [{ id: "organization", label: activeOrganization?.name ?? "Organization" }] : [],
            ...view === "organization" ? [{ id: "workspaces", label: "Workspaces" }] : [{ id: "root", label: view === "workspace" ? workspace : "My files" }, ...folders.map((folder) => ({ id: folder.id, label: folder.name }))]
          ], onNavigate: (id) => {
            if (id === "organization") {
              setOrganizationID(activeOrganization?.id ?? null);
              navigate("organization");
            } else if (id !== "workspaces") visitFolder(id === "root" ? [] : folders.slice(0, folders.findIndex((f) => f.id === id) + 1));
          } }),
          /* @__PURE__ */ jsx(ApplicationListControls, { filters: /* @__PURE__ */ jsxs("div", { className: "aui-file-type-filters", role: "group", "aria-label": "Filter files by type", children: [
            /* @__PURE__ */ jsx("button", { type: "button", "aria-pressed": typeFilter === "all", onClick: () => setTypeFilter("all"), children: "All" }),
            view !== "organization" && cfg.types.map((type) => /* @__PURE__ */ jsxs("button", { type: "button", "aria-pressed": typeFilter === type.id, onClick: () => setTypeFilter(type.id), children: [
              /* @__PURE__ */ jsx(FileIcon, { icon: type.icon, size: 16 }),
              type.label
            ] }, type.id))
          ] }), search: /* @__PURE__ */ jsx("input", { "aria-label": "Filter by name or person", placeholder: "Filter by name or person", value: nameFilter, onChange: (e) => setNameFilter(e.target.value) }), actions: /* @__PURE__ */ jsxs("div", { className: "library-list-tools", children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                className: "library-tool library-selected-chip",
                style: { visibility: selectedIds.size ? "visible" : "hidden" },
                "aria-label": "Clear selection",
                onClick: () => {
                  setSelected(null);
                  setSelectedIds(/* @__PURE__ */ new Set());
                },
                children: [
                  /* @__PURE__ */ jsx(AetherIcon, { name: "close" }),
                  " ",
                  selectedIds.size,
                  " selected"
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              ToolMenu,
              {
                label: "Sort",
                icon: /* @__PURE__ */ jsx(AetherIcon, { name: "sort-chevron" }),
                onPick: (id) => {
                  if (id === "asc" || id === "desc") setSortAsc(id === "asc");
                  else setSortKey(id);
                },
                items: [
                  { id: "opened", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "history" }), label: "Opened", checked: sortKey === "opened" },
                  { id: "name", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "text" }), label: "Name", checked: sortKey === "name" },
                  { id: "owner", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "person" }), label: "Owner", checked: sortKey === "owner" },
                  { id: "asc", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "arrow-up" }), label: "Ascending", checked: sortAsc },
                  { id: "desc", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "arrow-down" }), label: "Descending", checked: !sortAsc }
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              ToolMenu,
              {
                label: "",
                ariaLabel: "File view",
                icon: /* @__PURE__ */ jsx(AetherIcon, { name: grid ? "layout" : "items" }),
                onPick: (id) => setGrid(id === "grid"),
                items: [
                  { id: "list", label: "List view", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "items", width: 15, height: 15 }), checked: !grid },
                  { id: "grid", label: "Grid view", icon: /* @__PURE__ */ jsx(AetherIcon, { name: "layout", width: 15, height: 15 }), checked: grid }
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                className: "library-tool",
                "aria-pressed": showDetails,
                onClick: () => {
                  const next = !showDetails;
                  setShowDetails(next);
                  writeDetailsPreference(app, next);
                },
                children: [
                  /* @__PURE__ */ jsx(AetherIcon, { name: "sidebar" }),
                  " Details"
                ]
              }
            )
          ] }) }),
          directoryError && /* @__PURE__ */ jsxs("p", { role: "alert", children: [
            "Workspace directory: ",
            directoryError
          ] }),
          view === "workspace" && /* @__PURE__ */ jsxs("p", { className: "library-note", children: [
            workspace,
            " \xB7 ",
            cfg.brand,
            " files and shared folders. Access follows this workspace\u2019s permissions."
          ] }),
          view === "shared" && /* @__PURE__ */ jsx("p", { className: "library-note", children: "Files individually shared with you will appear here once per-user sharing lands on the host. Workspace files live under your workspace in the sidebar." }),
          view === "trash" && /* @__PURE__ */ jsx("p", { className: "library-note", children: "Deleted files will be recoverable here once host-side deletion lands." }),
          /* @__PURE__ */ jsxs("div", { className: "library-listing", children: [
            /* @__PURE__ */ jsx(
              "div",
              {
                className: "library-listing-main",
                "aria-busy": loading,
                onClick: (e) => {
                  if (e.target === e.currentTarget) setSelected(null);
                },
                children: loading ? /* @__PURE__ */ jsx("div", { className: "library-empty", role: "status", children: "Loading files\u2026" }) : listingError ? /* @__PURE__ */ jsxs("div", { className: "library-empty", role: "alert", children: [
                  /* @__PURE__ */ jsx("h3", { children: !storage.hosted && listingError === FOLDER_REQUIRED ? "Choose where to keep your files" : "Unable to load files" }),
                  /* @__PURE__ */ jsx("p", { children: listingError }),
                  /* @__PURE__ */ jsx(Button, { onClick: () => void list(), children: "Retry" })
                ] }) : tableRows.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "library-empty", children: [
                  /* @__PURE__ */ jsx(AetherIcon, { name: "folder", width: 48, height: 48 }),
                  /* @__PURE__ */ jsx("h3", { children: query || nameFilter || typeFilter !== "all" ? view === "organization" ? "No matching workspaces" : "No matching files" : view === "home" || view === "recent" ? "Your recent work will appear here" : view === "organization" ? "No workspaces available" : "This folder is ready for your work" }),
                  /* @__PURE__ */ jsxs("p", { children: [
                    query || nameFilter || typeFilter !== "all" ? "Try another search." : view === "organization" ? "Ask your organization manager for workspace access." : cfg.emptyHint,
                    (nameFilter || typeFilter !== "all") && /* @__PURE__ */ jsx(Button, { onClick: () => {
                      setNameFilter("");
                      setTypeFilter("all");
                    }, children: "Clear filters" })
                  ] })
                ] }) : grid ? /* @__PURE__ */ jsxs("div", { className: "library-grid", children: [
                  childWorkspaces.map((entry) => /* @__PURE__ */ jsxs("button", { onClick: () => {
                    setWorkspaceID(entry.id);
                    navigate("workspace");
                  }, children: [
                    /* @__PURE__ */ jsx(WorkspaceIcon, { name: entry.name }),
                    /* @__PURE__ */ jsx("strong", { children: entry.name }),
                    /* @__PURE__ */ jsx("small", { children: "Workspace" })
                  ] }, entry.id)),
                  shown.map((file) => /* @__PURE__ */ jsxs(
                    "button",
                    {
                      className: selected?.id === file.id ? "selected" : "",
                      onClick: () => setSelected(file),
                      onDoubleClick: () => open(file),
                      onKeyDown: (event) => {
                        if (event.key === "Enter") {
                          event.preventDefault();
                          open(file);
                        }
                      },
                      onContextMenu: (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setSelected(file);
                        setMenu({ x: e.clientX, y: e.clientY, file });
                      },
                      children: [
                        /* @__PURE__ */ jsx(FileObjectPreview, { file, app, preview: cfg.preview, request: api, size: "gallery" }),
                        /* @__PURE__ */ jsx("strong", { children: file.name }),
                        /* @__PURE__ */ jsx("small", { children: file.owner })
                      ]
                    },
                    file.id
                  ))
                ] }) : /* @__PURE__ */ jsx(
                  ApplicationFileTable,
                  {
                    sort: { id: sortKey, ascending: sortAsc },
                    onSort: (id) => {
                      if (id === sortKey) setSortAsc(!sortAsc);
                      else setSortKey(id);
                    },
                    columns: [
                      { id: "type", label: "Type", render: (row) => row.entry ? "Workspace" : row.file.kind === "folder" ? "Folder" : fileTypeFor({ ...row.file, app }).id === "project" || /\.acad$/i.test(row.name) ? "Hybrid Design" : fileTypeFor({ ...row.file, app }).label },
                      { id: "opened", sortable: true, label: view === "home" || view === "recent" ? "Opened" : "Modified", render: (file) => file.date },
                      { id: "owner", sortable: true, label: "Owner", render: (file) => file.owner, secondary: true }
                    ],
                    rows: tableRows,
                    selectedIds,
                    onSelectedIdsChange: setSelectedIds,
                    onSelect: (row) => setSelected(row.file ?? null),
                    onOpen: (row) => {
                      if (row.entry) {
                        setWorkspaceID(row.entry.id);
                        navigate("workspace");
                      } else if (row.file) open(row.file);
                    },
                    onContextMenu: (row, event) => {
                      event.preventDefault();
                      event.stopPropagation();
                      setSelected(row.file ?? null);
                      setMenu({ x: event.clientX, y: event.clientY, file: row.file, workspace: row.entry });
                    }
                  }
                )
              }
            ),
            showDetails && /* @__PURE__ */ jsx("aside", { className: "library-details studio-file-inspector", children: selected ? /* @__PURE__ */ jsx(
              FileDetails,
              {
                name: selected.name,
                icon: /* @__PURE__ */ jsx(FileObjectPreview, { file: selected, app, preview: cfg.preview, request: api, size: "details" }),
                subtitle: /\.acad$/i.test(selected.name) ? "Hybrid Design" : fileTypeFor({ ...selected, app }).label,
                accessNote: selected.scope === "workspace" ? "Access follows this workspace\u2019s permissions" : "Only you",
                information: [
                  { label: "Owner", value: selected.owner },
                  { label: "Modified", value: new Date(selected.modified * 1e3).toLocaleString() },
                  ...selected.kind === "file" ? [{ label: "Size", value: `${Math.max(1, Math.round(selected.size / 1024))} KB` }] : []
                ]
              }
            ) : /* @__PURE__ */ jsx(Inspector, { children: /* @__PURE__ */ jsxs("div", { className: "library-details-empty", children: [
              /* @__PURE__ */ jsx(AetherIcon, { name: "document", width: 70, height: 70 }),
              /* @__PURE__ */ jsx("p", { children: "Select a file or folder to see its details." })
            ] }) }) })
          ] })
        ]
      }
    ),
    storage.hosted && showHistory && selected && /* @__PURE__ */ jsx(
      DocumentHistory,
      {
        file: { ...selected, app },
        onClose: () => setShowHistory(false),
        onChanged: async () => {
          await list();
        }
      }
    ),
    connecting && /* @__PURE__ */ jsx("div", { className: "library-modal", children: /* @__PURE__ */ jsxs("form", { role: "dialog", "aria-modal": "true", "aria-label": "Connect to Studio", onSubmit: (event) => {
      event.preventDefault();
      try {
        const url = new URL(server);
        if (!["https:", "http:"].includes(url.protocol) || url.username || url.password || url.pathname !== "/" || url.search || url.hash) throw Error("Enter the Studio server address, for example https://aetherstudio.local:8780.");
        url.pathname = `/${app}/`;
        location.assign(url.href);
      } catch (problem) {
        setError(problem.message);
      }
    }, children: [
      /* @__PURE__ */ jsx("h2", { children: "Connect to Studio" }),
      /* @__PURE__ */ jsx("p", { children: "Open your server workspace and sign in. Local files stay in your chosen folder." }),
      /* @__PURE__ */ jsx(TextField, { "aria-label": "Studio server address", placeholder: "https://aetherstudio.local:8780", value: server, onChange: (event) => setServer(event.target.value), required: true }),
      error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
      /* @__PURE__ */ jsx(Button, { onClick: () => setConnecting(false), children: "Cancel" }),
      /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", children: "Connect" })
    ] }) }),
    dialog && /* @__PURE__ */ jsx("div", { className: "library-modal", children: /* @__PURE__ */ jsxs(
      "form",
      {
        role: "dialog",
        "aria-modal": "true",
        "aria-label": dialog === "folder" ? "New folder" : "Rename",
        onSubmit: (e) => {
          e.preventDefault();
          void run(edit);
        },
        children: [
          /* @__PURE__ */ jsx("h2", { children: dialog === "folder" ? "New folder" : "Rename" }),
          /* @__PURE__ */ jsxs("label", { children: [
            "Name",
            /* @__PURE__ */ jsx(
              TextField,
              {
                "aria-label": "Name",
                value: name,
                onChange: (e) => setName(e.target.value),
                autoFocus: true,
                required: true,
                maxLength: 180
              }
            )
          ] }),
          error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Button, { onClick: () => setDialog(null), children: "Cancel" }),
            /* @__PURE__ */ jsx(Button, { primary: true, type: "submit", disabled: busy, children: dialog === "folder" ? "Create folder" : "Save name" })
          ] })
        ]
      }
    ) })
  ] }) });
}
export {
  ApplicationHome
};
