const defaultLibraryPreferences = { designKind: "part", startPage: "home", destination: "personal", view: "list", showUpdates: true, objectPreviews: true, lengthUnit: "mm", angleUnit: "deg", decimals: 3 };
function readLibraryPreferences(app) {
  let raw = {};
  try {
    raw = JSON.parse(localStorage.getItem(`aether-${app}.library-preferences.v1`) || "{}");
  } catch {
  }
  if (!raw || typeof raw !== "object") raw = {};
  const base = defaultLibraryPreferences;
  return {
    designKind: raw.designKind === "assembly" || raw.designKind === "project" ? raw.designKind : "part",
    startPage: ["home", "personal", "workspace"].includes(raw.startPage ?? "") ? raw.startPage : base.startPage,
    destination: raw.destination === "workspace" ? "workspace" : "personal",
    objectPreviews: raw.objectPreviews !== false,
    view: raw.view === "grid" ? "grid" : "list",
    showUpdates: raw.showUpdates !== false,
    lengthUnit: ["mm", "cm", "m", "in", "ft"].includes(raw.lengthUnit ?? "") ? raw.lengthUnit : base.lengthUnit,
    angleUnit: raw.angleUnit === "rad" ? "rad" : "deg",
    decimals: Number.isInteger(raw.decimals) && raw.decimals >= 0 && raw.decimals <= 8 ? raw.decimals : base.decimals
  };
}
function writeLibraryPreferences(app, value) {
  localStorage.setItem(`aether-${app}.library-preferences.v1`, JSON.stringify(value));
}
export {
  defaultLibraryPreferences,
  readLibraryPreferences,
  writeLibraryPreferences
};
