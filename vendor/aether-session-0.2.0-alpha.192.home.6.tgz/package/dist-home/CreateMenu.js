import { jsx, jsxs } from "react/jsx-runtime";
import { FileIcon, MenuButton, SidebarLabel } from "@aether/ui";
function CreateMenu({ onChoose, disabled, items = [] }) {
  const kinds = items.filter(([id]) => id !== "folder" && id !== "import");
  const menu = [
    { id: "folder", label: "Folder", icon: /* @__PURE__ */ jsx(FileIcon, { icon: "file-folder", size: 18 }) },
    { id: "import", label: "Files upload", icon: /* @__PURE__ */ jsx(FileIcon, { icon: "import", size: 18 }), separatorBefore: true },
    ...kinds.map(([id, label, icon], index) => ({
      id,
      label,
      icon: /* @__PURE__ */ jsx(FileIcon, { icon, size: 18 }),
      separatorBefore: index === 0
    }))
  ];
  return /* @__PURE__ */ jsxs(
    MenuButton,
    {
      density: "comfortable",
      className: "library-create",
      label: "Create or upload",
      disabled,
      placement: "bottom-start",
      items: menu,
      onSelect: (id) => onChoose(id),
      children: [
        /* @__PURE__ */ jsx("span", { className: "library-create-plus", "aria-hidden": "true", children: "+" }),
        /* @__PURE__ */ jsx(SidebarLabel, { children: "Create or upload" })
      ]
    }
  );
}
export {
  CreateMenu
};
