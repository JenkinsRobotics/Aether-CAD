import { useCallback, useEffect, useRef, useState } from "react";
import { inLibraryWorkspace } from "./library-location.js";
import { api } from "@aether/session/library/api";
function useLibraryListing({ app, view, parent, query, location, request = api }) {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const generation = useRef(0);
  const key = JSON.stringify([app, view, parent, query, location?.organization, location?.workspace]);
  const currentKey = useRef(key);
  currentKey.current = key;
  const reload = useCallback(async () => {
    if (key !== currentKey.current) return null;
    const sequence = ++generation.current;
    const current = () => sequence === generation.current && key === currentKey.current;
    setLoading(true);
    setError("");
    try {
      const result = view === "organization" || view === "trash" || view === "shared" ? { files: [] } : await request("/api/library/list", {
        app,
        view: view === "home" ? query ? "personal" : "recent" : view,
        parent,
        query
      });
      if (!current()) return null;
      const visible = view === "workspace" ? inLibraryWorkspace(result.files, location) : result.files;
      setFiles(visible);
      return visible;
    } catch (cause) {
      if (current()) {
        setFiles([]);
        setError(cause instanceof Error ? cause.message : "Unable to load files.");
      }
      return null;
    } finally {
      if (current()) setLoading(false);
    }
  }, [app, view, parent, query, key, request]);
  useEffect(() => {
    setFiles([]);
    void reload();
    return () => {
      generation.current++;
    };
  }, [reload]);
  return { files, loading, error, reload };
}
export {
  useLibraryListing
};
