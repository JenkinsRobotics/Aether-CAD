function isStudioHosted() {
  return typeof document !== "undefined" && !!document.querySelector('meta[name="aether-runtime"][content="studio"], script[src="/suite/account.js"]');
}
function isLocalDocument() {
  return !isStudioHosted() && typeof location !== "undefined" && new URLSearchParams(location.search).get("storage") === "local";
}
function shouldShowHome(editorKeys = []) {
  const query = new URLSearchParams(location.search);
  return !["document", "editor", "new", "demo", ...editorKeys].some((key) => query.has(key));
}
function documentURL(id) {
  const url = new URL(location.href);
  url.search = "";
  url.hash = "";
  url.searchParams.set("document", id);
  if (isLocalDocument()) url.searchParams.set("storage", "local");
  return url.href;
}
export {
  documentURL,
  isLocalDocument,
  isStudioHosted,
  shouldShowHome
};
