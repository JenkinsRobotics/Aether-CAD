import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { SettingsWindow, SettingsCard, SettingsRow, SelectField, Button, NumberField } from "@aether/ui";
import { defaultLibraryPreferences } from "./library-preferences.js";
function LibrarySettings({ design, hosted, open, name, workspace, preferences, onChange, onClose }) {
  const [pane, setPane] = useState("general");
  const set = (patch) => onChange({ ...preferences, ...patch });
  return /* @__PURE__ */ jsx(SettingsWindow, { open, title: `${name} settings`, sections: [{ title: name, panes: [{ id: "general", label: "General" }, { id: "workspace", label: "Default workspace" }, ...!!design ? [{ id: "units", label: "Units" }] : [], ...hosted ? [{ id: "extensions", label: "Extensions" }] : []] }], activePaneID: pane, onSelectPane: setPane, onClose, children: pane === "general" ? /* @__PURE__ */ jsxs(SettingsCard, { title: "General", caption: "App preferences are saved in this browser. Changes to startup defaults apply the next time you open the library.", children: [
    /* @__PURE__ */ jsx(SettingsRow, { label: "Start page", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Start page", value: preferences.startPage, options: [{ value: "home", label: "Home" }, { value: "personal", label: "My files" }, ...hosted ? [{ value: "workspace", label: workspace }] : []], onChange: (e) => set({ startPage: e.target.value }) }) }),
    /* @__PURE__ */ jsx(SettingsRow, { label: "Default file view", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Default file view", value: preferences.view, options: [{ value: "list", label: "List" }, { value: "grid", label: "Grid" }], onChange: (e) => set({ view: e.target.value }) }) }),
    /* @__PURE__ */ jsx(SettingsRow, { label: "Table thumbnails", caption: "Gallery and Details always try to show the saved object. Empty or unsupported files use a file icon.", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Table thumbnails", value: preferences.objectPreviews ? "preview" : "icon", options: [{ value: "preview", label: "Object previews" }, { value: "icon", label: "File type icons" }], onChange: (e) => set({ objectPreviews: e.target.value === "preview" }) }) }),
    /* @__PURE__ */ jsx(SettingsRow, { label: "What\u2019s new", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Show updates", value: preferences.showUpdates ? "show" : "hide", options: [{ value: "show", label: "Show on Home" }, { value: "hide", label: "Hide on Home" }], onChange: (e) => set({ showUpdates: e.target.value === "show" }) }) }),
    /* @__PURE__ */ jsx(Button, { onClick: () => onChange({ ...defaultLibraryPreferences }), children: "Reset app defaults" })
  ] }) : pane === "workspace" ? /* @__PURE__ */ jsxs(SettingsCard, { title: "Default workspace", caption: "Choose where files created from Home are saved. Creating inside a folder or workspace continues to use that location.", children: [
    !!design && /* @__PURE__ */ jsx(SettingsRow, { label: "Default design", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Default design", value: preferences.designKind, options: design.kinds.map((kind) => ({ value: kind.id, label: kind.title })), onChange: (e) => set({ designKind: e.target.value }) }) }),
    /* @__PURE__ */ jsx(SettingsRow, { label: "New file location", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "New file location", value: preferences.destination, options: [{ value: "personal", label: "My files" }, ...hosted ? [{ value: "workspace", label: workspace }] : []], onChange: (e) => set({ destination: e.target.value }) }) }),
    /* @__PURE__ */ jsx("p", { children: "Editor docking and panel placement are managed in the editor\u2019s Layout settings. Toolbars, sidebar tabs and spacing are available in the shared settings below." })
  ] }) : pane === "units" ? /* @__PURE__ */ jsxs(SettingsCard, { title: "New document units", caption: "Applies to newly created CAD documents. Existing documents retain their own Workspace units. Geometry is stored in millimeters; these preferences control input and display.", children: [
    /* @__PURE__ */ jsx(SettingsRow, { label: "Length", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Default length unit", value: preferences.lengthUnit, options: [{ value: "mm", label: "Millimeters" }, { value: "cm", label: "Centimeters" }, { value: "m", label: "Meters" }, { value: "in", label: "Inches" }, { value: "ft", label: "Feet" }], onChange: (e) => set({ lengthUnit: e.target.value }) }) }),
    /* @__PURE__ */ jsx(SettingsRow, { label: "Angle", children: /* @__PURE__ */ jsx(SelectField, { "aria-label": "Default angle unit", value: preferences.angleUnit, options: [{ value: "deg", label: "Degrees" }, { value: "rad", label: "Radians" }], onChange: (e) => set({ angleUnit: e.target.value }) }) }),
    /* @__PURE__ */ jsx(SettingsRow, { label: "Display decimals", children: /* @__PURE__ */ jsx(NumberField, { "aria-label": "Default display decimals", min: 0, max: 8, precision: 0, value: preferences.decimals, onCommit: (value) => set({ decimals: value }) }) })
  ] }) : /* @__PURE__ */ jsxs(SettingsCard, { title: "Extensions", caption: "Installed extensions and agent connections are managed by Aether Studio. Availability depends on your account and server permissions.", children: [
    /* @__PURE__ */ jsx("p", { children: "Open the extension manager to review installed plugins and available connections." }),
    /* @__PURE__ */ jsx(Button, { onClick: () => location.assign("/?section=plugins"), children: "Manage extensions" }),
    /* @__PURE__ */ jsx("p", { children: "Installing third-party tool extensions is not supported yet." })
  ] }) });
}
export {
  LibrarySettings
};
