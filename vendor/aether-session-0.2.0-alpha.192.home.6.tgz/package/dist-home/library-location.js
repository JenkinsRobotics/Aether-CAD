function inLibraryWorkspace(files, location) {
  if (!location?.workspace) return [];
  return files.filter((file) => file.organization === location.organization && file.workspace === location.workspace);
}
export {
  inLibraryWorkspace
};
