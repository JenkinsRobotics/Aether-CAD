import { api } from "@aether/session/library/api";
import { driveRequest } from "@aether/session/library/drive-api";
import { localDocumentRequest, chooseLocalFolder } from "../local-documents";
import { isStudioHosted } from "./runtime.js";
function createHomeStorage(app, hosted = isStudioHosted()) {
  const request = hosted ? api : async (path, body) => {
    if (!path.startsWith("/api/library/")) throw Error("This operation requires Aether Studio.");
    return localDocumentRequest(app, path.slice("/api/library/".length), { ...body });
  };
  return {
    hosted,
    request,
    ...!hosted ? { chooseFolder: () => chooseLocalFolder(app) } : {},
    directory: () => hosted ? driveRequest("context") : Promise.resolve({ organizations: [], workspaces: [] }),
    openURL: (editorURL, id) => {
      const url = new URL(editorURL, location.href);
      url.searchParams.set("document", id);
      if (!hosted) url.searchParams.set("storage", "local");
      return url.href;
    },
    createFile: async (file, destination) => {
      const bytes = new Uint8Array(await file.arrayBuffer());
      let raw = "";
      for (let i = 0; i < bytes.length; i += 8192) raw += String.fromCharCode(...bytes.subarray(i, i + 8192));
      return request("/api/library/create", { app, ...destination, name: file.name, kind: "file", data_base64: btoa(raw) });
    }
  };
}
export {
  createHomeStorage
};
