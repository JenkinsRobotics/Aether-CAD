import { jsx } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { FileIcon } from "@aether/ui";
import { api } from "@aether/session/library/api";
import "./FileObjectPreview.css";
const previews = /* @__PURE__ */ new Map();
let queue = Promise.resolve();
if (typeof document !== "undefined") document.addEventListener("aether-account", () => previews.clear());
function requestPreview(app, file, preview, request) {
  const key = `${app}/${file.id}/${file.revision}`;
  const existing = previews.get(key);
  if (existing) return existing;
  const task = queue.then(async () => {
    const saved = await request("/api/library/read_revision", { app, id: file.id, revision: file.revision });
    const bytes = Uint8Array.from(atob(saved.data_base64), (char) => char.charCodeAt(0));
    return { image: await preview.render(new TextDecoder().decode(bytes)), reason: void 0 };
  }).catch((error) => ({ image: null, reason: error instanceof Error ? error.message : "Preview unavailable" }));
  queue = task;
  previews.set(key, task);
  if (previews.size > 48) previews.delete(previews.keys().next().value);
  return task;
}
function FileObjectPreview({ file, app, size = "row", enabled = true, preview, request = api }) {
  const ref = useRef(null);
  const [image, setImage] = useState(null);
  const [reason, setReason] = useState("");
  const supported = !!preview && file.kind === "file" && preview.accept.test(file.name);
  useEffect(() => {
    setImage(null);
    setReason("");
    if (!enabled || !supported) return;
    let live = true;
    const load = () => {
      setReason("Loading preview\u2026");
      void requestPreview(app, file, preview, request).then((value) => {
        if (live) {
          setImage(value.image);
          setReason(value.reason ?? "");
        }
      });
    };
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        observer.disconnect();
        load();
      }
    }, { rootMargin: "120px" });
    if (ref.current) observer.observe(ref.current);
    return () => {
      live = false;
      observer.disconnect();
    };
  }, [app, file.id, file.revision, file.name, enabled, supported, preview, request]);
  return /* @__PURE__ */ jsx("span", { ref, className: "library-object-preview", "data-size": size, "data-preview-supported": supported, "data-preview-enabled": enabled, title: image ? `Saved object preview: ${file.name}` : `${file.name} \u2014 ${reason || "file type icon"}`, children: enabled && image ? /* @__PURE__ */ jsx("img", { src: image, alt: `Preview of ${file.name}` }) : /* @__PURE__ */ jsx(FileIcon, { file: { ...file, app }, size: size === "row" ? 28 : 64 }) });
}
export {
  FileObjectPreview
};
