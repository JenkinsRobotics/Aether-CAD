import { jsx, jsxs } from "react/jsx-runtime";
import { useMemo, useState } from "react";
import {
  Button,
  DocumentVersionPanel,
  DocumentCollaborationPanel
} from "@aether/ui";
import { documentRequest } from "@aether/session/documents";
function DocumentHistory({
  file,
  onClose,
  onChanged
}) {
  const [tab, setTab] = useState("versions");
  const app = file.app ?? "cad";
  const connection = useMemo(
    () => ({
      key: `${app}:${file.id}`,
      name: file.name,
      writable: file.writable,
      call: (action, data = {}) => documentRequest(app, action, { ...data, id: file.id }),
      flush: async () => {
      },
      reload: onChanged,
      openBranch: async (branch) => {
        location.assign(
          `/${app}/index.html?document=${encodeURIComponent(file.id)}&branch=${encodeURIComponent(branch)}`
        );
      }
    }),
    [file.id, file.writable, app]
  );
  return /* @__PURE__ */ jsx("div", { className: "library-modal", children: /* @__PURE__ */ jsxs(
    "section",
    {
      className: "history-dialog",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": "Document history",
      children: [
        /* @__PURE__ */ jsxs("header", { children: [
          /* @__PURE__ */ jsx("h2", { children: file.name }),
          /* @__PURE__ */ jsx(Button, { onClick: onClose, children: "Close" })
        ] }),
        /* @__PURE__ */ jsx("nav", { "aria-label": "Document services", children: ["versions", "comments", "notes", "tasks", "reminders"].map((id) => /* @__PURE__ */ jsx(
          Button,
          {
            "aria-pressed": tab === id,
            onClick: () => setTab(id),
            children: id === "versions" ? "Versions and history" : id === "tasks" ? "Action items" : id.charAt(0).toUpperCase() + id.slice(1)
          },
          id
        )) }),
        tab === "versions" ? /* @__PURE__ */ jsx(DocumentVersionPanel, { connection }) : /* @__PURE__ */ jsx(DocumentCollaborationPanel, { connection, kind: tab })
      ]
    }
  ) });
}
export {
  DocumentHistory
};
