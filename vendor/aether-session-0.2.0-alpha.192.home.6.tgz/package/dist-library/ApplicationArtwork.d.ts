declare const artwork: {
    studio: string;
    cad: string;
    animation: string;
    map: string;
    drive: string;
    io: string;
    sketch: string;
};
declare const heroes: {
    io: string;
    sketch: string;
    cad: string;
    animation: string;
    map: string;
    drive: string;
};
/** Full-size welcome artwork belongs to Studio's home bundle, not the UI barrel. */
export declare function ApplicationArtwork({ app }: {
    app: keyof typeof artwork;
}): import("react").JSX.Element;
export declare function ApplicationHeroArtwork({ app }: {
    app: keyof typeof heroes;
}): import("react").JSX.Element;
export {};
