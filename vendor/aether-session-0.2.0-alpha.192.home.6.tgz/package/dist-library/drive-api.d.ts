export interface DriveFile {
    id: string;
    name: string;
    kind: "file" | "folder";
    app: string;
    scope: string;
    parent: string | null;
    organization: string;
    workspace: string | null;
    owner: string;
    owner_id: string;
    size: number;
    modified: number;
    revision: number;
    structure_revision?: number;
    writable: boolean;
    manageable: boolean;
    role: string;
    favorite: boolean;
    versions: number;
    trashed: boolean;
    mime: string;
    opened?: number;
    deleted_at?: number | null;
    deleted_by?: string | null;
    created_by?: string | null;
    original_location?: string;
    shared_at?: number | null;
    shared_by?: string | null;
    modified_by?: string | null;
    child_count?: number | null;
    sharing?: "Private" | "Shared" | "Workspace";
    activity?: {
        action: string;
        author: string;
        created: number;
    } | null;
}
export interface DriveWorkspace {
    id: string;
    organization: string;
    name: string;
    role: string;
    is_default?: boolean;
    favorite?: boolean;
    opened?: number | null;
}
export interface DriveContext {
    organizations: {
        id: string;
        name: string;
        role: string;
    }[];
    workspaces: DriveWorkspace[];
    user: {
        id: string;
        username: string;
        name: string;
        admin: boolean;
    };
    apps: {
        id: string;
        name: string;
        url: string;
        enabled: boolean;
        installed: boolean;
    }[];
}
export interface DriveLocation {
    organization: string;
    workspace?: string | null;
    parent?: string | null;
}
export declare const driveRequest: <T>(action: string, data?: object) => Promise<T>;
export declare const bytes: (n: number) => string;
export declare const fileIcon: (file: DriveFile) => string;
export declare const fileType: (file: DriveFile) => string;
export declare function encodeFile(file: File): Promise<string>;
export declare function fileBlob(encoded: string, mime: string): Blob;
export declare function editorURL(file: DriveFile): string;
