export declare function createNativeFile<T>(app: string, kind: string, name: string, destination: object, service?: 'library' | 'drive'): Promise<T>;
