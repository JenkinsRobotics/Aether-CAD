import { type DriveContext } from "./drive-api.js";
export declare function DriveMembers({ context, organization, workspace, onClose, onChanged, }: {
    context: DriveContext;
    organization: string;
    workspace?: string;
    onClose: () => void;
    onChanged: () => void;
}): import("react").JSX.Element;
