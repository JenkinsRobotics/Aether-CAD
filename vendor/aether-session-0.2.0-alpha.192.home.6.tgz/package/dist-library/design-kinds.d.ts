import type { DesignKind } from "@aether/ui/new-design";
/** CAD-only design kinds. Hybrid uses the existing project document format. */
export declare const CAD_DESIGN_KINDS: readonly DesignKind[];
/** Unit systems offered beside every design kind. */
export declare const DESIGN_UNIT_OPTIONS: readonly [{
    readonly value: "mm";
    readonly label: "millimeter (mm)";
}, {
    readonly value: "cm";
    readonly label: "centimeter (cm)";
}, {
    readonly value: "m";
    readonly label: "meter (m)";
}, {
    readonly value: "in";
    readonly label: "inch (in)";
}, {
    readonly value: "ft";
    readonly label: "foot (ft)";
}];
