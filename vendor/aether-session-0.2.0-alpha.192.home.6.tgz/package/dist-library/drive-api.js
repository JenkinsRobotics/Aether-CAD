import { fileTypeFor } from "@aether/ui/file-types";
import { api } from "./api.js";
import { fileLinkRequest, memberUpdateRequest, directoryCreateRequest, fileCopyRequest, fileGrantRequest, fileFavoriteRequest, fileCreateRequest, fileEditRequest, fileRecycleRequest, workspacePreferenceRequest } from "@aether/session/documents";
const driveRequest = (action, data = {}) => action === "workspace_open" || action === "workspace_favorite" ? workspacePreferenceRequest(action, { ...data }) : action === "organization_create" || action === "workspace_create" ? directoryCreateRequest(action, { ...data }) : action === "link_create" || action === "link_revoke" ? fileLinkRequest(action, { ...data }) : action === "member_update" ? memberUpdateRequest({ ...data }) : action === "favorite" ? fileFavoriteRequest({ ...data }) : action === "trash" || action === "restore" ? fileRecycleRequest(action, { ...data }) : action === "rename" || action === "move" ? fileEditRequest(action, { ...data }) : action === "copy" ? fileCopyRequest({ ...data }) : action === "grant" ? fileGrantRequest({ ...data }) : action === "create" ? fileCreateRequest({ ...data }) : api("/api/drive/" + action, data);
const bytes = (n) => n < 1024 ? `${n} B` : n < 1024 ** 2 ? `${(n / 1024).toFixed(1)} KB` : n < 1024 ** 3 ? `${(n / 1024 ** 2).toFixed(1)} MB` : `${(n / 1024 ** 3).toFixed(1)} GB`;
const fileIcon = (file) => fileTypeFor(file).icon;
const fileType = (file) => fileTypeFor(file).label;
async function encodeFile(file) {
  const data = new Uint8Array(await file.arrayBuffer());
  let raw = "";
  for (let i = 0; i < data.length; i += 8192)
    raw += String.fromCharCode(...data.subarray(i, i + 8192));
  return btoa(raw);
}
function fileBlob(encoded, mime) {
  return new Blob([Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0))], {
    type: mime
  });
}
function editorURL(file) {
  return `/${file.app}/index.html?document=${encodeURIComponent(file.id)}`;
}
export {
  bytes,
  driveRequest,
  editorURL,
  encodeFile,
  fileBlob,
  fileIcon,
  fileType
};
