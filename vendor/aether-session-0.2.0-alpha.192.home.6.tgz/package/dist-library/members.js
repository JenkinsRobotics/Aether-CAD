import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { Button, Dialog } from "@aether/ui";
import { driveRequest } from "./drive-api.js";
function DriveMembers({
  context,
  organization,
  workspace,
  onClose,
  onChanged
}) {
  const organizationDefault = context.workspaces.some((w) => w.id === workspace && w.is_default && w.id !== "shared");
  const [members, setMembers] = useState([]), [user, setUser] = useState(""), [role, setRole] = useState(workspace ? "editor" : "member"), [error, setError] = useState(""), [busy, setBusy] = useState(false);
  const load = () => driveRequest("members", {
    organization,
    workspace
  }).then((r) => setMembers(r.members));
  useEffect(() => {
    void load().catch((e) => setError(e.message));
  }, [organization, workspace]);
  return /* @__PURE__ */ jsxs(
    Dialog,
    {
      open: true,
      title: workspace ? "Workspace members" : "Organization members",
      onClose,
      actions: /* @__PURE__ */ jsx(Button, { onClick: onClose, children: "Done" }),
      children: [
        /* @__PURE__ */ jsx("p", { children: workspace ? "Select an organization member and set their workspace access." : "Add an existing Studio account by username. Server administrators create accounts in Studio." }),
        organizationDefault && /* @__PURE__ */ jsx("p", { children: "All organization members can view this default workspace. Grant Editor to allow changes; organization owners manage access." }),
        /* @__PURE__ */ jsxs("div", { className: "drive-form-row", children: [
          /* @__PURE__ */ jsxs("label", { children: [
            workspace ? "Member" : "Username",
            workspace ? /* @__PURE__ */ jsxs(
              "select",
              {
                "aria-label": "Member",
                value: user,
                onChange: (e) => setUser(e.target.value),
                children: [
                  /* @__PURE__ */ jsx("option", { value: "", children: "Choose member" }),
                  members.map((m) => /* @__PURE__ */ jsx("option", { value: m.id, children: m.name }, m.id))
                ]
              }
            ) : /* @__PURE__ */ jsx(
              "input",
              {
                "aria-label": "Username",
                value: user,
                onChange: (e) => setUser(e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("label", { children: [
            "Role",
            /* @__PURE__ */ jsx(
              "select",
              {
                "aria-label": "Member role",
                value: role,
                onChange: (e) => setRole(e.target.value),
                children: (workspace ? ["viewer", "editor", "owner", "remove"] : ["member", "owner", "remove"]).map((r) => /* @__PURE__ */ jsx("option", { value: r, children: r === "remove" && organizationDefault ? "Use organization access (viewer)" : r }, r))
              }
            )
          ] }),
          /* @__PURE__ */ jsx(
            Button,
            {
              disabled: busy || !user,
              onClick: async () => {
                setBusy(true);
                setError("");
                try {
                  const target = members.find((m) => workspace ? m.id === user : m.username === user || m.id === user);
                  const expected = workspace ? target && "assigned_workspace_role" in target ? target.assigned_workspace_role : target?.workspace_role : target?.role;
                  await driveRequest("member_update", {
                    organization,
                    workspace,
                    user,
                    role,
                    expected_role: expected ?? null
                  });
                  await load();
                  onChanged();
                } catch (e) {
                  setError(e.message);
                } finally {
                  setBusy(false);
                }
              },
              children: "Apply access"
            }
          )
        ] }),
        /* @__PURE__ */ jsx("ul", { children: members.map((m) => /* @__PURE__ */ jsxs("li", { children: [
          m.name,
          " \xB7",
          " ",
          workspace ? m.workspace_role ?? "No workspace access" : m.role,
          m.id === context.user.id ? " (you)" : ""
        ] }, m.id)) }),
        error && /* @__PURE__ */ jsx("p", { role: "alert", children: error })
      ]
    }
  );
}
export {
  DriveMembers
};
