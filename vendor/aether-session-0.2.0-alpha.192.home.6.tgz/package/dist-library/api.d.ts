export declare function api<T>(path: string, body?: object): Promise<T>;
