import { api } from "./api.js";
import { encodeFile } from "./drive-api.js";
const factories = {
  cad: "/cad/create-document.js",
  map: "/map/create-document.js",
  animation: "/animation/create-document.js",
  sketch: "/sketch/create-document.js",
  io: "/io/create-document.js"
};
async function createNativeFile(app, kind, name, destination, service = "library") {
  if (app === "cad" && (kind === "assembly" || kind === "project")) {
    const base = name.trim().replace(kind === "assembly" ? /\.acasm$/i : /\.acad$/i, "").trim();
    return api("/api/library/project_create", { app, name: base, packaging: kind, ...destination });
  }
  const moduleURL = factories[app];
  if (!moduleURL) throw new Error("This app does not support file creation yet.");
  const product = await import(
    /* @vite-ignore */
    moduleURL
  );
  const file = await product.createDocument(name);
  return api(`/api/${service}/create`, { app, name: file.name, kind: "file", data_base64: await encodeFile(file), ...destination });
}
export {
  createNativeFile
};
