import { BrowserDocument, type DirectoryHandle, type FileHandle } from '@aether/files';
import { isStudioHosted } from './home/runtime';
import { SaveError } from './autosave';
/** Ordinary files in a user-selected directory. IndexedDB stores only the granted
 * directory capability, never document contents. Studio never calls this adapter. */
export interface LocalDocument {
  id:string; app:string; name:string; kind:'file'|'folder'; scope:string; parent:string|null;
  organization:string; workspace:string|null; owner:string; writable:boolean;
  revision:number; modified:number; size:number; data_base64?:string; opened?:number;
}
type GrantedDirectory = DirectoryHandle & {name:string;queryPermission?:(options:{mode:string})=>Promise<string>};
const roots=new Map<string,GrantedDirectory>();
const fingerprints=new Map<string,string>();
export class LocalDocumentError extends SaveError {}
export const FOLDER_REQUIRED='Choose your local Documents folder to browse and save files.';
export const supportsLocalFolders=()=>typeof window!=='undefined'&&'showDirectoryPicker' in window;
async function savedRoot(app:string,value?:GrantedDirectory):Promise<GrantedDirectory|undefined> {
  return new Promise((resolve,reject)=>{
    const request=indexedDB.open('aether-local-folders-v1',1);
    request.onupgradeneeded=()=>request.result.createObjectStore('folders');
    request.onerror=()=>reject(request.error);
    request.onsuccess=()=>{
      const db=request.result,tx=db.transaction('folders',value?'readwrite':'readonly');
      const operation=value?tx.objectStore('folders').put(value,app):tx.objectStore('folders').get(app);
      let result:GrantedDirectory|undefined;
      operation.onsuccess=()=>{result=value??operation.result;};
      tx.oncomplete=()=>{db.close();resolve(result);};tx.onabort=()=>{db.close();reject(tx.error);};
    };
  });
}
/** Must be called from the user's click; never on page load or in hosted mode. */
export async function chooseLocalFolder(app:string):Promise<string> {
  if(isStudioHosted())throw Error('Local folder access is unavailable in a Studio-hosted application.');
  if(!supportsLocalFolders())throw Error('Direct folder access is unavailable in this browser. Use a browser with file-system access or the standalone desktop application.');
  const picker=(window as unknown as {showDirectoryPicker:(options:object)=>Promise<GrantedDirectory>}).showDirectoryPicker;
  const root=await picker({id:`aether-${app}`,mode:'readwrite',startIn:'documents'});
  await savedRoot(app,root);roots.set(app,root);return root.name;
}
async function rootFor(app:string):Promise<GrantedDirectory> {
  const root=roots.get(app)??await savedRoot(app);
  if(!root || (root.queryPermission && await root.queryPermission({mode:'readwrite'})!=='granted'))throw new LocalDocumentError(FOLDER_REQUIRED,403);
  roots.set(app,root);return root;
}
function components(id:unknown):string[] {
  if(typeof id!=='string'||!id||id.length>8192)throw Error('Choose a local file.');
  const parts=id.split('/');
  if(parts.some(part=>!part||part==='.'||part==='..'||/[\\\x00-\x1f]/.test(part)))throw Error('Invalid local file path.');
  return parts;
}
function nameOf(value:unknown):string {
  const parts=components(value);if(parts.length!==1||parts[0].length>180)throw Error('Enter a file name without path separators.');return parts[0];
}
async function folder(root:DirectoryHandle,path:unknown):Promise<DirectoryHandle> {
  let current=root;if(path)for(const part of components(path))current=await current.getDirectoryHandle(part);return current;
}
function encode(bytes:Uint8Array):string {let raw='';for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(raw);}
const decode=(value:unknown)=>Uint8Array.from(atob(String(value??'')),char=>char.charCodeAt(0));
async function inspect(app:string,id:string,handle:FileHandle,content=false):Promise<LocalDocument> {
  const doc=new BrowserDocument(handle,`${app}:${id}`,{locks:navigator.locks,crypto});
  const read=await doc.read(),blob=await handle.getFile();
  const revision=parseInt(read.file.sha256.slice(0,13),16)+1;
  fingerprints.set(`${app}:${id}:${revision}`,read.file.sha256);
  const parts=components(id);
  return {app,id,name:handle.name,kind:'file',scope:'personal',parent:parts.length>1?parts.slice(0,-1).join('/'):null,organization:'local',workspace:null,owner:'This device',writable:true,revision,modified:('lastModified' in blob?Number(blob.lastModified):Date.now())/1000,size:read.file.size_bytes,...(content?{data_base64:encode(read.content)}:{})};
}
export async function localDocumentRequest<T>(app:string,action:string,data:Record<string,unknown>={}):Promise<T> {
 try {
  if(data.branch && data.branch!=='Main')throw new LocalDocumentError('Branches require Aether Studio.',501);
  if(!['list','read','read_revision','create','save','rename','copy'].includes(action))throw new LocalDocumentError('This operation requires Aether Studio.',501);
  if(isStudioHosted())throw new LocalDocumentError('Hosted documents use Aether Studio storage.',403);
  const root=await rootFor(app);
  if(action==='list') {
    const directory=await folder(root,data.parent),files:LocalDocument[]=[];
    for await(const [name,entry] of directory.entries()) {
      if(name.startsWith('.')||!name.toLowerCase().includes(String(data.query??'').toLowerCase()))continue;
      const id=data.parent?`${data.parent}/${name}`:name;
      if(entry.kind==='file')files.push(await inspect(app,id,await directory.getFileHandle(name)));
      else files.push({id,app,name,kind:'folder',scope:'personal',parent:(data.parent as string)??null,organization:'local',workspace:null,owner:'This device',writable:true,revision:1,modified:0,size:0});
    }
    return {files} as T;
  }
  if(action==='create') {
    const name=nameOf(data.name),directory=await folder(root,data.parent),id=data.parent?`${data.parent}/${name}`:name;
    return await navigator.locks.request(`aether-local-create:${app}:${id}`,async()=>{
      for await(const [existing] of directory.entries())if(existing===name)throw new LocalDocumentError('A file with that name already exists here.',409);
      if(data.kind==='folder') {await directory.getDirectoryHandle(name,{create:true});return {id,app,name,kind:'folder',scope:'personal',parent:data.parent??null,organization:'local',workspace:null,owner:'This device',writable:true,revision:1,modified:Date.now()/1000,size:0} as T;}
      const handle=await directory.getFileHandle(name,{create:true}),doc=new BrowserDocument(handle,`${app}:${id}`,{locks:navigator.locks,crypto});
      const initial=await doc.read();
      if(initial.file.size_bytes!==0)throw new LocalDocumentError('Another application created this file. It was not overwritten.',409);
      await doc.save({kind:'content',sha256:initial.file.sha256},decode(data.data_base64));
      return await inspect(app,id,handle,true) as T;
    });
  }
  const parts=components(data.id),name=parts.at(-1)!,parent=parts.slice(0,-1).join('/'),id=parts.join('/'),directory=await folder(root,parent);
  const handle=await directory.getFileHandle(name),doc=new BrowserDocument(handle,`${app}:${id}`,{locks:navigator.locks,crypto});
  if(action==='read'||action==='read_revision') {
    const file=await inspect(app,id,handle,true);
    if(action==='read_revision'&&data.revision!==file.revision)throw new LocalDocumentError('The file changed. Refresh its preview.',409);
    return file as T;
  }
  if(action==='copy') {
    const read=await inspect(app,id,handle,true);
    return await localDocumentRequest<T>(app,'create',{parent:parent||null,name:read.name.replace(/(\.[^.]+)?$/,' copy$1'),data_base64:read.data_base64});
  }
  const expected=fingerprints.get(`${app}:${id}:${data.expected_revision}`);
  if(!expected)throw new LocalDocumentError('Reopen this file before saving. Keep a copy of unsaved edits.',409);
  if(action==='rename')throw new LocalDocumentError('Rename ordinary local files in your file manager, then refresh this page.',501);
  await doc.save({kind:'content',sha256:expected},decode(data.data_base64));
  return await inspect(app,id,handle,true) as T;
 }catch(error) {
  if(error instanceof SaveError)throw error;
  const code=(error as {code?:string}).code;
  throw new LocalDocumentError(error instanceof Error?error.message:String(error),code==='conflict'?409:code==='permission_denied'?403:code==='outcome_unknown'?500:400,false);
 }
}
