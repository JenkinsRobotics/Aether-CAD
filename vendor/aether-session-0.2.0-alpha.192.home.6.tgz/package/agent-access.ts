import type { AgentAccessService } from '@aether/ui/AgentServices';
/** Authenticated account transport; connection secrets are never persisted here. */
export const studioAgentAccessService: AgentAccessService = {
  get mcpURL() { return typeof location==='undefined'?'':`${location.origin}/mcp`; },
  async call<T>(action:'list'|'create'|'revoke', data:Record<string,unknown>={}):Promise<T> {
    const response=await fetch(`/api/automation/connections/${action}`,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    const result=await response.json();
    if(!response.ok)throw Error(result.error?.message??result.error??'Agent connections are unavailable.');
    return result as T;
  },
};
