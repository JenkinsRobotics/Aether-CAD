import type { ReactNode } from 'react';
import type { AetherIconName, ApplicationUpdate } from '@aether/ui';
import type { NewDesignDialog } from '@aether/ui/new-design';
import type { ComponentProps } from 'react';
import type { LibraryPreferences } from './library-preferences';
import type { HomeStorage } from './storage';
import type { LocalDocument } from '../local-documents';
export type HomeEntry = LocalDocument;
export interface HomeCreationContext {
  storage: HomeStorage;
  destination: {scope:string; parent:string|null; organization:string; workspace:string|null};
  preferences: LibraryPreferences;
}
/** Product-owned behavior. No product registry or engine is part of this package. */
export interface AppHomeDefinition {
  brand:string; appIcon:"cad"|"map"|"animation"|"io"|"sketch"; appUrl:string; accept:string; uploadPattern:RegExp;
  uploadHint:string; heroLead:string; emptyHint:string; fallbackIcon:AetherIconName;
  types: readonly {id:string; label:string; icon:AetherIconName; test:RegExp}[];
  menu: readonly (readonly [string,string,AetherIconName])[];
  start: readonly {kind:string; title:string; tagline:string; icon:AetherIconName; action?:'new-doc'|'dialog'|'import'|'navigate'; tooltip?:string; href?:string; requiresStudio?:boolean}[];
  navigation?: readonly {id:string; label:string; icon:AetherIconName; href:string; requiresStudio?:boolean}[];
  updates?:ApplicationUpdate[]; welcome?:ReactNode;
  design?: {kinds:ComponentProps<typeof NewDesignDialog>['kinds']; units:NonNullable<ComponentProps<typeof NewDesignDialog>['units']>['options']};
  preview?:{accept:RegExp; render:(text:string)=>Promise<string|null>};
  create:(kind:string,name:string,context:HomeCreationContext)=>Promise<HomeEntry>;
}
