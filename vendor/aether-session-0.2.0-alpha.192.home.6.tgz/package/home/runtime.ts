/** Selected deliberately; a failed Studio request must never switch storage. */
export function isStudioHosted(): boolean {
  return typeof document !== 'undefined' && !!document.querySelector('meta[name="aether-runtime"][content="studio"], script[src="/suite/account.js"]');
}
export function isLocalDocument(): boolean {
  return !isStudioHosted() && typeof location !== 'undefined' && new URLSearchParams(location.search).get('storage') === 'local';
}
export function shouldShowHome(editorKeys: readonly string[] = []): boolean {
  const query = new URLSearchParams(location.search);
  return !['document','editor','new','demo',...editorKeys].some(key=>query.has(key));
}

/** Retain the selected storage adapter when opening another document. */
export function documentURL(id:string):string {
  const url=new URL(location.href);url.search='';url.hash='';
  url.searchParams.set('document',id);
  if(isLocalDocument())url.searchParams.set('storage','local');
  return url.href;
}
