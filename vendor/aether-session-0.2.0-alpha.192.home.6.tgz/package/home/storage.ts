import { api } from '@aether/session/library/api';
import { driveRequest, type DriveContext } from '@aether/session/library/drive-api';
import { localDocumentRequest, chooseLocalFolder } from '../local-documents';
import { isStudioHosted } from './runtime';
import type { HomeEntry } from './types';
export interface HomeStorage {
  hosted:boolean;
  chooseFolder?:()=>Promise<string>;
  request:typeof api;
  directory:()=>Promise<DriveContext>;
  openURL:(editorURL:string,id:string)=>string;
  createFile:(file:File,destination:Record<string,unknown>)=>Promise<HomeEntry>;
}
export function createHomeStorage(app:string,hosted=isStudioHosted()):HomeStorage {
  const request:typeof api=hosted?api:async<T,>(path:string,body?:object)=>{
    if(!path.startsWith('/api/library/'))throw Error('This operation requires Aether Studio.');
    return localDocumentRequest<T>(app,path.slice('/api/library/'.length),{...body});
  };
  return {
    hosted,request,
    ...(!hosted ? {chooseFolder:()=>chooseLocalFolder(app)} : {}),
    directory:()=>hosted?driveRequest<DriveContext>('context'):Promise.resolve({organizations:[],workspaces:[]} as unknown as DriveContext),
    openURL:(editorURL,id)=>{
      const url=new URL(editorURL,location.href);url.searchParams.set('document',id);
      if(!hosted)url.searchParams.set('storage','local');
      return url.href;
    },
    createFile:async(file,destination)=>{
      const bytes=new Uint8Array(await file.arrayBuffer());let raw='';
      for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));
      return request<HomeEntry>('/api/library/create',{app,...destination,name:file.name,kind:'file',data_base64:btoa(raw)});
    },
  };
}
