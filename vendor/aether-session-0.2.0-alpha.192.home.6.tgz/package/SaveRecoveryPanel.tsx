import React from 'react';
import { DocumentSaveGuard, Dialog, Button } from '@aether/ui';
import type { SaveRecoveryController } from './save-recovery';

export function SaveRecoveryPanel<Base>({ controller, loading = false, error }: { controller: SaveRecoveryController<Base> | null; loading?: boolean; error?: string }) {
  const [, redraw] = React.useReducer(n => n + 1, 0);
  React.useEffect(() => controller?.subscribe(redraw), [controller]);
  if (!controller && loading) return <Dialog open title={error ? 'Document could not be opened' : 'Opening document'} onClose={() => {}}>
    <p role="status">{error ?? 'Checking the saved document and recovery copies…'}</p>
    {error && <><Button onClick={() => window.open(`/?next=${encodeURIComponent(location.pathname + location.search)}`, '_blank', 'noopener')}>Sign in</Button><Button onClick={() => location.reload()}>Retry opening document</Button></>}
  </Dialog>;
  if (!controller) return null;
  return <DocumentSaveGuard state={controller.state} recoveries={controller.recoveries}
    recoveryOpensTab onRecover={controller.recover} onKeepSaved={controller.keepSaved}
    onSignIn={controller.signIn} onRetry={controller.retry} onCopy={controller.copy}
    onDownload={controller.download} onOpenSaved={controller.openSaved} />;
}
