import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { MenuButton } from "./Menu.js";
import "./EnvironmentControl.css";
function EnvironmentControl({ actions, onSelect, opens = "down" }) {
  const [open, setOpen] = useState(false);
  const [up, setUp] = useState(false);
  const button = useRef(null);
  const toggle = () => {
    const control = button.current?.closest(".aui-environment-control");
    if (!open && opens === "side" && control) {
      const box = control.getBoundingClientRect(), right = box.left + 48 + actions.length * 38;
      const area = control.closest(".aui-shell-area");
      setUp(!!area && (right > area.getBoundingClientRect().right - 12 || [...area.querySelectorAll(":scope > .aui-shell-fledge > *")].some((card) => {
        const c = card.getBoundingClientRect();
        return c.width > 0 && c.left < right && c.right > box.left && c.top < box.bottom && c.bottom > box.top;
      })));
    }
    setOpen(!open);
  };
  const id = useId();
  useEffect(() => {
    if (!open) return;
    const close = (event) => {
      if (event.key !== "Escape" || event.defaultPrevented) return;
      const focused = event.target instanceof Element ? event.target : document.activeElement;
      if (focused?.closest(".aui-studio-camera-control")) return;
      setOpen(false);
      button.current?.focus();
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [open]);
  return /* @__PURE__ */ jsxs("div", { className: "aui-environment-control", "data-expanded": open, "data-opens": opens, "data-up": opens === "side" && up || void 0, style: { "--environment-actions": actions.length }, children: [
    /* @__PURE__ */ jsxs("div", { className: "aui-environment-surface", children: [
      /* @__PURE__ */ jsx("button", { ref: button, className: "aui-environment-toggle", type: "button", "aria-label": "Environment", title: open ? "Collapse environment" : "Expand environment", "aria-expanded": open, "aria-controls": id, onClick: toggle, children: /* @__PURE__ */ jsx(AetherIcon, { name: "lighting" }) }),
      /* @__PURE__ */ jsx("div", { id, className: "aui-environment-content", role: "group", "aria-label": "Environment and snapping controls", "aria-hidden": !open, inert: !open, children: actions.map((action) => action.items ? /* @__PURE__ */ jsxs(MenuButton, { className: "aui-environment-action", menuClassName: "aui-collection-popup", label: action.label, placement: opens !== "side" ? "bottom-end" : up ? "right-start" : "top-start", items: action.items, onSelect, disabled: action.disabled, children: [
        action.icon,
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-down", className: "aui-environment-action-caret" })
      ] }, action.id) : /* @__PURE__ */ jsx("button", { className: "aui-environment-action", type: "button", "aria-label": action.label, title: action.disabledReason ?? action.label, "aria-pressed": action.pressed, disabled: action.disabled, onClick: () => onSelect(action.id), children: action.icon }, action.id)) })
    ] }),
    /* @__PURE__ */ jsx("span", { className: "aui-environment-caption", children: "Environment" })
  ] });
}
export {
  EnvironmentControl
};
