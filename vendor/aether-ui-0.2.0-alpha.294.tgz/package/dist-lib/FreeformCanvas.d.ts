import { type ReactNode, type Ref } from "react";
import { type FreeformCamera, type FreeformItem, type FreeformPoint, type FreeformRect, type FreeformZoomLimits } from "./freeform-canvas-model.js";
import "./FreeformCanvas.css";
export type FreeformTool = "select" | "pen" | "connector" | "rectangle" | "rounded-rectangle" | "ellipse" | "text" | "sticky" | "table" | "attachment";
export type FreeformChangeType = "create" | "move" | "resize" | "nudge" | "edit" | "delete";
/** What a change did, so the host can label and group its undo steps. One gesture is one change. */
export interface FreeformChange {
    type: FreeformChangeType;
    ids: readonly string[];
}
export interface FreeformItemRendererProps {
    item: FreeformItem;
    selected: boolean;
    /** True after a double-click; the renderer may show editors and call onCommit. */
    editing: boolean;
    onCommit: (patch: Partial<FreeformItem>) => void;
}
export type FreeformItemRenderer = (props: FreeformItemRendererProps) => ReactNode;
/** Imperative camera control for host commands (menus, shortcuts, "zoom to device"). */
export interface FreeformCanvasController {
    panBy: (dx: number, dy: number) => void;
    /** Zoom to `zoom` around a viewport point (default: the centre). */
    zoomTo: (zoom: number, screen?: FreeformPoint) => void;
    /** Fit the given items, or all content when omitted. */
    fit: (ids?: readonly string[]) => void;
}
export interface FreeformCanvasProps {
    items: readonly FreeformItem[];
    onChange: (items: FreeformItem[], change: FreeformChange) => void;
    camera: FreeformCamera;
    onCameraChange: (camera: FreeformCamera) => void;
    selection: readonly string[];
    onSelectionChange: (ids: string[]) => void;
    /** Host-owned history. Cmd/Ctrl+Z and Shift+Cmd/Ctrl+Z (or Ctrl+Y) call these. */
    onUndo?: () => void;
    onRedo?: () => void;
    /** Add or replace renderers by item kind. Unknown kinds draw as a plain frame. */
    renderers?: Readonly<Record<string, FreeformItemRenderer>>;
    /** Toolbar tools, in order. Attachment shows only when onAttachFiles is set. */
    tools?: readonly FreeformTool[];
    /** Files picked from the toolbar or dropped on the canvas; the host stores them and adds items. */
    onAttachFiles?: (files: File[], at: FreeformPoint) => void;
    zoomLimits?: FreeformZoomLimits;
    createId?: () => string;
    controllerRef?: Ref<FreeformCanvasController>;
    defaultShowGrid?: boolean;
    defaultShowConnectors?: boolean;
    "aria-label"?: string;
    className?: string;
    /** Controlled tool. Built-in ids are FreeformTool; any id in `hostTools` belongs to the host. */
    tool?: string;
    onToolChange?: (tool: string) => void;
    /** Host content drawn in world space beneath the items, e.g. a vector drawing.
     * In the select tool, pointer presses that hit no item reach this layer. */
    layer?: ReactNode;
    /** Tools the host handles inside `layer`: the canvas only pans and zooms while one is active. */
    hostTools?: readonly string[];
    /** Extra world bounds included in "fit to content", e.g. the host layer's drawing. */
    contentBounds?: FreeformRect | null;
    /** false hides the built-in zoom and view controls; a StandardAppShell host puts them in its environment stack. */
    hud?: boolean;
    /** Controlled dot grid and connector visibility (otherwise internal, from the defaults). */
    showGrid?: boolean;
    onShowGridChange?: (shown: boolean) => void;
    showConnectors?: boolean;
    onShowConnectorsChange?: (shown: boolean) => void;
}
/** Readable text on a host-chosen #rrggbb fill; undefined keeps the theme ink. */
export declare function inkOn(fill?: string): string | undefined;
/** The built-in renderers. Hosts override any kind via `renderers`. */
export declare const freeformRenderers: Readonly<Record<string, FreeformItemRenderer>>;
/** An unbounded dot-grid canvas with free placement. Controlled: the host owns
 * items, camera and selection, and records history from onChange. Built-in
 * items cover shapes, text, sticky notes, pen strokes, images, attachments,
 * tables and connectors; hosts add their own kinds through `renderers`. */
export declare function FreeformCanvas(props: FreeformCanvasProps): import("react").JSX.Element;
