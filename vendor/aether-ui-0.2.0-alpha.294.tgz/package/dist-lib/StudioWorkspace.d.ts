import { type ReactNode } from "react";
import { type WorkspaceShellProps } from "./WorkspaceShell.js";
import "./StudioAppFrame.css";
export interface StudioWorkspaceProps extends Omit<WorkspaceShellProps, "preset" | "design"> {
    preset?: WorkspaceShellProps["preset"];
    /** Workspace selection and view-state buttons; never document/app identity. */
    workspaceControls?: ReactNode;
    /** Where the main tool bar (ribbon) sits. */
    toolPosition?: "top" | "bottom";
    /** The center icon tray at the bottom centre (tools, UI toggles, a window pop-up), shown when the tool bar is on top. */
    centerTray?: ReactNode;
}
/** Shared floating cards, matched side widths and center tool trays. */
export declare function StudioWorkspace({ preset, workspaceControls, toolPosition, toolbar, centerBottom, centerTray, ...props }: StudioWorkspaceProps): import("react").JSX.Element;
