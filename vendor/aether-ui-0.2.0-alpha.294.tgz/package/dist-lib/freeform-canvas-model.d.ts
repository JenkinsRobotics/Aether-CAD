/** Pure geometry for FreeformCanvas: camera maths, hit-testing and edits.
 * World units are canvas pixels at 100% zoom. A camera maps world → screen as
 * `screen = world * zoom + (x, y)`, so (x, y) is where the world origin sits
 * on screen. Nothing here touches the DOM. */
export interface FreeformPoint {
    x: number;
    y: number;
}
export interface FreeformRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface FreeformCamera {
    x: number;
    y: number;
    zoom: number;
}
export interface FreeformZoomLimits {
    min: number;
    max: number;
}
export type FreeformHandle = "nw" | "n" | "ne" | "e" | "se" | "s" | "sw" | "w";
/** One canvas item. Built-in kinds: rectangle, rounded-rectangle, ellipse, text,
 * sticky, pen, image, attachment, table and connector. Hosts add their own kinds
 * with a renderer and keep kind-specific state in `data`. */
export interface FreeformItem extends FreeformRect {
    id: string;
    kind: string;
    text?: string;
    /** Host colour for shapes and sticky notes; any CSS colour. */
    fill?: string;
    /** Pen stroke points, local to the item's top-left corner. */
    points?: readonly FreeformPoint[];
    /** Image or attachment URL supplied by the host. */
    src?: string;
    /** Attachment file name. */
    name?: string;
    /** Table cells, row-major. */
    cells?: readonly (readonly string[])[];
    /** Connector endpoints: ids of the items it joins. Its own rect is unused. */
    from?: string;
    to?: string;
    data?: unknown;
}
export declare const FREEFORM_ZOOM_LIMITS: FreeformZoomLimits;
export declare const FREEFORM_HANDLES: readonly FreeformHandle[];
export declare const clampZoom: (zoom: number, limits?: FreeformZoomLimits) => number;
export declare const worldToScreen: (camera: FreeformCamera, p: FreeformPoint) => FreeformPoint;
export declare const screenToWorld: (camera: FreeformCamera, p: FreeformPoint) => FreeformPoint;
export declare const panCamera: (camera: FreeformCamera, dx: number, dy: number) => FreeformCamera;
/** Zoom to `zoom` while the world point under `screen` stays under it. */
export declare function zoomCameraAt(camera: FreeformCamera, screen: FreeformPoint, zoom: number, limits?: FreeformZoomLimits): FreeformCamera;
/** Centre `bounds` in a viewport. Never zooms in past `maxZoom` (100% by default),
 * so fitting one small item does not blow it up. */
export declare function fitCamera(bounds: FreeformRect, viewport: {
    width: number;
    height: number;
}, padding?: number, limits?: FreeformZoomLimits, maxZoom?: number): FreeformCamera;
/** Screen spacing of the dot grid: world `base`, doubled until dots are at least `minimum` px apart. */
export declare function gridSpacing(zoom: number, base?: number, minimum?: number): number;
export declare const normalizeRect: (a: FreeformPoint, b: FreeformPoint) => FreeformRect;
export declare const rectsIntersect: (a: FreeformRect, b: FreeformRect) => boolean;
export declare function unionRect(rects: readonly FreeformRect[]): FreeformRect | null;
/** A connector's two ends, clipped to the edges of the items it joins; null when either is missing. */
export declare function connectorEnds(items: readonly FreeformItem[], connector: FreeformItem): [FreeformPoint, FreeformPoint] | null;
export declare const isConnector: (item: FreeformItem) => boolean;
/** The world rect an item covers; connectors cover their two ends. */
export declare function itemBounds(items: readonly FreeformItem[], item: FreeformItem): FreeformRect | null;
/** Does world point `p` touch the item? `tolerance` is in world units. */
export declare function itemContains(items: readonly FreeformItem[], item: FreeformItem, p: FreeformPoint, tolerance?: number): boolean;
/** Topmost item under `p` (later items draw on top), or null. */
export declare function hitTest(items: readonly FreeformItem[], p: FreeformPoint, tolerance?: number, include?: (item: FreeformItem) => boolean): string | null;
/** Ids of items whose bounds touch the marquee rect. */
export declare function itemsInRect(items: readonly FreeformItem[], rect: FreeformRect, include?: (item: FreeformItem) => boolean): string[];
/** Drag one of the eight handles of `rect` by (dx, dy), keeping at least `minimum` in each direction. */
export declare function resizeRect(rect: FreeformRect, handle: FreeformHandle, dx: number, dy: number, minimum?: number): FreeformRect;
/** Map the selected items from rect `from` onto rect `to`, scaling pen strokes with them. */
export declare function transformItems(items: readonly FreeformItem[], ids: ReadonlySet<string>, from: FreeformRect, to: FreeformRect): FreeformItem[];
export declare const moveItems: (items: readonly FreeformItem[], ids: ReadonlySet<string>, dx: number, dy: number) => FreeformItem[];
/** Remove items and any connector left without both ends. */
export declare function deleteItems(items: readonly FreeformItem[], ids: ReadonlySet<string>): FreeformItem[];
/** Turn absolute world stroke points into a pen item (points local to its bounds). */
export declare function penItem(id: string, stroke: readonly FreeformPoint[]): FreeformItem;
