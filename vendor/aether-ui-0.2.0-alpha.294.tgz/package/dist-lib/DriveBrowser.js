import { jsx, jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { Button } from "./Button.js";
import { IconButton } from "./IconButton.js";
import { Menu, MenuButton } from "./Menu.js";
import { NewFileDialog } from "./NewFileDialog.js";
import { PanelNotice } from "./PanelNotifications.js";
import { SelectField } from "./SelectField.js";
import "./DriveBrowser.css";
const defaultDrive = (file) => `/drive/${file ? `?file=${encodeURIComponent(file.id)}` : ""}`;
const defaultDownload = (file) => `/api/drive/download?id=${encodeURIComponent(file.id)}`;
function DriveBrowser({
  documentID,
  request,
  describe,
  app,
  onOpen,
  createItems = [],
  onCreate,
  flush,
  documentNoun = "document",
  draggable,
  onFileDragStart,
  driveURL = defaultDrive,
  downloadURL = defaultDownload
}) {
  const [context, setContext] = useState(null);
  const [place, setPlace] = useState(null);
  const [listing, setListing] = useState({ files: [], path: [] });
  const [error, setError] = useState(""), [busy, setBusy] = useState(false), [refresh, setRefresh] = useState(0);
  const [creating, setCreating] = useState(null);
  const [menu, setMenu] = useState(null);
  const serial = useRef(0);
  const create = [...createItems, { id: "folder", label: "New folder\u2026", separatorBefore: createItems.length > 0 }];
  useEffect(() => {
    let live = true;
    setBusy(true);
    setError("");
    void (async () => {
      const next = await request("context");
      const current = documentID ? await request("details", { id: documentID }) : null;
      if (!live) return;
      setContext(next);
      setPlace(current ? {
        organization: current.organization,
        workspace: current.workspace,
        parent: current.parent,
        view: current.workspace ? "workspace" : current.owner_id === next.user.id ? "personal" : "shared"
      } : { organization: next.organizations[0]?.id ?? "all", workspace: null, parent: null, view: "personal" });
    })().catch((e) => {
      if (live) {
        setError(String(e instanceof Error ? e.message : e));
        setBusy(false);
      }
    });
    return () => {
      live = false;
      serial.current++;
    };
  }, [documentID, refresh]);
  const load = async (more = false) => {
    if (!place) return;
    const id = ++serial.current;
    setBusy(true);
    setError("");
    try {
      const result = await request("list", { ...place, paged: true, limit: 100, ...more ? { after: listing.next } : {} });
      if (id === serial.current) setListing((previous) => ({ ...result, files: more ? [...previous.files, ...result.files] : result.files }));
    } catch (e) {
      if (id === serial.current) setError(String(e instanceof Error ? e.message : e));
    } finally {
      if (id === serial.current) setBusy(false);
    }
  };
  useEffect(() => {
    setListing({ files: [], path: [] });
    void load();
    return () => {
      serial.current++;
    };
  }, [place]);
  const run = async (operation) => {
    setError("");
    try {
      await operation();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  };
  const leave = async (url) => {
    await flush?.();
    location.assign(url);
  };
  const open = (file) => void run(async () => {
    if (file.kind === "folder") {
      setPlace({
        organization: file.organization,
        workspace: file.workspace,
        parent: file.id,
        view: file.workspace ? "workspace" : file.owner_id === context?.user.id ? "personal" : "shared"
      });
      return;
    }
    if (file.app === app) {
      await flush?.();
      await onOpen(file);
    } else await leave(driveURL(file));
  });
  const action = (id) => {
    const file = menu?.file;
    setMenu(null);
    if (create.some((item) => item.id === id)) setCreating(id);
    else if (id === "refresh") {
      if (place) void load();
      else setRefresh((v) => v + 1);
    } else if (id === "open" && file) open(file);
    else if (id === "drive") void run(() => leave(driveURL(file)));
    else if (id === "download" && file) {
      const a = document.createElement("a");
      a.href = downloadURL(file);
      a.download = file.name;
      a.click();
    }
  };
  const items = menu?.file ? [
    { id: "open", label: menu.file.kind === "folder" ? "Open folder" : menu.file.app === app ? `Open ${documentNoun}` : "Open in Drive" },
    { id: "drive", label: "Details and sharing in Drive\u2026" },
    ...menu.file.kind === "file" ? [{ id: "download", label: "Download", separatorBefore: true }] : []
  ] : [...create.map((item) => ({ ...item, disabled: !place || busy })), { id: "refresh", label: "Refresh", separatorBefore: true }, { id: "drive", label: "Open Aether Drive" }];
  const rootName = place?.workspace ? context?.workspaces.find((w) => w.id === place.workspace)?.name ?? "Workspace" : place?.view === "shared" ? "Shared files" : "My files";
  const files = [...listing.files].sort((a, b) => Number(b.kind === "folder") - Number(a.kind === "folder") || a.name.localeCompare(b.name));
  return /* @__PURE__ */ jsxs("section", { className: "aui-tab-browser aui-drive-browser", "aria-label": "Drive files", onContextMenu: (event) => {
    if (event.target.closest('input,select,textarea,[contenteditable],[role="menu"]')) return;
    event.preventDefault();
    event.stopPropagation();
    setMenu({ x: event.clientX, y: event.clientY });
  }, children: [
    /* @__PURE__ */ jsxs("header", { className: "aui-tab-browser-head", children: [
      /* @__PURE__ */ jsx("h2", { children: "Drive" }),
      /* @__PURE__ */ jsx(MenuButton, { label: "Create in Drive", menuClassName: "aui-collection-popup", items: create, onSelect: setCreating, disabled: !place || busy, children: /* @__PURE__ */ jsx(AetherIcon, { name: "plus" }) })
    ] }),
    context && place && /* @__PURE__ */ jsx(SelectField, { "aria-label": "Drive location", value: place.workspace ?? `personal:${place.organization}`, onChange: (event) => {
      const ws = context.workspaces.find((w) => w.id === event.target.value);
      setPlace(ws ? { organization: ws.organization, workspace: ws.id, parent: null, view: "workspace" } : { organization: event.target.value.slice("personal:".length), workspace: null, parent: null, view: "personal" });
    }, options: [
      ...context.organizations.map((org) => ({ value: `personal:${org.id}`, label: context.organizations.length > 1 ? `My files \xB7 ${org.name}` : "My files" })),
      ...context.workspaces.map((ws) => ({ value: ws.id, label: ws.name }))
    ] }),
    /* @__PURE__ */ jsxs("nav", { className: "aui-tab-browser-path", "aria-label": "Drive path", children: [
      /* @__PURE__ */ jsx("button", { "aria-label": `Back to ${rootName}`, disabled: !place?.parent, onClick: () => setPlace((p) => p && { ...p, parent: null }), children: /* @__PURE__ */ jsx(AetherIcon, { name: "home" }) }),
      /* @__PURE__ */ jsx("span", { children: rootName }),
      listing.path.map((folder) => /* @__PURE__ */ jsxs("span", { children: [
        /* @__PURE__ */ jsx(AetherIcon, { name: "chevron-right" }),
        /* @__PURE__ */ jsx("button", { onClick: () => setPlace((p) => p && { ...p, parent: folder.id }), children: folder.name })
      ] }, folder.id))
    ] }),
    /* @__PURE__ */ jsx(PanelNotice, { message: error }),
    /* @__PURE__ */ jsxs("ul", { className: "aui-tab-browser-items", children: [
      files.map((file) => {
        const info = describe(file);
        return /* @__PURE__ */ jsxs(
          "li",
          {
            "data-drive-id": file.id,
            "data-current": file.id === documentID || void 0,
            draggable: draggable?.(file) || void 0,
            onDragStart: (event) => onFileDragStart?.(event, file),
            onContextMenu: (event) => {
              event.preventDefault();
              event.stopPropagation();
              setMenu({ file, x: event.clientX, y: event.clientY });
            },
            children: [
              /* @__PURE__ */ jsxs("button", { className: "aui-tab-browser-row", title: file.name, "aria-current": file.id === documentID ? "page" : void 0, onClick: () => open(file), children: [
                /* @__PURE__ */ jsx("span", { className: "aui-tab-browser-thumb", children: info.icon }),
                /* @__PURE__ */ jsxs("span", { className: "aui-tab-browser-text", children: [
                  /* @__PURE__ */ jsx("strong", { children: file.name }),
                  /* @__PURE__ */ jsxs("small", { children: [
                    info.type,
                    file.kind === "file" ? ` \xB7 Revision ${file.revision}` : ""
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsx(IconButton, { label: `Options for ${file.name}`, onClick: (event) => {
                const r = event.currentTarget.getBoundingClientRect();
                setMenu({ file, x: r.left, y: r.bottom });
              }, children: /* @__PURE__ */ jsx(AetherIcon, { name: "more" }) })
            ]
          },
          file.id
        );
      }),
      !busy && !files.length && /* @__PURE__ */ jsx("li", { className: "aui-tab-browser-empty", children: "This folder is empty." }),
      busy && /* @__PURE__ */ jsx("li", { role: "status", children: "Loading files\u2026" }),
      listing.next && /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Button, { disabled: busy, onClick: () => void load(true), children: "Load more" }) })
    ] }),
    /* @__PURE__ */ jsx(Menu, { className: "aui-collection-popup", open: Boolean(menu), anchor: menu, ariaLabel: "Drive actions", items, onSelect: action, onClose: () => setMenu(null) }),
    creating && place && /* @__PURE__ */ jsx(
      NewFileDialog,
      {
        title: creating === "folder" ? "New Drive folder" : createItems.find((i) => i.id === creating)?.label.replace(/…$/, "") ?? `New ${documentNoun}`,
        directory: [rootName, ...listing.path.map((p) => p.name)].join(" / "),
        onClose: () => setCreating(null),
        onCreate: async (name) => {
          await flush?.();
          const destination = { organization: place.organization, workspace: place.workspace, parent: place.parent };
          if (creating === "folder") {
            await request("create", { ...destination, app: "drive", kind: "folder", name, data_base64: "" });
            await load();
          } else await onCreate?.(creating, name, destination);
        }
      }
    )
  ] });
}
export {
  DriveBrowser
};
