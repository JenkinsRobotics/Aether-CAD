import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useLayoutEffect, useRef } from "react";
import { WorkspaceShell } from "./WorkspaceShell.js";
import { FloatingToolbar } from "./FloatingToolbar.js";
import "./StudioAppFrame.css";
import { StudioDesignContext } from "./StudioDesignContext.js";
function StudioToolTray({ children, isCenterTray = false }) {
  const ref = useRef(null);
  useLayoutEffect(() => {
    const node = ref.current;
    const center = node?.closest(".aui-shell-center");
    if (!node || !center) return;
    const measure = () => center.style.setProperty("--aui-studio-tools-clearance", `${Math.max(0, center.getBoundingClientRect().bottom - node.getBoundingClientRect().top + 12)}px`);
    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(node);
    observer?.observe(center);
    return () => {
      observer?.disconnect();
      center.style.removeProperty("--aui-studio-tools-clearance");
    };
  }, []);
  useLayoutEffect(() => {
    const node = ref.current, area = node?.closest(".aui-shell-area");
    if (!node || !area) return;
    const measure = () => {
      const areaBox = area.getBoundingClientRect();
      if (isCenterTray) {
        const tray = node.querySelector(".aui-floating-toolbar") ?? node.firstElementChild;
        if (!tray) return;
        const trayBox = tray.getBoundingClientRect();
        area.style.setProperty("--aui-studio-center-tray-left", `${trayBox.left - areaBox.left}px`);
        const column = area.querySelector(":scope > .aui-shell-fledge--left");
        const cards = column ? [...column.children].filter((card) => card.getBoundingClientRect().width > 0) : [];
        const needed = column ? cards.reduce((sum, card) => sum + (parseFloat(getComputedStyle(card).minWidth) || card.getBoundingClientRect().width), 0) + Math.max(0, cards.length - 1) * (parseFloat(getComputedStyle(column).columnGap) || 0) : 0;
        if (column && column.getBoundingClientRect().left + needed > trayBox.left - 12) area.style.setProperty("--aui-studio-center-tray-lift", `${areaBox.bottom - trayBox.top + 12}px`);
        else area.style.removeProperty("--aui-studio-center-tray-lift");
        return;
      }
      const bar = node.closest(".aui-shell-fltoolbar") ? node.firstElementChild?.getBoundingClientRect() : void 0;
      const covers = bar && [...area.querySelectorAll(":scope > .aui-shell-fledge, .aui-standard-view-cube")].some((card) => {
        const box = card.getBoundingClientRect();
        return box.width > 0 && box.left < bar.right && box.right > bar.left;
      });
      if (bar && covers) area.style.setProperty("--aui-studio-toolbar-clearance", `${bar.bottom - areaBox.top + 12}px`);
      else area.style.removeProperty("--aui-studio-toolbar-clearance");
    };
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(measure);
    const observe = () => {
      observer.disconnect();
      for (const element of [node, area, node.firstElementChild, ...area.querySelectorAll(":scope > .aui-shell-fledge, :scope > .aui-shell-fledge > *, .aui-standard-view-cube")]) if (element) observer.observe(element);
    };
    observe();
    const children2 = typeof MutationObserver === "undefined" ? null : new MutationObserver(() => {
      observe();
      measure();
    });
    children2?.observe(area, { childList: true });
    for (const element of area.querySelectorAll(":scope > .aui-shell-fledge, .aui-shell-center-slot")) children2?.observe(element, { childList: true });
    return () => {
      observer.disconnect();
      children2?.disconnect();
      for (const name of isCenterTray ? ["--aui-studio-center-tray-left", "--aui-studio-center-tray-lift"] : ["--aui-studio-toolbar-clearance"]) area.style.removeProperty(name);
    };
  }, [isCenterTray]);
  return /* @__PURE__ */ jsx("div", { ref, className: "aui-studio-tool-tray", children });
}
function StudioWorkspace({ preset = "floating", workspaceControls, toolPosition = "bottom", toolbar, centerBottom, centerTray, ...props }) {
  const tools = toolbar ? /* @__PURE__ */ jsx(StudioToolTray, { children: toolbar }) : null;
  const auxTools = centerTray && toolPosition === "top" ? /* @__PURE__ */ jsx(StudioToolTray, { isCenterTray: true, children: /* @__PURE__ */ jsx("div", { className: "aui-studio-center-tray", children: centerTray }) }) : null;
  return /* @__PURE__ */ jsx(StudioDesignContext.Provider, { value: true, children: /* @__PURE__ */ jsx(
    WorkspaceShell,
    {
      ...props,
      design: "studio",
      preset,
      sidebarSizing: props.sidebarSizing ?? { width: 216, minWidth: 180, maxWidth: 520, minCenterWidth: 240 },
      inheritChromePreferences: false,
      sidebarAttachment: "detached",
      frameToolbar: false,
      toolbar: workspaceControls || toolPosition === "top" && tools ? /* @__PURE__ */ jsxs("div", { className: "aui-studio-workspace-tools", children: [
        workspaceControls && /* @__PURE__ */ jsx(FloatingToolbar, { variant: "document", ariaLabel: "Workspace controls", groups: [], onAction: () => {
        }, leading: workspaceControls }),
        toolPosition === "top" && tools
      ] }) : void 0,
      centerBottom: centerBottom || toolPosition === "bottom" && tools || auxTools ? /* @__PURE__ */ jsxs(Fragment, { children: [
        centerBottom,
        toolPosition === "bottom" ? tools : auxTools
      ] }) : void 0
    }
  ) });
}
export {
  StudioWorkspace
};
