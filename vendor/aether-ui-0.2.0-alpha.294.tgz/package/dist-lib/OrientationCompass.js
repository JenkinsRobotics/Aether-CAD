import { jsx, jsxs } from "react/jsx-runtime";
import { rotateIntoCamera } from "./ViewportNavigationCube.js";
import { viewportCubeAxes, viewportCubeAxisOrigin, viewportCubeProjection } from "./viewport-cube-geometry.js";
import "./OrientationCompass.css";
const CORNERS = [[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1], [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]];
const FACES = [
  { corners: [4, 5, 6, 7], normal: [0, 0, 1] },
  { corners: [1, 0, 3, 2], normal: [0, 0, -1] },
  { corners: [5, 1, 2, 6], normal: [1, 0, 0] },
  { corners: [0, 4, 7, 3], normal: [-1, 0, 0] },
  { corners: [7, 6, 2, 3], normal: [0, 1, 0] },
  { corners: [0, 1, 5, 4], normal: [0, -1, 0] }
];
function OrientationCompass({ orientation, size = 40 }) {
  const k = size / viewportCubeProjection.size, c = size / 2, s = viewportCubeProjection.scale * k;
  const point = (v) => {
    const [x, y] = rotateIntoCamera(v, orientation);
    return [c + x * s, c - y * s];
  };
  const corners = CORNERS.map(point);
  const faces = FACES.filter((face) => rotateIntoCamera(face.normal, orientation)[2] > 0.01);
  const [ox, oy] = point(viewportCubeAxisOrigin);
  return /* @__PURE__ */ jsxs("svg", { className: "aui-orientation-compass", width: size, height: size, viewBox: `0 0 ${size} ${size}`, "aria-hidden": "true", children: [
    faces.map((face, i) => /* @__PURE__ */ jsx("polygon", { className: "aui-orientation-compass-face", points: face.corners.map((n) => corners[n].join(",")).join(" ") }, i)),
    viewportCubeAxes.map((axis) => {
      const [x, y] = point(axis.end);
      return /* @__PURE__ */ jsx("line", { className: `aui-orientation-compass-axis-${axis.id}`, x1: ox, y1: oy, x2: x, y2: y }, axis.id);
    })
  ] });
}
export {
  OrientationCompass
};
