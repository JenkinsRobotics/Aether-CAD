import { jsx, jsxs } from "react/jsx-runtime";
import { useRef } from "react";
import "./ColorWheel.css";
function hexToHsv(hex) {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255);
  const max = Math.max(r, g, b), d = max - Math.min(r, g, b);
  const h = d === 0 ? 0 : max === r ? ((g - b) / d + 6) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return { h: h / 6, s: max === 0 ? 0 : d / max, v: max };
}
function hsvToHex({ h, s, v }) {
  const f = (n) => {
    const k = (n + h * 6) % 6;
    return v - v * s * Math.max(0, Math.min(k, 4 - k, 1));
  };
  return "#" + [f(5), f(3), f(1)].map((c) => Math.round(c * 255).toString(16).padStart(2, "0")).join("");
}
function ColorWheel({ value, onChange, ariaLabel, disabled = false, size = 176, className }) {
  const hsv = hexToHsv(/^#[0-9a-f]{6}$/i.test(value) ? value : "#000000"), wheel = useRef(null), strip = useRef(null);
  const pick = (e, part) => {
    if (disabled || e.type === "pointermove" && !e.buttons) return;
    if (e.type === "pointerdown") e.currentTarget.setPointerCapture?.(e.pointerId);
    const box = (part === "wheel" ? wheel : strip).current.getBoundingClientRect();
    if (part === "strip") {
      onChange(hsvToHex({ ...hsv, v: Math.min(1, Math.max(0, 1 - (e.clientY - box.top) / box.height)) }));
      return;
    }
    const x = e.clientX - box.left - box.width / 2, y = e.clientY - box.top - box.height / 2;
    onChange(hsvToHex({ h: (Math.atan2(y, x) / (Math.PI * 2) + 1) % 1, s: Math.min(1, Math.hypot(x, y) / (box.width / 2)), v: hsv.v || 1 }));
  };
  const key = (e, part) => {
    const step = e.shiftKey ? 0.1 : 0.02, d = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1 }[e.key];
    if (disabled || d === void 0) return;
    e.preventDefault();
    if (part === "strip") onChange(hsvToHex({ ...hsv, v: Math.min(1, Math.max(0, hsv.v + d * step)) }));
    else if (e.key === "ArrowLeft" || e.key === "ArrowRight") onChange(hsvToHex({ ...hsv, h: (hsv.h + d * step + 1) % 1 }));
    else onChange(hsvToHex({ ...hsv, s: Math.min(1, Math.max(0, hsv.s + d * step)) }));
  };
  const angle = hsv.h * Math.PI * 2, r = hsv.s * size / 2;
  return /* @__PURE__ */ jsxs("div", { className: ["aui-color-wheel", className].filter(Boolean).join(" "), "data-disabled": disabled || void 0, role: "group", "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: wheel,
        className: "aui-color-wheel-disc",
        style: { width: size, height: size, ["--aui-wheel-dim"]: String(1 - hsv.v) },
        role: "slider",
        tabIndex: disabled ? -1 : 0,
        "aria-label": `${ariaLabel} hue and saturation`,
        "aria-valuetext": `Hue ${Math.round(hsv.h * 360)}\xB0, saturation ${Math.round(hsv.s * 100)}%`,
        onPointerDown: (e) => pick(e, "wheel"),
        onPointerMove: (e) => pick(e, "wheel"),
        onKeyDown: (e) => key(e, "wheel"),
        children: /* @__PURE__ */ jsx("span", { className: "aui-color-wheel-mark", style: { left: size / 2 + Math.cos(angle) * r, top: size / 2 + Math.sin(angle) * r, background: value } })
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: strip,
        className: "aui-color-wheel-strip",
        style: { height: size, background: `linear-gradient(${hsvToHex({ ...hsv, v: 1 })}, #000)` },
        role: "slider",
        tabIndex: disabled ? -1 : 0,
        "aria-label": `${ariaLabel} brightness`,
        "aria-valuemin": 0,
        "aria-valuemax": 100,
        "aria-valuenow": Math.round(hsv.v * 100),
        onPointerDown: (e) => pick(e, "strip"),
        onPointerMove: (e) => pick(e, "strip"),
        onKeyDown: (e) => key(e, "strip"),
        children: /* @__PURE__ */ jsx("span", { className: "aui-color-wheel-level", style: { top: (1 - hsv.v) * size } })
      }
    )
  ] });
}
function SwatchPalette({ swatches, current, onPick, onStore, ariaLabel, className }) {
  return /* @__PURE__ */ jsx("div", { className: ["aui-swatch-palette", className].filter(Boolean).join(" "), role: "group", "aria-label": ariaLabel, children: swatches.map((hex, i) => hex ? /* @__PURE__ */ jsx("button", { type: "button", className: "aui-swatch", style: { background: hex }, "aria-label": hex, "aria-pressed": current?.toLowerCase() === hex.toLowerCase(), onClick: () => onPick(hex) }, i) : /* @__PURE__ */ jsx("button", { type: "button", className: "aui-swatch aui-swatch--empty", "aria-label": "Save current colour", disabled: !onStore, onClick: () => onStore?.(i) }, i)) });
}
export {
  ColorWheel,
  SwatchPalette,
  hexToHsv,
  hsvToHex
};
