import "./ColorWheel.css";
/** HSV in 0–1 (hue 0–1 around the wheel). */
export interface HSV {
    h: number;
    s: number;
    v: number;
}
export declare function hexToHsv(hex: string): HSV;
export declare function hsvToHex({ h, s, v }: HSV): string;
export interface ColorWheelProps {
    value: string;
    onChange: (hex: string) => void;
    ariaLabel: string;
    disabled?: boolean;
    /** Diameter in px. */
    size?: number;
    className?: string;
}
/** A hue/saturation wheel with a brightness strip, the colour picker painting apps use. Arrow keys step hue and saturation. */
export declare function ColorWheel({ value, onChange, ariaLabel, disabled, size, className }: ColorWheelProps): import("react").JSX.Element;
export interface SwatchPaletteProps {
    /** Saved colours; `null` is an empty slot that stores the current colour when clicked. */
    swatches: readonly (string | null)[];
    current?: string;
    onPick: (hex: string) => void;
    onStore?: (index: number) => void;
    ariaLabel: string;
    className?: string;
}
/** A grid of colour swatches with empty slots to save into, like a painting app's palette. */
export declare function SwatchPalette({ swatches, current, onPick, onStore, ariaLabel, className }: SwatchPaletteProps): import("react").JSX.Element;
