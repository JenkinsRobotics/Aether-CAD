import { type ReactNode } from "react";
import "./StudioAppFrame.css";
import "./StudioCameraControl.css";
/** One expanding camera surface; products supply their real navigation. */
/** `compass` (an OrientationCompass fed the cube's orientation) is the collapsed state: the cube
 * shrunk to its live axes, no caption. Clicking it opens the full cube; nothing else. */
export declare function StudioCameraControl({ projection, children, expanded, onExpandedChange, compass }: {
    projection?: string;
    children: ReactNode;
    expanded?: boolean;
    onExpandedChange?: (open: boolean) => void;
    compass?: ReactNode;
}): import("react").JSX.Element;
