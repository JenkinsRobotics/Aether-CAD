import { type DragEvent, type ReactNode } from 'react';
import { type MenuItem } from './Menu.js';
import './DriveBrowser.css';
/** The fields of a Studio Drive entry this browser reads (a subset of @aether/session's DriveFile). */
export interface DriveBrowserFile {
    id: string;
    name: string;
    kind: 'file' | 'folder';
    app: string;
    organization: string;
    workspace: string | null;
    owner_id: string;
    revision: number;
}
export interface DriveBrowserContext {
    organizations: readonly {
        id: string;
        name: string;
    }[];
    workspaces: readonly {
        id: string;
        organization: string;
        name: string;
    }[];
    user: {
        id: string;
    };
}
export interface DriveBrowserPlace {
    organization: string;
    workspace: string | null;
    parent: string | null;
    view: 'personal' | 'workspace' | 'shared';
}
export type DriveDestination = Pick<DriveBrowserPlace, 'organization' | 'workspace' | 'parent'>;
export interface DriveBrowserProps {
    /** The open document's Drive id; the browser starts in its folder and marks it current. */
    documentID: string | null;
    /** Studio's Drive request (`driveRequest` from @aether/session/library/drive-api). The UI itself performs no network calls. */
    request: <T>(operation: string, body?: object) => Promise<T>;
    /** Icon and type line for a row (from the session's `fileIcon`/`fileType`). */
    describe: (file: DriveBrowserFile) => {
        icon: ReactNode;
        type: string;
    };
    /** The app's own documents. Opening anything else goes to Drive. */
    app: string;
    /** Called with an app file the person opens; the app saves and navigates. */
    onOpen: (file: DriveBrowserFile) => void | Promise<void>;
    /** What the app can create here, besides folders; `onCreate` makes it and usually opens it. */
    createItems?: readonly MenuItem[];
    onCreate?: (kind: string, name: string, destination: DriveDestination) => Promise<void>;
    /** Saves pending edits before leaving the page. */
    flush?: () => Promise<void>;
    /** Noun for the app's documents in menus: "design", "drawing", "show". */
    documentNoun?: string;
    draggable?: (file: DriveBrowserFile) => boolean;
    onFileDragStart?: (event: DragEvent<HTMLLIElement>, file: DriveBrowserFile) => void;
    /** Studio routes; defaults match the installed Drive. */
    driveURL?: (file?: DriveBrowserFile) => string;
    downloadURL?: (file: DriveBrowserFile) => string;
}
/** The Drive half of the standard Files panel: location, path, folders first, open in the app or in Drive. */
export declare function DriveBrowser({ documentID, request, describe, app, onOpen, createItems, onCreate, flush, documentNoun, draggable, onFileDragStart, driveURL, downloadURL }: DriveBrowserProps): import("react").JSX.Element;
