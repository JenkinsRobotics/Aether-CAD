import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { AetherIcon } from "./AetherIcon.js";
import { CollectionView } from "./CollectionView.js";
import { IconButton } from "./IconButton.js";
import "./LayerStack.css";
function LayerStack({ title = "Layers", ariaLabel, layers, selectedID, onSelect, onToggleVisible, onToggleLock, onMove, controls, footer, className }) {
  const [drag, setDrag] = useState(null), [over, setOver] = useState(null);
  const position = (e) => {
    const box = e.currentTarget.getBoundingClientRect();
    return e.clientY < box.top + box.height / 2 ? "before" : "after";
  };
  return /* @__PURE__ */ jsx(CollectionView, { title, controls, showFooter: false, footer, className: ["aui-layer-stack", className].filter(Boolean).join(" "), children: /* @__PURE__ */ jsx("ul", { className: "aui-layer-stack-list", role: "listbox", "aria-label": ariaLabel, children: layers.map((layer) => /* @__PURE__ */ jsxs(
    "li",
    {
      role: "option",
      "aria-selected": layer.id === selectedID,
      tabIndex: layer.id === selectedID ? 0 : -1,
      className: "aui-layer-stack-row",
      "data-hidden": !layer.visible || void 0,
      "data-drop": over?.id === layer.id ? over.position : void 0,
      draggable: !!onMove,
      onClick: () => onSelect(layer.id),
      onKeyDown: (e) => {
        const i = layers.findIndex((l) => l.id === layer.id), next = e.key === "ArrowDown" ? layers[i + 1] : e.key === "ArrowUp" ? layers[i - 1] : void 0;
        if (next) {
          e.preventDefault();
          onSelect(next.id);
          e.currentTarget.parentElement?.children[layers.indexOf(next)]?.focus();
        }
      },
      onDragStart: (e) => {
        setDrag(layer.id);
        e.dataTransfer.effectAllowed = "move";
      },
      onDragOver: (e) => {
        if (!drag || drag === layer.id) return;
        e.preventDefault();
        setOver({ id: layer.id, position: position(e) });
      },
      onDragLeave: () => setOver((o) => o?.id === layer.id ? null : o),
      onDrop: (e) => {
        e.preventDefault();
        if (drag && drag !== layer.id) onMove?.(drag, layer.id, position(e));
        setDrag(null);
        setOver(null);
      },
      onDragEnd: () => {
        setDrag(null);
        setOver(null);
      },
      children: [
        /* @__PURE__ */ jsxs("span", { className: "aui-layer-stack-flags", children: [
          /* @__PURE__ */ jsx(IconButton, { label: `${layer.visible ? "Hide" : "Show"} ${layer.label}`, onClick: (e) => {
            e.stopPropagation();
            onToggleVisible(layer.id);
          }, children: /* @__PURE__ */ jsx(AetherIcon, { name: layer.visible ? "visible" : "hidden" }) }),
          onToggleLock && /* @__PURE__ */ jsx(IconButton, { label: `${layer.locked ? "Unlock" : "Lock"} ${layer.label}`, onClick: (e) => {
            e.stopPropagation();
            onToggleLock(layer.id);
          }, children: /* @__PURE__ */ jsx(AetherIcon, { name: layer.locked ? "lock" : "unlock" }) })
        ] }),
        /* @__PURE__ */ jsx("span", { className: "aui-layer-stack-preview", "aria-hidden": "true", children: layer.thumbnail }),
        /* @__PURE__ */ jsxs("span", { className: "aui-layer-stack-text", children: [
          /* @__PURE__ */ jsx("span", { className: "aui-layer-stack-name", children: layer.label }),
          layer.detail && /* @__PURE__ */ jsx("span", { className: "aui-layer-stack-detail", children: layer.detail })
        ] })
      ]
    },
    layer.id
  )) }) });
}
export {
  LayerStack
};
