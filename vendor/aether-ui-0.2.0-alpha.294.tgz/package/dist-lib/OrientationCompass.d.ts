import { type ViewportOrientation } from "./ViewportNavigationCube.js";
import "./OrientationCompass.css";
export interface OrientationCompassProps {
    /** The same orientation the view cube shows. */
    orientation: ViewportOrientation;
    size?: number;
}
/** The collapsed view cube: the same cube, small, turning with the camera. Purely a picture;
 * StudioCameraControl makes it the button that opens the full cube. */
export declare function OrientationCompass({ orientation, size }: OrientationCompassProps): import("react").JSX.Element;
