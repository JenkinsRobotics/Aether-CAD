import { type ReactNode } from "react";
import { type CollectionControl } from "./CollectionView.js";
import "./LayerStack.css";
export interface LayerStackItem {
    id: string;
    label: string;
    /** A small picture of the layer, e.g. an SVG of its content. */
    thumbnail: ReactNode;
    visible: boolean;
    locked?: boolean;
    /** Secondary text such as "Multiply · 60%". */
    detail?: string;
}
export interface LayerStackProps {
    title?: string;
    ariaLabel: string;
    /** Top of the stack first. */
    layers: readonly LayerStackItem[];
    selectedID?: string;
    onSelect: (id: string) => void;
    onToggleVisible: (id: string) => void;
    onToggleLock?: (id: string) => void;
    /** Drag to reorder: drop `source` before or after `target`. */
    onMove?: (source: string, target: string, position: "before" | "after") => void;
    controls?: readonly CollectionControl[];
    /** Footer content, e.g. a switch back to a compact tree. */
    footer?: ReactNode;
    className?: string;
}
/** Layers with large previews, the way painting apps show them: eye, lock, preview, name and blend. */
export declare function LayerStack({ title, ariaLabel, layers, selectedID, onSelect, onToggleVisible, onToggleLock, onMove, controls, footer, className }: LayerStackProps): import("react").JSX.Element;
